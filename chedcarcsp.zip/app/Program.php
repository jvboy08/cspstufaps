<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Program extends Model
{
    protected $guarded = [];

	public function awards() {
		return $this->hasMany(Award::class);
	}

	public function billing_statements() {
		return $this->hasMany(BillingStatement::class);
	}
}

?>