<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Award extends Model
{
    protected $guarded = [];

    public function program() {
		return $this->belongsTo(Program::class);
	}

    public function getAcademicYearAttribute() {
    	$next_year = $this->award_year + 1;
    	return $this->award_year.' - '.$next_year;
    }
}

?>