<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Institution extends Model
{
    protected $guarded = [];

	public function courses() {
		return $this->hasMany(Course::class);
	}

	public function updates() {
		return $this->hasMany(Update::class);
	}

    public function getFullSectorAttribute() {
		if($this->sector === 'P') {
			return 'Private';
		} else if ($this->sector === 'SUC') {
			return 'State Universities and Colleges';
		} else if ($this->sector === 'LUC') {
			return 'Local Universities and Colleges';
		} else {
			return 'Other Government Schools';
		}
    }

    public function getAlternateFullSectorAttribute() {
		if($this->sector === 'P') {
			return 'Private';
		} else if ($this->sector === 'SUC') {
			return 'State Universities and Colleges';
		} else if ($this->sector === 'LUC') {
			return 'Public Universities and Colleges';
		} else {
			return 'Other Govt. Schools';
		}
    }
}

?>