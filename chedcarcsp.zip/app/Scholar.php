<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Scholar extends Model
{
    protected $guarded = [];

    public function award() {
        return $this->belongsTo(Award::class);
    }
    
    public function applicant() {
        return $this->belongsTo(Applicant::class);
    }

    public function semestral_awards() {
        return $this->hasMany(SemestralAward::class);
    }

    public function user() {
        return $this->hasOne(User::class);
    }

    public function getFullYearLevelAcceptedAttribute() {
        if($this->year_level_accepted == 1) {
            return '1st Year';
        } else if($this->year_level_accepted == 2) {
            return '2nd Year';
        } else if($this->year_level_accepted == 3) {
            return '3rd Year';
        } else if($this->year_level_accepted == 4) {
            return '4th Year';
        } else if($this->year_level_accepted == 5) {
            return '5th Year';
        } else if($this->year_level_accepted == 6) {
            return '6th Year';
        } 
    }

    public function getFullLatestYearLevelAttribute() {
        if($this->latest_year_level == 1) {
            return '1st Year';
        } else if($this->latest_year_level == 2) {
            return '2nd Year';
        } else if($this->latest_year_level == 3) {
            return '3rd Year';
        } else if($this->latest_year_level == 4) {
            return '4th Year';
        } else if($this->latest_year_level == 5) {
            return '5th Year';
        } else if($this->latest_year_level == 6) {
            return '6th Year';
        } 
    }
}

?>