<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Scholar;
use App\SemestralAward;
use App\Applicant;
use App\User;
use Storage;
use Auth;

class StudentsController extends Controller
{
    public function login() {
    	return view('students.login');
    }

    public function sign_up() {
    	return view('students.sign_up');
    }

    public function index() {
    	$scholar = Scholar::find(auth()->user()->scholar_id);
    	$semestral_awards = SemestralAward::where('scholar_id', $scholar->id)
            ->where('status', '!=', null)
    		->orderBy('acad_year', 'ASC')
    		->orderBy('semester', 'ASC')->get();

        $unchecked_semestral_award = SemestralAward::where('scholar_id', $scholar->id)
            ->where('status', null)->where('enrollment_form', '!=', null)->first();

        $sum = 0;

        foreach($semestral_awards as $semestral_award) {
            if($semestral_award->amount_chedro != null) {
                $sum+=$semestral_award->amount_chedro;
            }
        }
    	return view('students.index', compact('scholar', 'semestral_awards', 'unchecked_semestral_award', 'sum'));
    }

    public function edit(Scholar $scholar)
    {
        return view('students.edit', compact('scholar'));
    }

    public function update(Scholar $scholar)
    {

        $applicant_details = [

        ////////// GENERAL INFORMATION

            // CONTACT DETAILS
            'contact_number' => request()->contact_number == null ? null : preg_replace("/[^0-9]/", '', trim(request()->contact_number)),
            'fb_account' => request()->fb_account == null ? null : trim(request()->fb_account),

        ////////// ADDRESS INFORMATION

            // PERMANENT ADDRESS
            'perm_district' => trim(request()->filled('perm_add_is_car') ? request()->perm_district : request()->perm_district2),
            'perm_province' => trim(request()->filled('perm_add_is_car') ? request()->perm_province : request()->perm_province2),
            'perm_muni_city' => trim(request()->filled('perm_add_is_car') ? request()->perm_muni_city : request()->perm_muni_city2),
            'perm_barangay' => trim(request()->perm_barangay),
            'perm_zip_code' => trim(request()->perm_zip_code),

            // PRESENT ADDRESS
            'pres_is_perm' => request()->filled('pres_is_perm') ? 1 : 0,
            'pres_district' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_district : request()->pres_district2),
            'pres_province' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_province : request()->pres_province2),
            'pres_muni_city' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_muni_city : request()->pres_muni_city2),
            'pres_barangay' => request()->filled('pres_is_perm') ? null : trim(request()->pres_barangay),
            'pres_zip_code' => request()->filled('pres_is_perm') ? null : request()->pres_zip_code
        ];

        Applicant::find($scholar->applicant_id)->update($applicant_details); 

        $scholar->update([
            'latest_year_level' => request()->latest_year_level
        ]);


        return redirect('/scholar/home');
    }

    // PAYMENT REQUIREMENTS

    public function store_requirement(Scholar $scholar)
    {
        if(request()->has('school_id')) {
            $school_id_path = Storage::disk('s3')->url(request()->file('school_id')->store('documents', 's3'));
            $atm_card_path = Storage::disk('s3')->url(request()->file('atm_card')->store('documents', 's3'));

            $scholar->update([
                'school_id' => $school_id_path,
                'atm_card' => $atm_card_path,
            ]);
        } else {
            $enrollment_form_path = Storage::disk('s3')->url(request()->file('enrollment_form')->store('documents', 's3'));
            $previous_grades_path = Storage::disk('s3')->url(request()->file('previous_grades')->store('documents', 's3'));
            $acad_year = 0;
            $semester = 0;

            if($scholar->latest_semester == 1) {
                $acad_year = $scholar->latest_acad_year;
                $semester = 2;
            } else {
                $acad_year = $scholar->latest_acad_year + 1;
                $semester = 1;
            }

            SemestralAward::create([
                'scholar_id' => $scholar->id,
                'acad_year' => $acad_year,
                'semester' => $semester,
                'enrollment_form' => $enrollment_form_path,
                'previous_grades' => $previous_grades_path
            ]);
        }
        
        return redirect('/scholar/home');
    }

    public function edit_requirement()
    {
        $id = request()->id;
        $document = request()->document;
        return view('students.edit_requirement', compact('id', 'document'));
    }

    public function update_requirement()
    {
        $document = request()->document;
        if($document == 'school_id' || $document == 'atm_card') {
            $scholar = Scholar::find(request()->id);
            $index = strpos($scholar->$document, 'documents/');
            Storage::disk('s3')->delete(substr($scholar->$document, $index, strlen($scholar->$document) - $index));
            $path = Storage::disk('s3')->url(request()->file('file')->store('documents', 's3'));
            $scholar->update([$document => $path]); 
        } else {
            $semestral_award = SemestralAward::find(request()->id);
            $index = strpos($semestral_award->$document, 'documents/');
            Storage::disk('s3')->delete(substr($semestral_award->$document, $index, strlen($semestral_award->$document) - $index));
            $path = Storage::disk('s3')->url(request()->file('file')->store('documents', 's3'));
            $semestral_award->update([$document => $path]); 
        }

        return redirect('/scholar/home');
    }

    public function update_is_thru_hei(Scholar $scholar)
    {
        $scholar->update(['is_thru_hei' => 1]);
        return redirect('/scholar/home');
    }

    // FINANCIAL BENEFITS

    public function update_is_payment_received(SemestralAward $semestral_award)
    {
        $semestral_award->update(['is_payment_received' => request()->value]);
        return request()->value;
    }

    // CHANGE PASSWORD

    public function edit_password()
    {
        return view('students.edit_password');
    }

    public function update_password()
    {
        $validated_fields = request()->validate([ 
            'email' => 'required|email',
            'old_password' => 'required',
            'new_password' => 'required|min:8',
            'confirm_password' => 'required|same:new_password'
        ]);

        if(Auth::attempt(['email' => $validated_fields['email'], 'password' => $validated_fields['old_password']])) { 
                User::find(Auth::id())->update(['password' => bcrypt(request()->new_password)]);
                Auth::logout();
                return redirect('/scholar/login');
        } else {
            return back()->withErrors([
                'credentials' => 'Incorrect email or password'
            ]);
        }
    }
}
