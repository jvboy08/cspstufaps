<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Scholar;
use App\Course;
use App\Institution;
use App\Award;
use App\Program;
use App\SemestralAward;
use App\Applicant;
use App\User;

class ScholarsController extends Controller
{
    public function index() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();
        $query = Scholar::query()->where('latest_status', '!=', null)
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // ACADEMIC PERIOD
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('scholars.latest_acad_year', $period[0]);
            $query->where('scholars.latest_semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // ACADEMIC PERIOD
        if(request()->filled('started')) {
            $started = explode(',', request()->started);
            $query->where('scholars.acad_year_accepted', $started[0]);
            $query->where('scholars.semester_accepted', $started[1]);
            $sort_filters['started'] = request()->started;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            if(request()->institution == 'outside_car') {
                $query->where('applicants.institution_id', null);
            } else {
                $query->where('applicants.institution_id', request()->institution);
            }
            $sort_filters['institution'] = request()->institution;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // STATUS
        if(request()->filled('status')) {
            $query->where('scholars.latest_status', request()->status);
            $sort_filters['status'] = request()->status;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else {
                $query->orderBy('programs.code', 'ASC')->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
            } 
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('programs.code', 'ASC')->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $scholars = $query->select('scholars.*', 'scholars.id as scholar_id', 'awards.*', 'programs.*', 'applicants.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $scholars = $query->select('scholars.*', 'scholars.id as scholar_id', 'awards.*', 'programs.*', 'applicants.*')->paginate(10);
        }

        return view('scholars.index', compact('scholars', 'institutions', 'programs', 'sort_filters'));
    }

    public function show(Scholar $scholar)
    {
        $semestral_awards = SemestralAward::where('scholar_id', $scholar->id)
            ->where('status', '!=', null)
            ->orderBy('acad_year', 'ASC')
            ->orderBy('semester', 'ASC')
            ->get();

        $sum = 0;

        foreach($semestral_awards as $semestral_award) {
            if($semestral_award->amount_chedro != null) {
                $sum+=$semestral_award->amount_chedro;
            }
        }

        $unreviewed_semestral_awards = SemestralAward::where('scholar_id', $scholar->id)
            ->where('status', null)
            ->orderBy('acad_year', 'ASC')
            ->orderBy('semester', 'ASC')
            ->get();

        if($scholar->semester_accepted == 1) {
            $replaced = Scholar::where('award_number', $scholar->award_number)
                ->where('acad_year_accepted', '<', $scholar->acad_year_accepted)
                ->orderBy('acad_year_accepted', 'DESC')
                ->orderBy('semester_accepted', 'DESC')
                ->first();

            $replaced_by = Scholar::where(function($query) use ($scholar) {
                    $query->where('award_number', $scholar->award_number);
                    $query->where('acad_year_accepted', '>', $scholar->acad_year_accepted);
                })
                ->orWhere(function($query) use ($scholar) {
                    $query->where('award_number', $scholar->award_number);
                    $query->where('acad_year_accepted', $scholar->acad_year_accepted);
                    $query->where('semester_accepted', 2);
                })
                ->orderBy('acad_year_accepted', 'ASC')
                ->orderBy('semester_accepted', 'ASC')
                ->first(); 
        } else {
            $replaced = Scholar::where(function($query) use ($scholar) {
                    $query->where('award_number', $scholar->award_number);
                    $query->where('acad_year_accepted', '<', $scholar->acad_year_accepted);
                })
                ->orWhere(function($query) use ($scholar) {
                    $query->where('award_number', $scholar->award_number);
                    $query->where('acad_year_accepted', $scholar->acad_year_accepted);
                    $query->where('semester_accepted', 1);
                })
                ->orderBy('acad_year_accepted', 'DESC')
                ->orderBy('semester_accepted', 'DESC')
                ->first();

            $replaced_by = Scholar::where('award_number', $scholar->award_number)
                ->where('acad_year_accepted', '>', $scholar->acad_year_accepted)
                ->orderBy('acad_year_accepted', 'ASC')
                ->orderBy('semester_accepted', 'ASC')
                ->first();
        }

        $is_registered = User::where('scholar_id', $scholar->id)->count() == 1 ? 1 : 0;
        return view('scholars.show', compact('scholar', 'semestral_awards', 'sum', 'replaced', 'replaced_by', 'unreviewed_semestral_awards', 'is_registered'));
    }

    public function getCourses($id) {
        $states = Course::where("institution_id", $id)
            ->orderBy('course_name', 'ASC')
            ->pluck("course_name", "id");
        return json_encode($states);
    }

    public function edit(Applicant $applicant)
    {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $courses = Course::orderBy('course_name', 'ASC')->get();
        return view('scholars.edit', compact('institutions', 'applicant', 'courses'));
    }

    public function update(Applicant $applicant)
    {
        $validated_fields = request()->validate([
            'name_first' => 'required',
            'name_last' => 'required',
            'birthday' => 'required',
            'sex' => 'required',

            'email_address' => 'required|unique:applicants,email_address,'.$applicant->id,
            'contact_number' => 'required',

            'course_id' => 'required',
            'institution_id' => 'required',

            'has_graduated' => 'required',
            'twelve_gwa' => 'required',
            'annual_gross_income' => 'required',

            'barangay' => 'required',
            'muni_city' => 'required',
            'province' => 'required',
            'district' => 'required',
            'zip_code' => 'required',

            'are_documents_validated' => 'required'
        ]);

        $validated_fields['name_middle'] = request()->name_middle == null ? null : request()->name_middle;
        $validated_fields['name_ext'] = request()->name_ext == null ? null : request()->name_ext;

        if(request()->special_grp != null) {
            $validated_fields['special_grp'] = request()->special_grp;
            if(request()->special_grp == 'IP' || request()->special_grp == 'PWD') {
                $validated_fields['special_grp_type'] = request()->special_grp_type;
            } else {
                $validated_fields['special_grp_type'] = null;
            }
        } else {
            $validated_fields['special_grp'] = null;
            $validated_fields['special_grp_type'] = null;
        }

        $score = 0;
        $gwa = 0;
        
        $validated_fields['twelve_gwa'] = request()->twelve_gwa;
        if(request()->has_graduated) {
            $validated_fields['eleven_gwa'] = null;
            $gwa = request()->twelve_gwa;
        } else {
            $validated_fields['eleven_gwa'] = request()->eleven_gwa;
            $gwa = (request()->twelve_gwa + request()->eleven_gwa) / 2;
        }

        if($gwa >= 99) {
            $score += (100 * 0.7);
        } else if($gwa >= 97) {
            $score += (95 * 0.7);
        } else if($gwa >= 95) {
            $score += (90 * 0.7);
        } else if($gwa >= 93) {
            $score += (85 * 0.7);
        } else if($gwa >= 91) {
            $score += (80 * 0.7);
        } else {
            $score += (75 * 0.7);
        }

        if(request()->annual_gross_income <= 70000) {
            $score += (100 * 0.3);
        } else if(request()->annual_gross_income <= 136000) {
            $score += (95 * 0.3);
        } else if(request()->annual_gross_income <= 202000) {
            $score += (90 * 0.3);
        } else if(request()->annual_gross_income <= 268000) {
            $score += (85 * 0.3);
        } else if(request()->annual_gross_income <= 334000) {
            $score += (80 * 0.3);
        } else {
            $score += (75 * 0.3);
        }

        if(request()->special_grp != null) {
            $score += 5;
        }

        $validated_fields['score'] = $score > 100 ? 100 : $score;

        $applicant->update($validated_fields); 
        return redirect('/scholars/'.$applicant->scholar->id);
    }

    public function delete(Scholar $scholar)
    {
        $semestral_awards = SemestralAward::where('scholar_id', $scholar->id)->get();
        foreach ($semestral_awards as $semestral_award){ 
            $semestral_award->delete();
        }
        $scholar->delete();
        return redirect('/scholars/awarded');
    }
}
