<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Program;

class ProgramsController extends Controller
{
    public function index() {
        $programs = Program::orderBy('program_name', 'ASC')->paginate(10);
        return view('programs.index', compact('programs'));
    }

    public function create()
    {
        return view('programs.create');
    }

    public function store()
    {
        $validated_fields = request()->validate([
            'program_name' => 'required',
            'code' => 'required|unique:programs,code',
            'amount_per_sem' => 'required',
            'reference_cmo' => 'required'
        ]);
        Program::create($validated_fields); 
        return redirect('/programs');
    }

    public function edit(Program $program)
    {
        return view('programs.edit', compact('program'));
    }

    public function update(Program $program)
    {
        $validated_fields = request()->validate([
            'program_name' => 'required',
            'code' => 'required|unique:programs,code,'.$program->id,
            'amount_per_sem' => 'required',
            'reference_cmo' => 'required'
        ]);
        $program->update($validated_fields);
        return redirect('/programs');
    }

    public function delete(Program $program)
    {
        $program->delete();
        return redirect('/programs');
    }
}
