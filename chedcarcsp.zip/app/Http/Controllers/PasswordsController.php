<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Carbon\Carbon;
use Auth;

class PasswordsController extends Controller
{
    public function email_form() {
    	return view('passwords.email_form');
    }

    public function send_email() {        
    	$user_check = User::where('email', request()->email)->first();

    	if($user_check == null) {
    		return back()->withErrors([
				'unknown' => 'No account was found with the email address entered'
			]);
    	}

        if($user_check->user_type == 'scholar') {
            if($user_check->is_verified == 0) {
                $email = $user_check->email;
                return view('students.messages.unverified', compact('email'));
            } else if($user_check->is_verified == 1) {
                $details = [
                    'email' => request()->email,
                    'date' => Carbon::now()->toDateTimeString(),
                    'verification_code' => $user_check->verification_code
                ];
                \Mail::to(request()->email)->send(new \App\Mail\ResetPassword($details));
                return view('passwords.email_sent');
            }
        } else if ($user_check->user_type == 'coordinator') {
            if($user_check->is_verified == 1) {
                $details = [
                    'email' => request()->email,
                    'date' => Carbon::now()->toDateTimeString(),
                    'verification_code' => $user_check->verification_code
                ];
                
                \Mail::to(request()->email)->send(new \App\Mail\ResetPassword($details));
                return view('passwords.email_sent');
            }
        }

        return back()->withErrors([
			'unknown' => 'No account was found with the email address entered'
		]);
    }

    public function edit($verification_code) {
    	return view('passwords.edit', compact('verification_code'));
    }

    public function update($verification_code)
    {
        $validated_fields = request()->validate([ 
            'password' => 'required|min:8',
            'confirm_password' => 'required|same:password'
        ]);

    	$user = User::where('verification_code', $verification_code)->first();

        $user->update(['password' => bcrypt(request()->password)]);

        Auth::attempt([
        	'email' => $user->email,
        	'password' => request()->password
        ]);

        if(auth()->user()->user_type == 'scholar') {
            return redirect('/scholar/home');
        } else {
            return redirect('/coordinator/home');
        }
    }
}
