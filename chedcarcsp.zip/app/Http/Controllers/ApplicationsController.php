<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ApplicationPeriod;
use App\Institution;
use App\Course;
use App\Applicant;
use App\Scholar;
use App\SemestralAward;
use Storage;
use Auth;

class ApplicationsController extends Controller
{
    public function index() {
        if(Auth::check()) {
            if(auth()->user()->user_type == 'scholar') {
                return redirect('/scholar/home');
            } else if(auth()->user()->user_type == 'coordinator'){
                return redirect('/coordinator/home');
            }
        }
    	$application_period = ApplicationPeriod::orderBy('start_date', 'DESC')->first();
        $numbers = array();
        $numbers[0] = Scholar::where('latest_status', 'Active')->count();
        $numbers[1] = Scholar::where('acad_year_accepted', now()->month < 8 ? now()->year - 2 : now()->year - 1)->count();
        $numbers[2] = SemestralAward::where('acad_year', now()->month < 8 ? now()->year - 2 : now()->year - 1)->where('status', 'Graduate')->count();
    	return view('applications.index', compact('application_period', 'numbers'));
    }

    public function form() {
        $application_period = ApplicationPeriod::orderBy('start_date', 'DESC')->first();
    	if(now() >= $application_period->start_date && now() <= $application_period->end_date) {
	        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
	        $courses = Course::orderBy('course_name', 'ASC')->get();
	    	return view('applications.form', compact('institutions', 'courses'));
    	} else {
	    	return redirect('/');
    	}
    }

    public function check($name_first, $name_middle, $name_last, $name_ext, $name_maiden, $birthday){

        $applicant = Applicant::query();
        if(!in_array(strtolower(trim($name_first)), ['na', 'n/a'])) {
            $applicant->where('name_first', trim($name_first));
        }
        if(!in_array(strtolower(trim($name_middle)), ['na', 'n/a'])) {
            $applicant->where('name_middle', trim($name_middle));
        }
        if(!in_array(strtolower(trim($name_last)), ['na', 'n/a'])) {
            $applicant->where('name_last', trim($name_last));
        }
        if(!in_array(strtolower(trim($name_ext)), ['na', 'n/a'])) {
            $applicant->where('name_ext', trim($name_ext));
        }
        if(!in_array(strtolower(trim($name_maiden)), ['na', 'n/a'])) {
            $applicant->where('name_maiden', trim($name_maiden));
        }
        $check = $applicant->where('birthday', $birthday)->first();

        if($check == null) {
            return 0;
        } else {
            return 1;
        }
    }

    public function store() {
        // CREATE APPLICATION NUMBER
        $app_no = 0;
        $check = true;
        while($check) {
            $app_no = rand(1000000, 9999999);
            if(Applicant::where('app_no', $app_no)->first() == null) {
                $check = false;
            }
        }

        // INITIALIZE DISABILITY
        $disability = '';
        if(request()->filled('is_pwd')) {
            if(request()->disability != 'Others') {
                $disability = request()->disability;
            } else {
                $disability = request()->disability_others;
            }
        } else {
            $disability = null;
        }

        // COMPUTE SCORE
        $twelve_gwa_count = 1;
        $twelve_gwa_sum = request()->twelve_gwa_1;
        if(!in_array(strtolower(trim(request()->twelve_gwa_2)), ['na', 'n/a'])) {
            $twelve_gwa_sum = $twelve_gwa_sum + request()->twelve_gwa_2;
            $twelve_gwa_count++;
        }
        if(!in_array(strtolower(trim(request()->twelve_gwa_3)), ['na', 'n/a'])) {
            $twelve_gwa_sum = $twelve_gwa_sum + request()->twelve_gwa_3;
            $twelve_gwa_count++;
        }
        $twelve_gwa = round($twelve_gwa_sum / $twelve_gwa_count);

        if(request()->type == 'Graduating') {
            $eleven_gwa_count = 1;
            $eleven_gwa_sum = request()->eleven_gwa_1;
            if(!in_array(strtolower(trim(request()->eleven_gwa_2)), ['na', 'n/a'])) {
                $eleven_gwa_sum = $eleven_gwa_sum + request()->eleven_gwa_2;
                $eleven_gwa_count++;
            }
            if(!in_array(strtolower(trim(request()->eleven_gwa_3)), ['na', 'n/a'])) {
                $eleven_gwa_sum = $eleven_gwa_sum + request()->eleven_gwa_3;
                $eleven_gwa_count++;
            }
            $eleven_gwa = round($eleven_gwa_sum / $eleven_gwa_count);
        }

        if(request()->type == 'Graduating') {
            $gwa = round(($twelve_gwa_sum + $eleven_gwa_sum) / ($twelve_gwa_count + $eleven_gwa_count));
        } else {
            $gwa = $twelve_gwa;
        }

        $score = 0;

        if($gwa >= 99) {
            $score += (100 * 0.7);
        } else if($gwa >= 97) {
            $score += (95 * 0.7);
        } else if($gwa >= 95) {
            $score += (90 * 0.7);
        } else if($gwa >= 93) {
            $score += (85 * 0.7);
        } else if($gwa >= 91) {
            $score += (80 * 0.7);
        } else {
            $score += (75 * 0.7);
        }

        if(request()->annual_gross_income <= 70000) {
            $score += (100 * 0.3);
        } else if(request()->annual_gross_income <= 136000) {
            $score += (95 * 0.3);
        } else if(request()->annual_gross_income <= 202000) {
            $score += (90 * 0.3);
        } else if(request()->annual_gross_income <= 268000) {
            $score += (85 * 0.3);
        } else if(request()->annual_gross_income <= 334000) {
            $score += (80 * 0.3);
        } else {
            $score += (75 * 0.3);
        }

        if(request()->filled('is_ip') || request()->filled('is_pwd') || request()->filled('is_sc') || request()->filled('is_sp') || (request()->filled('f_is_deceased') && request()->filled('m_is_deceased'))) {
            $score += 5;
        }

        // STORE FILES
        $birth_cert_path = Storage::disk('s3')->url(request()->file('birth_cert')->store('documents', 's3'));
        $id_photo_path = Storage::disk('s3')->url(request()->file('id_photo')->store('documents', 's3'));
        $twelve_card_path = Storage::disk('s3')->url(request()->file('twelve_card')->store('documents', 's3'));
        $eleven_card_path = request()->type == 'Graduating' ? Storage::disk('s3')->url(request()->file('eleven_card')->store('documents', 's3')) : null;
        $income_proof_path = Storage::disk('s3')->url(request()->file('income_proof')->store('documents', 's3'));
        $cert_indigency_path = request()->filled('is_ip') ? Storage::disk('s3')->url(request()->file('cert_indigency')->store('documents', 's3')) : null;
        $pwd_id_path = request()->filled('is_pwd') ? Storage::disk('s3')->url(request()->file('pwd_id')->store('documents', 's3')) : null;
        $sc_id_path = request()->filled('is_sc') ? Storage::disk('s3')->url(request()->file('sc_id')->store('documents', 's3')) : null;
        $sp_id_path = request()->filled('is_sp') ? Storage::disk('s3')->url(request()->file('sp_id')->store('documents', 's3')) : null;

        $application_period = ApplicationPeriod::orderBy('start_date', 'DESC')->first();

        $applicant_details = [

        ////////// APPLICATION DETAILS
            'app_no' => $app_no,
            'entry_date' => date("Y-m-d"),
            'entry_acad_year' => $application_period->acad_year,
            'is_accepted' => 0,
            'are_documents_validated' => 0,
            'score' => $score,

        ////////// PERSONAL INFORMATION
            
            // PERSONAL DETAILS
            'name_last' => trim(request()->name_last),
            'name_first' => trim(request()->name_first),
            'name_middle' => in_array(strtolower(trim(request()->name_middle)), ['na', 'n/a']) ? null : trim(request()->name_middle),
            'name_ext' => in_array(strtolower(trim(request()->name_ext)), ['na', 'n/a']) ? null : trim(request()->name_ext),
            'name_maiden' => in_array(strtolower(trim(request()->name_maiden)), ['na', 'n/a']) ? null : trim(request()->name_maiden),
            'birthday' => request()->birthday,
            'birthplace' => trim(request()->birthplace),
            'sex' => request()->sex,
            'civil_status' => request()->civil_status,
            'citizenship' => trim(request()->citizenship),

            // CONTACT DETAILS
            'email_address' => trim(request()->email_address),
            'contact_number' => in_array(strtolower(trim(request()->contact_number)), ['na', 'n/a']) ? null : preg_replace("/[^0-9]/", '', trim(request()->contact_number)),
            'fb_account' => in_array(strtolower(trim(request()->fb_account)), ['na', 'n/a']) ? null : trim(request()->fb_account),

            // PERSONAL IDENTIFICATION
            'birth_cert' => $birth_cert_path,
            'id_photo' => $id_photo_path,

        ////////// ADDRESS INFORMATION

            // PERMANENT ADDRESS
            'perm_district' => trim(request()->filled('perm_add_is_car') ? request()->perm_district : request()->perm_district2),
            'perm_province' => trim(request()->filled('perm_add_is_car') ? request()->perm_province : request()->perm_province2),
            'perm_muni_city' => trim(request()->filled('perm_add_is_car') ? request()->perm_muni_city : request()->perm_muni_city2),
            'perm_barangay' => trim(request()->perm_barangay),
            'perm_zip_code' => trim(request()->perm_zip_code),

            // PRESENT ADDRESS
            'pres_is_perm' => request()->filled('pres_is_perm') ? 1 : 0,
            'pres_district' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_district : request()->pres_district2),
            'pres_province' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_province : request()->pres_province2),
            'pres_muni_city' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_muni_city : request()->pres_muni_city2),
            'pres_barangay' => request()->filled('pres_is_perm') ? null : trim(request()->pres_barangay),
            'pres_zip_code' => request()->filled('pres_is_perm') ? null : request()->pres_zip_code,

        ////////// ACADEMIC INFORMATION

            // PREVIOUS SCHOOL
            'highschool' => trim(request()->highschool),
            'highschool_add' => trim(request()->highschool_add),
            'highschool_sector' => request()->highschool_sector,
            'type' => request()->type,

            // GWA
            'gwa' => $gwa,
            'twelve_gwa' => $twelve_gwa,
            'twelve_gwa_1' => in_array(strtolower(trim(request()->twelve_gwa_1)), ['na', 'n/a']) ? null : request()->twelve_gwa_1,
            'twelve_gwa_2' => in_array(strtolower(trim(request()->twelve_gwa_2)), ['na', 'n/a']) ? null : request()->twelve_gwa_2,
            'twelve_gwa_3' => in_array(strtolower(trim(request()->twelve_gwa_3)), ['na', 'n/a']) ? null : request()->twelve_gwa_3,
            'eleven_gwa' => request()->type == 'Graduating' ? $eleven_gwa : null,
            'eleven_gwa_1' => in_array(strtolower(trim(request()->eleven_gwa_1)), ['na', 'n/a']) ? null : request()->eleven_gwa_1,
            'eleven_gwa_2' => in_array(strtolower(trim(request()->eleven_gwa_2)), ['na', 'n/a']) ? null : request()->eleven_gwa_2,
            'eleven_gwa_3' => in_array(strtolower(trim(request()->eleven_gwa_3)), ['na', 'n/a']) ? null : request()->eleven_gwa_3,

            // ACADEMIC REQUIREMENTS
            'twelve_card' => $twelve_card_path,
            'eleven_card' => $eleven_card_path,

            // IF FUTURE SCHOOL IS WITHIN CAR
            'institution_id' => request()->filled('hei_is_car') ? request()->institution_id : null,

            // IF FUTURE SCHOOL IS OUTSIDE CAR
            'hei_out_car_name' => request()->filled('hei_is_car') ? null : trim(request()->hei_out_car_name),
            'hei_out_car_address' => request()->filled('hei_is_car') ? null : trim(request()->hei_out_car_address),
            'hei_out_car_sector' => request()->filled('hei_is_car') ? null : trim(request()->hei_out_car_sector),

            // COURSE
            'course_id' => request()->course_id,

            // OTHER SOURCES OF ASSISTANCE
            'other_fa_agency' => request()->has_other_fa == 1 ? trim(request()->other_fa_agency) : null,
            'other_fa_type' => request()->has_other_fa == 1 ? trim(request()->other_fa_type) : null,
            'other_fa_agency2' => request()->has_other_fa == 1 && request()->other_fa_count == 2 ? trim(request()->other_fa_agency2) : null,
            'other_fa_type2' => request()->has_other_fa == 1 && request()->other_fa_count == 2 ? trim(request()->other_fa_type2) : null,

        ////////// FAMILY BACKGROUND

            // FATHER
            'f_is_living' => request()->filled('f_is_deceased') ? 0 : 1,
            'f_name' => in_array(strtolower(trim(request()->f_name)), ['na', 'n/a']) ? null : trim(request()->f_name),
            'f_add' => request()->filled('f_is_deceased') || in_array(strtolower(trim(request()->f_add)), ['na', 'n/a']) ? null : trim(request()->f_add),
            'f_contact_no' => request()->filled('f_is_deceased') || in_array(strtolower(trim(request()->f_contact_no)), ['na', 'n/a']) ? null : preg_replace("/[^0-9]/", '', trim(request()->f_contact_no)),
            'f_occupation' => request()->filled('f_is_deceased') || in_array(strtolower(trim(request()->f_occupation)), ['na', 'n/a']) ? null : trim(request()->f_occupation),
            'f_employer' => request()->filled('f_is_deceased') || in_array(strtolower(trim(request()->f_employer)), ['na', 'n/a']) ? null : trim(request()->f_employer),
            'f_employer_add' => request()->filled('f_is_deceased') || in_array(strtolower(trim(request()->f_employer_add)), ['na', 'n/a']) ? null : trim(request()->f_employer_add),
            'f_education' => request()->filled('f_is_deceased') || in_array(strtolower(trim(request()->f_education)), ['na', 'n/a']) ? null : trim(request()->f_education),

            // MOTHER
            'm_is_living' => request()->filled('m_is_deceased') ? 0 : 1,
            'm_name' => in_array(strtolower(trim(request()->m_name)), ['na', 'n/a']) ? null : trim(request()->m_name),
            'm_add' => request()->filled('m_is_deceased') || in_array(strtolower(trim(request()->m_add)), ['na', 'n/a']) ? null : trim(request()->m_add),
            'm_contact_no' => request()->filled('m_is_deceased') || in_array(strtolower(trim(request()->m_contact_no)), ['na', 'n/a']) ? null : preg_replace("/[^0-9]/", '', trim(request()->m_contact_no)),
            'm_occupation' => request()->filled('m_is_deceased') || in_array(strtolower(trim(request()->m_occupation)), ['na', 'n/a']) ? null : trim(request()->m_occupation),
            'm_employer' => request()->filled('m_is_deceased') || in_array(strtolower(trim(request()->m_employer)), ['na', 'n/a']) ? null : trim(request()->m_employer),
            'm_employer_add' => request()->filled('m_is_deceased') || in_array(strtolower(trim(request()->m_employer_add)), ['na', 'n/a']) ? null : trim(request()->m_employer_add),
            'm_education' => request()->filled('m_is_deceased') || in_array(strtolower(trim(request()->m_education)), ['na', 'n/a']) ? null : trim(request()->m_education),

            // LEGAL GUARDIAN
            'g_name' => request()->has_legal_guardian == 0 || in_array(strtolower(trim(request()->g_name)), ['na', 'n/a']) ? null : trim(request()->g_name),
            'g_add' => request()->has_legal_guardian == 0 || in_array(strtolower(trim(request()->g_add)), ['na', 'n/a']) ? null : trim(request()->g_add),
            'g_contact_no' => request()->has_legal_guardian == 0 || in_array(strtolower(trim(request()->g_contact_no)), ['na', 'n/a']) ? null : preg_replace("/[^0-9]/", '', trim(request()->g_contact_no)),
            'g_occupation' => request()->has_legal_guardian == 0 || in_array(strtolower(trim(request()->g_occupation)), ['na', 'n/a']) ? null : trim(request()->g_occupation),
            'g_employer' => request()->has_legal_guardian == 0 || in_array(strtolower(trim(request()->g_employer)), ['na', 'n/a']) ? null : trim(request()->g_employer),
            'g_employer_add' => request()->has_legal_guardian == 0 || in_array(strtolower(trim(request()->g_employer_add)), ['na', 'n/a']) ? null : trim(request()->g_employer_add),
            'g_education' => request()->has_legal_guardian == 0 || in_array(strtolower(trim(request()->g_education)), ['na', 'n/a']) ? null : trim(request()->g_education),

            // FAMILY
            'siblings' => request()->siblings,
            'annual_gross_income' => request()->annual_gross_income,

            // INCOME REQUIREMENT
            'income_proof_type' => request()->income_proof_type,
            'income_proof' => $income_proof_path,

            // DSWD 4PS 
            'is_dswd_4ps' => request()->is_dswd_4ps,

        ////////// SPECIAL GROUP

            // IP
            'tribe' => request()->filled('is_ip') ? trim(ucwords(strtolower(str_replace(['tribe', 'Tribe'], '', request()->tribe)))) : null,
            'cert_indigency' => $cert_indigency_path,

            // PWD
            'disability' => $disability,
            'pwd_id' => $pwd_id_path,

            // SC
            'sc_type' => request()->filled('is_sc') ? 'Dependent' : null,
            'sc_id' => $sc_id_path,

            // SP
            'sp_type' => request()->filled('is_sp') ? 'Dependent' : null,
            'sp_id' => $sp_id_path,

            // ORPHAN
            'is_orphan' => request()->filled('f_is_deceased') && request()->filled('m_is_deceased') ? 1 : 0 
        ]; 

        $applicant = Applicant::create($applicant_details); 
        return redirect('/application/success');
    }

    public function success() {
        return view('applications.success');
    }

    public function heis() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        return view('applications.heis', compact('institutions'));
    }
}
