<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Institution;
use App\Course;
use App\Scholar;
use App\Program;
use App\User;
use App\Document;
use App\SemestralAward;
use App\BillingStatement;
use App\Update;
use App\Applicant;
use Storage;
use Auth;
use Redirect;

class CoordinatorsController extends Controller
{
    public function login() {
    	return view('coordinators.login');
    }

    public function sign_up() {
    	return view('coordinators.sign_up');
    }

    // HOME

    public function index() {
    	$institution = Institution::find(auth()->user()->institution_id);
        $head_coordinator = User::where('coordinator_role', 'head')->where('institution_id', $institution->id)->first();

    	return view('coordinators.home.index', compact('institution', 'head_coordinator'));
    }

    public function edit_hei(Institution $institution) {
        return view('coordinators.home.edit_hei', compact('institution'));
    }

    public function update_hei(Institution $institution)
    {
        $validated_fields = request()->validate([
            'address' => 'required',
            'hei_email' => 'required',
            'hei_contact_no' => 'required',
            'hei_website' => 'nullable'
        ]);

        $institution->update($validated_fields);
        return redirect('/coordinator/home');
    }

    public function edit_org(Institution $institution) {
        return view('coordinators.home.edit_organization', compact('institution'));
    }

    public function update_org(Institution $institution)
    {
        $validated_fields = request()->validate([
            'institution_head' => 'required',
            'registrar' => 'required',
            'accountant' => 'required'
        ]);

        $institution->update($validated_fields);
        return redirect('/coordinator/home');
    }

    // UNDERGRADUATES

    public function undergraduates() {
        $institution = Institution::find(auth()->user()->institution_id);
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();

        $query = Scholar::query()->where('latest_status', '!=', 'Graduate')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('applicants.institution_id', $institution->id);

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // ACADEMIC PERIOD
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('scholars.latest_acad_year', $period[0]);
            $query->where('scholars.latest_semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // ACADEMIC PERIOD
        if(request()->filled('started')) {
            $started = explode(',', request()->started);
            $query->where('scholars.acad_year_accepted', $started[0]);
            $query->where('scholars.semester_accepted', $started[1]);
            $sort_filters['started'] = request()->started;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // YEAR LEVEL
        if(request()->filled('year_level')) {
            $query->where('scholars.latest_year_level', request()->year_level);
            $sort_filters['year_level'] = request()->year_level;
        }

        // STATUS
        if(request()->filled('status')) {
            $query->where('scholars.latest_status', request()->status);
            $sort_filters['status'] = request()->status;
        } else {
            $query->where('scholars.latest_status', 'Active');
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else {
                $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
            } 
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $scholars = $query->select('scholars.*', 'scholars.id as scholar_id', 'applicants.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $scholars = $query->select('scholars.*', 'scholars.id as scholar_id', 'applicants.*')->paginate(10);
        }

        return view('coordinators.undergraduates.index', compact('scholars', 'sort_filters', 'programs', 'institution'));
    }

    public function undergraduates_edit(Scholar $scholar) {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $courses = Course::orderBy('course_name', 'ASC')->get();
        return view('coordinators.undergraduates.edit', compact('scholar', 'institutions', 'courses'));
    }

    public function delete_existing_update($applicant_id, $field) {
        $check = Update::where('applicant_id', $applicant_id)
            ->where('field', $field)
            ->where('is_approved', null)
            ->first();
        if($check != null) {
            $check->delete();
        }
    }

    public function create_update($applicant_id, $institution_id, $field, $old_value, $new_value) {
        Update::create([
            'applicant_id' => $applicant_id,
            'institution_id' => $institution_id,
            'field' => $field,
            'old_value' => $old_value,
            'new_value' => $new_value,
        ]);
    }

    public function undergraduates_update(Scholar $scholar) {
        $applicant_id = $scholar->applicant_id;
        $institution_id = auth()->user()->institution_id;

        // EMAIL ADDRESS
        if($scholar->applicant->email_address != request()->email_address) {
            $this->delete_existing_update($applicant_id, 'email_address');
            $this->create_update($applicant_id, $institution_id, 'email_address', $scholar->applicant->email_address, request()->email_address);
        }
        // CONTACT NUMBER
        if($scholar->applicant->contact_number != preg_replace("/[^0-9]/", '', trim(request()->contact_number))) {
            $this->delete_existing_update($applicant_id, 'contact_number');
            $this->create_update($applicant_id, $institution_id, 'contact_number', $scholar->applicant->contact_number, preg_replace("/[^0-9]/", '', trim(request()->contact_number)));
        }
        // FACEBOOK ACCOUNT
        if($scholar->applicant->fb_account != request()->fb_account) {
            $this->delete_existing_update($applicant_id, 'fb_account');
            $this->create_update($applicant_id, $institution_id, 'fb_account', $scholar->applicant->fb_account, request()->fb_account);
        }
        // COURSE
        if($scholar->applicant->course_id != request()->course_id) {
            $this->delete_existing_update($applicant_id, 'course_id');
            $this->create_update($applicant_id, $institution_id, 'course_id', $scholar->applicant->course_id, request()->course_id);
        }
        // YEAR LEVEL
        if($scholar->latest_year_level != request()->latest_year_level) {
            $this->delete_existing_update($applicant_id, 'latest_year_level');
            $this->create_update($applicant_id, $institution_id, 'latest_year_level', $scholar->latest_year_level, request()->latest_year_level);
        }

        // INSTITUTION
        if($scholar->applicant->institution_id != request()->institution_id) {
            $this->delete_existing_update($applicant_id, 'institution_id');
            $this->create_update($applicant_id, $institution_id, 'institution_id', $scholar->applicant->institution_id, request()->institution_id);
        }

        $are_addresses_same = true;

        // PERMANENT ADDRESS
        if($scholar->applicant->perm_district != trim(request()->filled('perm_add_is_car') ? request()->perm_district : request()->perm_district2)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->perm_province != trim(request()->filled('perm_add_is_car') ? request()->perm_province : request()->perm_province2)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->perm_muni_city != trim(request()->filled('perm_add_is_car') ? request()->perm_muni_city : request()->perm_muni_city2)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->perm_barangay != trim(request()->perm_barangay)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->perm_zip_code != trim(request()->perm_zip_code)) {
            $are_addresses_same = false;

        // PRESENT ADDRESS
        } else if($scholar->applicant->pres_is_perm != (request()->filled('pres_is_perm') ? 1 : 0)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->pres_district != trim(request()->filled('pres_add_is_car') ? request()->pres_district : request()->pres_district2)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->pres_province != trim(request()->filled('pres_add_is_car') ? request()->pres_province : request()->pres_province2)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->pres_muni_city != trim(request()->filled('pres_add_is_car') ? request()->pres_muni_city : request()->pres_muni_city2)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->pres_barangay != trim(request()->pres_barangay)) {
            $are_addresses_same = false;
        } else if($scholar->applicant->pres_zip_code != trim(request()->pres_zip_code)) {
            $are_addresses_same = false;
        }

        if($are_addresses_same == false) {
            // OLD ADDRESS
            if($scholar->applicant->pres_is_perm) {
                $old_present_address = '0';
            } else {
                $old_present_address = $scholar->applicant->pres_barangay.'|'.
                $scholar->applicant->pres_muni_city.'|'.
                $scholar->applicant->pres_province.'|'.
                $scholar->applicant->pres_district.'|'.
                $scholar->applicant->pres_zip_code;
            }
            $old_value = $scholar->applicant->perm_barangay.'|'.
                $scholar->applicant->perm_muni_city.'|'.
                $scholar->applicant->perm_province.'|'.
                $scholar->applicant->perm_district.'|'.
                $scholar->applicant->perm_zip_code.'|'.$old_present_address;

            // NEW ADDRESS
            if(request()->filled('pres_is_perm')) {
                $new_present_address = '0';
            } else {
                $new_present_address = trim(request()->pres_barangay).'|'.
                trim(request()->filled('pres_add_is_car') ? request()->pres_muni_city : request()->pres_muni_city2).'|'.
                trim(request()->filled('pres_add_is_car') ? request()->pres_province : request()->pres_province2).'|'.
                trim(request()->filled('pres_add_is_car') ? request()->pres_district : request()->pres_district2).'|'.
                trim(request()->pres_zip_code);
            }
            $new_value = trim(request()->perm_barangay).'|'.
                trim(request()->filled('perm_add_is_car') ? request()->perm_muni_city : request()->perm_muni_city2).'|'.
                trim(request()->filled('perm_add_is_car') ? request()->perm_province : request()->perm_province2).'|'.
                trim(request()->filled('perm_add_is_car') ? request()->perm_district : request()->perm_district2).'|'.
                trim(request()->perm_zip_code).'|'.$new_present_address;
            $this->delete_existing_update($applicant_id, 'address');
            $this->create_update($applicant_id, $institution_id, 'address', $old_value, $new_value);
        }

        return redirect('/coordinator/undergraduates');
    }

    // GRADUATES

    public function graduates() {
        $institution = Institution::find(auth()->user()->institution_id);
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();

        $query = Scholar::query()
            ->join('semestral_awards', 'semestral_awards.scholar_id', '=', 'scholars.id')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('applicants.institution_id', $institution->id)
            ->where('semestral_awards.status', 'Graduate');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // PERIOD GRADUATED
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('semestral_awards.acad_year', $period[0]);
            $query->where('semestral_awards.semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // PERIOD STARTED
        if(request()->filled('started')) {
            $started = explode(',', request()->started);
            $query->where('scholars.acad_year_accepted', $started[0]);
            $query->where('scholars.semester_accepted', $started[1]);
            $sort_filters['started'] = request()->started;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $scholars = $query->select('scholars.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $scholars = $query->select('scholars.*')->paginate(10);
        }

        return view('coordinators.graduates.index', compact('scholars', 'sort_filters', 'programs'));
    }

    public function graduates_create() {
        $institution = Institution::find(auth()->user()->institution_id);
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();

        $query = Applicant::query()
            ->doesntHave('updates')
            ->join('scholars', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('scholars.latest_status', 'Active')
            ->where('applicants.institution_id', $institution->id);

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // LATEST PERIOD
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('scholars.latest_acad_year', $period[0]);
            $query->where('scholars.latest_semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // PERIOD STARTED
        if(request()->filled('started')) {
            $started = explode(',', request()->started);
            $query->where('scholars.acad_year_accepted', $started[0]);
            $query->where('scholars.semester_accepted', $started[1]);
            $sort_filters['started'] = request()->started;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // YEAR LEVEL
        if(request()->filled('year_level')) {
            $query->where('scholars.latest_year_level', request()->year_level);
            $sort_filters['year_level'] = request()->year_level;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else {
                $query->orderBy('scholars.latest_year_level', 'DESC')->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } 
            $sort_filters['sort'] = request()->sort;
        } else {
                $query->orderBy('scholars.latest_year_level', 'DESC')->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $applicants = $query->select('applicants.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $applicants = $query->select('applicants.*')->paginate(10);
        }

        return view('coordinators.graduates.create', compact('applicants', 'sort_filters', 'programs'));
    }

    public function graduates_store(Scholar $scholar) {
        Update::create([
            'applicant_id' => $scholar->applicant_id,
            'institution_id' => auth()->user()->institution_id,
            'field' => 'status',
            'old_value' => 'Active',
            'new_value' => 'Graduate',
            'remarks' => request()->input('remarks_'.$scholar->id),
        ]);
        return redirect('/coordinator/graduates/create');
    }

    public function graduates_update(Update $update) {
        $update->update([
            'remarks' => request()->input('remarks_'.$update->id),
        ]);
        return redirect('/coordinator/graduates/pending');
    }


    public function graduates_pending() {
        $institution = Institution::find(auth()->user()->institution_id);
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();

        $query = $query = Update::query()
            ->join('applicants', 'updates.applicant_id', '=', 'applicants.id')
            ->join('scholars', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('updates.institution_id', auth()->user()->institution_id)
            ->where('updates.field', 'status')
            ->where('updates.is_approved', null);

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // LABEL
        if(request()->filled('label')) {
            $query->where("updates.field", request()->label);
            $sort_filters['label'] = request()->label;
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(10);
        }

        return view('coordinators.graduates.pending', compact('updates', 'sort_filters', 'programs'));
    }

    // UPDATES

    public function updates() {
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();
        $query = Update::query()
            ->join('applicants', 'updates.applicant_id', '=', 'applicants.id')
            ->join('scholars', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('updates.institution_id', auth()->user()->institution_id)
            ->where('updates.field', '!=', 'status');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // STATUS
        if(request()->filled('status')) {
            if(request()->status == 'pending') {
                $query->where('updates.is_approved', null);
            } else {
                $query->where('updates.is_approved', request()->status == 'approved' ? 1 : 0);
            }
            $sort_filters['status'] = request()->status;
        } else {
            $query->where('updates.is_approved', null);
        }

        // LABEL
        if(request()->filled('label')) {
            $query->where("updates.field", request()->label);
            $sort_filters['label'] = request()->label;
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(10);
        }

        return view('coordinators.updates.index', compact('updates', 'sort_filters', 'programs', 'institution', 'updates'));
    }

    public function updates_cancel(Update $update) {
        $update->delete();
        return Redirect::back();
    }

    // BILLING 

    public function billing() {
        $institution = Institution::find(auth()->user()->institution_id);
        $current_acad_period = now()->year;
        $current_acad_period = $current_acad_period + (now()->month < 8 ? 0: 0.5); 

        $programs_distinct = Scholar::join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where(function($query) use ($institution) {
                $query->where('applicants.institution_id', $institution->id);
                $query->whereIn('scholars.latest_status', ['Active', 'Replacement']);
                $query->where('scholars.latest_acad_year', 2020);
                $query->where('scholars.latest_semester', 2);
            })
            ->orWhere(function($query) use ($institution) {
                $query->where('applicants.institution_id', $institution->id);
                $query->whereIn('scholars.latest_status', ['Active', 'Replacement']);
                $query->where('scholars.latest_acad_year', '>=', 2021);
            })
            ->select('programs.id', 'programs.code')
            ->distinct('programs.id')
            ->get();

        $counts = array();
        $count = 0;
        $billing_statements = array();
        for($i = 2021; $i <= $current_acad_period; $i = $i + 0.5) {
            foreach ($programs_distinct as $key => $program) {
                $scholars = Scholar::join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->orderBy('awards.award_year', 'ASC')
                    ->orderBy('scholars.award_number', 'ASC')
                    ->orderBy('scholars.acad_year_accepted', 'ASC')
                    ->where('applicants.institution_id', $institution->id)
                    ->where('awards.program_id', $program->id)
                    ->select('scholars.id as scholar_id', 'scholars.*', 'applicants.*', 'awards.*')
                    ->get();

                $counts[$count][$key][0] = 0;
                $counts[$count][$key][1] = 0;
                foreach ($scholars as $scholar) {
                    $prev_semester = 
                        SemestralAward::where('scholar_id', $scholar->scholar_id)
                        ->where('acad_year', floor($i) != $i ? (int)floor($i) : (int)floor($i - 1))
                        ->where('semester', floor($i) != $i ? 1 : 2)
                        ->whereIn('status', ['Active', 'Replacement'])->count();

                    if($prev_semester == 1) {
                        $counts[$count][$key][0] = $counts[$count][$key][0] + 1;

                        $current_semester = 
                            SemestralAward::where('scholar_id', $scholar->scholar_id)
                            ->where('acad_year', (int)floor($i))
                            ->where('semester', floor($i) != $i ? 2 : 1)
                            ->whereNotNull('current_year_level')
                            ->whereNotNull('previous_gwa')
                            ->whereNotNull('units_enrolled')
                            ->whereNotNull('tuition_fee')->count();

                        if($current_semester > 0) {
                            $counts[$count][$key][1] = $counts[$count][$key][1] + 1;
                        }
                    }
                }
                $billing_statements[$count][$key] = 
                    BillingStatement::where('acad_year', (int)floor($i))
                    ->where('semester', floor($i) != $i ? 2 : 1)
                    ->where('institution_id', $institution->id)
                    ->where('program_id', $program->id)->first();
            }
            $count++;
        }
        return view('coordinators.billing.index', compact('current_acad_period', 'counts', 'count', 'programs_distinct', 'billing_statements'));

    }

    public function edit_billing(Program $program) {
        $acad_year = request()->acad_year;
        $semester = request()->semester;
        $institution = Institution::find(auth()->user()->institution_id);

        $scholars = Scholar::join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('semestral_awards', 'scholars.id', '=', 'semestral_awards.scholar_id')
            ->orderBy('awards.award_year', 'ASC')
            ->orderBy('scholars.award_number', 'ASC')
            ->orderBy('scholars.acad_year_accepted', 'ASC')
            ->where('applicants.institution_id', $institution->id)
            ->where('awards.program_id', $program->id)
            ->where('semestral_awards.acad_year', $semester == 1 ? $acad_year - 1 : $acad_year)
            ->where('semestral_awards.semester', $semester == 1 ? 2 : 1)
            ->whereIn('semestral_awards.status', ['Active', 'Replacement'])
            ->select('scholars.id as scholar_id', 'scholars.*', 'applicants.*', 'awards.*')
            ->get();

        $semestral_awards = array();

        foreach ($scholars as $key => $scholar) {
            $semestral_awards[$key] = SemestralAward::where('scholar_id', $scholar->scholar_id)
                ->where('acad_year', $acad_year)
                ->where('semester', $semester)->first();
        }

        $is_org_complete = 0;
        if($institution->registrar != null && $institution->accountant != null && $institution->institution_head != null) {
            $is_org_complete = 1;
        }

        return view('coordinators.billing.edit_billing', compact('program', 'acad_year', 'semester', 'scholars', 'semestral_awards', 'is_org_complete'));
    }

    public function update_billing(Program $program)
    {
        $acad_year = request()->acad_year;
        $semester = request()->semester;
        $institution = Institution::find(auth()->user()->institution_id);

        $scholars = Scholar::join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('semestral_awards', 'scholars.id', '=', 'semestral_awards.scholar_id')
            ->orderBy('awards.award_year', 'ASC')
            ->orderBy('scholars.award_number', 'ASC')
            ->orderBy('scholars.acad_year_accepted', 'ASC')
            ->where('applicants.institution_id', $institution->id)
            ->where('awards.program_id', $program->id)
            ->where('semestral_awards.acad_year', $semester == 1 ? $acad_year - 1 : $acad_year)
            ->where('semestral_awards.semester', $semester == 1 ? 2 : 1)
            ->whereIn('semestral_awards.status', ['Active', 'Replacement'])
            ->select('scholars.id as scholar_id', 'scholars.*', 'applicants.*', 'awards.*')
            ->get();

        $semestral_awards = array();

        foreach ($scholars as $key => $scholar) {
            $semestral_award = SemestralAward::where('scholar_id', $scholar->scholar_id)
                ->where('acad_year', $acad_year)
                ->where('semester', $semester)->first();
            if($semestral_award != null) {
                $semestral_award->update([
                    'current_year_level' => request()->input('current_year_level_'.$key),
                    'previous_gwa' => request()->input('previous_gwa_'.$key),
                    'units_enrolled' => request()->input('units_enrolled_'.$key),
                    'tuition_fee' => request()->input('tuition_fee_'.$key),
                    'remarks_coordinator' => request()->input('remarks_'.$key)
                ]);
                $semestral_awards[$key] = $semestral_award;
            } else {
                $semestral_awards[$key] = SemestralAward::create([
                    'scholar_id' => $scholar->scholar_id,
                    'acad_year' => $acad_year,
                    'semester' => $semester,
                    'current_year_level' => request()->input('current_year_level_'.$key),
                    'previous_gwa' => request()->input('previous_gwa_'.$key),
                    'units_enrolled' => request()->input('units_enrolled_'.$key),
                    'tuition_fee' => request()->input('tuition_fee_'.$key),
                    'remarks_coordinator' => request()->input('remarks_'.$key)
                ]);
            }
        }

        if(request()->action == 'generate') {
            $head_coordinator = User::where('coordinator_role', 'head')->where('institution_id', $institution->id)->first();
            return view('coordinators.billing.generate_billing', compact('scholars', 'semestral_awards', 'acad_year', 'semester', 'institution', 'program', 'head_coordinator'));
        }
        return redirect('/coordinator/billing');
    }

    public function create_document(Program $program)
    {
        $acad_year = request()->acad_year;
        $semester = request()->semester;
        return view('coordinators.billing.create_document', compact('program', 'acad_year', 'semester'));
    }

    public function store_document(Program $program)
    {
        $path = Storage::disk('s3')->url(request()->file('file')->store('documents', 's3'));

        BillingStatement::create([
            'program_id' => $program->id,
            'institution_id' => auth()->user()->institution_id,
            'acad_year' => request()->acad_year,
            'semester' => request()->semester,
            'path' => $path,
            'is_reviewed' => 0
        ]);
        
        return redirect('/coordinator/billing');
    }

    public function edit_document(BillingStatement $billing_statement)
    {
        return view('coordinators.billing.edit_document', compact('billing_statement'));
    }

    public function update_document(BillingStatement $billing_statement)
    {
        $index = strpos($billing_statement->path, 'documents/');
        Storage::disk('s3')->delete(substr($billing_statement->path, $index, strlen($billing_statement->path) - $index));
        $path = Storage::disk('s3')->url(request()->file('file')->store('documents', 's3'));
        $billing_statement->update(['path' => $path]); 

        return redirect('/coordinator/billing');
    }

    // CHANGE PASSWORD

    public function edit_password()
    {
        return view('coordinators.edit_password');
    }

    public function update_password()
    {
        $validated_fields = request()->validate([ 
            'email' => 'required|email',
            'old_password' => 'required',
            'new_password' => 'required|min:8',
            'confirm_password' => 'required|same:new_password'
        ]);

        if(Auth::attempt(['email' => $validated_fields['email'], 'password' => $validated_fields['old_password']])) { 
                User::find(Auth::id())->update(['password' => bcrypt(request()->new_password)]);
                Auth::logout();
                return redirect('/coordinator/login');
        } else {
            return back()->withErrors([
                'credentials' => 'Incorrect email or password'
            ]);
        }
    }

    // COORDINATORS

    public function coordinators()
    {
        $institution = Institution::find(auth()->user()->institution_id);
        $coordinators = User::where('user_type', 'coordinator')->where('institution_id', auth()->user()->institution_id)->orderBy('coordinator_role', 'DESC')->orderBy('name', 'ASC')->get();

        return view('coordinators.coordinators.index', compact('coordinators'));
    }

    public function coordinators_create()
    {
        return view('coordinators.coordinators.create', compact('institution'));
    }

    public function coordinators_store()
    {
        $validated_fields = request()->validate([
            'name' => 'required',
            'email' => 'required|unique:users|email',
            'password' => 'required|min:8',
            'confirm_password' => 'required|same:password'
        ]);

        $validated_fields['coordinator_role'] = 'assistant';
        $validated_fields['password'] = bcrypt(request()->password);
        $validated_fields['institution_id'] = auth()->user()->institution_id;
        $validated_fields['user_type'] = 'coordinator';
        $validated_fields['is_verified'] = 1;
        $validated_fields['verification_code'] = sha1(time());

        User::create($validated_fields);
        return redirect('/coordinator/coordinators');
    }

    public function coordinators_replace(User $coordinator)
    {   
        $coordinator->update([
            'coordinator_role' => 'head'
        ]);

        $former_head_coordinator = User::find(auth()->user()->id)->update([
            'coordinator_role' => 'assistant'
        ]);
        return redirect('/coordinator/coordinators');
    }

    public function coordinators_delete(User $coordinator)
    {   
        $coordinator->delete();
        return redirect('/coordinator/coordinators');
    }
 }
