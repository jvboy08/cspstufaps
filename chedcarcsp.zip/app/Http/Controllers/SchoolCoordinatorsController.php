<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Institution;

class SchoolCoordinatorsController extends Controller
{
    public function index() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();

        $sort_filters = array();
        $query = User::query()
        	->where('user_type', 'coordinator')
	        ->orderBy('name', 'ASC')
	        ->join('institutions', 'users.institution_id', '=', 'institutions.id');

	    // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("users.name", 'like', '%'.request()->name.'%');
            $sort_filters['name'] = request()->name;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            $query->where('users.institution_id', request()->institution);
            $sort_filters['institution'] = request()->institution;
        }

        // STATUS
        if(request()->filled('status')) {
            $query->where('users.is_verified', request()->status);
            $sort_filters['status'] = request()->status;
        }

        // POSITION
        if(request()->filled('position')) {
            $query->where('users.coordinator_role', request()->position);
            $sort_filters['position'] = request()->position;
        }

		// ITEMS PER PAGE
        if(request()->filled('items')) {
            $school_coordinators = $query->select('users.*', 'users.id as user_id', 'institutions.*')
            	->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $school_coordinators = $query->select('users.*', 'users.id as user_id', 'institutions.*')
            	->paginate(10);
        }

        return view('schoolcoordinators.index', compact('sort_filters', 'school_coordinators', 'institutions'));
    }

    public function create()
    {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();

        return view('schoolcoordinators.create', compact('institutions'));
    }

    public function store()
    {
        $validated_fields = request()->validate([
            'name' => 'required',
            'email' => 'required|unique:users|email',
            'institution_id' => 'required',
            'coordinator_role' => 'required'
        ]);

        $validated_fields['user_type'] = 'coordinator';
        $validated_fields['is_verified'] = 0;
        $validated_fields['verification_code'] = sha1(time());

        User::create($validated_fields);
        return redirect('/academic/school_coordinators');
    }

    public function edit(User $school_coordinator)
    {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        return view('schoolcoordinators.edit', compact('institutions', 'school_coordinator'));
    }

    public function update(User $school_coordinator)
    {
        $validated_fields = request()->validate([
            'name' => 'required',
            'email' => 'required|email|unique:users,email,'.$school_coordinator->id,
            'institution_id' => 'required',
            'coordinator_role' => 'required'
        ]);
        $school_coordinator->update($validated_fields);
        return redirect('/academic/school_coordinators');
    }

    public function delete(User $school_coordinator)
    {
        $school_coordinator->delete();
        return redirect('/academic/school_coordinators');
    }
}
