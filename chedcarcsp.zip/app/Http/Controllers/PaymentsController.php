<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SemestralAward;
use App\Program;
use App\Scholar;
use App\Institution;

class PaymentsController extends Controller
{
    public function index() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();

        $sort_filters = array();
        $positive_statuses = ['Active', 'Replacement', 'Graduate'];
        $query = Scholar::query()
            ->join('semestral_awards', 'semestral_awards.scholar_id', '=', 'scholars.id')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->whereIn('semestral_awards.status', $positive_statuses);

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // ACADEMIC PERIOD
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('semestral_awards.acad_year', $period[0]);
            $query->where('semestral_awards.semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // PAYMENT
        if(request()->filled('payment')) {
            if(request()->payment == 0) {
                $query->where('semestral_awards.amount_chedro', null);
            } else {
                $query->where('semestral_awards.amount_chedro', '!=', null);
            }
            $sort_filters['payment'] = request()->payment;
        } else {
            $query->where('semestral_awards.amount_chedro', null);
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            $query->where('applicants.institution_id', request()->institution);
            $sort_filters['institution'] = request()->institution;
        }

        $amount_per_sem = 0;

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('awards.program_id', request()->program);
            $sort_filters['program'] = request()->program;
            $amount_per_sem = Program::find(request()->program)->amount_per_sem;
        } else {
            $query->where('awards.program_id', $programs[0]->id);
            $amount_per_sem = $programs[0]->amount_per_sem;
        }

        // MODE OF PAYMENT
        if(request()->filled('mode_of_payment')) {
            $query->where('semestral_awards.mode_of_payment', request()->mode_of_payment);
            $sort_filters['mode_of_payment'] = request()->mode_of_payment;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else {
                $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
            } 
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
        $semestral_awards = $query->select('semestral_awards.id as semestral_award_id', 'semestral_awards.*', 'scholars.id as scholar_id', 'scholars.*', 'awards.*', 'programs.*', 'applicants.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $semestral_awards = $query->select('semestral_awards.id as semestral_award_id', 'semestral_awards.*', 'scholars.id as scholar_id', 'scholars.*', 'awards.*', 'programs.*', 'applicants.*')->paginate(10);
        }

        return view('payments.index', compact('semestral_awards', 'sort_filters', 'programs', 'amount_per_sem', 'institutions', 'programs'));
    }

    public function setAmount()
    {
        foreach (request()->semestral_awards as $key => $semestral_award) {
            SemestralAward::find($semestral_award)->update([
                'amount_chedro' => request()->amount,
                'date_processed' => request()->date_processed,
                'mode_of_payment' => request()->mode_of_payment
            ]);
        }

        return redirect()->back();
    }
}
