<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Institution;
use App\Course;

class CoursesController extends Controller
{
    public function index() {
        $sort_filters = array();
        $query = Course::query()->orderBy('course_name', 'ASC');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where('course_name', 'like', '%' . request()->name . '%');
            $sort_filters['name'] = request()->name;
        }

        // CMO
        if(request()->filled('cmo')) {
            if(request()->cmo == '2021') {
                $query->where('cmo_2021', '!=', 'none');
            } else if(request()->cmo == '2019') {
                $query->where('cmo_2019', '!=', 'none');
            } else {
                $query->where('cmo_2014', '!=', 'none');
            }
            $sort_filters['cmo'] = request()->cmo;
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $courses = $query->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $courses = $query->paginate(10);
        }

        return view('courses.index', compact('courses', 'sort_filters'));
    }

    public function create()
    {
        return view('courses.create', compact('institution'));
    }

    public function store()
    {
        $validated_fields = request()->validate([
            'course_name' => 'required',
            'cmo_2014' => 'required',
            'cmo_2019' => 'required',
            'cmo_2021' => 'required'
        ]);
        Course::create($validated_fields);
        return redirect('/academic/degree_programs');
    }

    public function edit(Course $course)
    {
        return view('courses.edit', compact('institution', 'course'));
    }

    public function update(Course $course)
    {
        $validated_fields = request()->validate([
            'course_name' => 'required',
            'cmo_2014' => 'required',
            'cmo_2019' => 'required',
            'cmo_2021' => 'required'
        ]);
        $course->update($validated_fields);
        return redirect('/academic/degree_programs');
    }

    public function delete(Course $course)
    {
        $course->delete();
        return redirect('/academic/degree_programs');
    }
}






