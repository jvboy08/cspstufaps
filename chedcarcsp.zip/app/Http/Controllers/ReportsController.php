<?php

namespace App\Http\Controllers;
ini_set('max_execution_time', 300);

use Illuminate\Http\Request;
use App\Scholar;
use App\SemestralAward;
use App\Program;
use App\Applicant;

class ReportsController extends Controller
{
    public function index() {
        $programs = Program::orderby('code', 'ASC')->get();
    	return view('reports.index', compact('programs'));
    }

    public function database() {
        $min_period = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                ->join('awards', 'scholars.award_id', '=', 'awards.id')
                ->orderBy('semestral_awards.acad_year', 'ASC')
                ->orderBy('semestral_awards.semester', 'ASC')
                ->first();
        $min = $min_period->semester == 1 ? $min_period->acad_year : $min_period->acad_year + 0.5;
        $max_period = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                ->join('awards', 'scholars.award_id', '=', 'awards.id')
                ->orderBy('semestral_awards.acad_year', 'DESC')
                ->orderBy('semestral_awards.semester', 'DESC')
                ->first();
        $max = $max_period->semester == 1 ? $max_period->acad_year : $max_period->acad_year + 0.5;
        $scholars = Scholar::join('awards', 'scholars.award_id', '=', 'awards.id')
                ->join('programs', 'awards.program_id', '=', 'programs.id')
                ->orderBy('programs.code', 'ASC')
                ->orderBy('awards.award_year', 'ASC')
                ->orderBy('scholars.award_number', 'ASC')
                ->orderBy('scholars.acad_year_accepted', 'ASC')
                ->select('scholars.*', 'scholars.id as scholar_id', 'awards.*')
                ->get();

        $semestral_awards = array();

        foreach ($scholars as $key => $scholar) {
            $count = 0;
            for($i = $min; $i <= $max; $i += 0.5) {
                $semestral_award = SemestralAward::where('scholar_id', $scholar->scholar_id)
                    ->where('acad_year', substr($i, 0, 4))
                    ->where('semester', floor($i) != $i ? '2' : '1')
                    ->first();
                if($semestral_award != null) {
                    $semestral_awards[$key][$count][0] = $semestral_award->current_year_level;
                    $semestral_awards[$key][$count][1] = $semestral_award->status;
                    $semestral_awards[$key][$count][2] = $semestral_award->amount_chedro;
                    $semestral_awards[$key][$count][3] = $semestral_award->mode_of_payment;
                    $semestral_awards[$key][$count][4] = $semestral_award->remarks_chedro;
                    $semestral_awards[$key][$count][5] = $semestral_award->acad_year;
                    $semestral_awards[$key][$count][6] = $semestral_award->semester;
                } else {
                    for($j = 0; $j <= 5; $j++) {
                        $semestral_awards[$key][$count][$j] = null;
                    }
                }
                $count++;
            }
        }

        return view('reports.database', compact('scholars', 'semestral_awards', 'count', 'min', 'max'));
    }

    public function yearly() {
        $acad_year = request()->acad_year;  

        if(request()->report == 'ranklist') {
            $applicants = Applicant::where('entry_acad_year', request()->acad_year)
            ->orderBy('score', 'DESC')
            ->orderBy('name_last', 'ASC')
            ->orderBy('name_first', 'ASC')
            ->orderBy('name_middle', 'ASC')
            ->get();
            $numbers = array();
            $scores = array();
            foreach($applicants as $i => $applicant) {
                $numbers[$i][0] = $applicant->gwa;

                if($numbers[$i][0] >= 99) {
                    $numbers[$i][1] = 100;
                    $numbers[$i][2] = 100 * 0.7;
                } else if($numbers[$i][0] >= 97) {
                    $numbers[$i][1] = 95;
                    $numbers[$i][2] = 95 * 0.7;
                } else if($numbers[$i][0] >= 95) {
                    $numbers[$i][1] = 90;
                    $numbers[$i][2] = 90 * 0.7;
                } else if($numbers[$i][0] >= 93) {
                    $numbers[$i][1] = 85;
                    $numbers[$i][2] = 85 * 0.7;
                } else if($numbers[$i][0] >= 91) {
                    $numbers[$i][1] = 80;
                    $numbers[$i][2] = 80 * 0.7;
                } else {
                    $numbers[$i][1] = 75;
                    $numbers[$i][2] = 75 * 0.7;
                }

                if($applicant->annual_gross_income <= 70000) {
                    $numbers[$i][3] = 100;
                    $numbers[$i][4] = 100 * 0.3;
                } else if($applicant->annual_gross_income <= 136000) {
                    $numbers[$i][3] = 95;
                    $numbers[$i][4] = 95 * 0.3;
                } else if($applicant->annual_gross_income <= 202000) {
                    $numbers[$i][3] = 90;
                    $numbers[$i][4] = 90 * 0.3;
                } else if($applicant->annual_gross_income <= 268000) {
                    $numbers[$i][3] = 85;
                    $numbers[$i][4] = 85 * 0.3;
                } else if($applicant->annual_gross_income <= 334000) {
                    $numbers[$i][3] = 80;
                    $numbers[$i][4] = 80 * 0.3;
                } else {
                    $numbers[$i][3] = 75;
                    $numbers[$i][4] = 75 * 0.3;
                }

                $numbers[$i][5] = $numbers[$i][2] + $numbers[$i][4];

                if($applicant->tribe == null && $applicant->disability == null && $applicant->sp_type == null && $applicant->is_orphan == 0 && $applicant->sc_type == null) {
                    $numbers[$i][6] = $numbers[$i][5];
                } else {
                    $numbers[$i][6] = $numbers[$i][5] + 5;
                }

                array_push($scores, $numbers[$i][6].'');
            }

            $count = 0;
            $unique = $scores; 
            rsort($unique);
            $unique = array_count_values($unique);

            foreach ($unique as $key => $frequency) {
                foreach (range(1, $frequency) as $i) {
                    $unique[$key] += $count++;
                }

                $unique[$key] /= $frequency;
            }

            foreach ($scores as $key => $value) {
                $scores[$key] = $unique[$value];
            }

            return view('reports.ranklist', compact('applicants', 'numbers', 'scores', 'acad_year'));
        } else if(request()->report == 'benefits') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();
            $sem1_total = 0;
            $sem2_total = 0;
            foreach($programs as $i => $program) {
                for($j = 1; $j <= 2; $j++) {
                    $counts[$i][$j] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                        ->join('awards', 'scholars.award_id', '=', 'awards.id')
                        ->join('programs', 'awards.program_id', '=', 'programs.id')
                        ->where('programs.id', $program->id)
                        ->where('semestral_awards.acad_year', $acad_year)
                        ->where('semestral_awards.semester', $j)
                        ->whereNotNull('semestral_awards.amount_chedro')
                        ->count();
                    if($j == 1) {
                        $sem1_total += $counts[$i][$j];
                    } else {
                        $sem2_total += $counts[$i][$j];
                    }
                }
            }

            return view('reports.benefits', compact('programs', 'sem1_total', 'sem2_total', 'counts', 'acad_year'));
        }
    }

    public function semestral() {
        $period = explode(',', request()->period);
        $acad_year = $period[0];
        $semester = $period[1];

    	if(request()->report == 'status_total') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();
            $statuses = ['Active', 'Terminated', 'Deferred', 'Waived', 'Graduate', 'Replacement'];

            foreach($programs as $i => $program) {
                foreach($statuses as $j => $status) {
                    $counts[$i][$j] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                        ->join('awards', 'scholars.award_id', '=', 'awards.id')
                        ->join('programs', 'awards.program_id', '=', 'programs.id')
                        ->where('semestral_awards.acad_year', $acad_year)
                        ->where('semestral_awards.semester', $semester)
                        ->where('semestral_awards.status', $status)
                        ->where('programs.id', $program->id)
                        ->count();
                }
            }
            return view('reports.status_total', compact('counts', 'acad_year', 'semester', 'programs'));
        } else if(request()->report == 'graduates_total') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();

            foreach($programs as $i => $program) {
                $counts[$i] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->where('semestral_awards.status', 'Graduate')
                    ->where('programs.id', $program->id)
                    ->count();
            }
            return view('reports.graduates_total', compact('counts', 'acad_year', 'semester', 'programs'));
        } else if(request()->report == 'graduates_list') {
            $semestral_awards = SemestralAward::where('acad_year', $acad_year)
                ->where('semester', $semester)
                ->where('status', 'Graduate')
                ->join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                ->orderBy('scholars.award_number', 'ASC')->get();
            return view('reports.graduates_list', compact('semestral_awards', 'acad_year', 'semester'));
        } else if(request()->report == 'by_level') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();

            foreach($programs as $i => $program) {
                $counts[$i][6] = 0;
                for($j = 0; $j <= 5; $j++) {
                    $counts[$i][$j] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                        ->join('awards', 'scholars.award_id', '=', 'awards.id')
                        ->join('programs', 'awards.program_id', '=', 'programs.id')
                        ->where('semestral_awards.acad_year', $acad_year)
                        ->where('semestral_awards.semester', $semester)
                        ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                        ->where('programs.id', $program->id)
                        ->where('semestral_awards.current_year_level', $j+1)
                        ->count();
                    $counts[$i][6] = $counts[$i][6] + $counts[$i][$j];
                }
            }
            return view('reports.by_level', compact('counts', 'acad_year', 'semester', 'programs'));
        } else if(request()->report == 'by_sex') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();
            $sexes = ['F', 'M'];

            foreach($programs as $i => $program) {
                foreach($sexes as $j => $sex) {
                    $counts[$i][$j] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                        ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                        ->join('awards', 'scholars.award_id', '=', 'awards.id')
                        ->join('programs', 'awards.program_id', '=', 'programs.id')
                        ->where('semestral_awards.acad_year', $acad_year)
                        ->where('semestral_awards.semester', $semester)
                        ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                        ->where('programs.id', $program->id)
                        ->where('applicants.sex', $sex)
                        ->count();
                }
                $counts[$i][2] = $counts[$i][0] + $counts[$i][1];
            }
            return view('reports.by_sex', compact('counts', 'acad_year', 'semester', 'programs'));
        } else if(request()->report == 'by_hei_type') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();

            foreach($programs as $i => $program) {
                // FOR INSTITUTIONS WITHIN CAR
                $counts[$i][0] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->join('institutions', 'applicants.institution_id', '=', 'institutions.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                    ->where('programs.id', $program->id)
                    ->where('institutions.sector', 'P')
                    ->count();
                // FOR INSTITUTIONS OUTSIDE CAR
                $counts[$i][0] = $counts[$i][0] + SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                    ->where('programs.id', $program->id)
                    ->where('applicants.hei_out_car_sector', 'Private')
                    ->count();

                // FOR INSTITUTIONS WITHIN CAR
                $counts[$i][1] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->join('institutions', 'applicants.institution_id', '=', 'institutions.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                    ->where('programs.id', $program->id)
                    ->where('institutions.sector', '!=', 'P')
                    ->count();
                // FOR INSTITUTIONS OUTSIDE CAR
                $counts[$i][1] = $counts[$i][1] + SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                    ->where('programs.id', $program->id)
                    ->where('applicants.hei_out_car_sector', '!=', 'Private')
                    ->count();

                $counts[$i][2] = $counts[$i][0] + $counts[$i][1];
            }
            return view('reports.by_hei_type', compact('counts', 'acad_year', 'semester', 'programs'));
        } else if(request()->report == 'by_district') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();
            $districts = ['Abra', 'Apayao', 'Baguio City', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province'];

            foreach($programs as $i => $program) {
                $counts[$i][8] = 0;
                foreach($districts as $j => $district) {
                    $counts[$i][$j] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                        ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                        ->join('awards', 'scholars.award_id', '=', 'awards.id')
                        ->join('programs', 'awards.program_id', '=', 'programs.id')
                        ->where('semestral_awards.acad_year', $acad_year)
                        ->where('semestral_awards.semester', $semester)
                        ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                        ->where('programs.id', $program->id)
                        ->where('applicants.perm_district', $district)
                        ->count();
                    $counts[$i][8] = $counts[$i][8] + $counts[$i][$j];
                }
                $counts[$i][7] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                    ->where('programs.id', $program->id)
                    ->whereNotIn('applicants.perm_district', $districts)
                    ->count();
                $counts[$i][8] = $counts[$i][8] + $counts[$i][7];
            }
            return view('reports.by_district', compact('counts', 'acad_year', 'semester', 'programs'));
        } else if(request()->report == 'by_special') {
            $programs = Program::orderBy('code', 'ASC')->get();
            $counts = array();
            $tribes = array();
            $disabilities = array();
            $tribes_counts = array();
            $disabilities_counts = array();

            $ips = SemestralAward::query()
                ->join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                ->join('awards', 'scholars.award_id', '=', 'awards.id')
                ->join('programs', 'awards.program_id', '=', 'programs.id')
                ->where('semestral_awards.acad_year', $acad_year)
                ->where('semestral_awards.semester', $semester)
                ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                ->where('applicants.tribe', '!=', null)->get();

            $pwds = SemestralAward::query()
                ->join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                ->join('awards', 'scholars.award_id', '=', 'awards.id')
                ->join('programs', 'awards.program_id', '=', 'programs.id')
                ->where('semestral_awards.acad_year', $acad_year)
                ->where('semestral_awards.semester', $semester)
                ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                ->where('applicants.disability', '!=', null)->get();

            foreach($ips as $ip) {
                if(!in_array($ip->tribe, $tribes)){
                    $tribes[] = $ip->tribe;
                }                
            }

            foreach($pwds as $pwd) {
                if(!in_array($pwd->disability, $disabilities)){
                    $disabilities[] = $pwd->disability;
                }                
            }

            sort($tribes);
            sort($disabilities);
            $remaining_groups = ['SP', 'O'];

            foreach($programs as $i => $program) {
                $counts[$i][2] = 0;
                foreach($tribes as $j => $tribe) {
                    $tribes_counts[$i][$j] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                        ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                        ->join('awards', 'scholars.award_id', '=', 'awards.id')
                        ->join('programs', 'awards.program_id', '=', 'programs.id')
                        ->where('semestral_awards.acad_year', $acad_year)
                        ->where('semestral_awards.semester', $semester)
                        ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                        ->where('applicants.tribe', $tribe)
                        ->where('programs.id', $program->id)
                        ->count();
                    $counts[$i][2] += $tribes_counts[$i][$j];
                }

                foreach($disabilities as $k => $disability) {
                    $disabilities_counts[$i][$k] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                        ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                        ->join('awards', 'scholars.award_id', '=', 'awards.id')
                        ->join('programs', 'awards.program_id', '=', 'programs.id')
                        ->where('semestral_awards.acad_year', $acad_year)
                        ->where('semestral_awards.semester', $semester)
                        ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                        ->where('applicants.disability', $disability)
                        ->where('programs.id', $program->id)
                        ->count();
                    $counts[$i][2] += $disabilities_counts[$i][$k];
                }

                $counts[$i][0] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                    ->where('programs.id', $program->id)
                    ->where('applicants.sp_type', '!=', null)
                    ->count();
                $counts[$i][2] += $counts[$i][0];

                $counts[$i][1] = SemestralAward::join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
                    ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
                    ->join('awards', 'scholars.award_id', '=', 'awards.id')
                    ->join('programs', 'awards.program_id', '=', 'programs.id')
                    ->where('semestral_awards.acad_year', $acad_year)
                    ->where('semestral_awards.semester', $semester)
                    ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
                    ->where('programs.id', $program->id)
                    ->where('applicants.is_orphan', 1)
                    ->count();
                $counts[$i][2] += $counts[$i][1];
            }

            return view('reports.by_special', compact('counts', 'tribes', 'tribes_counts', 'disabilities', 'disabilities_counts', 'acad_year', 'semester', 'programs'));
        }
    }

    public function semestral_program() {
        if(request()->report == 'masterlist') {
            $period = explode(',', request()->period);
            $semestral_awards = SemestralAward::
            join('scholars', 'semestral_awards.scholar_id', '=', 'scholars.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('semestral_awards.acad_year', $period[0])
            ->where('semestral_awards.semester', $period[1])
            ->whereIn('semestral_awards.status', ['Active', 'Replacement', 'Graduate', 'Deferred'])
            ->where('programs.id', request()->program)
            ->orderBy('scholars.award_number', 'ASC')->get();

            $acad_year = $period[0];
            $semester = $period[1];
            return view('reports.masterlist', compact('semestral_awards', 'acad_year', 'semester'));
        } 
    }
}
