<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Program;
use App\Award;
use App\SemestralAward;
use App\Scholar;
use App\Institution;
use App\Applicant;

class ReplacementsController extends Controller
{
	public function replace(Applicant $applicant) {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();
        $query = Scholar::query()->whereIn('latest_status', ['Terminated', 'Graduate', 'Waived'])
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $names = explode(" ", request()->name);
            $query->where(function($query) use ($names) {
                $query->whereIn('applicants.name_first', $names);
                $query->orWhere(function($query) use ($names) {
                    $query->whereIn('applicants.name_last', $names);
                });
            });
            $sort_filters['name'] = request()->name;
        }

        // LATEST ACADEMIC PERIOD
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('scholars.latest_acad_year', $period[0]);
            $query->where('scholars.latest_semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // ACADEMIC PERIOD STARTED
        if(request()->filled('started')) {
            $started = explode(',', request()->started);
            $query->where('scholars.acad_year_accepted', $started[0]);
            $query->where('scholars.semester_accepted', $started[1]);
            $sort_filters['started'] = request()->started;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            $query->where('applicants.institution_id', request()->institution);
            $sort_filters['institution'] = request()->institution;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // STATUS
        if(request()->filled('status')) {
            $query->where('scholars.latest_status', request()->status);
            $sort_filters['status'] = request()->status;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else {
                $query->orderBy('scholars.award_number', 'ASC');
            } 
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('scholars.award_number', 'ASC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $scholars = $query->select('scholars.*', 'scholars.id as scholar_id', 'applicants.*', 'awards.*', 'programs.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $scholars = $query->select('scholars.*', 'scholars.id as scholar_id', 'applicants.*', 'awards.*', 'programs.*')->paginate(10);
        }

        return view('replacements.replace', compact('applicant', 'scholars', 'institutions', 'programs', 'sort_filters'));
    }

	public function replaceBy(Scholar $scholar) {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();

        $sort_filters = array();
        $query = Applicant::query()->join('courses', 'applicants.course_id', '=', 'courses.id')
            ->where('applicants.is_accepted', '0');

        // ACADEMIC YEAR
        if(request()->filled('acad_year')) {
            $query->where('applicants.entry_acad_year', request()->acad_year);
            $sort_filters['acad_year'] = request()->acad_year;
        } else {
            $query->where('applicants.entry_acad_year', now()->month < 8 ? now()->year-1 : now()->year);
        }

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $names = explode(" ", request()->name);
            $query->where(function($query) use ($names) {
                $query->whereIn('applicants.name_first', $names);
                $query->orWhere(function($query) use ($names) {
                    $query->whereIn('applicants.name_last', $names);
                });
            });
            $sort_filters['name'] = request()->name;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            $query->where('applicants.institution_id', request()->institution);
            $sort_filters['institution'] = request()->institution;
        }

        // CMO
        if(request()->filled('cmo')) {
            if(request()->cmo == '2019') {
                $query->where('courses.cmo_2019', '!=', 'none');
            } else {
                $query->where('courses.cmo_2014', '!=', 'none');
            }
            $sort_filters['cmo'] = request()->cmo;
        }

        // VALIDATED DOCUMENTS
        if(request()->filled('are_documents_validated')) {
            $query->where('applicants.are_documents_validated', request()->are_documents_validated);
            $sort_filters['are_documents_validated'] = request()->are_documents_validated;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else if(request()->sort == 'score') {
                $query->orderBy('applicants.score', 'DESC');
            } else if(request()->sort == 'entry_date'){
                $query->orderBy('applicants.entry_date', 'DESC');
            } else {
                $query->orderBy('applicants.created_at', 'DESC');
            }
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('applicants.score', 'DESC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $applicants = $query->orderBy('name_last', 'ASC')->orderBy('name_first', 'ASC')->orderBy('name_middle', 'ASC')->select('applicants.*', 'applicants.id as applicant_id', 'courses.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $applicants = $query->orderBy('name_last', 'ASC')->orderBy('name_first', 'ASC')->orderBy('name_middle', 'ASC')->select('applicants.*', 'applicants.id as applicant_id', 'courses.*')->paginate(10);
        }

        return view('replacements.replaceby', compact('scholar', 'applicants', 'institutions', 'sort_filters'));
    }

    public function form(Applicant $applicant, Scholar $scholar)
    {
        $latest_semestral_award = SemestralAward::where('scholar_id', $scholar->id)
            ->orderBy('acad_year', 'DESC')
            ->orderBy('semester', 'DESC')
            ->first();
        $previous_remarks = $latest_semestral_award->remarks_chedro;
        return view('replacements.form', compact('applicant', 'scholar', 'previous_remarks'));
    }

    public function store(Applicant $applicant, Scholar $scholar)
    {
        // UPDATE APPLICANT

        $applicant->update([
            'is_accepted' => 1
        ]);

        // CREATE SCHOLAR

        $new_scholar = Scholar::create([
            'applicant_id' => $applicant->id,

            'award_id' => $scholar->award_id,
            'award_number' => $scholar->award_number,

            'acad_year_accepted' => request()->acad_year,
            'semester_accepted' => request()->semester,

            'latest_acad_year' => request()->acad_year,
            'latest_semester' => request()->semester,
            'latest_year_level' => 1,
            'latest_status' => 'Replacement'
        ]);

        // CREATE SEMESTRAL AWARD OF CREATED SCHOLAR

        $validated_fields = request()->validate([
            'acad_year' => 'required',
            'semester' => 'required'
        ]);

        if(request()->is_processed == 1) {
            $validated_fields['amount_chedro'] = request()->amount_chedro;
            $validated_fields['mode_of_payment'] = request()->mode_of_payment;
            $validated_fields['date_processed'] = request()->date_processed;
        } else {
            $validated_fields['amount_chedro'] = null;
            $validated_fields['mode_of_payment'] = null;
            $validated_fields['date_processed'] = null;
        }

        $validated_fields['scholar_id'] = $new_scholar->id;
        $validated_fields['status'] = 'Replacement';
        $validated_fields['current_year_level'] = 1;
        $validated_fields['remarks_chedro'] = request()->remarks_chedro == null ? null : request()->remarks_chedro;
        $validated_fields['remarks_osds'] = request()->remarks_osds == null ? null : request()->remarks_osds;
        $validated_fields['saro'] = request()->saro == null ? null : request()->saro;
        $validated_fields['nta_number'] = request()->nta_number == null ? null : request()->nta_number;

        SemestralAward::create($validated_fields);

        // CREATE OR UPDATE SEMESTRAL AWARD AND UPDATE REPLACED SCHOLAR

        // If same academic period with the latest, update the latest semestral award 
        if($scholar->latest_acad_year == request()->acad_year && $scholar->latest_semester == request()->semester) {
            $latest_semestral_award = SemestralAward::where('scholar_id', $scholar->id)
                ->where('acad_year', $scholar->latest_acad_year)
                ->where('semester', $scholar->latest_semester)
                ->first();
            $latest_semestral_award->update([
                'remarks_chedro' => request()->remarks_chedro2
            ]);

            $scholar->update([
                'latest_status' => 'Replaced',
            ]);

        // If different academic period with the latest, create a semestral award 
        } else {
            SemestralAward::create([
                'acad_year' => request()->acad_year,
                'semester' => request()->semester,
                'scholar_id' => $scholar->id,
                'status' => 'Replaced',
                'remarks_chedro' => request()->remarks_chedro2,
                'current_year_level' => (request()->acad_year - $scholar->latest_acad_year) + $scholar->latest_year_level
            ]);

            $scholar->update([
                'latest_acad_year' => request()->acad_year,
                'latest_semester' => request()->semester,
                'latest_status' => 'Replaced',
                'latest_year_level' => (request()->acad_year - $scholar->latest_acad_year) + $scholar->latest_year_level
            ]);
        }

        return redirect('/scholars/'.$new_scholar->id);
    }
}
