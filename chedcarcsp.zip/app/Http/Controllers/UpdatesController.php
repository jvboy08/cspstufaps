<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Update;
use App\Scholar;
use App\Applicant;
use App\Institution;
use App\Program;
use App\SemestralAward;
use Redirect;

class UpdatesController extends Controller
{
    public function updates_scholars() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();
        $query = Update::query()
        	->join('applicants', 'updates.applicant_id', '=', 'applicants.id')
        	->join('scholars', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
        	->join('institutions', 'updates.institution_id', '=', 'institutions.id')
            ->where('updates.field', '!=', 'status');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // STATUS
        if(request()->filled('status')) {
        	if(request()->status == 'pending') {
            	$query->where('updates.is_approved', null);
        	} else {
            	$query->where('updates.is_approved', request()->status == 'approved' ? 1 : 0);
        	}
            $sort_filters['status'] = request()->status;
        } else {
            $query->where('updates.is_approved', null);
        }

        // LABEL
        if(request()->filled('label')) {
            $query->where("updates.field", request()->label);
            $sort_filters['label'] = request()->label;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            if(request()->institution == 'outside_car') {
                $query->where('applicants.institution_id', null);
            } else {
                $query->where('applicants.institution_id', request()->institution);
            }
            $sort_filters['institution'] = request()->institution;
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
        	$updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
        	$updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(10);
        }

        return view('updates.scholars', compact('updates', 'institutions', 'programs', 'sort_filters'));
    }

    public function updates_scholars_approve(Update $update) {
    	if($update->field == 'latest_year_level') {
    		Scholar::find($update->applicant->scholar->id)->update([
    			'latest_year_level' => $update->new_value
    		]);
        } if($update->field == 'address') {
            $values = explode("|", $update->new_value);
            Applicant::find($update->applicant_id)->update([
                'perm_district' => $values[3],
                'perm_province' => $values[2],
                'perm_muni_city' => $values[1],
                'perm_barangay' => $values[0],
                'perm_zip_code' => $values[4],

                'pres_is_perm' => count($values) == 6 ? 1 : 0,
                'pres_district' => count($values) == 6 ? null : $values[8],
                'pres_province' => count($values) == 6 ? null : $values[7],
                'pres_muni_city' => count($values) == 6 ? null : $values[6],
                'pres_barangay' => count($values) == 6 ? null : $values[5],
                'pres_zip_code' => count($values) == 6 ? null : $values[9]
            ]);
        } else {
    		Applicant::find($update->applicant_id)->update([
    			$update->field => $update->new_value
    		]);
        }

		$update->update([
			'is_approved' => 1
		]);

        return Redirect::back();
    }

    public function updates_scholars_decline(Update $update) {
        $update->update([
            'is_approved' => 0
        ]);

        return Redirect::back();
    }

    public function updates_graduates() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();
        $query = Update::query()
            ->join('applicants', 'updates.applicant_id', '=', 'applicants.id')
            ->join('scholars', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->join('institutions', 'updates.institution_id', '=', 'institutions.id')
            ->where('updates.field', 'status');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // STATUS
        if(request()->filled('status')) {
            if(request()->status == 'pending') {
                $query->where('updates.is_approved', null);
            } else {
                $query->where('updates.is_approved', request()->status == 'approved' ? 1 : 0);
            }
            $sort_filters['status'] = request()->status;
        } else {
            $query->where('updates.is_approved', null);
        }

        // LABEL
        if(request()->filled('label')) {
            $query->where("updates.field", request()->label);
            $sort_filters['label'] = request()->label;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('programs.id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            if(request()->institution == 'outside_car') {
                $query->where('applicants.institution_id', null);
            } else {
                $query->where('applicants.institution_id', request()->institution);
            }
            $sort_filters['institution'] = request()->institution;
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $updates = $query->orderBy('created_at', 'DESC')->select('updates.*')->paginate(10);
        }

        return view('updates.graduates', compact('updates', 'institutions', 'programs', 'sort_filters'));
    }

    public function updates_graduates_approve(Update $update) {
        $last_semestral_award = SemestralAward::where('scholar_id', $update->applicant->scholar->id)
            ->orderBy('acad_year', 'DESC')
            ->orderBy('semester', 'DESC')
            ->first();

        $update->applicant->scholar->update([
            'latest_status' => 'Graduate'
        ]);

        $last_semestral_award->update([
            'status' => 'Graduate',
            'remarks_chedro' => $last_semestral_award->remarks_chedro != null ? $last_semestral_award.' / '.$update->remarks : $update->remarks
        ]);

        $update->update([
            'is_approved' => 1
        ]);

        return Redirect::back();
    }

    public function updates_graduates_decline(Update $update) {
        $update->update([
            'is_approved' => 0
        ]);

        return Redirect::back();
    }
}
