<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Scholar;
use App\Institution;
use App\Course;
use App\Applicant;
use Storage;

class ApplicantsController extends Controller
{
    public function index() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();

        $sort_filters = array();
        $query = Applicant::query()->join('courses', 'applicants.course_id', '=', 'courses.id');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("name_first", 'like', request()->name)
            ->orWhere("name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // ACADEMIC YEAR
        if(request()->filled('acad_year')) {
            $query->where('applicants.entry_acad_year', request()->acad_year);
            $sort_filters['acad_year'] = request()->acad_year;
        } else {
            $query->where('applicants.entry_acad_year', now()->month < 8 ? now()->year-1 : now()->year);
        }

        // STATUS
        if(request()->filled('status')) {
            $query->where('applicants.is_accepted', request()->status);
            $sort_filters['status'] = request()->status;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            if(request()->institution == 'outside_car') {
                $query->where('applicants.institution_id', null);
            } else {
                $query->where('applicants.institution_id', request()->institution);
            }
            $sort_filters['institution'] = request()->institution;
        }

        // CMO
        if(request()->filled('cmo')) {
            if(request()->cmo == '2019') {
                $query->where('courses.cmo_2019', '!=', 'none');
            } else if(request()->cmo == '2021') {
                $query->where('courses.cmo_2021', '!=', 'none');
            } else {
                $query->where('courses.cmo_2014', '!=', 'none');
            }
            $sort_filters['cmo'] = request()->cmo;
        }

        // VALIDATED DOCUMENTS
        if(request()->filled('are_documents_validated')) {
            $query->where('applicants.are_documents_validated', request()->are_documents_validated);
            $sort_filters['are_documents_validated'] = request()->are_documents_validated;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else if(request()->sort == 'score') {
                $query->orderBy('applicants.score', 'DESC');
            } else if(request()->sort == 'entry_date'){
                $query->orderBy('applicants.entry_date', 'DESC');
            } else {
                $query->orderBy('applicants.created_at', 'DESC');
            }
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('applicants.score', 'DESC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $applicants = $query->orderBy('name_last', 'ASC')->orderBy('name_first', 'ASC')->orderBy('name_middle', 'ASC')->select('applicants.*', 'applicants.id as applicant_id', 'courses.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $applicants = $query->orderBy('name_last', 'ASC')->orderBy('name_first', 'ASC')->orderBy('name_middle', 'ASC')->select('applicants.*', 'applicants.id as applicant_id', 'courses.*')->paginate(10);
        }
        
        return view('applicants.index', compact('applicants', 'institutions', 'sort_filters'));
    }

    public function import()
    {
        return view('applicants.import');
    }

    public function display()
    {   
        $path = request()->file('applicants')->getRealPath();
        $data = array_map('str_getcsv', file($path));
        $applicants = array_slice($data, $data[0][0] == 'id' ? 1 : 0);
        $new_applicants = 0;
        $errors = array();
        
        foreach($applicants as $key => $applicant) {
            // CHECK IF APPLICANT IS ALREADY ADDED
            $birthday = substr($applicant[15], 6, 4).'-'.substr($applicant[15], 3, 2).'-'.substr($applicant[15], 0, 2);
            $applicant_check = Applicant::whereRaw('LOWER(name_last) = ?', [trim(strtolower($applicant[9]))])
                ->whereRaw('LOWER(name_first) = ?', [trim(strtolower($applicant[10]))])
                ->whereRaw('LOWER(name_middle) = ?', [trim(strtolower($applicant[11]))])
                ->where('birthday', $birthday)
                ->count();

            if($applicant_check == 0) {
                // CHECK IF DEGREE PROGRAM DOES NOT EXIST 
                $course_id = Course::where('course_name', 'like', trim($applicant[30]))->first();
                if($course_id == null) {
                    array_push($errors, [$key + 1, $applicant[9].', '.$applicant[10], '"'.$applicant[30].'" was not found in the list of degree programs.']);
                } else {
                    // CHECK IF EMAIL ADDRESS ALREADY EXISTS
                    $email_check = Applicant::where('email_address', trim($applicant[17]))->first();
                    if($email_check != null) {
                        array_push($errors, [$key + 1, $applicant[9].', '.$applicant[10], "The scholar's email address is already owned by ".$email_check->alternate_full_name."."]);
                    } else {
                        // IF THERE'S NO ERROR, ADD APPLICANT
                        $institution = Institution::where('institution_name', 'like', trim($applicant[28]))->first();
                        $course_id = Course::where('course_name', 'like', trim($applicant[30]))->first()->id;

                        $type = '';
                        if(substr($applicant[25], 0, 1) == 'A') {
                            $type = 'Graduate';
                        } else if(substr($applicant[25], 0, 1) == 'B') {
                            $type = 'Graduating';
                        } else if(substr($applicant[25], 0, 1) == 'C') {
                            $type = 'ALS';
                        } else if(substr($applicant[25], 0, 1) == 'D') {
                            $type = 'PEPT';
                        }

                        $types_of_disability = [null, 'CD', 'DCI', 'LD', 'ID', 'OD', 'MPD', 'VD', 'Others'];
                        $disability = null;
                        if(substr($applicant[103], 0, 1) < 8) {
                            $disability = $types_of_disability[substr($applicant[103], 0, 1)];
                        } else if(substr($applicant[103], 0, 1) == 8) {
                            $disability = ucwords(strtolower(trim($applicant[105])));
                        }

                        $district = '';
                        if(in_array($applicant[21], ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province'])) {
                            if($applicant[21] == 'Benguet') {
                                if(strpos($applicant[20], 'Baguio')) {
                                    $district = 'Baguio';
                                } else {
                                    $district = 'Benguet';
                                }
                            } else {
                                $district = $applicant[21];
                            }
                        } else {
                            $district = $applicant[22];
                        }

                        $f_name = null;
                        if(!in_array(strtolower(trim($applicant[59])), ['na', 'null'])) {
                            if($applicant[61] != null && $applicant[62] != null) {
                                $f_name = ucwords(strtolower($applicant[59])).' '.ucwords(substr($applicant[61], 0, 1)).'. '.ucwords(strtolower($applicant[60])).' '.$applicant[62];
                            } else if($applicant[61] != null && $applicant[62] == null) {
                                $f_name = ucwords(strtolower($applicant[59])).' '.ucwords(substr($applicant[61], 0, 1)).'. '.ucwords(strtolower($applicant[60]));
                            } else if($applicant[61] == null && $applicant[62] != null) {
                                $f_name = ucwords(strtolower($applicant[59])).' '.ucwords(strtolower($applicant[60])).' '.$applicant[62];
                            } else {
                                $f_name = ucwords(strtolower($applicant[59])).' '.ucwords(strtolower($applicant[60]));
                            }
                        }

                        $m_name = null;
                        if(!in_array(strtolower(trim($applicant[59])), ['na', 'null'])) {
                            if($applicant[69] != null && $applicant[70] != null) {
                                $m_name = ucwords(strtolower($applicant[67])).' '.ucwords(substr($applicant[69], 0, 1)).'. '.ucwords(strtolower($applicant[68])).' '.$applicant[70];
                            } else if($applicant[69] != null && $applicant[70] == null) {
                                $m_name = ucwords(strtolower($applicant[67])).' '.ucwords(substr($applicant[69], 0, 1)).'. '.ucwords(strtolower($applicant[68]));
                            } else if($applicant[69] == null && $applicant[70] != null) {
                                $m_name = ucwords(strtolower($applicant[67])).' '.ucwords(strtolower($applicant[68])).' '.$applicant[70];
                            } else {
                                $m_name = ucwords(strtolower($applicant[67])).' '.ucwords(strtolower($applicant[68]));
                            }
                        }

                        $g_name = null;
                        if(!in_array(strtolower(trim($applicant[74])), ['na', 'null'])) {
                            if($applicant[76] != null && $applicant[77] != null) {
                                $m_name = ucwords(strtolower($applicant[74])).' '.ucwords(substr($applicant[76], 0, 1)).'. '.ucwords(strtolower($applicant[75])).' '.$applicant[77];
                            } else if($applicant[76] != null && $applicant[77] == null) {
                                $m_name = ucwords(strtolower($applicant[74])).' '.ucwords(substr($applicant[76], 0, 1)).'. '.ucwords(strtolower($applicant[75]));
                            } else if($applicant[76] == null && $applicant[77] != null) {
                                $m_name = ucwords(strtolower($applicant[74])).' '.ucwords(strtolower($applicant[75])).' '.$applicant[77];
                            } else {
                                $m_name = ucwords(strtolower($applicant[74])).' '.ucwords(strtolower($applicant[75]));
                            }
                        }

                        $new_applicant = Applicant::create([

                        ////////// APPLICATION DETAILS
                            'app_no' => substr($applicant[4], 11, 7),
                            'entry_date' => substr($applicant[2], 6, 4).'-'.substr($applicant[2], 3, 2).'-'.substr($applicant[2], 0, 2),
                            'entry_acad_year' => substr($applicant[7], 0, 4),
                            'is_accepted' => 0,
                            'are_documents_validated' => 0,
                            'score' => $applicant[37],

                        ////////// PERSONAL INFORMATION
                            
                            // PERSONAL DETAILS
                            'name_last' => trim($applicant[9]),
                            'name_first' => trim($applicant[10]),
                            'name_middle' => trim($applicant[11]),
                            'name_ext' => in_array(trim($applicant[12]), ['NA', null]) ? null : trim($applicant[12]),
                            'name_maiden' => null,
                            'birthday' => $birthday,
                            'birthplace' => trim($applicant[16]),
                            'sex' => $applicant[13] == 'Male' ? 'M' : 'F',
                            'civil_status' => trim($applicant[14]),
                            'citizenship' => null,

                            // CONTACT DETAILS
                            'email_address' => trim($applicant[17]),
                            'contact_number' => preg_replace("/[^0-9]/", '', trim($applicant[18])),
                            'fb_account' => in_array($applicant[24], ['NA', null]) ? null : trim($applicant[24]),

                            // PERSONAL IDENTIFICATION
                            'birth_cert' => null,
                            'id_photo' => null,

                        ////////// ADDRESS INFORMATION

                            // PERMANENT ADDRESS
                            'perm_district' => trim($district),
                            'perm_province' => trim($applicant[21]),
                            'perm_muni_city' => trim($applicant[20]),
                            'perm_barangay' => trim($applicant[19]),
                            'perm_zip_code' => $applicant[23],

                            // PRESENT ADDRESS
                            'pres_is_perm' => 1,
                            'pres_district' => null,
                            'pres_province' => null,
                            'pres_muni_city' => null,
                            'pres_barangay' => null,
                            'pres_zip_code' => null,

                        ////////// ACADEMIC INFORMATION

                            // PREVIOUS SCHOOL
                            'highschool' => trim($applicant[26]),
                            'highschool_add' => null,
                            'highschool_sector' => null,
                            'type' => $type,
                            'gwa' => $type == 'ALS' || $type == 'PEPT' ? '80' : $applicant[33],
                            'twelve_gwa' => $type == 'ALS' || $type == 'PEPT' ? '80' : $applicant[33],
                            'eleven_gwa' => null,

                            // ACADEMIC REQUIREMENTS
                            'twelve_card' => null,
                            'eleven_card' => null,

                            // FUTURE SCHOOL
                            'institution_id' => $institution == null ? null : $institution->id,
                            'hei_out_car_name' => $institution == null ? trim($applicant[28]) : null,
                            'course_id' => $course_id,

                            // OTHER SOURCES OF ASSISTANCE
                            'other_fa_agency' => $applicant[82] == 'NO' ? null : trim($applicant[84]),
                            'other_fa_type' => $applicant[82] == 'NO' ? null : trim($applicant[83]),
                            'other_fa_agency2' => null,
                            'other_fa_type2' => null,

                        ////////// FAMILY BACKGROUND

                            // FATHER
                            'f_is_living' => $applicant[66] == 'NO' ? 0 : 1,
                            'f_name' => $f_name,
                            'f_add' => $applicant[64] == null || in_array(strtolower(trim($applicant[64])), ['na', 'null']) ? null : trim($applicant[64]),
                            'f_contact_no' => null,
                            'f_occupation' => $applicant[63] == null || in_array(strtolower(trim($applicant[63])), ['na', 'null']) ? null : trim($applicant[63]),
                            'f_employer' => null,
                            'f_employer_add' => null,
                            'f_education' => trim($applicant[65]),

                            // MOTHER
                            'm_is_living' => $applicant[73] == 'NO' ? 0 : 1,
                            'm_name' => $m_name,
                            'm_add' => $applicant[71] == null || in_array(strtolower(trim($applicant[71])), ['na', 'null']) ? null : trim($applicant[71]),
                            'm_contact_no' => null,
                            'm_occupation' => $applicant[70] == null || in_array(strtolower(trim($applicant[70])), ['na', 'null']) ? null : trim($applicant[70]),
                            'm_employer' => null,
                            'm_employer_add' => null,
                            'm_education' => trim($applicant[72]),

                            // LEGAL GUARDIAN
                            'g_name' => $g_name,
                            'g_add' => $applicant[79] == null || in_array(strtolower(trim($applicant[79])), ['na', 'null']) ? null : trim($applicant[79]),
                            'g_contact_no' => null,
                            'g_occupation' => $applicant[78] == null || in_array(strtolower(trim($applicant[78])), ['na', 'null']) ? null : trim($applicant[78]),
                            'g_employer' => null,
                            'g_employer_add' => null,
                            'g_education' => null,

                            // FAMILY
                            'siblings' => $applicant[80],
                            'annual_gross_income' => $applicant[35],

                            // INCOME REQUIREMENT
                            'income_proof_type' => null,
                            'income_proof' => null,

                            // DSWD 4PS 
                            'is_dswd_4ps' => $applicant[81] == 'NO' ? 0 : 1,

                        ////////// SPECIAL GROUP

                            // IP
                            'tribe' => trim(ucwords(strtolower(str_replace(['tribe', 'Tribe'], '', $applicant[104])))),
                            'cert_indigency' => null,

                            // PWD
                            'disability' => $disability, 
                            'pwd_id' => null,

                            // SC
                            'sc_type' => null,
                            'sc_id' => null,

                            // SP
                            'sp_type' => $applicant[107] == 'YES' ? 'Dependent' : null, 
                            'sp_id' => null,

                            // ORPHAN
                            'is_orphan' => $applicant[66] == 'NO' && $applicant[73] == 'NO' ? 1 : 0,
                        ]);
                        
                        $new_applicants++;
                    }
                }
            }
        }
        return view('applicants.display', compact('new_applicants', 'errors'));
    }

    public function show(Applicant $applicant)
    {
        return view('applicants.show', compact('applicant'));
    }

    public function edit(Applicant $applicant)
    {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $courses = Course::orderBy('course_name', 'ASC')->get();
        return view('applicants.edit', compact('institutions', 'applicant', 'courses'));
    }

    public function update(Applicant $applicant)
    {
        $validated_fields = request()->validate([
            'email_address' => 'required|unique:applicants,email_address,'.$applicant->id,
        ]);

            // SCORE
        if(request()->type == 'ALS' || request()->type == 'PEPT') {
            $twelve_gwa = 80;
            $gwa = 80;
        } else {
            if(request()->filled('are_gwas_unknown')) {
                $twelve_gwa = request()->twelve_gwa;
                if(request()->type == 'Graduating') {
                    $eleven_gwa = request()->eleven_gwa;
                    $gwa = round((($eleven_gwa * 2) + $twelve_gwa) / 3);
                } else {
                    $gwa = $twelve_gwa;
                }
            } else {
                $twelve_gwa_count = 1;
                $twelve_gwa_sum = request()->twelve_gwa_1;
                if(request()->twelve_gwa_2 != null) {
                    $twelve_gwa_sum = $twelve_gwa_sum + request()->twelve_gwa_2;
                    $twelve_gwa_count++;
                }
                if(request()->twelve_gwa_3 != null) {
                    $twelve_gwa_sum = $twelve_gwa_sum + request()->twelve_gwa_3;
                    $twelve_gwa_count++;
                }
                $twelve_gwa = round($twelve_gwa_sum / $twelve_gwa_count);

                if(request()->type == 'Graduating') {
                    $eleven_gwa_count = 1;
                    $eleven_gwa_sum = request()->eleven_gwa_1;
                    if(request()->eleven_gwa_2 != null) {
                        $eleven_gwa_sum = $eleven_gwa_sum + request()->eleven_gwa_2;
                        $eleven_gwa_count++;
                    }
                    if(request()->eleven_gwa_3 != null) {
                        $eleven_gwa_sum = $eleven_gwa_sum + request()->eleven_gwa_3;
                        $eleven_gwa_count++;
                    }
                    $eleven_gwa = round($eleven_gwa_sum / $eleven_gwa_count);
                }

                if(request()->type == 'Graduate') {
                    $gwa = $twelve_gwa;
                } else {
                    $gwa = round(($twelve_gwa_sum + $eleven_gwa_sum) / ($twelve_gwa_count + $eleven_gwa_count));
                }
            }
        }

        $score = 0;

        if($gwa >= 99) {
            $score += (100 * 0.7);
        } else if($gwa >= 97) {
            $score += (95 * 0.7);
        } else if($gwa >= 95) {
            $score += (90 * 0.7);
        } else if($gwa >= 93) {
            $score += (85 * 0.7);
        } else if($gwa >= 91) {
            $score += (80 * 0.7);
        } else {
            $score += (75 * 0.7);
        }

        if(request()->annual_gross_income <= 70000) {
            $score += (100 * 0.3);
        } else if(request()->annual_gross_income <= 136000) {
            $score += (95 * 0.3);
        } else if(request()->annual_gross_income <= 202000) {
            $score += (90 * 0.3);
        } else if(request()->annual_gross_income <= 268000) {
            $score += (85 * 0.3);
        } else if(request()->annual_gross_income <= 334000) {
            $score += (80 * 0.3);
        } else {
            $score += (75 * 0.3);
        }

        if(request()->filled('is_ip') || request()->filled('is_pwd') || request()->filled('is_sc') || request()->filled('is_sp') || request()->filled('is_orphan')) {
            $score += 5;
        }

            // INITIALIZE DISABILITY
        $disability = '';
        if(request()->filled('is_pwd')) {
            if(request()->disability != 'Others') {
                $disability = request()->disability;
            } else {
                $disability = request()->disability_others;
            }
        } else {
            $disability = null;
        }

        $applicant_details = [

            ////////// APPLICATION DETAILS
            'score' => $score,
            'are_documents_validated' => 0,

            ////////// PERSONAL INFORMATION

                // PERSONAL DETAILS
            'name_last' => trim(request()->name_last),
            'name_first' => trim(request()->name_first),
            'name_middle' => request()->name_middle == null ? null : trim(request()->name_middle),
            'name_ext' => request()->name_ext == null ? null : trim(request()->name_ext),
            'name_maiden' => request()->name_maiden == null ? null : trim(request()->name_maiden),
            'birthday' => request()->birthday,
            'birthplace' => request()->birthplace == null ? null : trim(request()->birthplace),
            'sex' => request()->sex,
            'civil_status' => request()->civil_status,
            'citizenship' => request()->citizenship == null ? null : trim(request()->citizenship),

                // CONTACT DETAILS
            'email_address' => request()->email_address == null ? null : trim(request()->email_address),
            'contact_number' => request()->contact_number == null ? null : preg_replace("/[^0-9]/", '', trim(request()->contact_number)),
            'fb_account' => request()->fb_account == null ? null : trim(request()->fb_account),

            ////////// ADDRESS INFORMATION

                // PERMANENT ADDRESS
            'perm_district' => trim(request()->filled('perm_add_is_car') ? request()->perm_district : request()->perm_district2),
            'perm_province' => trim(request()->filled('perm_add_is_car') ? request()->perm_province : request()->perm_province2),
            'perm_muni_city' => trim(request()->filled('perm_add_is_car') ? request()->perm_muni_city : request()->perm_muni_city2),
            'perm_barangay' => trim(request()->perm_barangay),
            'perm_zip_code' => trim(request()->perm_zip_code),

                // PRESENT ADDRESS
            'pres_is_perm' => request()->filled('pres_is_perm') ? 1 : 0,
            'pres_district' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_district : request()->pres_district2),
            'pres_province' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_province : request()->pres_province2),
            'pres_muni_city' => request()->filled('pres_is_perm') ? null : trim(request()->filled('pres_add_is_car') ? request()->pres_muni_city : request()->pres_muni_city2),
            'pres_barangay' => request()->filled('pres_is_perm') ? null : trim(request()->pres_barangay),
            'pres_zip_code' => request()->filled('pres_is_perm') ? null : request()->pres_zip_code,

            ////////// ACADEMIC INFORMATION

                // PREVIOUS SCHOOL
            'highschool' => trim(request()->highschool),
            'highschool_add' => request()->highschool_add == null ? null : trim(request()->highschool_add),
            'highschool_sector' => request()->highschool_sector == null ? null : request()->highschool_sector,
            'type' => request()->type,
            'gwa' => $gwa,
            'twelve_gwa' => $twelve_gwa,
            'twelve_gwa_1' => in_array(request()->type, ['ALS', 'PEPT']) || request()->filled('are_gwas_unknown') || request()->twelve_gwa_1 == null ? null : request()->twelve_gwa_1,
            'twelve_gwa_2' => in_array(request()->type, ['ALS', 'PEPT']) || request()->filled('are_gwas_unknown') || request()->twelve_gwa_2 == null ? null : request()->twelve_gwa_2,
            'twelve_gwa_3' => in_array(request()->type, ['ALS', 'PEPT']) || request()->filled('are_gwas_unknown') || request()->twelve_gwa_3 == null ? null : request()->twelve_gwa_3,
            'eleven_gwa' => request()->type == 'Graduating' ? $eleven_gwa : null,
            'eleven_gwa_1' => in_array(request()->type, ['ALS', 'PEPT']) || request()->filled('are_gwas_unknown') || request()->twelve_gwa_1 == null ? null : request()->twelve_gwa_1,
            'eleven_gwa_2' => in_array(request()->type, ['ALS', 'PEPT']) || request()->filled('are_gwas_unknown') || request()->twelve_gwa_2 == null ? null : request()->twelve_gwa_2,
            'eleven_gwa_3' => in_array(request()->type, ['ALS', 'PEPT']) || request()->filled('are_gwas_unknown') || request()->twelve_gwa_3 == null ? null : request()->twelve_gwa_3,

                // IF FUTURE SCHOOL IS WITHIN CAR
            'institution_id' => request()->filled('hei_is_car') ? request()->institution_id : null,

                // IF FUTURE SCHOOL IS OUTSIDE CAR
            'hei_out_car_name' => request()->filled('hei_is_car') ? null : trim(request()->hei_out_car_name),
            'hei_out_car_address' => request()->filled('hei_is_car') ? null : trim(request()->hei_out_car_address),
            'hei_out_car_sector' => request()->filled('hei_is_car') ? null : trim(request()->hei_out_car_sector),

                // COURSE
            'course_id' => request()->course_id,

                // OTHER SOURCES OF ASSISTANCE
            'other_fa_agency' => request()->other_fa_agency == null ? null : trim(request()->other_fa_agency),
            'other_fa_type' => request()->other_fa_type == null ? null : trim(request()->other_fa_type),
            'other_fa_agency2' => request()->other_fa_agency2 == null ? null : trim(request()->other_fa_agency2),
            'other_fa_type2' => request()->other_fa_type2 == null ? null : trim(request()->other_fa_type2),

            ////////// FAMILY BACKGROUND

                // FATHER
            'f_is_living' => request()->filled('f_is_deceased') ? 0 : 1,
            'f_name' => request()->f_name == null ? null : trim(request()->f_name),
            'f_add' => request()->filled('f_is_deceased') || request()->f_add == null ? null : trim(request()->f_add),
            'f_contact_no' => request()->filled('f_is_deceased') || request()->f_contact_no == null ? null : preg_replace("/[^0-9]/", '', trim(request()->f_contact_no)),
            'f_occupation' => request()->filled('f_is_deceased') || request()->f_occupation == null ? null : trim(request()->f_occupation),
            'f_employer' => request()->filled('f_is_deceased') || request()->f_employer == null ? null : trim(request()->f_employer),
            'f_employer_add' => request()->filled('f_is_deceased') || request()->f_employer_add == null ? null : trim(request()->f_employer_add),
            'f_education' => request()->filled('f_is_deceased') || request()->f_education == null ? null : trim(request()->f_education),

                // MOTHER
            'm_is_living' => request()->filled('m_is_deceased') ? 0 : 1,
            'm_name' => request()->m_name == null ? null : trim(request()->m_name),
            'm_add' => request()->filled('m_is_deceased') || request()->m_add == null ? null : trim(request()->m_add),
            'm_contact_no' => request()->filled('m_is_deceased') || request()->m_contact_no == null ? null : preg_replace("/[^0-9]/", '', trim(request()->m_contact_no)),
            'm_occupation' => request()->filled('m_is_deceased') || request()->m_occupation == null ? null : trim(request()->m_occupation),
            'm_employer' => request()->filled('m_is_deceased') || request()->m_employer == null ? null : trim(request()->m_employer),
            'm_employer_add' => request()->filled('m_is_deceased') || request()->m_employer_add == null ? null : trim(request()->m_employer_add),
            'm_education' => request()->filled('m_is_deceased') || request()->m_education == null ? null : trim(request()->m_education),

                // LEGAL GUARDIAN
            'g_name' => request()->has_legal_guardian == 0 || request()->g_name == null ? null : trim(request()->g_name),
            'g_add' => request()->has_legal_guardian == 0 || request()->g_add == null ? null : trim(request()->g_add),
            'g_contact_no' => request()->has_legal_guardian == 0 || request()->g_contact_no == null ? null : preg_replace("/[^0-9]/", '', trim(request()->g_contact_no)),
            'g_occupation' => request()->has_legal_guardian == 0 || request()->g_occupation == null ? null : trim(request()->g_occupation),
            'g_employer' => request()->has_legal_guardian == 0 || request()->g_employer == null ? null : trim(request()->g_employer),
            'g_employer_add' => request()->has_legal_guardian == 0 || request()->g_employer_add == null ? null : trim(request()->g_employer_add),
            'g_education' => request()->has_legal_guardian == 0 || request()->g_education == null ? null : trim(request()->g_education),

                // FAMILY
            'siblings' => request()->siblings == null ? null : request()->siblings,
            'annual_gross_income' => request()->annual_gross_income,

                // INCOME REQUIREMENT
            'income_proof_type' => request()->income_proof_type == null ? null : request()->income_proof_type,

                // DSWD 4PS 
            'is_dswd_4ps' => request()->filled('is_dswd_4ps'),

            ////////// SPECIAL GROUP

                // IP
            'tribe' => request()->filled('is_ip') ? trim(ucwords(strtolower(str_replace(['tribe', 'Tribe'], '', request()->tribe)))) : null,

                // PWD
            'disability' => $disability,

                // SC
            'sc_type' => request()->filled('is_sc') ? request()->sc_type : null,

                // SP
            'sp_type' => request()->filled('is_sp') ? request()->sp_type : null,

                // ORPHAN
            'is_orphan' => request()->filled('is_orphan') ? 1 : 0
        ];

        $applicant->update($applicant_details); 

        if($applicant->is_accepted == 0) {
            return redirect('/applicants/'.$applicant->id);
        } else {
            return redirect('/scholars/'.$applicant->scholar->id);
        }
    }

    public function create_file(Applicant $applicant, $file)
    {
        return view('applicants.create_file', compact('applicant', 'file'));
    }

    public function store_file(Applicant $applicant, $file)
    {
        $path = Storage::disk('s3')->url(request()->file('file_upload')->store('documents', 's3'));
        $applicant->update([$file => $path]); 

        if($applicant->is_accepted == 0) {
            return redirect('/applicants/'.$applicant->id);
        } else {
            return redirect('/scholars/'.$applicant->scholar->id);
        }
    }

    public function edit_file(Applicant $applicant, $file)
    {
        return view('applicants.edit_file', compact('applicant', 'file'));
    }

    public function update_file(Applicant $applicant, $file)
    {
        $index = strpos($applicant->$file, 'documents/');
        Storage::disk('s3')->delete(substr($applicant->$file, $index, strlen($applicant->$file) - $index));
        $path = Storage::disk('s3')->url(request()->file('file_upload')->store('documents', 's3'));

        $applicant->update([$file => $path]); 

        if($applicant->is_accepted == 0) {
            return redirect('/applicants/'.$applicant->id);
        } else {
            return redirect('/scholars/'.$applicant->scholar->id);
        }
    }

    public function delete(Applicant $applicant)
    {
        if($applicant->birth_cert != null) {
            $index = strpos($applicant->birth_cert, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->birth_cert, $index, strlen($applicant->birth_cert) - $index));
        }
        if($applicant->id_photo != null) {
            $index = strpos($applicant->id_photo, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->id_photo, $index, strlen($applicant->id_photo) - $index));
        }
        if($applicant->twelve_card != null) {
            $index = strpos($applicant->twelve_card, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->twelve_card, $index, strlen($applicant->twelve_card) - $index));
        }
        if($applicant->eleven_card != null) {
            $index = strpos($applicant->eleven_card, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->eleven_card, $index, strlen($applicant->eleven_card) - $index));
        }
        if($applicant->income_proof != null) {
            $index = strpos($applicant->income_proof, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->income_proof, $index, strlen($applicant->income_proof) - $index));
        }
        if($applicant->cert_indigency != null) {
            $index = strpos($applicant->cert_indigency, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->cert_indigency, $index, strlen($applicant->cert_indigency) - $index));
        }
        if($applicant->pwd_id != null) {
            $index = strpos($applicant->pwd_id, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->pwd_id, $index, strlen($applicant->pwd_id) - $index));
        }
        if($applicant->sc_id != null) {
            $index = strpos($applicant->sc_id, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->sc_id, $index, strlen($applicant->sc_id) - $index));
        }
        if($applicant->sp_id != null) {
            $index = strpos($applicant->sp_id, 'documents/');
            Storage::disk('s3')->delete(substr($applicant->sp_id, $index, strlen($applicant->sp_id) - $index));
        }

        $applicant->delete();
        return redirect('/applicants');
    }
}
