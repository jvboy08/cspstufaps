<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Institution;

class InstitutionsController extends Controller
{
    public function index() {
        $sort_filters = array();
        $query = Institution::query()->orderBy('institution_name', 'ASC');

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where('institution_name', 'like', '%' . request()->name . '%');
            $sort_filters['name'] = request()->name;
        }

        // SECTOR
        if(request()->filled('sector')) {
            $query->where('sector', request()->sector);
            $sort_filters['sector'] = request()->sector;
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $institutions = $query->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $institutions = $query->paginate(10);
        }

        return view('institutions.index', compact('institutions', 'sort_filters'));
    }

    public function show(Institution $institution)
    {
        return view('institutions.show', compact('institution'));
    }

    public function create()
    {
        return view('institutions.create');
    }

    public function store()
    {
        $validated_fields = request()->validate([
            'institution_name' => 'required|unique:institutions,institution_name',
            'sector' => 'required',
            'address' => 'required',
            'institution_head' => 'nullable',
            'registrar' => 'nullable',
            'accountant' => 'nullable',
            'hei_website' => 'nullable',
            'hei_email' => 'nullable',
            'hei_contact_no' => 'nullable'
        ]);
        Institution::create($validated_fields); 
        return redirect('/academic/institutions');
    }

    public function edit(Institution $institution)
    {
        return view('institutions.edit', compact('institution'));
    }

    public function update(Institution $institution)
    {
        $validated_fields = request()->validate([
            'institution_name' => 'required|unique:institutions,institution_name,'.$institution->id,
            'sector' => 'required',
            'address' => 'required',
            'institution_head' => 'nullable',
            'registrar' => 'nullable',
            'accountant' => 'nullable',
            'hei_website' => 'nullable',
            'hei_email' => 'nullable',
            'hei_contact_no' => 'nullable'
        ]);
        
        $institution->update($validated_fields);
        return redirect('/academic/institutions');
    }

    public function delete(Institution $institution)
    {
        $institution->delete();
        return redirect('/academic/institutions');
    }
}
