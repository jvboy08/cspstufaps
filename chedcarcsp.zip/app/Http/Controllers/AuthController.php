<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Applicant;
use App\User;
use Carbon\Carbon;

class AuthController extends Controller
{
    public function index() {
    	if(Auth::check()) {
            if(auth()->user()->user_type == 'admin') {
                return redirect('/dashboard');
            }
    	}
    	return view('login.index');
    }

    public function login_admin() {
    	$credentials = request()->validate([
			'email' => 'required|email', 
			'password' => 'required'
		]);

        $user_check = User::where('email', request()->email)->first();

        if($user_check != null) {
            if($user_check->user_type == 'admin') {
                if(Auth::attempt($credentials)) { 
                    return redirect('/dashboard');
                }
            }
        }

		return back()->withErrors([
			'credentials' => 'Incorrect email or password'
		]);
    }

    public function login_scholar() {
        $credentials = request()->validate([
            'email' => 'required|email', 
            'password' => 'required'
        ]);

        $user_check = User::where('email', request()->email)->first();

        if($user_check != null) {
            if($user_check->user_type == 'scholar') {
                if($user_check->is_verified == 0) {
                    $email = $user_check->email;
                    return view('students.messages.unverified', compact('email'));
                }
                if(Auth::attempt($credentials)) { 
                    return redirect('/scholar/home');
                }
            } 
        }

        return back()->withErrors([
            'credentials' => 'Incorrect email or password'
        ]);
    }

    public function login_coordinator() {
        $credentials = request()->validate([
            'email' => 'required|email', 
            'password' => 'required'
        ]);

        $user_check = User::where('email', request()->email)->first();

        if($user_check != null) {
            if($user_check->user_type == 'coordinator') {
                if(Auth::attempt($credentials)) { 
                    return redirect('/coordinator/home');
                }
            } 
        }

        return back()->withErrors([
            'credentials' => 'Incorrect email or password'
        ]);
    }

    public function sign_up_scholar() {
        $validated_fields = request()->validate([ 
            'email' => 'required|email',
            'password' => 'required|min:8',
            'confirm_password' => 'required|same:password'
        ]);

        $user_check = User::where('email', request()->email)->first();

        if($user_check != null) {
            if($user_check->is_verified == 1) {
                return view('students.messages.existing');
            } else {
                $email = $user_check->email;
                return view('students.messages.unverified', compact('email'));
            }
        }

        $applicant_check = Applicant::where('email_address', request()->email)->where('is_accepted', 1)->first();

        if($applicant_check == null) {
            return view('students.messages.unknown');
        }

        $new_user = User::create([
            'email' => request()->email,
            'name' => $applicant_check->alternate_full_name,
            'is_verified' => 0,
            'password' => bcrypt(request()->password),
            'user_type' => 'scholar',
            'verification_code' => sha1(time()),
            'scholar_id' => $applicant_check->scholar->id
        ]);

        $details = [
            'email' => request()->email,
            'date' => Carbon::now()->toDateTimeString(),
            'verification_code' => $new_user->verification_code
        ];
        \Mail::to(request()->email)->send(new \App\Mail\VerificationMail($details));

        $email = request()->email;
        return view('students.messages.signed_up', compact('email'));
    }

    public function sign_up_coordinator() {
        $validated_fields = request()->validate([ 
            'email' => 'required|email',
            'password' => 'required|min:8',
            'confirm_password' => 'required|same:password',
            'verification_code' => 'required'
        ]);

        $user_check = User::where('email', request()->email)->first();

        if($user_check != null) {
            if($user_check->is_verified == 1) {
                return view('coordinators.messages.existing');
            } else {
                if($user_check->verification_code == request()->verification_code) {
                    $user_check->update([
                        'is_verified' => 1,
                        'password' => bcrypt(request()->password),
                    ]);
                    Auth::attempt([
                        'email' => request()->email,
                        'password' => request()->password,
                    ]);
                    return redirect('/coordinator/home');
                } else {
                    return back()->withErrors([
                        'credentials' => 'The verification code entered is incorrect'
                    ]);
                }
                $email = $user_check->email;
                return view('students.messages.unverified', compact('email'));
            }
        } else {
            return back()->withErrors([
                'credentials' => 'The email address entered does not exist in the list of school coordinators. Please contact us for more information.'
            ]);
        }
    }

    public function verify($verification_code) {
        $user_check = User::where('verification_code', $verification_code)->first();

        if($user_check != null) {
            if($user_check->is_verified == 0) {
                $user_check->update([
                    'is_verified' => 1
                ]);
            }
            return view('students.messages.verified');
        } else {
            return redirect('/');
        }
    }

    public function resend($email) {
        $user = User::where('email', $email)->first();

        $details = [
            'email' => $email,
            'date' => Carbon::now()->toDateTimeString(),
            'verification_code' => $user->verification_code
        ];

        \Mail::to(request()->email)->send(new \App\Mail\VerificationMail($details));
        return redirect('/scholar/login');
    }

    public function password($email) {
        $user = User::where('email', $email)->first();

        $details = [
            'email' => $email,
            'date' => Carbon::now()->toDateTimeString(),
            'verification_code' => $user->verification_code
        ];

        \Mail::to(request()->email)->send(new \App\Mail\VerificationMail($details));
        return redirect('/scholar/login');
    }

    public function logout() {
        $user_type = auth()->user()->user_type;
    	Auth::logout(); 
        if($user_type == 'admin') {
            return redirect('/admin'); 
        } else if($user_type == 'scholar'){
            return redirect('/scholar/login'); 
        } else {
            return redirect('/coordinator/login'); 
        }
    }
}
