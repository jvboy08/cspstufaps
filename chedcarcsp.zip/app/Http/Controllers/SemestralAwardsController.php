<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Scholar;
use App\SemestralAward;

class SemestralAwardsController extends Controller
{
    public function create(Scholar $scholar)
    {
        return view('semestralawards.create', compact('scholar'));
    }

    public function store(Scholar $scholar)
    {
        // CHECK FIRST IF THERE'S A SCHOLAR WITH THE SAME AWARD NUMBER ON THE SELECTED ACADEMIC PERIOD

        $scholar_check = Scholar::join('semestral_awards', 'semestral_awards.scholar_id', '=', 'scholars.id')
            ->where('scholars.award_number', $scholar->award_number)
            ->where('semestral_awards.acad_year', request()->acad_year)
            ->where('semestral_awards.semester', request()->semester)
            ->first();

        if($scholar_check != null) {
            return redirect(url()->previous())->withErrors(['alert' => $scholar_check->applicant->alternate_full_name." already has the same award number on the chosen academic year and semester."]);
        }

        // IF NONE, CREATE SEMESTRAL AWARD

        $validated_fields = request()->validate([
            'acad_year' => [
                'required', Rule::unique('semestral_awards')
                    ->where('semester', request()->semester)
                    ->where('scholar_id', $scholar->id)
            ],
            'semester' => [
                'required', Rule::unique('semestral_awards')
                    ->where('acad_year', request()->acad_year)
                    ->where('scholar_id', $scholar->id)
            ],
            'status' => 'required',
            'current_year_level' => 'required'
        ]);

        if(request()->is_processed == 1) {
            $validated_fields['amount_chedro'] = request()->amount_chedro;
            $validated_fields['mode_of_payment'] = request()->mode_of_payment;
            $validated_fields['date_processed'] = request()->date_processed;
        } else {
            $validated_fields['amount_chedro'] = null;
            $validated_fields['mode_of_payment'] = null;
            $validated_fields['date_processed'] = null;
        }

        $validated_fields['scholar_id'] = $scholar->id;
        $validated_fields['remarks_chedro'] = request()->remarks_chedro == null ? null : request()->remarks_chedro;
        $validated_fields['remarks_osds'] = request()->remarks_osds == null ? null : request()->remarks_osds;
        $validated_fields['saro'] = request()->saro == null ? null : request()->saro;
        $validated_fields['nta_number'] = request()->nta_number == null ? null : request()->nta_number;
        $validated_fields['thesis_title'] = request()->thesis_title == null ? null : request()->thesis_title;
        $validated_fields['thesis_allowance'] = request()->thesis_allowance == null ? null : request()->thesis_allowance;
        $validated_fields['thesis_remarks'] = request()->thesis_remarks == null ? null : request()->thesis_remarks;
        
        SemestralAward::create($validated_fields); 

        // UPDATE SCHOLAR

    	if($scholar->latest_status == null || ($scholar->latest_acad_year < request()->acad_year || ($scholar->latest_acad_year == request()->acad_year && $scholar->latest_semester < request()->semester))) {
            $scholar->latest_status = request()->status;
	        $scholar->latest_acad_year = request()->acad_year;
	        $scholar->latest_semester = request()->semester;
            $scholar->latest_year_level = request()->current_year_level;
	        $scholar->save();
    	}

        return redirect('/scholars/'.$scholar->id);
    }

    public function edit(Scholar $scholar, SemestralAward $semestral_award)
    {
        return view('semestralawards.edit', compact('scholar', 'semestral_award'));
    }

    public function update(Scholar $scholar, SemestralAward $semestral_award)
    {
        $validated_fields = request()->validate([
            'acad_year' => [
                'required', Rule::unique('semestral_awards')
                    ->ignore($semestral_award->id)
                    ->where('semester', request()->semester)
                    ->where('scholar_id', $scholar->id)
            ],
            'semester' => [
                'required', Rule::unique('semestral_awards')
                    ->ignore($semestral_award->id)
                    ->where('acad_year', request()->acad_year)
                    ->where('scholar_id', $scholar->id)
            ],
            'status' => 'required',
            'current_year_level' => 'required'
        ]);

        if(request()->is_processed == 1) {
            $validated_fields['amount_chedro'] = request()->amount_chedro;
            $validated_fields['mode_of_payment'] = request()->mode_of_payment;
            $validated_fields['date_processed'] = request()->date_processed;
        } else {
            $validated_fields['amount_chedro'] = null;
            $validated_fields['mode_of_payment'] = null;
            $validated_fields['date_processed'] = null;
        }

        $validated_fields['remarks_chedro'] = request()->remarks_chedro == null ? null : request()->remarks_chedro;
        $validated_fields['remarks_osds'] = request()->remarks_osds == null ? null : request()->remarks_osds;
        $validated_fields['saro'] = request()->saro == null ? null : request()->saro;
        $validated_fields['nta_number'] = request()->nta_number == null ? null : request()->nta_number;
        $validated_fields['thesis_title'] = request()->thesis_title == null ? null : request()->thesis_title;
        $validated_fields['thesis_allowance'] = request()->thesis_allowance == null ? null : request()->thesis_allowance;
        $validated_fields['thesis_remarks'] = request()->thesis_remarks == null ? null : request()->thesis_remarks;
        
        $semestral_award->update($validated_fields); 

        if(($scholar->latest_acad_year == request()->acad_year && $scholar->latest_semester == request()->semester ) || ($scholar->latest_acad_year < request()->acad_year) || ($scholar->latest_acad_year == request()->acad_year && $scholar->latest_semester < request()->semester)) {
            $scholar->latest_status = request()->status;
            $scholar->latest_acad_year = request()->acad_year;
            $scholar->latest_semester = request()->semester;
            $scholar->latest_year_level = request()->current_year_level;
            $scholar->save();
        }
        return redirect('/scholars/'.$scholar->id);
    }

    public function delete(Scholar $scholar, SemestralAward $semestral_award)
    {
        if(SemestralAward::where('scholar_id', $scholar->id)->count() == 1) {
            $scholar->latest_status = null;
            $scholar->latest_acad_year = null;
            $scholar->latest_semester = null;
            $scholar->latest_year_level = null;
            $scholar->save();
            $semestral_award->delete();
        } else {
            if($semestral_award->acad_year == $scholar->latest_acad_year && $semestral_award->semester == $scholar->latest_semester) {
                $second_semestral_award = SemestralAward::where('scholar_id', $scholar->id)
                    ->orderBy('acad_year', 'DESC')
                    ->orderBy('semester', 'DESC')
                    ->skip(1)->first();
                $scholar->latest_status = $second_semestral_award->status;
                $scholar->latest_acad_year = $second_semestral_award->acad_year;
                $scholar->latest_semester = $second_semestral_award->semester;
                $scholar->latest_year_level = $second_semestral_award->current_year_level;
                $scholar->save();
            }
            $semestral_award->delete();
        }
        return redirect('/scholars/'.$scholar->id);
    }
}
