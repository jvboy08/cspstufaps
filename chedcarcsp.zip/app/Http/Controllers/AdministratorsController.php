<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Auth;

class AdministratorsController extends Controller
{
    public function index() {
        $administrators = User::where('user_type', 'admin')->orderBy('name', 'ASC')->paginate(10);
        return view('administrators.index', compact('administrators'));
    }

    public function create()
    {
        return view('administrators.create');
    }

    public function store()
    {
        $validated_fields = request()->validate([ 
            'name' => 'required',
            'email' => 'required|unique:users|email',
            'password' => 'required|min:8',
            'confirm_password' => 'required|same:password'
        ]);
        $validated_fields['user_type'] = 'admin';
        $validated_fields['is_verified'] = 1;
        $validated_fields['password'] = bcrypt($validated_fields['password']);
        User::create($validated_fields); 
        return redirect('/administrators');
    }

    public function password_form()
    {
        return view('administrators.password');
    }

    public function password()
    {
        $validated_fields = request()->validate([ 
            'email' => 'required|email',
            'old_password' => 'required',
            'new_password' => 'required|min:8',
            'confirm_password' => 'required|same:new_password'
        ]);

        if(Auth::attempt(['email' => $validated_fields['email'], 'password' => $validated_fields['old_password']])) { 
                User::find(Auth::id())->update(['password' => bcrypt(request()->new_password)]);
                Auth::logout();
                return redirect('/');
        } else {
            return back()->withErrors([
                'credentials' => 'Incorrect email or password'
            ]);
        }
    }

    public function delete()
    {
        User::find(Auth::id())->delete();
        return redirect('/');
    }
}
