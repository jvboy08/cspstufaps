<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Program;
use App\Award;
use App\SemestralAward;
use App\Scholar;
use App\Applicant;
use App\Institution;

class ScholarshipsController extends Controller
{
    public function create(Applicant $applicant) {
        $programs = Program::orderBy('program_name', 'ASC')->get();
        return view('scholarships.create', compact('programs', 'applicant'));
    }

    public function store(Applicant $applicant)
    {
        // CHECK FIRST IF THERE'S A SCHOLAR WITH THE SAME AWARD NUMBER ON THE SELECTED ACADEMIC PERIOD

        $scholar_check = Scholar::join('semestral_awards', 'semestral_awards.scholar_id', '=', 'scholars.id')
            ->where('scholars.award_number', request()->award_number)
            ->where('semestral_awards.acad_year', request()->acad_year_accepted)
            ->where('semestral_awards.semester', request()->semester_accepted)
            ->first();

        if($scholar_check != null) {
            return redirect(url()->previous())->withErrors(['alert' => $scholar_check->applicant->alternate_full_name." already has the same award number on the chosen academic year and semester."]);
        }

    	// CREATE SCHOLAR

        $validated_fields = request()->validate([
            'award_number' => 'required',
            'acad_year_accepted' => 'required',
            'semester_accepted' => 'required'
        ]);

        $array = explode("-", request()->award_number);
        $year = $array[count($array) - 2];
        $program_id = Program::where('code', request()->program_id)->first()->id;
        $validated_fields['award_id'] = Award::where('program_id', $program_id)->where('award_year', '20'.$year)->first()->id;

        $validated_fields['applicant_id'] = $applicant->id;
        $validated_fields['latest_acad_year'] = request()->acad_year_accepted;
        $validated_fields['latest_semester'] = request()->semester_accepted;
        $validated_fields['latest_year_level'] = 1;
        $validated_fields['latest_status'] = 'Active';

        $scholar = Scholar::create($validated_fields);

        // UPDATE APPLICANT

        $applicant->update([
            'is_accepted' => 1
        ]);

        // CREATE SEMESTRAL AWARD 

        $validated_fields2;

        $validated_fields2['scholar_id'] = $scholar->id;
        $validated_fields2['acad_year'] = request()->acad_year_accepted;
        $validated_fields2['semester'] = request()->semester_accepted;
        $validated_fields2['current_year_level'] = 1;
        $validated_fields2['status'] = 'Active';

        if(request()->is_processed == 1) {
            $validated_fields2['amount_chedro'] = request()->amount_chedro;
            $validated_fields2['mode_of_payment'] = request()->mode_of_payment;
            $validated_fields2['date_processed'] = request()->date_processed;
        } else {
            $validated_fields2['amount_chedro'] = null;
            $validated_fields2['mode_of_payment'] = null;
            $validated_fields2['date_processed'] = null;
        }

        $validated_fields2['remarks_chedro'] = request()->remarks_chedro == null ? null : request()->remarks_chedro;
        $validated_fields2['remarks_osds'] = request()->remarks_osds == null ? null : request()->remarks_osds;
        $validated_fields2['saro'] = request()->saro == null ? null : request()->saro;
        $validated_fields2['nta_number'] = request()->nta_number == null ? null : request()->nta_number;

        SemestralAward::create($validated_fields2); 

        return redirect('/scholars/'.$scholar->id);
    }

    public function getAwards($code) {
        $program_id = Program::where('code', $code)->first()->id;
        $awards = Award::where("program_id", $program_id)
            ->orderBy('award_year', 'DESC')
            ->select("award_year", "start_slot", "end_slot")
            ->get();
        return json_encode($awards);
    }

    public function getAmount($code) {
        $amount_per_sem = Program::where('code', $code)->first()->amount_per_sem;
        return $amount_per_sem;
    }

    public function edit(Scholar $scholar) {
        $awards = Award::orderBy('award_year', 'ASC')->where('program_id', $scholar->award->program->id)->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();
        return view('scholarships.edit', compact('awards', 'programs', 'scholar'));
    }

    public function update(Scholar $scholar)
    {
        $validated_fields = request()->validate([
            'award_number' => 'required',
            'acad_year_accepted' => 'required',
            'semester_accepted' => 'required'
        ]);

        // CHECK FIRST IF THERE'S A SCHOLAR WITH THE SAME AWARD NUMBER ON THE SELECTED ACADEMIC PERIOD

        $scholar_check = Scholar::join('semestral_awards', 'semestral_awards.scholar_id', '=', 'scholars.id')
            ->where('scholars.award_number', request()->award_number)
            ->where('semestral_awards.acad_year', request()->acad_year_accepted)
            ->where('semestral_awards.semester', request()->semester_accepted)
            ->first();

        if($scholar_check != null) {
            return redirect(url()->previous())->withErrors(['alert' => $scholar_check->applicant->alternate_full_name." already has the same award number on the chosen academic year and semester."]);
        }

        // UPDATE SCHOLARSHIP

        $array = explode("-", request()->award_number);
        $year = $array[count($array) - 2];
        $program = Program::where('code', request()->program_id)->first();
        $validated_fields['award_id'] = Award::where('program_id', $program->id)->where('award_year', '20'.$year)->first()->id;

        if($scholar->semestral_awards->count() < 2) {
            $validated_fields['latest_acad_year'] = request()->acad_year_accepted;
            $validated_fields['latest_semester'] = request()->semester_accepted;
            if($scholar->semestral_awards->count() == 1) {
                $single_semestral_award = SemestralAward::where('scholar_id', $scholar->id)->first();
                $single_semestral_award->update([
                    'acad_year' => request()->acad_year_accepted,
                    'semester' => request()->semester_accepted
                ]);
            }
        }

        $scholar->update($validated_fields);

        return redirect('/scholars/'.$scholar->id);
    }

    public function delete(Scholar $scholar)
    {
        $applicant = $scholar->applicant;
        $applicant->update([
            'is_accepted' => 0
        ]);

        $semestral_awards = SemestralAward::where('scholar_id', $scholar->id)->get();
        foreach ($semestral_awards as $key => $semestral_award) {
            $semestral_award->delete();
        }
        $scholar->delete();

        return redirect('/applicants/'.$applicant->id);
    }
}
