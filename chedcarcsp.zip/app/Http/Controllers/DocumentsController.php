<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SemestralAward;
use App\Program;
use App\Scholar;
use App\Institution;
use App\BillingStatement;

class DocumentsController extends Controller
{
	public function semestral_requirements() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();

        $sort_filters = array();
        $query = Scholar::query()
            ->join('semestral_awards', 'semestral_awards.scholar_id', '=', 'scholars.id')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('semestral_awards.enrollment_form', '!=', null);

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // REVIEW STATUS
        if(request()->filled('review_status')) {
            if(request()->review_status == 0) {
                $query->where('semestral_awards.status', null);
            } else {
                $query->where('semestral_awards.status', '!=', null);
            }
            $sort_filters['review_status'] = request()->review_status;
        } else {
            $query->where('semestral_awards.status', null);
        }

        // ACADEMIC PERIOD
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('semestral_awards.acad_year', $period[0]);
            $query->where('semestral_awards.semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('awards.program_id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else {
                $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
            } 
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
        $semestral_awards = $query->select('semestral_awards.id as semestral_award_id', 'semestral_awards.*', 'scholars.id as scholar_id', 'scholars.*', 'awards.*', 'programs.*', 'applicants.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $semestral_awards = $query->select('semestral_awards.id as semestral_award_id', 'semestral_awards.*', 'scholars.id as scholar_id', 'scholars.*', 'awards.*', 'programs.*', 'applicants.*')->paginate(10);
        }

        return view('documents.semestral_requirements', compact('semestral_awards', 'sort_filters', 'programs', 'institutions'));
    }

    public function payment_requirements() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();

        $sort_filters = array();
        $query = Scholar::query()
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('programs', 'awards.program_id', '=', 'programs.id')
            ->where('scholars.school_id', '!=', null)
            ->where('scholars.atm_card', '!=', null);

        // SEARCH BY NAME
        if(request()->filled('name')) {
            $query->where("applicants.name_first", 'like', request()->name)
                ->orWhere("applicants.name_last", 'like', request()->name);
            $sort_filters['name'] = request()->name;
        }

        // ACADEMIC PERIOD STARTED
        if(request()->filled('started')) {
            $started = explode(',', request()->started);
            $query->where('scholars.acad_year_accepted', $started[0]);
            $query->where('scholars.semester_accepted', $started[1]);
            $sort_filters['started'] = request()->started;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            $query->where('applicants.institution_id', request()->institution);
            $sort_filters['institution'] = request()->institution;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('awards.program_id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'alphabetical') {
                $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
            } else {
                $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
            } 
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
        }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $scholars = $query->select('scholars.id as scholar_id', 'scholars.*')->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $scholars = $query->select('scholars.id as scholar_id', 'scholars.*')->paginate(10);
        }

        return view('documents.payment_requirements', compact('scholars', 'sort_filters', 'institutions', 'programs'));
    }

    public function billing_statements() {
        $institutions = Institution::orderBy('institution_name', 'ASC')->get();
        $programs = Program::orderBy('program_name', 'ASC')->get();

        $sort_filters = array();
        $query = BillingStatement::query();

        // REVIEW STATUS
        if(request()->filled('review_status')) {
            $query->where('is_reviewed', request()->review_status);
            $sort_filters['review_status'] = request()->review_status;
        } else {
            $query->where('is_reviewed', 0);
        }

        // ACADEMIC PERIOD
        if(request()->filled('period')) {
            $period = explode(',', request()->period);
            $query->where('acad_year', $period[0]);
            $query->where('semester', $period[1]);
            $sort_filters['period'] = request()->period;
        }

        // INSTITUTION
        if(request()->filled('institution')) {
            $query->where('applicants.institution_id', request()->institution);
            $sort_filters['institution'] = request()->institution;
        }

        // PROGRAM
        if(request()->filled('program')) {
            $query->where('awards.program_id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // SORT
        // if(request()->filled('sort')) {
        //     if(request()->sort == 'alphabetical') {
        //         $query->orderBy('applicants.name_last', 'ASC')->orderBy('applicants.name_first', 'ASC')->orderBy('applicants.name_middle', 'ASC');
        //     } else {
        //         $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
        //     } 
        //     $sort_filters['sort'] = request()->sort;
        // } else {
        //     $query->orderBy('awards.award_year', 'ASC')->orderBy('scholars.award_number', 'ASC');
        // }

        // ITEMS PER PAGE
        if(request()->filled('items')) {
            $billing_statements = $query->paginate(request()->items);
            $sort_filters['items'] = request()->items;
        } else {
            $billing_statements = $query->paginate(10);
        }

        return view('documents.billing_statements', compact('sort_filters', 'billing_statements', 'institutions', 'programs'));
    }

    public function display_scholars(BillingStatement $billing_statement) {
        $scholars = Scholar::join('awards', 'scholars.award_id', '=', 'awards.id')
            ->join('applicants', 'scholars.applicant_id', '=', 'applicants.id')
            ->join('semestral_awards', 'scholars.id', '=', 'semestral_awards.scholar_id')
            ->orderBy('awards.award_year', 'ASC')
            ->orderBy('scholars.award_number', 'ASC')
            ->orderBy('scholars.acad_year_accepted', 'ASC')
            ->where('applicants.institution_id', $billing_statement->institution_id)
            ->where('awards.program_id', $billing_statement->program_id)
            ->where('semestral_awards.acad_year', $billing_statement->semester == 1 ? $billing_statement->acad_year - 1 : $billing_statement->acad_year)
            ->where('semestral_awards.semester', $billing_statement->semester == 1 ? 2 : 1)
            ->whereIn('semestral_awards.status', ['Active', 'Replacement'])
            ->select('scholars.id as scholar_id', 'scholars.*', 'applicants.*', 'awards.*')
            ->get();

        $semestral_awards = array();

        foreach ($scholars as $key => $scholar) {
            $semestral_awards[$key] = SemestralAward::where('scholar_id', $scholar->scholar_id)
                ->where('acad_year', $billing_statement->acad_year)
                ->where('semester', $billing_statement->semester)->first();
        }

        return view('documents.display_scholars', compact('scholars', 'semestral_awards', 'billing_statement'));
    }

    public function update_is_validated(BillingStatement $billing_statement)
    {
        $billing_statement->update(['is_reviewed' => request()->value]);
        return request()->value;
    }
}
