<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use App\Award;
use App\Program;

class AwardsController extends Controller
{
    public function index() {
        $programs = Program::orderBy('program_name', 'ASC')->get();
        $sort_filters = array();
        $query = Award::query()->join('programs', 'awards.program_id', '=', 'programs.id');

        // ACADEMIC YEAR
        if(request()->filled('acad_year')) {
            $query->where('awards.award_year', request()->acad_year);
            $sort_filters['acad_year'] = request()->acad_year;
        }

        // ACADEMIC YEAR
        if(request()->filled('program')) {
            $query->where('awards.program_id', request()->program);
            $sort_filters['program'] = request()->program;
        }

        // SORT
        if(request()->filled('sort')) {
            if(request()->sort == 'program_name') {
                $query->orderBy('programs.program_name', 'ASC');
            } else if(request()->sort == 'award_year_asc') {
                $query->orderBy('awards.award_year', 'ASC')->orderBy('programs.program_name', 'ASC');
            } else if(request()->sort == 'award_year_desc') {
                $query->orderBy('awards.award_year', 'DESC')->orderBy('programs.program_name', 'ASC');
            }
            $sort_filters['sort'] = request()->sort;
        } else {
            $query->orderBy('programs.program_name', 'ASC')->orderBy('awards.award_year', 'ASC');
        }

        $awards = $query->select('awards.*', 'awards.id as award_id', 'programs.*')->paginate(10);
        return view('awards.index', compact('awards', 'sort_filters', 'programs'));
    }

    public function create()
    {
        $programs = Program::get();
        return view('awards.create', compact('programs'));
    }

    public function store()
    {
        $validated_fields = request()->validate([
            'program_id' => 'required',
            'award_year' => 'required',
            'start_slot' => 'required',
            'end_slot' => 'required'
        ]);
        Award::create($validated_fields); 
        return redirect('/awards');
    }

    public function edit(Award $award)
    {
        $programs = Program::get();
        return view('awards.edit', compact('award', 'programs'));
    }

    public function update(Award $award)
    {
        $validated_fields = request()->validate([
            'program_id' => 'required',
            'award_year' => 'required',
            'start_slot' => 'required',
            'end_slot' => 'required'
        ]);
        $award->update($validated_fields);
        return redirect('/awards');
    }

    public function delete(Award $award)
    {
        $award->delete();
        return redirect('/awards');
    }
}
