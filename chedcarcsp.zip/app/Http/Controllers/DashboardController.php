<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\SemestralAward;
use App\Applicant;
use App\ApplicationPeriod;

class DashboardController extends Controller
{
    public function index() {
        $statistics1 = array();
        $statistics1[0] = now()->month < 8 ? now()->year - 1 : now()->year;
    	$statistics1[1] = now()->month < 8 ? 2 : 1; 

    	$statistics1[2] = SemestralAward::where('status', 'Active')
    		->where('acad_year', $statistics1[0])
    		->where('semester', $statistics1[1])
    		->count();
    	$statistics1[3] = SemestralAward::where('status', 'Graduate')
    		->where('acad_year', $statistics1[0])
    		->where('semester', $statistics1[1])
    		->count();
        $statistics1[4] = SemestralAward::where('status', 'Replacement')
            ->where('acad_year', $statistics1[0])
            ->where('semester', $statistics1[1])
            ->count();
    	$statistics1[5] = SemestralAward::where('status', 'Deferred')
    		->where('acad_year', $statistics1[0])
    		->where('semester', $statistics1[1])
    		->count();
    	$statistics1[6] = SemestralAward::where('status', 'Waived')
    		->where('acad_year', $statistics1[0])
    		->where('semester', $statistics1[1])
    		->count();
    	$statistics1[7] = SemestralAward::where('status', 'Terminated')
    		->where('acad_year', $statistics1[0])
    		->where('semester', $statistics1[1])
    		->count();

        $statistics2 = array();
        $statistics2[0] = now()->year - 1;
    	$statistics2[1] = now()->month < 8 ? 1 : 2; 

    	$statistics2[2] = SemestralAward::where('status', 'Active')
    		->where('acad_year', $statistics2[0])
    		->where('semester', $statistics2[1])
    		->count();
    	$statistics2[3] = SemestralAward::where('status', 'Graduate')
    		->where('acad_year', $statistics2[0])
    		->where('semester', $statistics2[1])
    		->count();
        $statistics2[4] = SemestralAward::where('status', 'Replacement')
            ->where('acad_year', $statistics2[0])
            ->where('semester', $statistics2[1])
            ->count();
    	$statistics2[5] = SemestralAward::where('status', 'Deferred')
    		->where('acad_year', $statistics2[0])
    		->where('semester', $statistics2[1])
    		->count();
    	$statistics2[6] = SemestralAward::where('status', 'Waived')
    		->where('acad_year', $statistics2[0])
    		->where('semester', $statistics2[1])
    		->count();
    	$statistics2[7] = SemestralAward::where('status', 'Terminated')
    		->where('acad_year', $statistics2[0])
    		->where('semester', $statistics2[1])
    		->count();

        $application_periods = ApplicationPeriod::orderBy('start_date', 'desc')->take(2)->get();

    	return view('dashboard.index', compact('statistics1', 'statistics2', 'application_periods'));
    }

    public function create()
    {
        return view('dashboard.create');
    }

    public function store()
    {
        $validated_fields = request()->validate([
            'acad_year' => 'required',
            'start_date' => 'required',
            'end_date' => 'required'
        ]);
        ApplicationPeriod::create($validated_fields); 
        return redirect('/dashboard');
    }

    public function edit(ApplicationPeriod $application_period)
    {
        return view('dashboard.edit', compact('application_period'));
    }

    public function update(ApplicationPeriod $application_period)
    {
        $validated_fields = request()->validate([
            'acad_year' => 'required',
            'start_date' => 'required',
            'end_date' => 'required'
        ]);
        $application_period->update($validated_fields);
        return redirect('/dashboard');
    }

    public function delete(ApplicationPeriod $application_period)
    {
        $application_period->delete();
        return redirect('/dashboard');
    }
}
