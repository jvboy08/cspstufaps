<?php

namespace App\Http\Middleware;

use Closure;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $user_type)
    {
        if($request->user()->user_type != $user_type) {
            if($request->user()->user_type == 'admin') {
                return redirect('/dashboard');
            } else if($request->user()->user_type == 'scholar') {
                return redirect('/scholar/home');
            } else {
                return redirect('/coordinator/home');
            }
        }
        return $next($request);
    }
}
