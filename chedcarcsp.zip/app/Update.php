<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Update extends Model
{
    protected $guarded = [];

    public function applicant() {
		return $this->belongsTo(Applicant::class);
	}
	
	public function institution() {
		return $this->belongsTo(Institution::class);
	}

	public function getFullFieldAttribute() {
		if($this->field == 'institution_id') {
            return 'Institution';
        } else if($this->field == 'course_id') {
            return 'Degree Program';
        } else if($this->field == 'latest_year_level') {
            return 'Year Level';
        } else if($this->field == 'contact_number') {
            return 'Contact Number';
        } else if($this->field == 'fb_account') {
            return 'Facebook Name';
        } else if($this->field == 'email_address') {
            return 'Email Address';
        } else if($this->field == 'address') {
            return 'Address';
        }
    }

	public function getFullOldValueAttribute() {
		if($this->field == 'institution_id') {
			return Institution::find($this->old_value)->institution_name;
        } else if($this->field == 'course_id') {
			return Course::find($this->old_value)->course_name;
        } else if($this->field == 'latest_year_level'){
            if($this->old_value == 1) {
                return '1st Year';
            } else if($this->old_value == 2) {
                return '2nd Year';
            } else if($this->old_value == 3) {
                return '3rd Year';
            } else if($this->old_value == 4) {
                return '4th Year';
            } else if($this->old_value == 5) {
                return '5th Year';
            } else if($this->old_value == 6) {
                return '6th Year';
            } 
        } else {
            return $this->old_value;
        }
    }

    public function getOldPermanentAddressAttribute() {
        $values = explode("|", $this->old_value);
        return $values[0].', '.$values[1].', '.$values[2].', '.$values[3].' '.$values[4];
    }

    public function getOldPresentAddressAttribute() {
        $values = explode("|", $this->old_value);
        if(count($values) == 6) {
            return 'Same';
        } else {
            return $values[5].', '.$values[6].', '.$values[7].', '.$values[8].' '.$values[9];
        }
    }

    public function getNewPermanentAddressAttribute() {
        $values = explode("|", $this->new_value);
        return $values[0].', '.$values[1].', '.$values[2].', '.$values[3].' '.$values[4];
    }

    public function getNewPresentAddressAttribute() {
        $values = explode("|", $this->new_value);
        if(count($values) == 6) {
            return 'Same';
        } else {
            return $values[5].', '.$values[6].', '.$values[7].', '.$values[8].' '.$values[9];
        }
    }

	public function getFullNewValueAttribute() {
		if($this->field == 'institution_id') {
			return Institution::find($this->new_value)->institution_name;
        } else if($this->field == 'course_id') {
			return Course::find($this->new_value)->course_name;
        } else if($this->field == 'latest_year_level'){
            if($this->new_value == 1) {
                return '1st Year';
            } else if($this->new_value == 2) {
                return '2nd Year';
            } else if($this->new_value == 3) {
                return '3rd Year';
            } else if($this->new_value == 4) {
                return '4th Year';
            } else if($this->new_value == 5) {
                return '5th Year';
            } else if($this->new_value == 6) {
                return '6th Year';
            } 
        } else {
            return $this->new_value;
        }
    }
}

?>