<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SemestralAward extends Model
{
    protected $guarded = [];

    public function scholar() {
		return $this->belongsTo(Scholar::class);
	}

    public function getFullYearLevelAttribute() {
        if($this->current_year_level == 1) {
            return '1st Year';
        } else if($this->current_year_level == 2) {
            return '2nd Year';
        } else if($this->current_year_level == 3) {
            return '3rd Year';
        } else if($this->current_year_level == 4) {
            return '4th Year';
        } else if($this->current_year_level == 5) {
            return '5th Year';
        } else if($this->current_year_level == 6) {
            return '6th Year';
        } 
    }
}

?>