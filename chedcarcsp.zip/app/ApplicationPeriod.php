<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApplicationPeriod extends Model
{
    protected $guarded = [];
}
