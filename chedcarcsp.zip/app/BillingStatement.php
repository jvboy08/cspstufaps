<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BillingStatement extends Model
{
    protected $guarded = [];

    public function program() {
		return $this->belongsTo(Program::class);
	}
	
	public function institution() {
		return $this->belongsTo(Institution::class);
	}
}

?>