<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Applicant extends Model
{
    protected $guarded = [];

	public function institution() {
		return $this->belongsTo(Institution::class);
	}

    public function course() {
		return $this->belongsTo(Course::class);
	}

    public function scholar() {
		return $this->hasOne(Scholar::class);
	}

    public function updates() {
        return $this->hasMany(Update::class);
    }

    public function getFullNameAttribute() {
        if($this->name_middle != null && $this->name_ext != null) {
            return ucwords(strtolower($this->name_last)).', '.ucwords(strtolower($this->name_first)).' '.ucwords(substr($this->name_middle, 0, 1)).'., '.$this->name_ext;
        } else if($this->name_middle != null && $this->name_ext == null) {
            return ucwords(strtolower($this->name_last)).', '.ucwords(strtolower($this->name_first)).' '.ucwords(substr($this->name_middle, 0, 1)).'.';
        } else if($this->name_middle == null && $this->name_ext != null) {
            return ucwords(strtolower($this->name_last)).', '.ucwords(strtolower($this->name_first)).', '.$this->name_ext;
        } else {
            return ucwords(strtolower($this->name_last)).', '.ucwords(strtolower($this->name_first));
        }
    }

    public function getAlternateFullNameAttribute() {
        if($this->name_middle != null && $this->name_ext != null) {
            return ucwords(strtolower($this->name_first)).' '.ucwords(substr($this->name_middle, 0, 1)).'. '.ucwords(strtolower($this->name_last)).' '.$this->name_ext;
        } else if($this->name_middle != null && $this->name_ext == null) {
            return ucwords(strtolower($this->name_first)).' '.ucwords(substr($this->name_middle, 0, 1)).'. '.ucwords(strtolower($this->name_last));
        } else if($this->name_middle == null && $this->name_ext != null) {
            return ucwords(strtolower($this->name_first)).' '.ucwords(strtolower($this->name_last)).' '.$this->name_ext;
        } else {
            return ucwords(strtolower($this->name_first)).' '.ucwords(strtolower($this->name_last));
        }
    }

    public function getFullSpecialGroupAttribute() {
        if($this->special_grp == 'IP') {
            return 'Indigenous People';
        } else if($this->special_grp == 'PWD') {
            return 'PWD';
        } else if($this->special_grp == 'SP') {
            return 'Solo Parent';
        } else if($this->special_grp == 'SC') {
            return 'Senior Citizen';
        } else if($this->special_grp == 'O') {
            return 'Orphan';
        }
    }
    
    public function getFormattedContactNumberAttribute() {
        return substr($this->contact_number, 0, 4).'-'.substr($this->contact_number, 4, 3).'-'.substr($this->contact_number, 7, 4);
    }
    
    public function getFormattedFContactNoAttribute() {
        return substr($this->f_contact_no, 0, 4).'-'.substr($this->f_contact_no, 4, 3).'-'.substr($this->f_contact_no, 7, 4);
    }
    
    public function getFormattedMContactNoAttribute() {
        return substr($this->m_contact_no, 0, 4).'-'.substr($this->m_contact_no, 4, 3).'-'.substr($this->m_contact_no, 7, 4);
    }
    
    public function getFormattedGContactNoAttribute() {
        return substr($this->g_contact_no, 0, 4).'-'.substr($this->g_contact_no, 4, 3).'-'.substr($this->g_contact_no, 7, 4);
    }

    public function getFullTypeAttribute() {
        if($this->type == 'Graduate') {
            return 'Senior/HS Graduate';
        } else if($this->type == 'Graduating') {
            return 'Graduating SH';
        } else if($this->type == 'ALS') {
            return 'ALS';
        } else {
            return 'PEPT';
        }
    }
    
    public function getFullDisabilityAttribute() {
        if($this->disability == 'CD') {
            return 'Communication';
        } else if($this->disability == 'DCI') {
            return 'Due to Chronic Illness';
        } else if($this->disability == 'LD') {
            return 'Learning';
        } else if($this->disability == 'ID') {
            return 'Intellectual';
        } else if($this->disability == 'OD') {
            return 'Orthopedic';
        } else if($this->disability == 'MPD') {
            return 'Mental/Psychosocial';
        } else if($this->disability == 'VD') {
            return 'Visual';
        } else {
            return $this->disability;
        }
    }
}

?>