<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

////////// PUBLIC

// Index
Route::get('/', 'ApplicationsController@index')->name('login');
// List of HEIs
Route::get('/higher_education_institutions', 'ApplicationsController@heis');

////////// APPLICATIONS

// Form
Route::get('/application', 'ApplicationsController@form');
// Store
Route::post('/application/store', 'ApplicationsController@store');
// Check Applicant
Route::get('/application/check/{name_first}/{name_middle}/{name_last}/{name_ext}/{name_maiden}/{birthday}', 'ApplicationsController@check');
// Success
Route::get('/application/success', 'ApplicationsController@success');

////////// AUTH

// Admin Login
Route::post('/login', 'AuthController@login_admin');
// Scholar Login
Route::post('/scholar/login', 'AuthController@login_scholar');
// Scholar Sign Up
Route::post('/scholar/sign_up', 'AuthController@sign_up_scholar');
// Coordinator Login
Route::post('/coordinator/login', 'AuthController@login_coordinator');
// Coordinator Sign Up
Route::post('/coordinator/sign_up', 'AuthController@sign_up_coordinator');
// Email Verification
Route::get('/verify/{verification_code}', 'AuthController@verify');
// Resend Email
Route::get('/resend/{email}', 'AuthController@resend');

// Password - Enter Email
Route::get('/password/email', 'PasswordsController@email_form');
// Password - Send Email
Route::post('/password/send', 'PasswordsController@send_email');
// Password - Enter New Password
Route::get('/password/{verification_code}/edit', 'PasswordsController@edit');
// Password - Update Password
Route::put('/password/{verification_code}', 'PasswordsController@update');

////////// FOR SCHOLAR USERS //////////

// Login
Route::get('/scholar/login', 'StudentsController@login');
// Sign Up
Route::get('/scholar/sign_up', 'StudentsController@sign_up');

Route::middleware('auth', 'check_role:scholar')->group(function() {

	// Log Out
	Route::get('/scholar/logout', 'AuthController@logout');
	// Index
	Route::get('/scholar/home', 'StudentsController@index');
	// Edit
	Route::get('/scholar/{scholar}/edit', 'StudentsController@edit');
	// Update
	Route::put('/scholar/{scholar}', 'StudentsController@update');

	////////// REQUIREMENTS

	// Store 
	Route::post('/requirements/{scholar}','StudentsController@store_requirement');
	// Edit
	Route::get('/requirements/{id}/{document}/edit','StudentsController@edit_requirement');
	// Update
	Route::put('/requirements/{id}/{document}','StudentsController@update_requirement');
	// Update is_thru_hei
	Route::get('/requirements/{scholar}/is_thru_hei','StudentsController@update_is_thru_hei');

	////////// FINANCIAL BENEFITS

	// Update is_payment_received
	Route::get('/update/is_payment_received/{semestral_award}/{value}','StudentsController@update_is_payment_received');

	// CHANGE PASSWORD

	// Edit
	Route::get('/scholar/password/change','StudentsController@edit_password');
	// Update
	Route::put('/scholar/password/change','StudentsController@update_password');
}); 

////////// FOR COORDINATOR USERS //////////

// Login
Route::get('/coordinator/login', 'CoordinatorsController@login');
// Sign Up
Route::get('/coordinator/sign_up', 'CoordinatorsController@sign_up');

Route::middleware('auth', 'check_role:coordinator')->group(function() {

	// Log Out
	Route::get('/coordinator/logout', 'AuthController@logout');

	////////// HOME

	// Index
	Route::get('/coordinator/home', 'CoordinatorsController@index');
	// Edit HEI
	Route::get('/coordinator/home/institution/{institution}/edit','CoordinatorsController@edit_hei');
	// Update HEI
	Route::put('/coordinator/home/institution/{institution}','CoordinatorsController@update_hei');
	// Edit Organization
	Route::get('/coordinator/home/organization/{institution}/edit','CoordinatorsController@edit_org');
	// Update Organization
	Route::put('/coordinator/home/organization/{institution}','CoordinatorsController@update_org');

	////////// UNDERGRADUATE SCHOLARS

	// Index
	Route::get('/coordinator/undergraduates','CoordinatorsController@undergraduates');
	// Edit
	Route::get('/coordinator/undergraduates/{scholar}/edit','CoordinatorsController@undergraduates_edit');
	// Update
	Route::put('/coordinator/undergraduates/{scholar}','CoordinatorsController@undergraduates_update');

	////////// GRADUATE SCHOLARS

	// Index
	Route::get('/coordinator/graduates','CoordinatorsController@graduates');
	// View Pending
	Route::get('/coordinator/graduates/pending','CoordinatorsController@graduates_pending');
	// Create
	Route::get('/coordinator/graduates/create','CoordinatorsController@graduates_create');
	// Store
	Route::post('/coordinator/graduates/{scholar}','CoordinatorsController@graduates_store');
	// Store
	Route::put('/coordinator/graduates/{update}','CoordinatorsController@graduates_update');

	////////// UPDATES

	// Index
	Route::get('/coordinator/updates','CoordinatorsController@updates');
	// Cancel
	Route::get('/coordinator/updates/cancel/{update}','CoordinatorsController@updates_cancel');

	////////// BILLING

	// Index
	Route::get('/coordinator/billing','CoordinatorsController@billing');
	// Edit Billing Statement
	Route::get('/coordinator/billing/{program}/{acad_year}/{semester}/edit','CoordinatorsController@edit_billing');
	// Update Billing Statement
	Route::put('/coordinator/billing/{program}/{acad_year}/{semester}','CoordinatorsController@update_billing');
	// Create 
	Route::get('/coordinator/billing/document/{program}/{acad_year}/{semester}','CoordinatorsController@create_document');
	// Store 
	Route::post('/coordinator/billing/document/{program}/{acad_year}/{semester}','CoordinatorsController@store_document');
	// Edit
	Route::get('/coordinator/billing/document/{billing_statement}/edit','CoordinatorsController@edit_document');
	// Update
	Route::put('/coordinator/billing/document/{billing_statement}','CoordinatorsController@update_document');

	////////// COORDINATORS

	// index
	Route::get('/coordinator/coordinators','CoordinatorsController@coordinators');
	// Create
	Route::get('/coordinator/coordinators/create','CoordinatorsController@coordinators_create');
	// Store
	Route::post('/coordinator/coordinators/','CoordinatorsController@coordinators_store');
	// Replace Head Coordinator
	Route::get('/coordinator/coordinators/{coordinator}/replace','CoordinatorsController@coordinators_replace');
	// Delete
	Route::get('/coordinator/coordinators/{coordinator}/delete','CoordinatorsController@coordinators_delete');

	// PASSWORD

	// Edit
	Route::get('/coordinator/password/change','CoordinatorsController@edit_password');
	// Update
	Route::put('/coordinator/password/change','CoordinatorsController@update_password');
}); 

////////// FOR ADMIN USERS //////////

// Index
Route::get('/admin', 'AuthController@index');

Route::middleware('auth', 'check_role:admin')->group(function() {

	// LOG OUT
	Route::get('/logout', 'AuthController@logout');

	////////// DASHBOARD

	// Index
	Route::get('/dashboard', 'DashboardController@index');
	// Create
	Route::get('/dashboard/application_periods/create', 'DashboardController@create');
	// Store
	Route::post('/dashboard/application_periods','DashboardController@store');
	// Edit
	Route::get('/dashboard/application_periods/{application_period}/edit','DashboardController@edit');
	// Update
	Route::put('/dashboard/application_periods/{application_period}','DashboardController@update');
	// Delete
	Route::get('/dashboard/application_periods/{application_period}/delete','DashboardController@delete');

	////////// PROGRAMS

	// Index
	Route::get('/programs','ProgramsController@index');
	// Create
	Route::get('/programs/create','ProgramsController@create');
	// Store
	Route::post('/programs','ProgramsController@store');
	// Edit
	Route::get('/programs/{program}/edit','ProgramsController@edit');
	// Update
	Route::put('/programs/{program}','ProgramsController@update');
	// Delete
	Route::get('/programs/{program}/delete','ProgramsController@delete');

	////////// AWARDS

	// Index
	Route::get('/awards', 'AwardsController@index');
	// Create
	Route::get('/awards/create','AwardsController@create');
	// Store
	Route::post('/awards','AwardsController@store');
	// Edit
	Route::get('/awards/{award}/edit','AwardsController@edit');
	// Update
	Route::put('/awards/{award}','AwardsController@update');
	// Delete
	Route::get('/awards/{award}/delete','AwardsController@delete');

	////////// APPLICANTS

	// Index
	Route::get('/applicants', 'ApplicantsController@index');
	// Import
	Route::get('/applicants/import', 'ApplicantsController@import');
	// Display
	Route::post('/applicants/display', 'ApplicantsController@display');
	// Show
	Route::get('/applicants/{applicant}', 'ApplicantsController@show');
	// Edit Information
	Route::get('/applicants/{applicant}/edit', 'ApplicantsController@edit');
	// Update Information
	Route::put('/applicants/{applicant}', 'ApplicantsController@update');
	// Create File
	Route::get('/applicants/{applicant}/file/{file}/create','ApplicantsController@create_file');
	// Store File
	Route::post('/applicants/{applicant}/file/{file}','ApplicantsController@store_file');
	// Edit File
	Route::get('/applicants/{applicant}/file/{file}/edit', 'ApplicantsController@edit_file');
	// Update File
	Route::put('/applicants/{applicant}/file/{file}', 'ApplicantsController@update_file');
	// Delete
	Route::get('/applicants/{applicant}/delete', 'ApplicantsController@delete');

	////////// SCHOLARS

	// Index
	Route::get('/scholars', 'ScholarsController@index');
	// Show
	Route::get('/scholars/{scholar}', 'ScholarsController@show');
	// Edit
	Route::get('/scholars/{applicant}/edit','ApplicantsController@edit');
	// Update
	Route::put('/scholars/{applicant}','ScholarsController@update');
	// Delete
	Route::get('/scholars/{scholar}/delete','ScholarsController@delete');

	////////// SCHOLARSHIPS

	// Create
	Route::get('/applicants/{applicant}/scholarships/create','ScholarshipsController@create');
	// Store
	Route::post('/applicants/{applicant}/scholarships','ScholarshipsController@store');
	// Edit
	Route::get('/scholars/{scholar}/scholarships/edit','ScholarshipsController@edit');
	// Update
	Route::put('/scholars/{scholar}/scholarships','ScholarshipsController@update');
	// Delete
	Route::get('/scholars/{scholar}/scholarships/delete','ScholarshipsController@delete');

	// Get Awards
	Route::get('/award_numbers/get/{code}', 'ScholarshipsController@getAwards');
	// Get Amount
	Route::get('/program_amount/get/{code}', 'ScholarshipsController@getAmount');

	////////// REPLACEMENTS

	// Replace Scholar
	Route::get('/scholars/{applicant}/replace_scholar','ReplacementsController@replace');
	// Replace By Scholar
	Route::get('/scholars/{scholar}/replace_by_scholar','ReplacementsController@replaceBy');

	// Form
	Route::get('/scholars/{applicant}/replace_scholar/{scholar}','ReplacementsController@form');
	// Store
	Route::post('/scholars/{applicant}/replace_scholar/{scholar}','ReplacementsController@store');
	// Undo
	Route::get('/scholars/{scholar}/undo','ReplacementsController@undo');

	////////// SEMESTRAL AWARDS

	// Create
	Route::get('/scholars/{scholar}/semestral_awards/create','SemestralAwardsController@create');
	// Store
	Route::post('/scholars/{scholar}/semestral_awards','SemestralAwardsController@store');
	// Edit
	Route::any('/scholars/{scholar}/semestral_awards/{semestral_award}/edit','SemestralAwardsController@edit');
	// Update
	Route::put('/scholars/{scholar}/semestral_awards/{semestral_award}','SemestralAwardsController@update');
	// Delete
	Route::any('/scholars/{scholar}/semestral_awards/{semestral_award}/delete','SemestralAwardsController@delete');

	////////// INSTITUTIONS

	// Index
	Route::get('/academic/institutions', 'InstitutionsController@index');
	// Create
	Route::get('/academic/institutions/create','InstitutionsController@create');
	// Show
	Route::get('/academic/institutions/{institution}','InstitutionsController@show');
	// Store
	Route::post('/academic/institutions','InstitutionsController@store');
	// Edit
	Route::get('/academic/institutions/{institution}/edit','InstitutionsController@edit');
	// Update
	Route::put('/academic/institutions/{institution}','InstitutionsController@update');
	// Delete
	Route::get('/academic/institutions/{institution}/delete','InstitutionsController@delete');


	////////// DEGREE PROGRAMS

	// Index
	Route::get('/academic/degree_programs', 'CoursesController@index');
	// Create
	Route::get('/academic/degree_programs/create','CoursesController@create');
	// Store
	Route::post('/academic/degree_programs','CoursesController@store');
	// Edit
	Route::any('/academic/degree_programs/{course}/edit','CoursesController@edit');
	// Update
	Route::put('/academic/degree_programs/{course}','CoursesController@update');
	// Delete
	Route::any('/academic/degree_programs/{course}/delete','CoursesController@delete');

	////////// SCHOOL COORDINATORS

	// Index
	Route::get('/academic/school_coordinators', 'SchoolCoordinatorsController@index');
	// Create
	Route::get('/academic/school_coordinators/create','SchoolCoordinatorsController@create');
	// Store
	Route::post('/academic/school_coordinators','SchoolCoordinatorsController@store');
	// Edit
	Route::any('/academic/school_coordinators/{school_coordinator}/edit','SchoolCoordinatorsController@edit');
	// Update
	Route::put('/academic/school_coordinators/{school_coordinator}','SchoolCoordinatorsController@update');
	// Delete
	Route::any('/academic/school_coordinators/{school_coordinator}/delete','SchoolCoordinatorsController@delete');

	////////// DOCUMENTS

	// Payment Requirements
	Route::get('/documents/payment_requirements', 'DocumentsController@payment_requirements');
	// Semestral Requirements
	Route::get('/documents/semestral_requirements', 'DocumentsController@semestral_requirements');

	// Billing Statements
	Route::get('/documents/billing_statements', 'DocumentsController@billing_statements');
	// Display Scholars
	Route::get('/documents/billing_statements/{billing_statement}', 'DocumentsController@display_scholars');
	// Update is_payment_received
	Route::get('/update/is_validated/{billing_statement}/{value}','DocumentsController@update_is_validated');

	////////// PAYMENTS

	// Index
	Route::get('/payments', 'PaymentsController@index');
	// Set Amount
	Route::put('/payments/set_amount','PaymentsController@setAmount');

	////////// UPDATES

	// Scholars
	Route::get('/updates/scholars', 'UpdatesController@updates_scholars');
	// Approve
	Route::get('/updates/scholars/approve/{update}', 'UpdatesController@updates_scholars_approve');
	// Decline
	Route::get('/updates/scholars/decline/{update}', 'UpdatesController@updates_scholars_decline');

	// Index
	Route::get('/updates/graduates', 'UpdatesController@updates_graduates');
	// Approve
	Route::get('/updates/graduates/approve/{update}', 'UpdatesController@updates_graduates_approve');
	// Decline
	Route::get('/updates/graduates/decline/{update}', 'UpdatesController@updates_graduates_decline');

	////////// REPORTS

	// Index
	Route::get('/reports', 'ReportsController@index');
	// Database
	Route::get('/reports/database', 'ReportsController@database');
	// Yearly
	Route::get('/reports/yearly', 'ReportsController@yearly');
	// Semestral
	Route::get('/reports/semestral', 'ReportsController@semestral');
	// Semestral and Program
	Route::get('/reports/semestral_program', 'ReportsController@semestral_program');

	////////// ADMINISTRATORS

	// Index
	Route::get('/administrators', 'AdministratorsController@index');
	// Create
	Route::get('/administrators/create','AdministratorsController@create');
	// Store
	Route::post('/administrators','AdministratorsController@store');
	// Change Password Form
	Route::get('/administrators/password','AdministratorsController@password_form');
	// Change Password Form
	Route::put('/administrators/password','AdministratorsController@password');
	// Delete
	Route::get('/administrators/delete','AdministratorsController@delete');

}); 