@extends('layouts.master')

@section('title')
CHED-CAR Admin | Dashboard
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Edit an Application Period</h1>
		<a class="add" href="/dashboard">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/dashboard/application_periods/{{ $application_period->id }}">
		@method('PUT')
		@csrf

		<!-- ACADEMIC YEAR -->
		<label for="acad_year">Academic Year :</label>
		<select name="acad_year" required>
			<option value="" disabled selected hidden>Select an academic year</option>
			@for($i = 2016; $i <= now()->year; $i++)
		        <option value="{{$i}}" {{ $application_period->acad_year == $i ? 'selected' : '' }}>{{ $i }} - {{ $i+1 }}</option>
		    @endfor
		</select>

		<!-- START DATE -->
		<label for="start_date">Start Date <span class="optional">(dd/mm/yyyy)</span> :</label>
		<input type="date" name="start_date" value="{{ $application_period->start_date }}" required>

		<!-- END DATE -->
		<label for="end_date">End Date <span class="optional">(dd/mm/yyyy)</span> :</label>
		<input type="date" name="end_date" value="{{ $application_period->end_date }}" required>

		<input type="submit" value="Submit Changes">
	</form>
</section>
@endsection