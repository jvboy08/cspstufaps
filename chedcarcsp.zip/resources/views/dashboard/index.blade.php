@extends('layouts.master')

@section('title')
CHED-CAR Admin | Dashboard
@endsection

@section('body')
<section class="dashboard">
  <div class="dashboard_left">
    <h1>Academic Year {{ $statistics1[0] }} - {{ $statistics1[0]+1 }}, {{ $statistics1[1] == 1 ? '1st' : '2nd' }} Semester</h1>
    <div class="statistics first">
      <div class="stat">
        <span class="material-icons-round">done_outline</span>
        <h2>{{ $statistics1[2] }} Active</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">school</span>
        <h2>{{ $statistics1[3] }} {{ $statistics1[3] == 1 ? 'Graduate' : 'Graduates' }}</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">published_with_changes</span>
        <h2>{{ $statistics1[4] }} {{ $statistics1[4] == 1 ? 'Replacement' : 'Replacements' }}</h2>
      </div>

      <div class="stat">
        <span class="material-icons-round">today</span>
        <h2>{{ $statistics1[5] }} Deferred</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">exit_to_app</span>
        <h2>{{ $statistics1[6] }} Waived</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">block</span>
        <h2>{{ $statistics1[7] }} Terminated</h2>
      </div>
    </div>

    <h1>Academic Year {{ $statistics2[0] }} - {{ $statistics2[0]+1 }}, {{ $statistics2[1] == 1 ? '1st' : '2nd' }} Semester</h1>
    <div class="statistics">
      <div class="stat">
        <span class="material-icons-round">done_outline</span>
        <h2>{{ $statistics2[2] }} Active</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">school</span>
        <h2>{{ $statistics2[3] }} {{ $statistics2[3] == 1 ? 'Graduate' : 'Graduates' }}</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">published_with_changes</span>
        <h2>{{ $statistics2[4] }} {{ $statistics2[4] == 1 ? 'Replacement' : 'Replacements' }}</h2>
      </div>

      <div class="stat">
        <span class="material-icons-round">today</span>
        <h2>{{ $statistics2[5] }} Deferred</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">exit_to_app</span>
        <h2>{{ $statistics2[6] }} Waived</h2>
      </div>
      <div class="stat">
        <span class="material-icons-round">block</span>
        <h2>{{ $statistics2[7] }} Terminated</h2>
      </div>
    </div>
  </div>
  <div class="dashboard_right">
    @if(date("H") < 12)
      <h1>Good Morning!</h1>
    @elseif(date("H") >= 12 && date("H") < 18)
      <h1>Good Afternoon!</h1>
    @elseif(date("H") >= 18)
      <h1>Good Evening!</h1>
    @endif
    <div class="stat date">
      <span class="material-icons-round">today</span>
      <div>
        <h3>{{ date('D', strtotime(now())) }}, {{ date('M d', strtotime(now())) }}</h3>
      </div>
    </div>
    <div class="header">
      @if(!$application_periods->isEmpty())
      <h3>Application Periods</h3>
      @else
      <h3>No Application Periods Found</h3>
      @endif
      <a class="add" href="/dashboard/application_periods/create">Add</a>
    </div>
    <div class="statistics periods">
      @if(!$application_periods->isEmpty())
      @foreach($application_periods as $application_period)
      <div class="period">
        <h2>{{ date('M j, Y', strtotime($application_period->start_date)) }} to {{ date('M j, Y', strtotime($application_period->end_date)) }}</h2>
        <div class="bottom">
          <h4>A.Y. {{ $application_period->acad_year }}</h4>
          <div>
            <a href="/dashboard/application_periods/{{ $application_period->id }}/edit">
            <div><span class="material-icons-round">edit</span><p>Edit</p></div>
            </a>
            <a href="/dashboard/application_periods/{{ $application_period->id }}/delete" onclick="return confirm('Are you sure you want to delete this application period?')">
            <div><span class="material-icons-round">delete</span><p>Delete</p></div>
            </a>
          </div>
        </div>
      </div>
      @endforeach
      @endif
    </div>
  </div>
</section>
@endsection
