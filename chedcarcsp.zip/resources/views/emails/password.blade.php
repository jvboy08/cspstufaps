<!doctype html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" type="text/css" href="/css/style.css?v=1">
	<link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&display=swap" rel="stylesheet">
	<title>CHED-CAR CSP</title>
	<style type="text/css">
		body.email {
			background-color: #F5F5F5;
			padding-top: 50px;
			padding-bottom: 50px;
		}

		.email .box {
			width: 100%;
		}

		.email .container {
			margin: 0 auto;
			width: 600px;
			background-color: white;
			border-top: 4px solid #0038A8;
			text-align: center;
			display: block;
		}

		.email .logo {
			margin-top: 30px;
			display: block;
			width: 100%;
			text-align: center;	
		}

		.email .svg1 {
			margin-top: 50px;
			width: 30%;
			margin-bottom: 50px;
		}

		.email a.button {
		    text-decoration: none;
		    padding: 0.7vw 1.2vw;
		    border-radius: 0.5vw;
		    background: #0038A8;
		}

		.email .svg2 {
			width: 75px;
		}

		.email .message {
			padding: 5% 10% 10%;
		}

		.email p {
			text-align: left;
			color: #000;
			font-weight: 500;
		}
	</style>
</head>
<body class="email">
	<div class="box">
		<div class="container">
			<img class="svg1" src="https://drive.google.com/uc?export=view&id=1Gh3zuBrz3Hy_jyAKX5CMLjy_CjT4hosU">
			<div class="message">
				<h2 style="font-family: Lora; font-size: 23px; color: #0038A8">Reset Your Password</h2>
				<p style="font-family: Lora">A request has been received to update the password for your CHED-CAR CSP account. Please click the button below to complete the process:</p><br>
				<a class="button" href="http://127.0.0.1:8000/password/{{ $details['verification_code'] }}/edit"><p style="font-family: Lora; color: #fff; font-weight: 700; text-align: center; margin: 0; padding: 0;">Reset Password</p></a><br><br>
				<p style="font-family: Lora">If you did not initiate this request, you can safely ignore this message.</p><br>
				<p style="font-family: Lora">Warm regards,</p>
				<p style="font-family: Lora; font-weight: 700;">CHED-CAR</p>
			</div>
		</div>
		<div class="logo">
			<p style="font-family: Lora; color: #858585; text-align: center">© 2021 CHED-CAR. All rights reserved.</p>
		</div>
	</div>
	<span style="opacity: 0"> {{ $details['date'] }} </span>
</body>
</html>