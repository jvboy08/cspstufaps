@extends('layouts.master')

@section('title')
CHED-CAR Admin | Updates
@endsection

@section('body')
<section>
	<div class="header">
		@if(!array_key_exists('status', $sort_filters) || (array_key_exists('status', $sort_filters) && $sort_filters['status'] == 'pending'))
			@if(!$updates->isEmpty())
			<h1 class="result">{{ $updates->total()}} {{ $updates->total() > 1 ? 'Pending Scholar Information Updates' : 'Pending Scholar Information Update' }} Found</h1>
			@else
			<h1 class="result">No Pending Scholar Information Updates Found</h1>
			@endif
		@elseif(array_key_exists('status', $sort_filters) && $sort_filters['status'] == 'approved')
			@if(!$updates->isEmpty())
			<h1 class="result">{{ $updates->total()}} {{ $updates->total() > 1 ? 'Approved Scholar Information Updates' : 'Approved Scholar Information Update' }} Found</h1>
			@else
			<h1 class="result">No Approved Scholar Information Updates Found</h1>
			@endif
		@elseif(array_key_exists('status', $sort_filters) && $sort_filters['status'] == 'declined')
			@if(!$updates->isEmpty())
			<h1 class="result">{{ $updates->total()}} {{ $updates->total() > 1 ? 'Declined Scholar Information Updates' : 'Declined Scholar Information Update' }} Found</h1>
			@else
			<h1 class="result">No Declined Scholar Information Updates Found</h1>
			@endif
		@endif
		<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
	</div>
	<div class="functions">
		<form action="/updates/scholars" method="GET">
			<div class="filter">
				<div class="pairs">

					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Name</h3>
						@if(array_key_exists('name', $sort_filters))
						<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
						@else						
						<input type="text" name="name" placeholder="Enter last or first name" id="name">
						@endif
					</div>

					<!-- STATUS -->
					<div class="pair">
						<h3>Status</h3>
						<select name="status">
							@if(array_key_exists('status', $sort_filters))
								<option value="pending" {{ $sort_filters['status'] == 'pending' ? 'selected' : ''}}>Pending</option>
								<option value="approved" {{ $sort_filters['status'] == 'approved' ? 'selected' : ''}}>Approved</option>
								<option value="declined" {{ $sort_filters['status'] == 'declined' ? 'selected' : ''}}>Declined</option>
							@else
								<option value="pending">Pending</option>
								<option value="approved">Approved</option>
								<option value="declined">Declined</option>
							@endif
						</select>
					</div>

					<!-- LABEL -->
					<div class="pair">
						<h3>Label</h3>
						<select name="label">
							<option value="" disabled selected hidden>Select a label</option>
							@if(array_key_exists('label', $sort_filters))
								<option value="institution_id" {{ $sort_filters['label'] == 'institution_id' ? 'selected' : ''}}>Institution</option>
								<option value="course_id" {{ $sort_filters['label'] == 'course_id' ? 'selected' : ''}}>Degree Program</option>
								<option value="latest_year_level" {{ $sort_filters['label'] == 'latest_year_level' ? 'selected' : ''}}>Current Year Level</option>
								<option value="email_address" {{ $sort_filters['label'] == 'email_address' ? 'selected' : ''}}>Email Address</option>
								<option value="contact_number" {{ $sort_filters['label'] == 'contact_number' ? 'selected' : ''}}>Contact Number</option>
								<option value="fb_account" {{ $sort_filters['label'] == 'fb_account' ? 'selected' : ''}}>Facebook Account</option>
								<option value="address" {{ $sort_filters['label'] == 'address' ? 'selected' : ''}}>Address</option>
							@else
								<option value="institution_id">Institution</option>
								<option value="course_id">Degree Program</option>
								<option value="latest_year_level">Current Year Level</option>
								<option value="email_address">Email Address</option>
								<option value="contact_number">Contact Number</option>
								<option value="fb_account">Facebook Account</option>
								<option value="address">Address</option>
							@endif
						</select>
					</div>
				</div>
				<div class="pair">
					<button type="button" class="clear" onclick="resetAll()">Reset</button>
					<input type="submit" value="Submit">
				</div>
			</div>
			<div class="filter">
				<div class="pairs">
					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							<option value="" disabled selected hidden>Select a program</option>
							@if(array_key_exists('program', $sort_filters))
							@foreach($programs as $program)
								<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
							@endforeach
							@else
							@foreach($programs as $program)
								<option value="{{ $program->id }}">{{ $program->code }}</option>
							@endforeach
							@endif
						</select>
					</div>
					
					<!-- INSTITUTION -->
					<div class="pair">
						<h3>Institution</h3>
						<select name="institution">
							<option value="" disabled selected hidden>Select a higher education institution</option>
							@if(array_key_exists('institution', $sort_filters))
							<option value="outside_car" {{ $sort_filters['institution'] == 'outside_car' ? 'selected' : '' }}>Institution Outside CAR</option>
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}" {{ $institution->id == $sort_filters['institution'] ? 'selected' : '' }}>{{ $institution->institution_name }}</option>
							@endforeach
							@else
							<option value="outside_car">Institution Outside CAR</option>
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}">{{ $institution->institution_name }}</option>
							@endforeach
							@endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$updates->isEmpty())
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Label</th>
					<th>Previous Value</th>
					<th>New Value</th>
					<th>Status</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($updates as $key => $update)
					<tr>
						<td>{{ $key + $updates->firstItem() }}</td>
						<td style="white-space: nowrap;">{{ $update->applicant->full_name }}</td>
						<td style="white-space: nowrap;">{{ $update->full_field }}</td>
						@if($update->field == 'email_address')
						<td style="word-break: break-all;">{{ $update->full_old_value }}</td>
						<td style="word-break: break-all;">{{ $update->full_new_value }}</td>
						@elseif($update->field == 'contact_number')
						<td>{{ substr($update->old_value, 0, 4).'-'.substr($update->old_value, 4, 3).'-'.substr($update->old_value, 7, 4) }}</td>
						<td>{{ substr($update->new_value, 0, 4).'-'.substr($update->new_value, 4, 3).'-'.substr($update->new_value, 7, 4) }}</td>
						@elseif($update->field == 'address')
						<td>Permanent: {{ $update->old_permanent_address }}<br><br>Present: {{ $update->old_present_address }}</td>
						<td>Permanent: {{ $update->new_permanent_address }}<br><br>Present: {{ $update->new_present_address }}</td>
						@else
						<td>{{ $update->full_old_value }}</td>
						<td>{{ $update->full_new_value }}</td>
						@endif
						@if($update->is_approved == null)
						<td class="settings">
						<a href="/updates/scholars/approve/{{ $update->id }}" onclick="return confirm('Are you sure you want to approve this update?')">
						<div><span class="material-icons-round">done</span></div>
						</a>
						<a href="/updates/scholars/decline/{{ $update->id }}" onclick="return confirm('Are you sure you want to decline this update?')">
						<div><span class="material-icons-round">close</span></div>
						</a>
						</td>
						@else
						<td><p class="table_status">{{ $update->is_approved == 1 ? 'Approved' : 'Declined' }}</p></td>
						@endif
						<td class="settings">
							<a href="/scholars/{{ $update->applicant->scholar->id }}" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous">{{ $updates->links() }}</div>
	</div>
	@endif
</section>
<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
		document.getElementById('name').value = null;
	}
</script>
@endsection
