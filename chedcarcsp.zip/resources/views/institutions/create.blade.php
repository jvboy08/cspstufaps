@extends('layouts.master')

@section('title')
CHED-CAR Admin | Institutions
@endsection

@section('body')
<section class="form full">
	<div class="header">
		<h1>Add an Institution</h1>
		<a class="add" href="/academic/institutions">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/academic/institutions"> 
		@csrf 
		<div class="columns">
			<div class="column">
				<h3>General Information</h3>

				<!-- NAME -->
				<label for="institution_name">Name :</label>
				<input type="text" name="institution_name" placeholder="Enter institution name" required>

				<!-- SECTOR -->
				<label for="sector">Sector :</label>
				<select name="sector" required>
					<option value="P">Private</option>
					<option value="SUC">State Universities and Colleges</option>
					<option value="LUC">Public Universities and Colleges</option>
					<option value="OGS">Other Govt. Schools</option>
				</select>

				<!-- NAME -->
				<label for="address">Address :</label>
				<input type="text" name="address" placeholder="Enter address of institution" required>
			</div>
			<div class="column">
				<h3>Organization Heads</h3>

				<!-- HEAD OF INSTITUTION -->
				<label for="institution_head">Head of Institution <span class="optional">(Optional)</span> :</label>
				<input type="text" name="institution_head" placeholder="Enter head of institution">
				
				<!-- REGISTRAR -->
				<label for="registrar">University Registrar <span class="optional">(Optional)</span> :</label>
				<input type="text" name="registrar" placeholder="Enter university registrar">
				
				<!-- CHIEF ACCOUNTANT -->
				<label for="accountant">Chief Accountant <span class="optional">(Optional)</span> :</label>
				<input type="text" name="accountant" placeholder="Enter chief accountant">
			</div>

			<div class="column">
				<h3>Contact Details</h3>

				<!-- HEAD OF INSTITUTION -->
				<label for="hei_email">Email Address <span class="optional">(Optional)</span> :</label>
				<input type="text" name="hei_email" placeholder="Enter email address">
				
				<!-- HEAD OF INSTITUTION -->
				<label for="hei_contact_no">Contact Number <span class="optional">(Optional)</span> :</label>
				<input type="text" name="hei_contact_no" placeholder="Enter contact number">
				
				<!-- HEAD OF INSTITUTION -->
				<label for="hei_website">Website Link <span class="optional">(Optional)</span> :</label>
				<input type="text" name="hei_website" placeholder="Enter website link">

				<input type="submit" value="Submit">
			</div>	
		</div>
	</form>
</section>
@endsection