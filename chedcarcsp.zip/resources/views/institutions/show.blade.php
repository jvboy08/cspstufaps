@extends('layouts.master')

@section('title')
CHED-CAR Admin | Institutions
@endsection

@section('body')
<section class="form full">
	<div class="header">
		<h1>{{ $institution->institution_name }}</h1>
		<a class="add" href="/academic/institutions">Go back</a>
	</div>
	<div class="view">
		<div class="columns">
			<div class="column pairs">
				<p>School Sector :</p>
				<p>{{ $institution->full_sector }}</p>
			</div>
			<div class="column pairs">
				<p>School Address :</p>
				<p>{{ $institution->address }}</p>
			</div>
		</div>
		<div class="columns">
			<div class="column">
				<h1>Organization Heads</h1>
			</div>
		</div>
		<div class="columns">
			<div class="column pairs">
				<p>Institution Head :</p>
				<p>{{ $institution->institution_head == null ? 'N/A' : $institution->institution_head }}</p>
				<p>University Registrar :</p>
				<p>{{ $institution->registrar == null ? 'N/A' : $institution->registrar }}</p>
			</div>
			<div class="column pairs">
				<p>Chief Accountant :</p>
				<p>{{ $institution->accountant == null ? 'N/A' : $institution->accountant }}</p>
			</div>
		</div>
		<div class="columns">
			<div class="column">
				<h1>Contact Details</h1>
			</div>
		</div>
		<div class="columns">
			<div class="column pairs">
				<p>Email Address :</p>
				<p>{{ $institution->hei_email == null ? 'N/A' : $institution->hei_email }}</p>
				<p>Contact Number :</p>
				<p>{{ $institution->hei_contact_no == null ? 'N/A' : $institution->hei_contact_no }}</p>
			</div>
			<div class="column pairs">
				<p>Website Link :</p>
				<p>{{ $institution->hei_website == null ? 'N/A' : $institution->hei_website }}</p>
			</div>
		</div>
	</div>
</section>
@endsection