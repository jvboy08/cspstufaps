@extends('layouts.master')

@section('title')
CHED-CAR Admin | Institutions
@endsection

@section('body')
<section class="institutions">
	<div class="header">
		@if(!$institutions->isEmpty())
		<h1 class="result">{{ $institutions->total()}} {{ $institutions->total() > 1 ? 'Higher Education Institutions' : 'Higher Education Institution' }} Found</h1>
		@else
		<h1 class="result">No Higher Education Institutions Found</h1>
		@endif
		<div class="header_buttons">
			<a class="add" href="/academic/institutions/create">Add an institution</a>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/academic/institutions" method="GET">
			<div class="filter">
				<div class="pairs">
					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Institution Name</h3>
						@if(array_key_exists('name', $sort_filters))
						<input type="text" name="name" placeholder="Enter institution name" value="{{ $sort_filters['name'] }}" id="name">
						@else						
						<input type="text" name="name" placeholder="Enter institution name" id="name">
						@endif
					</div>

					<!-- SECTOR -->
					<div class="pair">
						<h3>Sector</h3>
						<select name="sector">
							<option value="" disabled selected hidden>Select a sector</option>
							@if(array_key_exists('sector', $sort_filters))
							<option value="P" {{ $sort_filters['sector'] == "P" ? 'selected' : ''}}>Private</option>
							<option value="SUC" {{ $sort_filters['sector'] == "SUC" ? 'selected' : ''}}>State Universities and Colleges</option>
							<option value="LUC" {{ $sort_filters['sector'] == "LUC" ? 'selected' : ''}}>Public Universities and Colleges</option>
							<option value="OGS" {{ $sort_filters['sector'] == "OGS" ? 'selected' : ''}}>Other Govt. Schools</option>
						    @else
							<option value="P">Private</option>
							<option value="SUC">State Universities and Colleges</option>
							<option value="LUC">Public Universities and Colleges</option>
							<option value="OGS">Other Govt. Schools</option>
						    @endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$institutions->isEmpty())
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Institution Name</th>
					<th>Sector</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($institutions as $key => $institution)
					<tr>
						<td>{{ $key + $institutions->firstItem() }}</td>
						<td>{{ $institution->institution_name }}</td>
						<td>{{ $institution->alternate_full_sector }}</td>
						<td class="settings">
							<a href="/academic/institutions/{{ $institution->id }}">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<a href="/academic/institutions/{{ $institution->id }}/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							<a href="/academic/institutions/{{ $institution->id }}/delete" onclick="return confirm('Are you sure you want to delete this institution?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous">{{ $institutions->appends($sort_filters)->links() }}</div>
	</div>
	@endif
</section>

<script>
	function resetAll() {
		$('#name').val("");
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach((select, index) => {
			select.selectedIndex = 0;
		});
	}
</script>
@endsection
