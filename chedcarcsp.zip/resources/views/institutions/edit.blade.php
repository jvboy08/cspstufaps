 @extends('layouts.master')

@section('title')
CHED-CAR Admin | Institutions
@endsection

@section('body')
<section class="form full">
	<div class="header">
		<h1>Edit an Institution</h1>
		<a class="add" href="/academic/institutions">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/academic/institutions/{{ $institution->id }}">
		@method('PUT')
		@csrf 
		<div class="columns">
			<div class="column">
				<h3>General Information</h3>

				<!-- NAME -->
				<label for="institution_name">Name :</label>
				<input type="text" name="institution_name" placeholder="Enter institution name" value="{{ $institution->institution_name }}" required>

				<!-- SECTOR -->
				<label for="sector">Sector :</label>
				<select name="sector" required>
					<option value="P" {{ $institution->sector == "P" ? "selected" : ""}}>Private</option>
					<option value="SUC" {{ $institution->sector == "SUC" ? "selected" : ""}}>State Universities and Colleges</option>
					<option value="LUC" {{ $institution->sector == "LUC" ? "selected" : ""}}>Public Universities and Colleges</option>
					<option value="OGS" {{ $institution->sector == "OGS" ? "selected" : ""}}>Other Govt. Schools</option>
				</select>

				<!-- NAME -->
				<label for="address">Address :</label>
				<input type="text" name="address" placeholder="Enter address of institution" value="{{ $institution->address }}" required>
			</div>
			<div class="column">
				<h3>Organization Heads</h3>

				<!-- HEAD OF INSTITUTION -->
				<label for="institution_head">Head of Institution <span class="optional">(Optional)</span> :</label>
				<input type="text" name="institution_head" placeholder="Enter head of institution" value="{{ $institution->institution_head }}">
				
				<!-- REGISTRAR -->
				<label for="registrar">University Registrar <span class="optional">(Optional)</span> :</label>
				<input type="text" name="registrar" placeholder="Enter university registrar" value="{{ $institution->registrar }}">
				
				<!-- CHIEF ACCOUNTANT -->
				<label for="accountant">Chief Accountant <span class="optional">(Optional)</span> :</label>
				<input type="text" name="accountant" placeholder="Enter chief accountant" value="{{ $institution->accountant }}">
			</div>

			<div class="column">
				<h3>Contact Details</h3>

				<!-- HEAD OF INSTITUTION -->
				<label for="hei_email">Email Address <span class="optional">(Optional)</span> :</label>
				<input type="text" name="hei_email" placeholder="Enter email address" value="{{ $institution->hei_email }}">
				
				<!-- HEAD OF INSTITUTION -->
				<label for="hei_contact_no">Contact Number <span class="optional">(Optional)</span> :</label>
				<input type="text" name="hei_contact_no" placeholder="Enter contact number" value="{{ $institution->hei_contact_no }}">
				
				<!-- HEAD OF INSTITUTION -->
				<label for="hei_website">Website Link <span class="optional">(Optional)</span> :</label>
				<input type="text" name="hei_website" placeholder="Enter website link" value="{{ $institution->hei_website }}">

				<input type="submit" value="Submit Changes">
			</div>	
		</div>
	</form>
</section>
@endsection