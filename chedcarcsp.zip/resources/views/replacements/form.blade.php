@extends('layouts.master')

@section('title')
CHED-CAR Admin | Replacement
@endsection

@section('body')
<section class="form full" id="semestral_award_form">
	<div class="header">
		<h1>Scholarship Details of {{ $scholar->applicant->alternate_full_name}}</h1>
		<a class="add" href="{{ url()->previous() }}">Go back</a>
	</div>
	<div class="view">
		<div class="columns">
			<div class="column pairs">
				<p>Program :</p>
				<p>{{ $scholar->award->program->program_name }}</p>
				<p>Award Number :</p>
				<p>{{ $scholar->award_number }}</p>
				<p>Financial Benefits :</p>
				<p>PHP {{ number_format($scholar->award->program->amount_per_sem, 2, '.', ',') }} Per Semester</p>
			</div>
			<div class="column pairs">
				<p>Latest Academic Year :</p>
				<p>A.Y. {{ $scholar->latest_acad_year }} - {{ $scholar->latest_acad_year + 1 }}</p>
				<p>Latest Semester :</p>
				<p>{{ $scholar->latest_semester == 1 ? '1st' : '2nd'}} Semester</p>
				<p>Latest Status :</p>
				<p>{{ $scholar->latest_status }}</p>
			</div>
		</div>
	</div>
	<div class="header">
		<h1>Replaced by {{ $applicant->alternate_full_name }}</h1>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/scholars/{{ $applicant->id }}/replace_scholar/{{ $scholar->id }}"> 
		@csrf
		<div class="columns">
			<div class="column">
				<!-- ACADEMIC YEAR -->
				<label for="acad_year">Academic Year :</label>
				<select name="acad_year" required>
					@if($scholar->latest_status == 'Graduate')
				    	@if($scholar->latest_semester == 1)
						@for($i = $scholar->latest_acad_year; $i <= now()->year; $i++)
					        <option value="{{$i}}" {{ $scholar->latest_acad_year == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
					    @endfor
					    @else
						@for($i = $scholar->latest_acad_year; $i <= now()->year; $i++)
					        <option value="{{$i}}" {{ $scholar->latest_acad_year + 1 == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
					    @endfor
					    @endif
				   	@else
				   		@for($i = $scholar->latest_acad_year; $i <= now()->year; $i++)
					        <option value="{{$i}}" {{ $scholar->latest_acad_year == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
					    @endfor
					@endif
				</select>

				<!-- SEMESTER -->
				<label for="semester">Semester :</label>
				<select name="semester" required>
					@if(in_array($scholar->latest_status, ['Active', 'Graduating', 'Replacement', 'Graduate']))
						<option value="1" {{ $scholar->latest_semester == "1" ? "" : "selected"}}>1st Semester</option>
						<option value="2" {{ $scholar->latest_semester == "2" ? "" : "selected"}}>2nd Semester</option>
					@else
						<option value="1" {{ $scholar->latest_semester == "1" ? "selected" : ''}}>1st Semester</option>
						<option value="2" {{ $scholar->latest_semester == "2" ? "selected" : ''}}>2nd Semester</option>
					@endif
				</select>

				<!-- REMARKS CHEDRO -->
				<label for="remarks_chedro">Remarks for Replacement Scholar <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_chedro" placeholder="Enter remarks" value="{{ $scholar->applicant->full_name }}">

				<!-- REMARKS CHEDRO -->
				<label for="remarks_chedro2">Remarks for Replaced Scholar <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_chedro2" placeholder="Enter remarks" value="{{ $applicant->full_name }}{{ $previous_remarks != null ? ' / '.$previous_remarks : ''}}">
			</div>
			
			<div class="column">
				<!-- REMARKS OSDS -->
				<label for="remarks_osds">OSDS Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_osds" placeholder="Enter remarks of OSDS">
				
				<!-- SARO -->
				<label for="saro">SARO <span class="optional">(Optional)</span> :</label>
				<input type="text" name="saro" placeholder="Enter SARO">

				<!-- NTA Number -->
				<label for="nta_number">NTA Number <span class="optional">(Optional)</span> :</label>
				<input type="text" name="nta_number" placeholder="Enter NTA number">
			</div>

			<div class="column">

				<!-- IS PROCESSED -->
				<label for="is_processed">Is the payment already processed? :</label>
				<select id="is_processed" name="is_processed">
					<option value="1">Yes</option>
					<option value="0">No</option>
				</select>

				<div id="processed_container">
					<!-- AMOUNT CHEDRO -->
					<label for="amount_chedro">Amount Processed :</label>
					<input type="number" name="amount_chedro" value="{{ $scholar->award->program->amount_per_sem }}" id="amount" placeholder="Enter amount">

					<!-- DATE PROCESSED -->
					<label for="date_processed">Date Processed <span class="optional">(dd/mm/yyyy)</span> :</label>
					<input type="text" onfocus="(this.type='date')" name="date_processed" placeholder="Enter date processed" required>

					<!-- MODE OF PAYMENT -->
					<label for="mode_of_payment">Mode of Payment :</label>
					<select name="mode_of_payment" required>
						<option value="" disabled selected hidden>Select a mode of payment</option>
						<option value="HEI">HEI – if through the HEI</option>
						<option value="STUDENT">STUDENT – if through ATM/Cheque</option>
					</select>
				</div>

				<input type="submit" value="Submit">
			</div>
		</div>
	</form>
</section>

<script type="text/javascript">
	$(document).ready(function() {
		$('#is_processed').on('change', function() {
	    	if($('#is_processed').val() == 1) {
		        $('#processed_container').css('display', 'block');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', true);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', true);
		        });
	    	} else {
		        $('#processed_container').css('display', 'none');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', false);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', false);
		        });
	    	}
	    });
	});
</script>
@endsection