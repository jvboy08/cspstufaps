@extends('layouts.master')

@section('title')
CHED-CAR Admin | Awards
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Award New Slots</h1>
		<a class="add" href="/awards">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/awards"> 
		@csrf 
		<!-- PROGRAM -->
		<label for="program_id">Program :</label>
		<select name="program_id">
			<option value="" disabled selected hidden>Select a program</option>
			@foreach($programs as $program)
				<option value="{{ $program->id }}">{{ $program->code }} - {{ $program->program_name }}</option>
			@endforeach
		</select>

		<!-- ACADEMIC YEAR AWARDED -->
		<label for="award_year">Academic Year Awarded :</label>
		<select name="award_year" required>
			<option value="" disabled selected hidden>Select an academic year</option>
			@for($i = 2016; $i <= now()->year; $i++)
		        <option value="{{$i}}">{{ $i }} - {{ $i+1 }}</option>
		    @endfor
		</select>

		<!-- STARTING SLOT -->
		<label for="start_slot">Starting Slot :</label>
		<input type="number" name="start_slot" placeholder="Enter number of starting slot" required>

		<!-- ENDING SLOT -->
		<label for="end_slot">Ending Slot :</label>
		<input type="number" name="end_slot" placeholder="Enter number of ending slot" required>

		<input type="submit" value="Submit">
	</form>
</section>
@endsection