@extends('layouts.master')

@section('title')
CHED-CAR Admin | Awards
@endsection

@section('body')
<section>
	<div class="header">
		@if(!$awards->isEmpty())
		<h1 class="result">{{ $awards->total()}} Awarded Slots Found</h1>
		@else
		<h1 class="result">No Awarded Slots Found</h1>
		@endif
		<a class="add" href="/awards/create">Award new slots</a>
	</div>
	<div class="functions">
		<form action="/awards" method="GET">
			<div class="filter">
				<div class="pairs">

					<!-- SORT -->
					<div class="pair">
						<h3>Sort by</h3>
						<select name="sort">
							@if(array_key_exists('sort', $sort_filters))
							<option value="program_name" {{ $sort_filters["sort"] == "program_name" ? "selected" : "" }}>Alphabetical</option>
							<option value="award_year_asc" {{ $sort_filters["sort"] == "award_year_asc" ? "selected" : "" }}>Academic Year - Ascending</option>
							<option value="award_year_desc" {{ $sort_filters['sort'] == 'award_year_desc' ? 'selected' : '' }}>Academic Year - Descending</option>
							@else
							<option value="program_name" selected>Alphabetical</option>
							<option value="award_year_asc">Academic Year - Ascending</option>
							<option value="award_year_desc">Academic Year - Descending</option>
							@endif
						</select>
					</div>

					<!-- ACADEMIC YEAR AWARDED -->
					<div class="pair">
						<h3>Academic Year Awarded</h3>
						<select name="acad_year">
							<option value="" disabled selected hidden>Select an academic year</option>
							@if(array_key_exists('acad_year', $sort_filters))
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i}}" {{ $sort_filters["acad_year"] == $i ? "selected" : "" }}>A.Y. {{ $i }} - {{ $i+1 }}</option>
						    @endfor
						    @else
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i}}">A.Y. {{ $i }} - {{ $i+1 }}</option>
						    @endfor
						    @endif
						</select>
					</div>

					<button type="button" class="clear" onclick="resetAll()">Reset</button>
					<input type="submit" value="Submit">
				</div>
			</div>
			<div class="filter">
				<div class="pairs">
					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							<option value="" disabled selected hidden>Select a program</option>
							@if(array_key_exists('program', $sort_filters))
							@foreach($programs as $program)
								<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
							@endforeach
							@else
							@foreach($programs as $program)
								<option value="{{ $program->id }}">{{ $program->code }}</option>
							@endforeach
							@endif
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$awards->isEmpty())
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th style="white-space: nowrap;">Program Code</th>
					<th style="white-space: nowrap;">Academic Year Awarded</th>
					<th style="white-space: nowrap;">Starting Slot</th>
					<th style="white-space: nowrap;">Ending Slot</th>
					<th style="white-space: nowrap;">Total Slots</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($awards as $key => $award)
					<tr>
						<td>{{ $key + $awards->firstItem() }}</td>
						<td>{{ $award->code }}</td>
						<td>A.Y. {{ $award->award_year }} - {{ $award->award_year+1 }}</td>
						<td>{{ sprintf("%04d", $award->start_slot) }}</td>
						<td>{{ sprintf("%04d", $award->end_slot) }}</td>
						<td>{{ $award->end_slot - $award->start_slot + 1 }}</td>
						<td class="settings">
							<a href="/awards/{{ $award->award_id }}/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							<a href="/awards/{{ $award->award_id }}/delete" onclick="return confirm('Are you sure you want to delete these awarded slots?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous">{{ $awards->appends($sort_filters)->links() }}</div>
	</div>
	@else
	@endif
</section>

<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
	}
</script>
@endsection
