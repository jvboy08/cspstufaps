@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Password
@endsection

@section('content')
<section class="login_signup">
	<div class="form_container round_container">
		<div class="message">
			<h1>Reset Password</h1>
			<p>An email has been sent to reset your password. Please click the link provided in the email.</p>
		</div>
	</div>
</section>
@endsection