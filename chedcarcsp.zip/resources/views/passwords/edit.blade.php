@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Password
@endsection

@section('content')
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/password/{{ $verification_code }}">
        @method('PUT')
        @csrf 
        <h1>Change Password</h1>
        @include('layouts.errors_no_icon')
        <input type="password" name="password" placeholder="New Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <input type="submit" value="Change Password">
      </form>
    </div>
  </section>
@endsection