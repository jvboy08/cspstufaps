@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Password
@endsection

@section('content')
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/password/send">
        @csrf
        <h1>Reset Password</h1>
        <h6>Please enter your email address and we will send you an email to reset your password</h6>
        @include('layouts.errors_no_icon')
        <input type="email" id="email" name="email" placeholder="Email address" required>
        <input type="submit" value="Send Email">
      </form>
    </div>
  </section>
@endsection