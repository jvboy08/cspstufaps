<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">     
  <link rel="stylesheet" type="text/css" href="/css/style2.css?v=1">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&display=swap" rel="stylesheet">
  <link rel="icon" href="{{ URL::asset('/favicon.png') }}" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <title>CHED-CAR | CSP Application</title>
</head>
<body class="application">
  <header>
    <a href="/">
      <div class="left">
        <div class="logos">
          <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
        </div>
        <div class="names">
         <h1>Commission on Higher Education</h1>
         <h2>Cordillera Administrative Region</h2>
        </div>
      </div>
    </a>
    <div class="right">
      <a class="add" href="/">Homepage</a>
    </div>
  </header>

  <section class="header success_header">
    <div class="left">
      <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
    </div>
    <div class="right">
      <h2>Your application for</h2>
      <h1>CHED <span class="italic">Scholarship Program</span></h1>
      <h2>has been <span class="yellow">successfully submitted</span>!</h2>
    </div>
  </section>

  <section class="success_body">
    <h2>What will be the next step?</h2>
    <p>Thank you for taking the time to apply for the CHED Scholarship Program! If there is a need to validate your certified true copies of documents, you will be contacted by the CHED-CAR staff. Regarding the results of your application, a text message and/or an email message will be sent to you to inform you of the status of your application. For further notices, please check the CHED-CAR's Facebook page from time to time for posted updates of lists of new scholars.</p>
    <div class="buttons">
      <a type="button" class="add" href="/">Return to Homepage</a>
      <a type="button" class="add" target="_blank" href="https://www.facebook.com/chedstufaps.cordillera">Visit Facebook Page</a>
    </div>
  </section>
  @include('layouts.footer')
</body>
</html>