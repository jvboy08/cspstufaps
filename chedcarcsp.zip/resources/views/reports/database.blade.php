@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">Database</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'Database')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
		</div>
	</div>
	@if(!$scholars->isEmpty())
	<div class="table ranklist">
		<table id="table">
			<thead>
				<tr>
					<th rowspan="2">NO.</th>
					<th rowspan="2">REGION</th>
					<th rowspan="2">FUND</th>
					<th rowspan="2">CODE</th>
					<th rowspan="2">AWARD YEAR</th>
					<th rowspan="2" id="award_number" class="sticky_left">AWARD NUMBER</th>
					<th rowspan="2" id="last_name_header" class="sticky_left">LAST NAME</th>
					<th rowspan="2">FIRST NAME</th>
					<th rowspan="2">MIDDLE NAME</th>
					<th rowspan="2">EXT NAME</th>
					<th rowspan="2">BDAY</th>
					<th rowspan="2">SEX</th>
					<th rowspan="2">EMAIL</th>
					<th rowspan="2">CONTACT NUMBER</th>
					<th rowspan="2">BRGY</th>
					<th rowspan="2">TOWN/MUNICIPALITY</th>
					<th rowspan="2">PROVINCE</th>
					<th rowspan="2">DISTRICT</th>
					<th rowspan="2">ZIP CODE</th>
					<th rowspan="2">CURRENT ADDRESS</th>
					<th rowspan="2">HEI</th>
					<th rowspan="2">TYPE OF HEI</th>
					<th rowspan="2">PROGRAM</th>
					<th rowspan="2">PRIORITY PROGRAM</th>
					<th rowspan="2">PRIORITY PROGRAM CMO</th>
					<th rowspan="2">SPECIAL GROUP</th>
					<th rowspan="2">SPECIAL GROUP TYPE</th>
					@for($i = $min; $i <= $max; $i += 0.5)
					<th colspan="9" class="gap_left">A.Y. {{substr($i, 0, 4)}} - {{substr($i + 1, 0, 4)}}, {{ floor($i) != $i ? '2ND' : '1ST'}} SEMESTER</th>
					@endfor
				</tr>
				<tr>
					@for($i = $min; $i <= $max; $i += 0.5)
					<th class="gap_left">NTA NUMBER</th>
					<th>SARO</th>
					<th>CY LEVEL</th>
					<th>STATUS</th>
					<th>OSDS PAYMENT</th>
					<th>CHEDRO PAYMENT</th>
					<th>MODE OF PAYMENT</th>
					<th>CHEDRO REMARKS</th>
					<th>OSDS REMARKS</th>
					@endfor
				</tr>
			</thead>
			<tbody>
				@foreach($scholars as $key => $scholar)
				<tr class="row{{ $key + 1 }}" onclick="highlight({{ $key + 1}})">
					<td>{{ $loop->index+1 }}</td>
					<td>14 - CAR</td>
					<td></td>
					<td>{{ $scholar->award->program->code }}</td>
					<td>20{{ substr($scholar->award_number, strlen($scholar->award_number) - 5, 2) }}</td>
					<td class="sticky_left">{{ $scholar->award_number }}</td>
					<td class="sticky_left last_name_row">{{ $scholar->applicant->name_last }}</td>
					<td>{{ $scholar->applicant->name_first }}</td>
					<td>{{ $scholar->applicant->name_middle }}</td>
					<td>{{ $scholar->applicant->name_ext == null ? 'N/A' : $scholar->applicant->name_ext }}</td>
					<td>{{ date('d/m/Y', strtotime($scholar->applicant->birthday)) }}</td>
					<td>{{ $scholar->applicant->sex }}</td>
					<td>{{ $scholar->applicant->email_address }}</td>
					<td>{{ $scholar->applicant->contact_number }}</td>
					<td>{{ $scholar->applicant->perm_arangay }}</td>
					<td>{{ $scholar->applicant->perm_muni_city }}</td>
					<td>{{ $scholar->applicant->perm_province }}</td>
					<td>{{ $scholar->applicant->perm_district }}</td>
					<td>{{ $scholar->applicant->perm_zip_code }}</td>
					<td>N/C</td>
					@if($scholar->applicant->institution_id != null)
					<td>{{ strtoupper($scholar->applicant->institution->institution_name) }}</td>
					<td>{{ $scholar->applicant->institution->sector }}</td>
					@else
					<td>{{ strtoupper($scholar->applicant->hei_out_car_name) }}</td>
					<td>{{ $scholar->applicant->hei_out_car_sector == 'Private' ? 'P' : 'SUC' }}</td>
					@endif
					<td>{{ $scholar->applicant->course->course_name }}</td>
					@if($scholar->award->program->reference_cmo == 'CMO 1 S. 2014')
					<td>{{  $scholar->applicant->course->cmo_2014 == 'none' ? 'N/A' : $scholar->applicant->course->cmo_2014 }}</td>
					@elseif($scholar->award->program->reference_cmo == 'CMO 5 S. 2019')
					<td>{{ $scholar->applicant->course->cmo_2019 == 'none' ? 'N/A' : $scholar->applicant->course->cmo_2019 }}</td>
					@else
					<td>{{ $scholar->applicant->course->cmo_2021 == 'none' ? 'N/A' : $scholar->applicant->course->cmo_2021 }}</td>
					@endif
					<td>{{ $scholar->award->program->reference_cmo }}</td>
					@if($scholar->applicant->tribe != null)
					<td>IP</td>
					<td>{{ $scholar->applicant->tribe }}</td>
					@elseif($scholar->applicant->disability != null)
					<td>PWD</td>
					<td>{{ $scholar->applicant->full_disability }}</td>
					@elseif($scholar->applicant->sp_type != null)
					<td>SP</td>
					<td>{{ $scholar->applicant->sp_type }}</td>
					@elseif($scholar->applicant->is_orphan == 1)
					<td>O</td>
					<td></td>
					@elseif($scholar->applicant->sc_type != null)
					<td>SC</td>
					<td>$scholar->applicant->sc_type</td>
					@else
					<td>N/A</td>
					<td>N/A</td>
					@endif
					@for($i = 0; $i < $count; $i++)
					<td class="gap_left"></td>
					<td></td>
					<td>{{ $semestral_awards[$key][$i][0] }}</td>
					<td>{{ in_array($semestral_awards[$key][$i][1], ['Terminated', 'Waived']) && $scholar->latest_acad_year == $semestral_awards[$key][$i][5] && $scholar->latest_semester == $semestral_awards[$key][$i][6] && $scholar->replaced_by != null ? 'Replaced' : $semestral_awards[$key][$i][1] }}</td>
					<td></td>
					<td>{{ $semestral_awards[$key][$i][2] == null ? '' : $semestral_awards[$key][$i][2] + 0 }}</td>
					<td>{{ $semestral_awards[$key][$i][2] == null ? '' : $semestral_awards[$key][$i][3] }}</td>
					<td>{{ $semestral_awards[$key][$i][4] }}</td>
					<td></td>
					@endfor
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	@else
	<div class="header">
		<h1 class="result">No Scholars Found</h1>
	</div>
	@endif
</section>

<script type="text/javascript">
	window.onload = function(){ 
		let width = document.querySelector('#award_number').offsetWidth - 5;
		document.querySelector('#last_name_header').style.left = width + 'px';
		document.querySelectorAll('.last_name_row').forEach(div => {
			div.style.left = width + 'px';
		});
	};
</script>
@endsection
