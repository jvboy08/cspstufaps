@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">Status of Beneficiaries (A.Y. {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'Status of Beneficiaries (AY {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
		</div>
	</div>
	<div class="table">
		<table id="table">
			<thead>
				<tr>
					<th rowspan="2">PROGRAM CATEGORY</th>
					<th colspan="6">STATUS</th>
				</tr>
				<tr>
					<th>ACTIVE</th>
					<th>TERMINATED</th>
					<th>DEFERRED</th>
					<th>WAIVED</th>
					<th>GRADUATED</th>
					<th>REPLACEMENT</th>
				</tr>
			</thead>
			<tbody>
				@foreach($programs as $program)
				<tr>
					<td>{{ $program->code }}</td>
					<td>{{ $counts[$loop->index][0] }}</td>
					<td>{{ $counts[$loop->index][1] }}</td>
					<td>{{ $counts[$loop->index][2] }}</td>
					<td>{{ $counts[$loop->index][3] }}</td>
					<td>{{ $counts[$loop->index][4] }}</td>
					<td>{{ $counts[$loop->index][5] }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</section>
@endsection
