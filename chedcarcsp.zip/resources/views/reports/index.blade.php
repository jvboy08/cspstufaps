@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section class="full reports_container">

	<!-- DATABASE -->
	<form action="/reports/database" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter">
				<div class="pairs">
					<h1>Prescribed Database Cleansing Standards</h1>
				</div>
			</div>
		</div>

		<div class="reports">
			<div class="report">
				<h2>Database</h2>
				<a type="submit" href="/reports/database"><span class="material-icons-round">article</span>Generate
				</a>
			</div>
		</div>
	</form>

	<!-- BY ACADEMIC YEAR -->
	<form action="/reports/yearly" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter">
				<div class="pairs">
					<h1>By Academic Year</h1>

					<!-- ACADEMIC YEAR -->
					<div class="pair">
						<h3>Academic Year</h3>
						<select name="acad_year" required>
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i}}" {{ $i == (now()->month < 8 ? now()->year-1 : now()->year) ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}</option>
						    @endfor
						</select>
					</div>
				</div>
			</div>
		</div>

		<div class="reports">
			<div class="report">
				<h2>Ranklist</h2>
				<button type="submit" name="report" value="ranklist"><span class="material-icons-round">article</span>Generate
				</button>
			</div>

			<div class="report">
				<h2>Processed Benefits</h2>
				<button type="submit" name="report" value="benefits"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
		</div>
	</form>

	<!-- BY ACADEMIC PERIOD AND PROGRAM -->

	<form action="/reports/semestral_program" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter" style="margin-bottom: 1vw">
				<div class="pairs">
					<h1>By Academic Period & Program</h1>

					<!-- ACADEMIC PERIOD -->
					<div class="pair">
						<h3>Academic Period</h3>
						<select name="period" required>
							<option value="" disabled selected hidden>Select an academic period</option>
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Semester</option>
						        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Semester</option>
						    @endfor
						</select>
					</div>

					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program" required>
							<option value="" disabled selected hidden>Select a program</option>
							@foreach($programs as $program)
								<option value="{{ $program->id }}">{{ $program->code }}</option>
							@endforeach
						</select>
					</div>
				</div>
			</div>
		</div>

		<div class="reports">
			<div class="report">
				<h2>Masterlist</h2>
				<button type="submit" name="report" value="masterlist"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
		</div>
	</form>

	<!-- BY ACADEMIC PERIOD -->

	<form action="/reports/semestral" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter">
				<div class="pairs">
					<h1>By Academic Period</h1>

					<!-- ACADEMIC PERIOD -->
					<div class="pair">
						<h3>Academic Period</h3>
						<select name="period" required>
							<option value="" disabled selected hidden>Select an academic period</option>
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Semester</option>
						        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Semester</option>
						    @endfor
						</select>
					</div>
				</div>
			</div>
		</div>

		<div class="reports" style="margin-bottom: 0;">
			<div class="report">
				<h2>Status of Beneficiaries</h2>
				<button type="submit" name="report" value="status_total"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>Report on Graduates</h2>
				<button type="submit" name="report" value="graduates_total"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>Graduates of StuFAPs</h2>
				<button type="submit" name="report" value="graduates_list"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By Curriculum Level</h2>
				<button type="submit" name="report" value="by_level"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By Sex</h2>
				<button type="submit" name="report" value="by_sex"><span class="material-icons-round">article</span>Generate
				</button>
			</div>

			<div class="report">
				<h2>By Type of HEI</h2>
				<button type="submit" name="report" value="by_hei_type"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By District</h2>
				<button type="submit" name="report" value="by_district"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By Special Group</h2>
				<button type="submit" name="report" value="by_special"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
		</div>
	</form>
</section>

<script type="text/javascript">
	function changeView(view) {
		if(view == 1) {
			document.querySelector('#left-view').classList.add('active');
			document.querySelector('#right-view').classList.remove('active');
			document.querySelector('#left-nav').classList.add('active');
			document.querySelector('#right-nav').classList.remove('active');
		} else {
			document.querySelector('#left-view').classList.remove('active');
			document.querySelector('#right-view').classList.add('active');
			document.querySelector('#left-nav').classList.remove('active');
			document.querySelector('#right-nav').classList.add('active');
		}
	}
</script>
@endsection
