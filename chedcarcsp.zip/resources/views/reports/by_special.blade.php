@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">Status of Beneficiaries Belonging to Special Group (A.Y. {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'Belonging to Special Group (AY {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
		</div>
	</div>
	<div class="table">
		<table id="table">
			<thead>
				<tr>
					<th rowspan="2">PROGRAM CATEGORY</th>
					<th colspan="{{ count($tribes) }}" rowspan="{{ count($tribes) == 0 ? 2 : 1 }}">INDIGENOUS PEOPLE</th>
					<th colspan="{{ count($disabilities) }}" rowspan="{{ count($disabilities) == 0 ? 2 : 1 }}">PERSON WITH DISABILITY</th>
					<th rowspan="2">SOLO PARENT</th>
					<th rowspan="2">ORPHAN</th>
					<th rowspan="2">TOTAL</th>
				</tr>
				<tr>
					@foreach($tribes as $key => $tribe)
					<th>{{ $tribe }}</th>
					@endforeach
					@foreach($disabilities as $key => $disability)
					@if($disability == 'CD')
					<th>Communication</th>
			        @elseif($disability == 'DCI')
			        <th>Due to Chronic Illness</th>
			        @elseif($disability == 'LD')
			        <th>Learning</th>
			        @elseif($disability == 'ID')
			        <th>Intellectual</th>
			        @elseif($disability == 'OD')
			        <th>Orthopedic</th>
			        @elseif($disability == 'MPD')
			        <th>Mental/Psychosocial</th>
			        @elseif($disability == 'VD')
			        <th>Visual</th>
			        @else
			        <th>{{ $disability }}</th>
			        @endif
			        @endforeach
				</tr>
			</thead>
			<tbody>
				@foreach($programs as $i => $program)
				<tr>
					<td>{{ $program->code }}</td>
					@if(count($tribes) == 0)
					<td>0</td>
					@else
					@foreach($tribes as $j => $tribe)
					<td>{{ $tribes_counts[$i][$j] }}</td>
					@endforeach
					@endif
					@if(count($disabilities) == 0)
					<td>0</td>
					@else
					@foreach($disabilities as $k => $tribe)
					<td>{{ $disabilities_counts[$i][$k] }}</td>
					@endforeach
					@endif
					<td>{{ $counts[$i][0] }}</td>
					<td>{{ $counts[$i][1] }}</td>
					<td>{{ $counts[$i][2] }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</section>
@endsection
