@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">Masterlist (A.Y. {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'Masterlist (AY {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
		</div>
	</div>
	@if(!$semestral_awards->isEmpty())
	<div class="table ranklist">
		<table id="table">
			<thead>
				<tr>
					<th rowspan="2" colspan="2">AWARD NO.</th>
					<th colspan="4">NAME</th>
					<th rowspan="2">SEX</th>
					<th colspan="3">PERMANENT HOME ADDRESS</th>
					<th rowspan="2">DISTRICT</th>
					<th rowspan="2">HEI</th>
					<th rowspan="2">TYPE OF HEI</th>
					<th rowspan="2">BACCALAUREATE PROGRAM</th>
					<th rowspan="2">YR LEVEL</th>
					<th rowspan="2">FINANCIAL BENEFITS</th>
					<th rowspan="2">REMARKS</th>
				</tr>
				<tr>
					<th>LAST NAME</th>
					<th>FIRST NAME</th>
					<th>MIDDLE NAME</th>
					<th>EXT. NAME</th>
					<th>BRGY/STREET</th>
					<th>TOWN/CITY</th>
					<th>PROVINCE</th>
				</tr>
			</thead>
			<tbody>
				@foreach($semestral_awards as $key => $semestral_award)
				<tr class="row{{ $key + 1}}" onclick="highlight({{ $key + 1}})">
					<td>{{ $loop->index+1 }}</td>
					<td>{{ $semestral_award->award_number }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->name_last) }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->name_first) }}</td>
					<td>{{ $semestral_award->scholar->applicant->name_middle == null ? 'N/A' : strtoupper($semestral_award->scholar->applicant->name_middle) }}</td>
					<td>{{ $semestral_award->scholar->applicant->name_ext == null ? 'N/A' : strtoupper($semestral_award->scholar->applicant->name_ext) }}</td>
					<td>{{ $semestral_award->scholar->applicant->sex }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->perm_barangay) }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->perm_muni_city) }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->perm_province) }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->perm_district) }}</td>
					
					@if($semestral_award->scholar->applicant->institution_id != null)
					<td>{{ strtoupper($semestral_award->scholar->applicant->institution->institution_name) }}</td>
					@else
					<td>{{ strtoupper($semestral_award->scholar->applicant->hei_out_car_name) }}</td>
					@endif

					@if($semestral_award->scholar->applicant->institution_id != null)
					<td>{{ $semestral_award->scholar->applicant->institution->sector == 'P' ? 'P' : 'G' }}</td>
					@else
					<td>{{ $semestral_award->scholar->applicant->hei_out_car_sector == 'Private' ? 'P' : 'G' }}</td>
					@endif

					<td>{{ strtoupper($semestral_award->scholar->applicant->course->course_name) }}</td>
					<td>{{ $semestral_award->current_year_level }}</td>
					<td>{{ number_format($semestral_award->amount_chedro, 0, '.', ',') }}</td>
					<td>{{ $semestral_award->remarks_chedro == null ? 'N/A' : strtoupper($semestral_award->remarks_chedro) }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	@else
	<div class="header">
		<h1 class="result">No Scholars Found</h1>
	</div>
	@endif
</section>
@endsection
