@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">List of Graduates StuFAPs (A.Y. {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'List of Graduates StuFAPs (AY {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
		</div>
	</div>
	@if(!$semestral_awards->isEmpty())
	<div class="table">
		<table id="table">
			<thead>
				<tr>
					<th rowspan="2">Seq</th>
					<th rowspan="2">AWARD NO.</th>
					<th colspan="3">NAME</th>
					<th rowspan="2">SEX</th>
					<th colspan="3">PERMANENT HOME ADDRESS</th>
					<th rowspan="2">HEI</th>
					<th rowspan="2">TYPE OF HEI</th>
					<th rowspan="2">COURSE</th>
					<th rowspan="2">PRIORITY DISCIPLINE</th>
					<th colspan="2">INCLUSIVE</th>
					<th rowspan="2">REMARKS</th>
				</tr>
				<tr>
					<th>LAST</th>
					<th>FIRST</th>
					<th>MIDDLE</th>
					<th>BRGY/STREET</th>
					<th>TOWN/CITY</th>
					<th>PROVINCE</th>
					<th>FROM</th>
					<th>TO</th>
				</tr>
			</thead>
			<tbody>
				@foreach($semestral_awards as $semestral_award)
				<tr>
					<td>{{ $loop->index+1 }}</td>
					<td>{{ $semestral_award->award_number }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->name_last) }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->name_first) }}</td>
					<td>{{ $semestral_award->scholar->applicant->name_middle == null ? 'N/A' : strtoupper($semestral_award->scholar->applicant->name_middle) }}</td>
					<td>{{ $semestral_award->scholar->applicant->sex }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->barangay) }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->muni_city) }}</td>
					<td>{{ strtoupper($semestral_award->scholar->applicant->province) }}</td>

					@if($semestral_award->scholar->applicant->institution_id != null)
					<td>{{ strtoupper($semestral_award->scholar->applicant->institution->institution_name) }}</td>
					@else
					<td>{{ strtoupper($semestral_award->scholar->applicant->hei_out_car_name) }}</td>
					@endif

					@if($semestral_award->scholar->applicant->institution_id != null)
					<td>{{ $semestral_award->scholar->applicant->institution->sector == 'P' ? 'P' : 'G' }}</td>
					@else
					<td>{{ $semestral_award->scholar->applicant->hei_out_car_sector == 'Private' ? 'P' : 'G' }}</td>
					@endif

					<td>{{ strtoupper($semestral_award->scholar->applicant->course->course_name) }}</td>
					@if($semestral_award->scholar->award->program->reference_cmo == 'CMO 1 S. 2014')
					<td>{{  $semestral_award->scholar->applicant->course->cmo_2014 == 'none' ? 'N/A' : strtoupper($semestral_award->scholar->applicant->course->cmo_2014) }}</td>
					@else
					<td>{{ $semestral_award->scholar->applicant->course->cmo_2019 == 'none' ? 'N/A' : strtoupper($semestral_award->scholar->applicant->course->cmo_2019) }}</td>
					@endif
					<td>{{ $semestral_award->acad_year_accepted }}</td>
					<td>{{ $semestral_award->acad_year }}</td>
					<td>{{ strtoupper($semestral_award->remarks_chedro) }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	@else
	<div class="header">
		<h1 class="result">No Scholars Found</h1>
	</div>
	@endif
</section>
@endsection
