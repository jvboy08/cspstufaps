@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">Processed Benefits of Scholars (A.Y. {{ $acad_year }}-{{ $acad_year+1 }})</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'By Type of HEIs (AY {{ $acad_year }}-{{ $acad_year+1 }})')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
		</div>
	</div>
	<div class="table">
		<table id="table">
			<thead>
				<tr>
					<th></th>
					@foreach($programs as $program)
					<th>{{ $program->code }}</th>
					@endforeach
					<th>TOTAL</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>1ST SEM</td>
					@foreach($programs as $key => $program)
					<td>{{ $counts[$key][1] }}</td>
					@endforeach
					<td>{{ $sem1_total }}</td>
				</tr>
				<tr>
					<td>2ND SEM</td>
					@foreach($programs as $key => $program)
					<td>{{ $counts[$key][2] }}</td>
					@endforeach
					<td>{{ $sem2_total }}</td>
				</tr>
				<tr>
					<td>TOTAL</td>
					@foreach($programs as $key => $program)
					<td>{{ $counts[$key][1] + $counts[$key][2] }}</td>
					@endforeach
					<td>{{ $sem1_total + $sem2_total }}</td>
				</tr>
			</tbody>
		</table>
	</div>
</section>
@endsection
