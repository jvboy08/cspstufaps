@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">Ranklist (A.Y. {{ $acad_year }}-{{ $acad_year+1 }})</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'Ranklist (AY {{ $acad_year }}-{{ $acad_year+1 }})')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	@if(!$applicants->isEmpty())
	<div class="table ranklist">
		<table id="table">
			<thead>
				<tr>
					<th rowspan="2" class="sticky_left">Seq.</th>
					<th colspan="4">NAME</th>
					<th rowspan="2">BIRTHDAY</th>
					<th rowspan="2">SEX</th>
					<th colspan="3">PERMANENT HOME ADDRESS</th>
					<th rowspan="2">CONG. DISTRICT</th>
					<th rowspan="2">HIGH SCHOOL GRADUATED</th>
					<th colspan="8">GRADE</th>
					<th colspan="3">INCOME OF THE FAMILY</th>
					<th rowspan="2">TOTAL POINTS</th>
					<th rowspan="2">ADDL (5)</th>
					<th rowspan="2">TOTAL RANK SCORE</th>
					<th rowspan="2">RANK</th>
					<th rowspan="2">HEI</th>
					<th rowspan="2">TYPE OF HEI</th>
					<th rowspan="2">COURSE</th>
					<th rowspan="2">YEAR LEVEL</th>
					<th rowspan="2">REMARKS</th>
				</tr>
				<tr>
					<th>LAST NAME</th>
					<th>FIRST NAME</th>
					<th>MIDDLE NAME</th>
					<th>EXT. NAME</th>
					<th>BRGY/STREET</th>
					<th>TOWN/CITY</th>
					<th>PROVINCE</th>
					<th>SHS GRAD</th>
					<th>GRADE 11</th>
					<th>GRADE 12</th>
					<th>ALS/PEPT RATING</th>
					<th>TOTAL</th>
					<th>BASE %</th>
					<th>TOTAL AVE</th>
					<th>% ON GRADES (70%)</th>
					<th>AMOUNT</th>
					<th>BASE %</th>
					<th>% EQUIVALENT (30%)</th>
				</tr>
			</thead>
			<tbody>
				@foreach($applicants as $key => $applicant)
				<tr class="row{{ $key + 1 }}" onclick="highlight({{ $key + 1 }})">
					<td class="sticky_left">{{ $loop->index+1 }}</td>
					<td>{{ strtoupper($applicant->name_last) }}</td>
					<td>{{ strtoupper($applicant->name_first) }}</td>
					<td>{{ $applicant->name_middle == null ? 'N/A' : strtoupper($applicant->name_middle) }}</td>
					<td>{{ $applicant->name_ext == null ? 'N/A' : strtoupper($applicant->name_ext) }}</td>
					<td>{{ date('m/d/Y', strtotime($applicant->birthday)) }}</td>
					<td>{{ $applicant->sex }}</td>
					<td>{{ strtoupper($applicant->perm_barangay) }}</td>
					<td>{{ strtoupper($applicant->perm_muni_city) }}</td>
					<td>{{ strtoupper($applicant->perm_province) }}</td>
					<td>{{ strtoupper($applicant->perm_district) }}</td>
					<td>{{ strtoupper($applicant->highschool) }}</td>
					<td>{{ $applicant->type =='Graduate' ? $applicant->twelve_gwa + 0 : '' }}</td>
					<td>{{ $applicant->type =='Graduating' ? $applicant->eleven_gwa + 0 : '' }}</td>
					<td>{{ $applicant->type =='Graduating' ? $applicant->twelve_gwa + 0 : '' }}</td>
					<td>{{ in_array($applicant->type, ['ALS', 'PEPT']) ? 80 : '' }}</td>
					<td>{{ $numbers[$loop->index][0] + 0 }}</td>
					<td>{{ $numbers[$loop->index][1] }}</td>
					<td>{{ $numbers[$loop->index][1] }}</td>
					<td>{{ $numbers[$loop->index][2] }}</td>
					<td>{{ number_format($applicant->annual_gross_income, 2, '.', ',') }}</td>
					<td>{{ $numbers[$loop->index][3] }}</td>
					<td>{{ $numbers[$loop->index][4] }}</td>
					<td>{{ $numbers[$loop->index][5] }}</td>
					<td>{{ $numbers[$loop->index][5] == $numbers[$loop->index][6] ? '' : '5' }}</td>
					<td>{{ $numbers[$loop->index][6] }}</td>
					<td>{{ $scores[$loop->index] }}</td>
					
					@if($applicant->institution_id != null)
					<td>{{ strtoupper($applicant->institution->institution_name) }}</td>
					@else
					<td>{{ strtoupper($applicant->hei_out_car_name) }}</td>
					@endif

					@if($applicant->institution_id != null)
					<td>{{ $applicant->institution->sector == 'P' ? 'P' : 'G' }}</td>
					@else
					<td>{{ $applicant->hei_out_car_sector == 'Private' ? 'P' : 'G' }}</td>
					@endif

					<td>{{ strtoupper($applicant->course->course_name) }}</td>
					<td>1</td>
					<td>{{ $applicant->full_special_group }}{{ $applicant->special_grp_type != null ? ' - '.$applicant->special_grp_type : '' }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	@else
	<div class="header">
		<h1 class="result">No Scholars Found</h1>
	</div>
	@endif
</section>
@endsection
