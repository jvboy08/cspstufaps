@extends('layouts.master')

@section('title')
CHED-CAR Admin | Reports
@endsection

@section('body')
<section id="report">
	<div class="header">
		<h1 class="result">Status of Beneficiaries by Type of HEIs (A.Y. {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)</h1>
		<div class="header_buttons">
			<button class="add" onclick="exportTableToExcel('table', 'By Type of HEIs (AY {{ $acad_year }}-{{ $acad_year+1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)')">Download as Excel File</button>
			<a class="add" href="/reports">Go back</a>
		</div>
	</div>
	<div class="table">
		<table id="table">
			<thead>
				<tr>
					<th rowspan="2">PROGRAM CATEGORY</th>
					<th colspan="2">TYPE OF HEI</th>
					<th rowspan="2">TOTAL</th>
				</tr>
				<tr>
					<th>Private</th>
					<th>Public</th>
				</tr>
			</thead>
			<tbody>
				@foreach($programs as $program)
				<tr>
					<td>{{ $program->code }}</td>
					<td>{{ $counts[$loop->index][0] }}</td>
					<td>{{ $counts[$loop->index][1] }}</td>
					<td>{{ $counts[$loop->index][2] }}</td>
				</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</section>
@endsection
