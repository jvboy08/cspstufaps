@extends('layouts.master')

@section('title')
CHED-CAR Admin | Documents
@endsection

@section('body')
<section>
	<div class="header">
		@if(!array_key_exists('review_status', $sort_filters) || (array_key_exists('review_status', $sort_filters) && $sort_filters['review_status'] == 0))
			@if(!$billing_statements->isEmpty())
			<h1 class="result">{{ $billing_statements->total()}} {{ $billing_statements->total() > 1 ? 'Unreviewed Billing Statements' : 'Unreviewed Billing Statement' }} Found</h1>
			@else
			<h1 class="result">No Unreviewed Billing Statements Found</h1>
			@endif
		@else
			@if(!$billing_statements->isEmpty())
			<h1 class="result">{{ $billing_statements->total()}} {{ $billing_statements->total() > 1 ? 'Reviewed Billing Statements' : 'Reviewed Billing Statement' }} Found</h1>
			@else
			<h1 class="result">No Reviewed Billing Statements Found</h1>
			@endif
		@endif
		<div class="header_buttons">
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/documents/billing_statements" method="GET">
			<div class="filter">
				<div class="pairs">
					<!-- REVIEW STATUS -->
					<div class="pair">
						<h3>Review Status</h3>
						<select name="review_status">
							@if(array_key_exists('review_status', $sort_filters))
								<option value="0" {{ $sort_filters['review_status'] == 0 ? 'selected' : ''}}>Not Yet Reviewed</option>
								<option value="1" {{ $sort_filters['review_status'] == 1 ? 'selected' : ''}}>Reviewed</option>
							@else
								<option value="0" selected>Not Yet Reviewed</option>
								<option value="1">Reviewed</option>
							@endif
						</select>
					</div>

					<!-- ACADEMIC YEAR -->
					<div class="pair">
						<h3>Academic Period</h3>
						<select name="period">
							<option value="" disabled selected hidden>Select an academic period</option>
							@if(array_key_exists('period', $sort_filters))
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
						        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
						    @endfor
						    @else
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
						        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
						    @endfor
						    @endif
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>
			<div class="filter">
				<div class="pairs">
					
					<!-- INSTITUTION -->
					<div class="pair">
						<h3>Institution</h3>
						<select name="institution">
							<option value="" disabled selected hidden>Select a higher education institution</option>
							@if(array_key_exists('institution', $sort_filters))
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}" {{ $institution->id == $sort_filters['institution'] ? 'selected' : '' }}>{{ $institution->institution_name }}</option>
							@endforeach
							@else
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}">{{ $institution->institution_name }}</option>
							@endforeach
							@endif
						</select>
					</div>
					
					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							<option value="" disabled selected hidden>Select a program</option>
							@if(array_key_exists('program', $sort_filters))
							@foreach($programs as $program)
								<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
							@endforeach
							@else
							@foreach($programs as $key => $program)
								<option value="{{ $program->id }}">{{ $program->code }}</option>
							@endforeach
							@endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$billing_statements->isEmpty())
		<div class="table">
			<table>
				<thead>
					<tr>
						<th>No.</th>
						<th>Institution</th>
						<th>Program</th>
						<th>Academic Period</th>
						<th>Status</th>
						<th>Settings</th>
					</tr>
				</thead>
				<tbody>
					@foreach($billing_statements as $key => $billing_statement)
						<tr>
							<td>{{ $key + $billing_statements->firstItem() }}</td>
							<td>{{ $billing_statement->institution->institution_name }}</td>
							<td>{{ $billing_statement->program->code }}</td>
							<td>A.Y. {{ $billing_statement->acad_year }}, {{ $billing_statement->semester == 1 ? '1st' : '2nd' }} Sem</td>
							<td>{{ $billing_statement->is_reviewed == 1 ? 'Reviewed' : 'Not Yet Reviewed'}}</td>
							<td class="settings">
								<a href="ms-excel:ofe|u|{{ $billing_statement->path }}">
								<div><span class="material-icons-round">launch</span><p>Launch</p>
								</div></a>
								<a href="/documents/billing_statements/{{ $billing_statement->id }}" target="_blank">
								<div><span class="material-icons-round">format_list_bulleted</span><p>Display Scholars</p>
								</div></a>
							</td>
						</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<div class="pagination">
			<div class="previous">{{ $billing_statements->appends($sort_filters)->links() }}</div>
		</div>
	@endif
</section>
<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
		document.getElementById('name').value = null;
	}
</script>
@endsection
