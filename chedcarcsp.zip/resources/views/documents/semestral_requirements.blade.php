@extends('layouts.master')

@section('title')
CHED-CAR Admin | Documents
@endsection

@section('body')
<section>
	<div class="header">
		@if(!array_key_exists('review_status', $sort_filters) || (array_key_exists('review_status', $sort_filters) && $sort_filters['review_status'] == 0))
			@if(!$semestral_awards->isEmpty())
			<h1 class="result">{{ $semestral_awards->total()}} Unreviewed Semestral Requirements Found</h1>
			@else
			<h1 class="result">No Unreviewed Semestral Requirements Found</h1>
			@endif
		@else
			@if(!$semestral_awards->isEmpty())
			<h1 class="result">{{ $semestral_awards->total()}} Reviewed Semestral Requirements Found</h1>
			@else
			<h1 class="result">No Reviewed Semestral Requirements Found</h1>
			@endif
		@endif
		<div class="header_buttons">
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/documents/semestral_requirements" method="GET">
			<div class="filter">
				<div class="pairs">

					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Name</h3>
						@if(array_key_exists('name', $sort_filters))
						<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
						@else						
						<input type="text" name="name" placeholder="Enter last or first name" id="name">
						@endif
					</div>

					<!-- SORT BY -->
					<div class="pair">
						<h3>Sort By</h3>
						<select name="sort">
							@if(array_key_exists('sort', $sort_filters))
								<option value="award_number" {{ $sort_filters['sort'] == 'award_number' ? 'selected' : ''}}>Award Number</option>
								<option value="alphabetical" {{ $sort_filters['sort'] == 'alphabetical' ? 'selected' : ''}}>Alphabetical</option>
							@else
								<option value="award_number" selected>Award Number</option>
								<option value="alphabetical">Alphabetical</option>
							@endif
						</select>
					</div>

					<!-- FUNDING -->
					<div class="pair">
						<h3>Review Status</h3>
						<select name="review_status">
							@if(array_key_exists('review_status', $sort_filters))
								<option value="0" {{ $sort_filters['review_status'] == 0 ? 'selected' : ''}}>Not Yet Reviewed</option>
								<option value="1" {{ $sort_filters['review_status'] == 1 ? 'selected' : ''}}>Reviewed</option>
							@else
								<option value="0" selected>Not Yet Reviewed</option>
								<option value="1">Reviewed</option>
							@endif
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>
			<div class="filter">
				<div class="pairs">

					<!-- ACADEMIC YEAR -->
					<div class="pair">
						<h3>Academic Period</h3>
						<select name="period">
							<option value="" disabled selected hidden>Select an academic period</option>
							@if(array_key_exists('period', $sort_filters))
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Semester</option>
						        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Semester</option>
						    @endfor
						    @else
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Semester</option>
						        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Semester</option>
						    @endfor
						    @endif
						</select>
					</div>

					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							<option value="" disabled selected hidden>Select a program</option>
							@if(array_key_exists('program', $sort_filters))
							@foreach($programs as $program)
								<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
							@endforeach
							@else
							@foreach($programs as $key => $program)
								<option value="{{ $program->id }}">{{ $program->code }}</option>
							@endforeach
							@endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$semestral_awards->isEmpty())
		<div class="table">
			<table>
				<thead>
					<tr>
						<th>No.</th>
						<th>Full Name</th>
						<th>Award Number</th>
						<th>Academic Period</th>
						<th style="white-space: nowrap;">Enrollment Form</th>
						<th style="white-space: nowrap;">Previous Grades</th>
						@if(array_key_exists('review_status', $sort_filters) && $sort_filters['review_status'] == 1)
						<th>Status</th>
						@endif
						<th>Settings</th>
					</tr>
				</thead>
				<tbody>
					@foreach($semestral_awards as $key => $semestral_award)
						<tr>
							<td>{{ $key + $semestral_awards->firstItem() }}</td>
							<td>{{ $semestral_award->applicant->full_name }}</td>
							<td>{{ $semestral_award->award_number }}</td>
							<td>A.Y. {{ $semestral_award->acad_year }}, {{ $semestral_award->semester == 1 ? '1st' : '2nd' }} Sem</td>
							<td class="settings">
								<a href="{{ $semestral_award->enrollment_form }}" target="_blank">
								<div><span class="material-icons-round">open_in_new</span><p>Open</p></div>
								</a>
							</td>
							<td class="settings">
								<a href="{{ $semestral_award->previous_grades }}" target="_blank">
								<div><span class="material-icons-round">open_in_new</span><p>Open</p></div>
								</a>
							</td>
							@if(array_key_exists('review_status', $sort_filters) && $sort_filters['review_status'] == 1)
							<td><p class="{{ in_array($semestral_award->status, ['Active', 'Graduate', 'Replacement', 'Deferred']) ? 'positive' : 'negative' }}">{{ $semestral_award->status }}</p></td>
							@endif
							<td class="settings">
								<a href="/scholars/{{ $semestral_award->scholar_id }}/semestral_awards/{{ $semestral_award->semestral_award_id }}/edit" target="_blank">
								<div>
								@if(!array_key_exists('review_status', $sort_filters) || (array_key_exists('review_status', $sort_filters) && $sort_filters['review_status'] == 0))
								<span class="material-icons-round">add</span><p>Add Status</p>
								@else
								<span class="material-icons-round">create</span><p>Edit</p>
								@endif
								</div></a>
								<a href="/scholars/{{ $semestral_award->scholar_id }}" target="_blank">
								<div><span class="material-icons-round">visibility</span><p>View</p></div>
								</a>
							</td>
						</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<div class="pagination">
			<div class="previous">{{ $semestral_awards->appends($sort_filters)->links() }}</div>
		</div>
	@endif
</section>
<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
		document.getElementById('name').value = null;
	}
</script>
@endsection
