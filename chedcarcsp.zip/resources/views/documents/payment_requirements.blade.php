@extends('layouts.master')

@section('title')
CHED-CAR Admin | Documents
@endsection

@section('body')
<section>
	<div class="header">
		@if(!$scholars->isEmpty())
		<h1 class="result">{{ $scholars->total()}} Payment Requirements Found</h1>
		@else
		<h1 class="result">No Payment Requirements Found</h1>
		@endif
		<div class="header_buttons">
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/documents/payment_requirements" method="GET">
			<div class="filter">
				<div class="pairs">

					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Name</h3>
						@if(array_key_exists('name', $sort_filters))
						<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
						@else						
						<input type="text" name="name" placeholder="Enter last or first name" id="name">
						@endif
					</div>

					<!-- SORT BY -->
					<div class="pair">
						<h3>Sort By</h3>
						<select name="sort">
							@if(array_key_exists('sort', $sort_filters))
								<option value="award_number" {{ $sort_filters['sort'] == 'award_number' ? 'selected' : ''}}>Award Number</option>
								<option value="alphabetical" {{ $sort_filters['sort'] == 'alphabetical' ? 'selected' : ''}}>Alphabetical</option>
							@else
								<option value="award_number" selected>Award Number</option>
								<option value="alphabetical">Alphabetical</option>
							@endif
						</select>
					</div>
					
					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							<option value="" disabled selected hidden>Select a program</option>
							@if(array_key_exists('program', $sort_filters))
							@foreach($programs as $program)
								<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
							@endforeach
							@else
							@foreach($programs as $key => $program)
								<option value="{{ $program->id }}">{{ $program->code }}</option>
							@endforeach
							@endif
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>
			<div class="filter">
				<div class="pairs">

					<!-- ACADEMIC PERIOD STARTED-->
					<div class="pair">
						<h3>Academic Period Started</h3>
						<select name="started">
							<option value="" disabled selected hidden>Select an academic period</option>
							@if(array_key_exists('started', $sort_filters))
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
						        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
						    @endfor
						    @else
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
						        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
						    @endfor
						    @endif
						</select>
					</div>
					
					<!-- INSTITUTION -->
					<div class="pair">
						<h3>Institution</h3>
						<select name="institution">
							<option value="" disabled selected hidden>Select a higher education institution</option>
							@if(array_key_exists('institution', $sort_filters))
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}" {{ $institution->id == $sort_filters['institution'] ? 'selected' : '' }}>{{ $institution->institution_name }}</option>
							@endforeach
							@else
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}">{{ $institution->institution_name }}</option>
							@endforeach
							@endif
						</select>
					</div>
					
					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							<option value="" disabled selected hidden>Select a program</option>
							@if(array_key_exists('program', $sort_filters))
							@foreach($programs as $program)
								<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
							@endforeach
							@else
							@foreach($programs as $key => $program)
								<option value="{{ $program->id }}">{{ $program->code }}</option>
							@endforeach
							@endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$scholars->isEmpty())
		<div class="table">
			<table>
				<thead>
					<tr>
						<th>No.</th>
						<th>Full Name</th>
						<th>Award Number</th>
						<th>Academic Period Started</th>
						<th style="white-space: nowrap;">School ID</th>
						<th style="white-space: nowrap;">Land Bank Card</th>
						<th>Settings</th>
					</tr>
				</thead>
				<tbody>
					@foreach($scholars as $key => $scholar)
						<tr>
							<td>{{ $key + $scholars->firstItem() }}</td>
							<td>{{ $scholar->applicant->full_name }}</td>
							<td>{{ $scholar->award_number }}</td>
							<td>A.Y. {{ $scholar->acad_year_accepted }}, {{ $scholar->semester_accepted == 1 ? '1st' : '2nd' }} Semester</td>
							<td class="settings">
								<a href="{{ $scholar->school_id }}" target="_blank">
								<div><span class="material-icons-round">open_in_new</span><p>Open</p></div>
								</a>
							</td>
							<td class="settings">
								<a href="{{ $scholar->atm_card }}" target="_blank">
								<div><span class="material-icons-round">open_in_new</span><p>Open</p></div>
								</a>
							</td>
							<td class="settings">
								<a href="/scholars/{{ $scholar->scholar_id }}" target="_blank">
								<div><span class="material-icons-round">visibility</span><p>View</p></div>
								</a>
							</td>
						</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<div class="pagination">
			<div class="previous">{{ $scholars->appends($sort_filters)->links() }}</div>
		</div>
	@endif
</section>
<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
		document.getElementById('name').value = null;
	}
</script>
@endsection
