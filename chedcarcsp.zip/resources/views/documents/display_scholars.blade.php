@extends('layouts.master')

@section('title')
CHED-CAR Admin | Documents
@endsection

@section('body')
<section>
	<div class="header">
		<h1 class="result">{{ $billing_statement->program->code }} Scholars in {{ $billing_statement->institution->institution_name }} (A.Y. {{ $billing_statement->acad_year }}-{{ $billing_statement->acad_year + 1 }}, {{ $billing_statement->semester == 1 ? '1st' : '2nd' }} Semester)</h1>
		<div class="header_buttons">
			<h1 class="result">Reviewed</h1>
			<div class="toggle">
				<label class="switch">
					<input class="received_checkbox" onChange="update_is_validated(this)" type="checkbox" name="is_reviewed" data-id="{{ $billing_statement->id }}" {{ $billing_statement->is_reviewed ? 'checked' : '' }} >
					<span class="slider round"></span>
				</label>
			</div>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Award Number</th>
					<th>Full Name</th>
					<th>Previous GWA</th>
					<th>Units Enrolled</th>
					<th>Tuition Fee</th>
					<th>Remarks</th>
					<th>Status</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($scholars as $key => $scholar)
					<tr>
						<td>{{ $key + 1 }}</td>
						<td>{{ $scholar->award_number }}</td>
						<td>{{ $scholar->applicant->full_name }}</td>
						<td>{{ $semestral_awards[$key]->previous_gwa == 'NA' ? 'N/A' : $semestral_awards[$key]->previous_gwa }}</td>
						<td>{{ $semestral_awards[$key]->units_enrolled == 'NA' ? 'N/A' : $semestral_awards[$key]->units_enrolled }}</td>
						@if(is_numeric($semestral_awards[$key]->tuition_fee))
						<td>{{ number_format($semestral_awards[$key]->tuition_fee, 0, '.', ',') }}</td>
						@else
						<td>N/A</td>
						@endif
						<td>{{ $semestral_awards[$key]->remarks_coordinator == null ? 'N/A' : $semestral_awards[$key]->remarks_coordinator }}</td>
						@if($semestral_awards[$key]->status == null)
						<td class="settings">
							<a href="/scholars/{{ $scholar->scholar_id }}/semestral_awards/{{ $semestral_awards[$key]->id }}/edit" target="_blank">
							<div><span class="material-icons-round">add</span><p>Add Status</p>
							</div></a>
						</td>
						@else
						<td><p class="{{ in_array($semestral_awards[$key]->status, ['Active', 'Graduate', 'Replacement', 'Deferred']) ? 'positive' : 'negative' }}">{{ $semestral_awards[$key]->status }}</p></td>
						@endif
						<td class="settings">
							<a href="/scholars/{{ $scholar->scholar_id }}" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</section>
<script type="text/javascript">
	function update_is_validated(checkbox) {
		var value = $(checkbox).is(":checked") ? 1 : 0;
		$.ajax({
	        url: '/update/is_validated/'+$(checkbox).data('id')+'/'+value,
	        type: "GET",
	        dataType: "text"
	    });
	}
</script>
@endsection
