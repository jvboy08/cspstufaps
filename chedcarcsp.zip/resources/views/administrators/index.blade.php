@extends('layouts.master')

@section('title')
CHED-CAR Admin | Administrators
@endsection

@section('body')
<section>
	<div class="header">
		<h1 class="result">{{ $administrators->total()}} {{ $administrators->total() > 1 ? 'Administrators' : 'Administrator' }} Found</h1>
		<a class="add" href="/administrators/create">Add an administrator</a>
	</div>
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>Full Name</th>
					<th>Email Address</th>
					<!-- <th>Settings</th> -->
				</tr>
			</thead>
			<tbody>
				@foreach($administrators as $administrator)
					<tr>
						<td>{{ $administrator->name }}</td>
						<td>{{ $administrator->email }}</td>
						<!-- <td class="settings">
							<a href="/administrators/{{ $administrator->id }}/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
						</td> -->
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous">{{ $administrators->links() }}</div>
	</div>
</section>
@endsection
