@extends('layouts.master')

@section('title')
CHED-CAR Admin | Administrators
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Change Password</h1>
		<a class="add" href="/administrators">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/administrators/password">
		@method('PUT')
		@csrf 
		
		<!-- EMAIL ADDRESS -->
		<label for="email">Email Address :</label>
		<input type="email" name="email" placeholder="Enter email address" required>
		
		<!-- OLD PASSWORD -->
		<label for="old_password">Old Password :</label>
		<input type="password" name="old_password" placeholder="Enter old password" required>

		<!-- NEW PASSWORD -->
		<label for="new_password">New Password <span class="optional">(Minimum of 8 characters)</span> :</label>
		<input type="password" name="new_password" placeholder="Enter new password" required>

		<!-- CONFIRM PASSWORD -->
		<label for="confirm_password">Confirm Password :</label>
		<input type="password" name="confirm_password" placeholder="Confirm new password" required>

		<input type="submit" value="Submit"  id="password_button">
	</form>
</section>
@endsection


