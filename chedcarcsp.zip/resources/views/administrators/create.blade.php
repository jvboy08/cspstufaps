@extends('layouts.master')

@section('title')
CHED-CAR Admin | Administrators
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Add an Administrator</h1>
		<a class="add" href="/administrators">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/administrators"> 
		@csrf 

		<!-- NAME -->
		<label for="name">Full Name :</label>
		<input type="text" name="name" placeholder="Enter full name" required>

		<!-- EMAIL ADDRESS -->
		<label for="email">Email Address :</label>
		<input type="email" name="email" placeholder="Enter email address" required>

		<!-- PASSWORD -->
		<label for="password">Password <span class="optional">(Minimum of 8 characters)</span> :</label>
		<input type="password" name="password" placeholder="Enter password" required>

		<!-- CONFIRM PASSWORD -->
		<label for="confirm_password">Confirm Password :</label>
		<input type="password" name="confirm_password" placeholder="Confirm password" required>
		
		<input type="submit" value="Submit">
	</form>
</section>
@endsection