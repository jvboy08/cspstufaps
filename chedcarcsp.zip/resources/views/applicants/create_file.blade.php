 @extends('layouts.master')

@section('title')
CHED-CAR Admin | Applicants
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Create a File</h1>
		<a class="add" href="/applicants/{{ $applicant->id }}">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/applicants/{{ $applicant->id }}/file/{{ $file }}" enctype="multipart/form-data">
		@csrf 

		<!-- FILE -->
		@if($file == 'birth_cert')
		<label for="file_upload">Birth Certificate :</label>
		@elseif($file == 'id_photo')
		<label for="file_upload">ID Photo :</label>
		@elseif($file == 'twelve_card')
		@if($applicant->type == 'Graduate')
		<label for="file_upload">High School Report Card :</label>
		@else($applicant->type == 'Graduating')
		<label for="file_upload">Certified Grades for Grade 12, 1st Semester :</label>
		@endif
		@elseif($file == 'eleven_card')
		<label for="file_upload">Certified Grades for Grade 11 :</label>
		@elseif($file == 'income_proof')
		<label for="file_upload">{{ $applicant->income_proof_type }} :</label>
		@elseif($file == 'cert_indigency')
		<label for="file_upload">Certificate of Indigency :</label>
		@elseif($file == 'pwd_id')
		<label for="file_upload">PWD ID :</label>
		@elseif($file == 'sc_id')
		<label for="file_upload">Senior Citizen ID :</label>
		@elseif($file == 'sp_id')
		<label for="file_upload">Solo Parent ID :</label>
		@endif
		<input type="file" name="file_upload" accept="{{ $file == 'id_photo' ? 'image/png, image/jpeg' : 'image/png, image/jpeg, application/pdf' }}" required>

		<input type="submit" value="Submit Changes">
	</form>
</section>
@endsection