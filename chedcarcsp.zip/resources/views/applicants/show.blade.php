@extends('layouts.master')

@section('title')
CHED-CAR Admin | Applicants
@endsection

@section('body')
<section class="form full">
	<div class="header">
		<h1>{{ $applicant->full_name }} - No. {{ $applicant->app_no }}</h1>
		<a class="add" href="/applicants">Go back</a>
	</div>
	<div class="nav-scholar">
		<div id="left-nav" class="left active" onclick="changeView(1)">
			<h1>Information</h1>
		</div>
		<div id="right-nav" class="right" onclick="changeView(2)">
			<h1>Scholarship</h1>
		</div>
	</div>
	<div class="view">
		<div id="right-view" class="right">
			<div class="missing">
				<div class="header_with_info">
					<h1>No Scholarship Yet</h1>
					<div class="info_button" onclick="show(1)"><span class="material-icons-round">help</span></div>
					<div id="info1" class="info" onclick="hide(1)">
						<div class="info_content">
							<span class="material-icons-round help">help</span>
							<p style="text-align: left;">Replacing a scholar will display the scholars with the latest status<br>of Terminated, Waived, or Graduate, while adding a scholarship<br>will display a form that will ask for the necessary details.</p>
							<span id="close1" class="material-icons-round close" onclick="hide(1)">close</span>
						</div>
					</div>
				</div>
				<div class="header_buttons">
					<a class="add" href="/scholars/{{ $applicant->id }}/replace_scholar">Replace a scholar</a>
					<a class="add" href="/applicants/{{ $applicant->id }}/scholarships/create">Add a scholarship</a>
				</div>
			</div>
		</div>
		<div id="left-view" class="left active">
			<div id="display_wrapper">
				<iframe id="display_frame" frameborder="0"></iframe>
			</div>
			<div class="header">
				<div class="header_buttons">
					<button class="add" onclick="downloadPdf()">Create & Download PDF</button>
					<button id="display_btn" class="add" onclick="displayPdf()">Create & Display PDF</button>
				</div>
				<div class="header_buttons">
					@if($applicant->are_documents_validated == 0)
					<div class="unvalidated">
						<div class="info_button" onclick="show(2)"><span class="material-icons-round">help</span></div><h1 id="checkbox_label">Documents are not yet validated</h1>
						<div id="info2" class="info" onclick="hide(2)">
							<div class="info_content">
								<span class="material-icons-round help">help</span>
								<p>If the documents of the applicant have been validated, click the "Edit<br>Information" button and set the "Validation of Documents" to "Validated".</p>
								<span id="close2" class="material-icons-round close" onclick="hide(2)">close</span>
							</div>
						</div>
					</div>
					@endif
					<a class="add" href="/applicants/{{ $applicant->id }}/edit">Edit Information</a>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Entry Date :</p>
					<p>{{ date('F d, Y', strtotime($applicant->entry_date)) }}</p>
				</div>
				<div class="column pairs">
					<p>Academic Year :</p>
					<p>A.Y. {{ $applicant->entry_acad_year }} - {{ $applicant->entry_acad_year + 1 }}</p>
				</div>
				<div class="column pairs">
					<p>Total Rank Score :</p>
					<p>{{ $applicant->score + 0 }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Full Name</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>First Name :</p>
					<p>{{ $applicant->name_first }}</p>
					<p>Middle Name :</p>
					<p>{{ $applicant->name_middle == null ? 'N/A' : $applicant->name_middle }}</p>
				</div>
				<div class="column pairs">
					<p>Last Name :</p>
					<p>{{ $applicant->name_last }}</p>
					<p>Extension Name :</p>
					<p>{{ $applicant->name_ext == null ? 'N/A' : $applicant->name_ext }}</p>
				</div>
				<div class="column pairs">
					<p>Maiden Name :</p>
					<p>{{ $applicant->name_maiden == null ? 'N/A' : $applicant->name_maiden }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Personal Details</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Sex :</p>
					<p>{{ $applicant->sex == 'F' ? 'Female' : 'Male' }}</p>
					<p>Civil Status :</p>
					<p>{{ $applicant->civil_status }}</p>
				</div>
				<div class="column pairs">
					<p>Citizenship :</p>
					<p>{{ $applicant->citizenship == null ? 'N/A' : $applicant->citizenship }}</p>
					<p>Date of Birth :</p>
					<p>{{ date('F d, Y', strtotime($applicant->birthday)) }}</p>
				</div>
				<div class="column pairs">
					<p>Place of Birth :</p>
					<p>{{ $applicant->birthplace }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Contact Details</h1>
				</div>
				<div class="column"></div>
				<div class="column">
					<h1>Personal Identification</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Email :</p>
					<p style="word-break: break-all;">{{ $applicant->email_address }}</p>
					<p>Contact No. :</p>
					<p>{{ $applicant->formatted_contact_number }}</p>
				</div>
				<div class="column pairs">
					<p>Facebook :</p>
					<p>{{ $applicant->fb_account == null ? 'N/A' : $applicant->fb_account }}</p>
				</div>
				<div class="column pairs">
					<p>Birth Certificate :</p>
					@if($applicant->birth_cert != null)
					<p><a href="{{ $applicant->birth_cert }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/birth_cert/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/birth_cert/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					<p>ID Photo :</p>
					@if($applicant->id_photo != null)
					<p><a href="{{ $applicant->id_photo }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/id_photo/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/id_photo/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column2">
					<h1>Last School Attended</h1>
				</div>
				<div class="column">
					<h1>GWA</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column2 pairs">
					<p>School Name :</p>
					<p>{{ $applicant->highschool }}</p>
					<p>School Address :</p>
					<p>{{ $applicant->highschool_add == null ? 'N/A' : $applicant->highschool_add }}</p>
					<p>School Sector :</p>
					<p>{{ $applicant->highschool_sector == null ? 'N/A' : $applicant->highschool_sector }}</p>
				</div>
				<div class="column pairs">
					@if($applicant->twelve_gwa_1 == null)
						<!-- GRADE 12 -->
						@if($applicant->type == 'Graduate' || $applicant->type == 'Graduating')
						<p>Grade 12 GWA :</p>
						@else
						<!-- IF ALS OR PEPT -->
						<p>GWA :</p>
						@endif
						<p>{{ $applicant->twelve_gwa }}</p>

						<!-- GRADE 11 -->
						@if($applicant->type == 'Graduating')
						<p>Grade 11 GWA :</p>
						<p>{{ $applicant->eleven_gwa }}</p>
						@endif
					@else
						<p>G12 Avg : {{ $applicant->twelve_gwa }}</p>
						<p>1st: {{ $applicant->twelve_gwa_1 }}{{ $applicant->twelve_gwa_2 != null ? ', 2nd: '.$applicant->twelve_gwa_2 : ''}}{{ $applicant->twelve_gwa_3 != null ? ', 3rd: '.$applicant->twelve_gwa_3 : ''}}</p>

						<!-- GRADE 11 -->
						@if($applicant->type == 'Graduating')
						<p>G11 Avg : {{ $applicant->eleven_gwa }}</p>
						<p>1st: {{ $applicant->eleven_gwa_1 }}{{ $applicant->eleven_gwa_2 != null ? ', 2nd: '.$applicant->eleven_gwa_2 : ''}}{{ $applicant->eleven_gwa_3 != null ? ', 3rd: '.$applicant->eleven_gwa_3 : ''}}</p>
						@endif
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column2">
					<h1>School Intended to Enroll or Enrolled In</h1>
				</div>
				<div class="column">
					<h1>Academic Requirements</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column2 pairs">
					<p>School Name :</p>
					<p>{{ $applicant->institution_id == null ? $applicant->hei_out_car_name : $applicant->institution->institution_name }}</p>
					<p>School Address :</p>
					<p>{{ $applicant->institution_id == null ? $applicant->hei_out_car_address : $applicant->institution->address }}</p>
					<p>Degree Program :</p>
					<p>{{ $applicant->course->course_name }}</p>
				</div>
				<div class="column pairs">
					<p>Applicant Type :</p>
					<p>{{ $applicant->full_type }}</p>
					@if($applicant->type == 'Graduate')
					<p>HS Report Card :</p>
					@elseif($applicant->type == 'Graduating')
					<p>Grades for G12 :</p>
					@else
					<p>Report Card :</p>
					@endif
					@if($applicant->twelve_card != null)
					<p><a href="{{ $applicant->twelve_card }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/twelve_card/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/twelve_card/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@if($applicant->type == 'Graduating')
					<p>Grades for G11 :</p>
					@if($applicant->eleven_card != null)
					<p><a href="{{ $applicant->eleven_card }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/eleven_card/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/eleven_card/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Other Sources of Educational or Financial Assistance</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Grantee Agency :</p>
					<p>{{ $applicant->other_fa_agency == null ? 'N/A' : $applicant->other_fa_agency }}</p>
					<p>Scholarship Type :</p>
					<p>{{ $applicant->other_fa_type == null ? 'N/A' : $applicant->other_fa_type }}</p>
				</div>
				<div class="column pairs">
					<p>Grantee Agency :</p>
					<p>{{ $applicant->other_fa_agency2 == null ? 'N/A' : $applicant->other_fa_agency2 }}</p>
					<p>Scholarship Type :</p>
					<p>{{ $applicant->other_fa_type2 == null ? 'N/A' : $applicant->other_fa_type2 }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Father{{ $applicant->f_is_living == 0 ? ' (Deceased)' : '' }}</h1>
				</div>
				@if(!$applicant->f_is_living && !$applicant->m_is_living)
				<div class="column">
					<h1>Mother (Deceased)</h1>
				</div>
				@endif
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Full Name :</p>
					<p>{{ $applicant->f_name == null ? 'N/A' : $applicant->f_name }}</p>
					@if($applicant->f_is_living == 1)
					<p>Address :</p>
					<p>{{ $applicant->f_add == null ? 'N/A' : $applicant->f_add }}</p>
					<p>Contact Number :</p>
					<p>{{ $applicant->f_contact_no == null ? 'N/A' : $applicant->formatted_f_contact_no }}</p>
					<p>Education :</p>
					<p>{{ $applicant->f_education == null ? 'N/A' : $applicant->f_education }}</p>
					@endif
				</div>
				<div class="column pairs">
					@if($applicant->f_is_living == 1)
					<p>Occupation :</p>
					<p>{{ $applicant->f_occupation == null ? 'N/A' : $applicant->f_occupation }}</p>
					<p>Employer Name :</p>
					<p>{{ $applicant->f_employer == null ? 'N/A' : $applicant->f_employer }}</p>
					<p>Employer Address :</p>
					<p>{{ $applicant->f_employer_add == null ? 'N/A' : $applicant->f_employer_add }}</p>
					@endif
					@if(!$applicant->f_is_living && !$applicant->m_is_living)
					<p>Full Name :</p>
					<p>{{ $applicant->m_name == null ? 'N/A' : $applicant->m_name }}</p>
					@endif
				</div>
			</div>

			@if($applicant->f_is_living || $applicant->m_is_living)
			<div class="columns">
				<div class="column">
					<h1>Mother{{ $applicant->m_is_living == 0 ? ' (Deceased)' : '' }}</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Full Name :</p>
					<p>{{ $applicant->m_name == null ? 'N/A' : $applicant->m_name }}</p>
					@if($applicant->m_is_living == 1)
					<p>Address :</p>
					<p>{{ $applicant->m_add == null ? 'N/A' : $applicant->m_add }}</p>
					<p>Contact Number :</p>
					<p>{{ $applicant->m_contact_no == null ? 'N/A' : $applicant->formatted_m_contact_no }}</p>
					<p>Education :</p>
					<p>{{ $applicant->m_education == null ? 'N/A' : $applicant->m_education }}</p>
					@endif
				</div>
				<div class="column pairs">
					@if($applicant->m_is_living == 1)
					<p>Occupation :</p>
					<p>{{ $applicant->m_occupation == null ? 'N/A' : $applicant->m_occupation }}</p>
					<p>Employer Name :</p>
					<p>{{ $applicant->m_employer == null ? 'N/A' : $applicant->m_employer }}</p>
					<p>Employer Address :</p>
					<p>{{ $applicant->m_employer_add == null ? 'N/A' : $applicant->m_employer_add }}</p>
					@endif
				</div>
			</div>
			@endif

			@if($applicant->g_name != null)
			<div class="columns">
				<div class="column">
					<h1>Legal Guardian</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Full Name :</p>
					<p>{{ $applicant->g_name == null ? 'N/A' : $applicant->g_name }}</p>
					<p>Address :</p>
					<p>{{ $applicant->g_add == null ? 'N/A' : $applicant->g_add }}</p>
					<p>Contact Number :</p>
					<p>{{ $applicant->g_contact_no == null ? 'N/A' : $applicant->formatted_g_contact_no }}</p>
					<p>Education :</p>
					<p>{{ $applicant->g_education == null ? 'N/A' : $applicant->g_education }}</p>
				</div>
				<div class="column pairs">
					<p>Occupation :</p>
					<p>{{ $applicant->g_occupation == null ? 'N/A' : $applicant->g_occupation }}</p>
					<p>Employer Name :</p>
					<p>{{ $applicant->g_employer == null ? 'N/A' : $applicant->g_employer }}</p>
					<p>Employer Address :</p>
					<p>{{ $applicant->g_employer_add == null ? 'N/A' : $applicant->g_employer_add }}</p>
				</div>
			</div>
			@endif

			<div class="columns">
				<div class="column">
					<h1>Family</h1>
				</div>
				<div class="column">
					<h1>Income Requirement</h1>
				</div>
				<div class="column">
					<h1>DSWD's 4Ps</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Siblings 18 & below :</p>
					<p>{{ $applicant->siblings }}</p>
					<p>Annual Income :</p>
					<p>PHP {{ number_format($applicant->annual_gross_income, 2, '.', ',') }}</p>
				</div>
				<div class="column pairs">
					<p>{{ $applicant->income_proof_type == null ? 'Document' : $applicant->income_proof_type }} :</p>
					@if($applicant->income_proof != null)
					<p><a href="{{ $applicant->income_proof }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/income_proof/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/income_proof/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
				</div>
				<div class="column pairs">
					<p>Beneficiary :</p>
					<p>{{ $applicant->is_dswd_4ps == 1 ? 'Yes' : 'No' }}</p>
				</div>
			</div>

			<div class="header">
				<h1>{{ $applicant->pres_is_perm ? 'Permanent and Present Address' : 'Permanent Address' }}</h1>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Zip Code :</p>
					<p>{{ $applicant->perm_zip_code }}</p>
					<p>District :</p>
					<p>{{ $applicant->perm_district }}</p>
				</div>
				<div class="column pairs">
					<p>Province :</p>
					<p>{{ $applicant->perm_province }}</p>
					<p>Municipality :</p>
					<p>{{ $applicant->perm_muni_city }}</p>
				</div>
				<div class="column pairs">
					<p>Brgy/Street :</p>
					<p>{{ $applicant->perm_barangay }}</p>
				</div>
			</div>

			@if(!$applicant->pres_is_perm)
			<div class="header">
				<h1>Present Address</h1>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Zip Code :</p>
					<p>{{ $applicant->pres_zip_code }}</p>
					<p>District :</p>
					<p>{{ $applicant->pres_district }}</p>
				</div>
				<div class="column pairs">
					<p>Province :</p>
					<p>{{ $applicant->pres_province }}</p>
					<p>Municipality :</p>
					<p>{{ $applicant->pres_muni_city }}</p>
				</div>
				<div class="column pairs">
					<p>Brgy/Street :</p>
					<p>{{ $applicant->pres_barangay }}</p>
				</div>
			</div>
			@endif

			<div class="columns">
				<div class="column">
					<h1>Persons with Disability</h1>
				</div>
				<div class="column">
					<h1>Indigenous People</h1>
				</div>
				<div class="column">
					<h1>Solo Parent</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Disability :</p>
					<p>{{ $applicant->disability == null ? 'N/A' : $applicant->full_disability }}</p>
					@if($applicant->disability != null)
					<p>PWD ID :</p>
					@if($applicant->pwd_id != null)
					<p><a href="{{ $applicant->pwd_id }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/pwd_id/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/pwd_id/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
				<div class="column pairs">
					<p>Tribe :</p>
					<p>{{ $applicant->tribe == null ? 'N/A' : $applicant->tribe }}</p>
					@if($applicant->tribe != null)
					<p>Certification :</p>
					@if($applicant->cert_indigency != null)
					<p><a href="{{ $applicant->cert_indigency }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/cert_indigency/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/cert_indigency/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
				<div class="column pairs">
					<p>Beneficiary Type :</p>
					<p>{{ $applicant->sp_type == null ? 'N/A' : $applicant->sp_type }}</p>
					@if($applicant->sp_type != null)
					<p>Solo Parent ID :</p>
					@if($applicant->sp_id != null)
					<p><a href="{{ $applicant->sp_id }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/sp_id/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/sp_id/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Senior Citizen</h1>
				</div>
				<div class="column">
					<h1>Orphan</h1>
				</div>
				<div class="column" style="text-align: right;">
					<a class="add" href="/applicants/{{ $applicant->id }}/delete" onclick="return confirm('Warning: This would delete all the records of this applicant in the database, are you sure?')">
						Delete Applicant
					</a>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Beneficiary Type :</p>
					<p>{{ $applicant->sc_type == null ? 'N/A' : $applicant->sc_type }}</p>
					@if($applicant->sc_type != null)
					<p>Senior Citizen ID :</p>
					@if($applicant->sc_id != null)
					<p><a href="{{ $applicant->sc_id }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $applicant->id }}/file/sc_id/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $applicant->id }}/file/sc_id/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
				<div class="column pairs">
					<p>Orphan :</p>
					<p>{{ $applicant->is_orphan? 'Yes' : 'No' }}</p>
				</div>
				<div class="column pairs">
				</div>
			</div>
		</div>
	</div>
</section>

<script type="text/javascript">
	function changeView(view) {
		if(view == 1) {
			document.querySelector('#left-view').classList.add('active');
			document.querySelector('#right-view').classList.remove('active');
			document.querySelector('#left-nav').classList.add('active');
			document.querySelector('#right-nav').classList.remove('active');
		} else {
			document.querySelector('#left-view').classList.remove('active');
			document.querySelector('#right-view').classList.add('active');
			document.querySelector('#left-nav').classList.remove('active');
			document.querySelector('#right-nav').classList.add('active');
		}
	}

	var applicant = {!! json_encode($applicant->toArray(), JSON_HEX_TAG) !!};
	if(applicant['disability'] != null) {
		applicant['disability'] = '{!! $applicant->full_disability !!}';
	}
</script>
<script type="text/javascript" src="{{ URL::asset('js/downloadpdf.js') }}"></script>
@endsection