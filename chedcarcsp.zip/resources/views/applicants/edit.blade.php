@extends('layouts.master')

@section('title')
CHED-CAR Admin | {{ $applicant->is_accepted ? 'Scholars' : 'Applicants' }}
@endsection

@section('body')
<section class="form full">
	<div class="header">
		<h1>Edit Information</h1>
		<a class="add" href="/applicants/{{ $applicant->id }}">Go back</a>
	</div>
	@include('layouts.errors')
	<form id="edit_form" class="edit_form" method="POST" action="/applicants/{{ $applicant->id }}"> 
		@method('PUT') 
		@csrf 
		<div class="stepper">
			<button type="button" class="step0 active add" onclick="validate(0)">Personal Information</button>
			<button type="button" class="step1 inactive add" onclick="validate(1)">Academic Information</button>
			<button type="button" class="step2 inactive add" onclick="validate(2)">Family Background</button>
			<button type="button" class="step3 inactive add" onclick="validate(3)">Address Information</button>
			<button type="button" class="step4 inactive add" onclick="validate(4)">Special Group</button>

			<!-- VALIDATION OF DOCUMENTS -->
			<div style="padding: 1vw 0;">
				<label for="are_documents_validated">Validation of Documents :</label>
				<select name="are_documents_validated" required>
					<option value="0" {{ $applicant->are_documents_validated == "0" ? "selected" : ""}}>Not yet validated</option>
					<option value="1" {{ $applicant->are_documents_validated == "1" ? "selected" : ""}}>Validated</option>
				</select>
			</div>
			<input class="submit" type="submit" value="Submit Changes">
		</div>

		<!-- PERSONAL INFORMATION -->
		<div class="step">
			<!-- PERSONAL DETAILS -->
			<div class="group">
				<div class="title">
					<h3>Personal Details</h3>
				</div>
				<div class="pairs">
					<!-- FIRST NAME -->
					<div class="pair">
						<label for="name_first">First Name :</label>
						<input type="text" name="name_first" placeholder="Enter first name" value="{{ $applicant->name_first }}" required>
					</div>

					<!-- MIDDLE NAME -->
					<div class="pair">
						<label for="name_middle">Middle Name :</label>
						<input type="text" name="name_middle" placeholder="Enter middle name" value="{{ $applicant->name_middle }}" required>
					</div>

					<!-- LAST NAME -->
					<div class="pair">
						<label for="name_last">Last Name :</label>
						<input type="text" name="name_last" placeholder="Enter last name" value="{{ $applicant->name_last }}" required>
					</div>

					<!-- EXTENSION NAME -->
					<div class="pair">
						<label for="name_ext">Extension Name <span class="optional">(Optional)</span> :</label>
						<input type="text" name="name_ext" placeholder="Enter extension name" value="{{ $applicant->name_ext }}">
					</div>

					<!-- EXTENSION NAME -->
					<div class="pair">
						<label for="name_maiden">Maiden Name <span class="optional">(Optional)</span> :</label>
						<input type="text" name="name_maiden" placeholder="Enter maiden name" value="{{ $applicant->name_maiden }}">
					</div>

					<!-- BIRTHDATE -->
					<div class="pair">
						<label for="birthday">Date of Birth <span class="optional">(dd/mm/yyyy)</span> :</label>
						<input type="date" name="birthday" placeholder="Enter date of birth" value="{{ $applicant->birthday }}" required>
					</div>

					<!-- BIRTHPLACE -->
					<div class="pair">
						<label for="birthplace">Place of Birth <span class="optional">(City & Province)</span> :</label>
						<input type="text" name="birthplace" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->birthplace }}" required>
					</div>

					<!-- SEX -->
					<div class="pair">
						<label for="sex">Sex :</label>
						<select name="sex" required>
							<option value="M" {{ $applicant->sex == "M" ? "selected" : ""}}>Male</option>
							<option value="F" {{ $applicant->sex == "F" ? "selected" : ""}}>Female</option>
						</select>
					</div>

					<!-- CIVIL STATUS -->
					<div class="pair">
						<label for="civil_status">Civil Status :</label>
						<select name="civil_status" required>
							<option value="" disabled selected hidden>Select a civil status</option>
							<option value="Single" {{ $applicant->civil_status == "Single" ? "selected" : ""}}>Single</option>
							<option value="Married" {{ $applicant->civil_status == "Married" ? "selected" : ""}}>Married</option>
							<option value="Annulled" {{ $applicant->civil_status == "Annulled" ? "selected" : ""}}>Annulled</option>
							<option value="Widowed" {{ $applicant->civil_status == "Widowed" ? "selected" : ""}}>Widowed</option>
							<option value="Separated" {{ $applicant->civil_status == "Separated" ? "selected" : ""}}>Separated</option>
							<option value="Others" {{ $applicant->civil_status == "Others" ? "selected" : ""}}>Others</option>
						</select>
					</div>

					<!-- CITIZENSHIP -->
					<div class="pair">
						<label for="citizenship">Citizenship :</label>
						<input type="text" name="citizenship" placeholder="Enter citizenship" value="{{ $applicant->citizenship }}" required>
					</div>
				</div>
			</div>

			<!-- CONTACT DETAILS -->
			<div class="group">
				<div class="title">
					<h3>Contact Details</h3>
				</div>

				<div class="pairs">
					<!-- EMAIL ADDRESS -->
					<div class="pair">
						<label for="email_address">Email Address :</label>
						<input type="email" name="email_address" placeholder="Enter email address" value="{{ $applicant->email_address }}" required>
					</div>

					<!-- CONTACT NUMBER -->
					<div class="pair">
						<label for="contact_number">Mobile Number <span class="optional">(09XX-XXX-XXXX)</span> :</label>
						<input type="text" name="contact_number" data-parsley-validate-contact="" placeholder="E.g. 09XX-XXX-XXXX" value="{{ $applicant->contact_number == null ? '' : $applicant->formatted_contact_number }}" required>
					</div>

					<!-- FACEBOOK -->
					<div class="pair">
						<label for="fb_account">Facebook Name or Username <span class="optional">(Optional)</span> :</label>
						<input type="text" name="fb_account" placeholder="Enter Facebook name or username" value="{{ $applicant->fb_account }}">
					</div>
				</div>
			</div>
		</div>

		<!-- ACADEMIC INFORMATION -->
		<div class="step">

			<!-- PREVIOUS SCHOOL -->
			<div class="group">
				<div class="title">
					<h3>Last School Attended</h3>
				</div>
				<div class="pairs">
					<!-- HIGH SCHOOL -->
					<div class="pair">
						<label for="highschool">School Name :</label>
						<input type="text" name="highschool" placeholder="Enter name of school" value="{{ $applicant->highschool }}" required>
					</div>

					<!-- SCHOOL ADDRESS -->
					<div class="pair">
						<label for="highschool_add">School Address <span class="optional">(Optional)</span> :</label>
						<input type="text" name="highschool_add" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->highschool_add }}">
					</div>

					<!-- SCHOOL SECTOR -->
					<div class="pair">
						<label for="highschool_sector">School Sector <span class="optional">(Optional)</span> :</label>
						<select name="highschool_sector">
							<option value="" disabled selected hidden>Select a sector</option>
							<option value="Private" {{ $applicant->highschool_sector == "Private" ? "selected" : ""}}>Private</option>
							<option value="Public" {{ $applicant->highschool_sector == "Public" ? "selected" : ""}}>Public</option>
						</select>
					</div>

					<!-- APPLICANT TYPE -->
					<div class="pair">
						<label for="type">Applicant type :</label>
						<select id="type" name="type" required>
							<option value="Graduate" {{ $applicant->type == "Graduate" ? "selected" : ""}}>Senior/High School Graduate</option>
							<option value="Graduating" {{ $applicant->type == "Graduating" ? "selected" : ""}}>Graduating Senior High</option>
							<option value="ALS" {{ $applicant->type == "ALS" ? "selected" : ""}}>ALS</option>
							<option value="PEPT" {{ $applicant->type == "PEPT" ? "selected" : ""}}>PEPT</option>
						</select>
					</div>
				</div>
			</div>

			<!-- PREVIOUS SCHOOL -->
			<div class="group">
				<div class="title">
					<h3>GWAs</h3>
		            <div class="checkbox are_gwas_unknown_checkbox">
		              <input type="checkbox" id="are_gwas_unknown" name="are_gwas_unknown" {{ $applicant->twelve_gwa_1 == null ? 'checked' : ''}}>
		              <label for="are_gwas_unknown" style="white-space: nowrap;">GWA for each semester is unknown</label>
		            </div>
				</div>
				<div class="pairs">
					<!-- GRADE 12 GWA -->
					<div id="twelve_gwa_container" class="pair unknown_gwa" style="display: {{ $applicant->twelve_gwa_1 == null ? 'block' : 'none'}};">
						<label id="twelve_gwa_label" for="twelve_gwa">Grade 12 GWA :</label>
						<input id="twelve_gwa_input" type="number" name="twelve_gwa" placeholder="Enter GWA for Grade 12" step='0.01' min='0' max='100' value="{{ number_format($applicant->twelve_gwa, 0) }}" {{ $applicant->twelve_gwa_1 == null ? 'required' : ''}}>
					</div>

					<!-- GRADE 11 GWA -->
					<div id="eleven_gwa_container" class="pair unknown_gwa" style="display: {{ $applicant->twelve_gwa_1 == null && $applicant->type == 'Graduating' ? 'block' : 'none'}};">
						<label for="eleven_gwa">Grade 11 GWA :</label>
						<input id="eleven_gwa_input" type="number" name="eleven_gwa" placeholder="Enter GWA for Grade 11" step='0.01' min='0' max='100' value="{{ $applicant->eleven_gwa == null ? '' : number_format($applicant->eleven_gwa, 0) }}" {{ $applicant->twelve_gwa_1 == null && $applicant->type == 'Graduating' ? 'required' : ''}}>
					</div>

					<!-- GRADE 12 GWA -->
		            <div id="twelve_gwa_sems_container" class="pair known_gwa" style="display: {{ $applicant->twelve_gwa_1 == null ? 'none' : 'block'}};">
		              <label id="twelve_gwa_label" for="twelve_gwa">Grade 12 GWAs :</label>
		              <div class="grades">
		                <div class="pair">
		                  <label for="twelve_gwa_1">1st Sem :</label>
		                  <input id="twelve_gwa_1" type="text" name="twelve_gwa_1" placeholder="GWA" value="{{ $applicant->twelve_gwa_1 }}">
		                </div>
		                <div class="pair">
		                  <label for="twelve_gwa_2">2nd Sem :</label>
		                  <input id="twelve_gwa_2" type="text" name="twelve_gwa_2" placeholder="GWA" value="{{ $applicant->twelve_gwa_2 }}">
		                </div>
		                <div class="pair">
		                  <label for="twelve_gwa_3">3rd Sem :</label>
		                  <input id="twelve_gwa_3" type="text" name="twelve_gwa_3" placeholder="GWA" value="{{ $applicant->twelve_gwa_3 }}">
		                </div>
		              </div>
		            </div>

		            <!-- GRADE 11 GWA -->
		            <div id="eleven_gwa_sems_container" class="pair known_gwa" style="display: {{ $applicant->twelve_gwa_1 == null || $applicant->type != 'Graduating' ? 'none' : 'block'}};">
		              <label for="eleven_gwa">Grade 11 GWAs :</label>
		              <div class="grades">
		                <div class="pair">
		                  <label for="eleven_gwa_1">1st Sem :</label>
		                  <input id="eleven_gwa_1" type="text" name="eleven_gwa_1" placeholder="GWA" value="{{ $applicant->eleven_gwa_1 }}">
		                </div>
		                <div class="pair">
		                  <label for="eleven_gwa_2">2nd Sem :</label>
		                  <input id="eleven_gwa_2" type="text" name="eleven_gwa_2" placeholder="GWA" value="{{ $applicant->eleven_gwa_2 }}">
		                </div>
		                <div class="pair">
		                  <label for="eleven_gwa_3">3rd Sem :</label>
		                  <input id="eleven_gwa_3" type="text" name="eleven_gwa_3" placeholder="GWA" value="{{ $applicant->eleven_gwa_3 }}">
		                </div>
		              </div>
		            </div>
				</div>
			</div>

			<!-- FUTURE SCHOOL -->
			<div class="group">
				<div class="title">
					<h3>School Intended to Enroll or Enrolled In</h3>
		            <div class="checkbox">
		              <input type="checkbox" id="hei_is_car" name="hei_is_car" {{ $applicant->institution_id != null ? 'checked' : ''}}>
		              <label for="hei_is_car" style="white-space: nowrap;">Within CAR</label>
		            </div>
				</div>
				<div class="pairs">

					<!-- INSTITUTION -->
					<div class="pair hei_inside_car" style="display: {{ $applicant->institution_id != null ? 'block' : 'none'}};">
						<label for="institution_id">School Name :</label>
						<select name="institution_id" {{ $applicant->institution_id != null ? 'required' : ''}}>
							@foreach($institutions as $institution)
							<option value="{{ $institution->id }}" {{ $applicant->institution_id == $institution->id ? "selected" : ""}}>{{ $institution->institution_name }}</option>
							@endforeach
						</select>
					</div>

		            <!-- INSTITUTION -->
		            <div class="pair hei_outside_car" style="display: {{ $applicant->institution_id == null ? 'block' : 'none'}};">
		              <label for="hei_out_car_name">School Name :</label>
		              <input id="hei_out_car_name" type="text" name="hei_out_car_name" placeholder="Enter name of school" value="{{ $applicant->hei_out_car_name }}" {{ $applicant->institution_id == null ? 'required' : ''}}>
		            </div>

		            <!-- OUTSIDE CAR - ADDRESS -->
		            <div class="pair hei_outside_car" style="display: {{ $applicant->institution_id == null ? 'block' : 'none'}};">
		              <label for="hei_out_car_address">School Address :</label>
		              <input id="hei_out_car_address" type="text" name="hei_out_car_address" placeholder="Enter address of school" value="{{ $applicant->hei_out_car_address }}" {{ $applicant->institution_id == null ? 'required' : ''}}>
		            </div>

		            <!-- OUTSIDE CAR - SCHOOL SECTOR -->
		            <div class="pair hei_outside_car" style="display: {{ $applicant->institution_id == null ? 'block' : 'none'}};">
		              <label for="hei_out_car_sector">School Sector :</label>
		              <select id="hei_out_car_sector" name="hei_out_car_sector" {{ $applicant->institution_id == null ? 'required' : ''}}>
		                <option value="" disabled selected hidden>Select a sector</option>
		                <option value="Private" {{ $applicant->hei_out_car_sector == 'Private' ? 'selected' : '' }}>Private</option>
		                <option value="Public" {{ $applicant->hei_out_car_sector == 'Public' ? 'selected' : '' }}>Public</option>
		              </select>
		            </div>

					<!-- COURSE -->
					<div class="pair">
						<label for="course_id">Degree Program :</label>
						<select name="course_id" required id="course">
							@foreach($courses as $course)
							<option value="{{ $course->id }}" {{ $applicant->course_id == $course->id ? "selected" : ""}}>{{ $course->course_name }}</option>
							@endforeach
						</select>
					</div>
				</div>
			</div>

			<!-- OTHER SOURCES OF ASSISTANCE -->
			<div class="group">
				<div class="title">
					<h3>Other sources of educational or financial assistance</h3>
				</div>

				<input type="hidden" id="other_fa_count" name="other_fa_count" value="1">

				<div class="other_fa_container">
					<div class="pairs">
						<!-- AGENCY -->
						<div class="pair">
							<label for="other_fa_agency">1. Grantee Institution or Agency <span class="optional">(Optional)</span> :</label>
							<input type="text" name="other_fa_agency" placeholder="Enter grantee institution or agency" value="{{ $applicant->other_fa_agency }}">
						</div>

						<!-- TYPE -->
						<div class="pair">
							<label for="other_fa_type">1. Type of Scholarship <span class="optional">(Optional)</span> :</label>
							<input type="text" name="other_fa_type" placeholder="Enter type of scholarship" value="{{ $applicant->other_fa_type }}">
						</div>

						<!-- AGENCY -->
						<div class="pair">
							<label for="other_fa_agency2">2. Grantee Institution or Agency <span class="optional">(Optional)</span> :</label>
							<input type="text" name="other_fa_agency2" placeholder="Enter grantee institution or agency"  value="{{ $applicant->other_fa_agency2 }}">
						</div>

						<!-- TYPE -->
						<div class="pair">
							<label for="other_fa_type2">2. Type of Scholarship <span class="optional">(Optional)</span> :</label>
							<input type="text" name="other_fa_type2" placeholder="Enter type of scholarship" value="{{ $applicant->other_fa_type2 }}">
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- FAMILY BACKGROUND -->
		<div class="step">
			<!-- FATHER -->
			<div class="group">
				<div class="title">
					<h3>Father</h3>
					<div class="checkboxes">
						<div class="checkbox">
							<input id="f_is_deceased" type="checkbox" name="f_is_deceased" {{ $applicant->f_is_living == 0 ? "checked" : ""}}>
							<label for="f_is_deceased">Deceased</label>
						</div>
					</div>
				</div>

				<div class="pairs">
					<!-- FULL NAME -->
					<div class="pair">
						<label for="f_name">Full Name :</label>
						<input type="text" name="f_name" placeholder="Enter full name" value="{{ $applicant->f_name }}" required>
					</div>

					<!-- ADDRESS -->
					<div class="pair f_deceased_container" style="display: {{ $applicant->f_is_living == '1' ? 'block' : 'none'}};">
						<label for="f_add">Address <span class="optional">(Optional)</span> :</label>
						<input type="text" name="f_add" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->f_add }}">
					</div>

					<!-- CONTACT NUMBER -->
					<div class="pair f_deceased_container" style="display: {{ $applicant->f_is_living == '1' ? 'block' : 'none'}};">
						<label for="f_contact_no">Contact Number <span class="optional">(Optional)</span> :</label>
						<input type="text" name="f_contact_no" data-parsley-validate-contact="" placeholder="E.g. 0999-999-9999" value="{{ $applicant->f_contact_no == null ? '' : $applicant->formatted_f_contact_no }}">
					</div>

					<!-- OCCUPATION -->
					<div class="pair f_deceased_container" style="display: {{ $applicant->f_is_living == '1' ? 'block' : 'none'}};">
						<label for="f_occupation">Occupation <span class="optional">(Optional)</span> :</label>
						<input type="text" name="f_occupation" placeholder="Enter occupation" value="{{ $applicant->f_occupation }}">
					</div>

					<!-- NAME OF EMPLOYER -->
					<div class="pair f_deceased_container" style="display: {{ $applicant->f_is_living == '1' ? 'block' : 'none'}};">
						<label for="f_employer">Name of Employer <span class="optional">(Optional)</span> :</label>
						<input type="text" name="f_employer" placeholder="Enter name of employer" value="{{ $applicant->f_employer }}">
					</div>

					<!-- EMPLOYER ADDRESS -->
					<div class="pair f_deceased_container" style="display: {{ $applicant->f_is_living == '1' ? 'block' : 'none'}};">
						<label for="f_employer_add">Address of Employer <span class="optional">(Optional)</span> :</label>
						<input type="text" name="f_employer_add" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->f_employer_add }}">
					</div>

					<!-- HIGHEST EDUCATIONAL ATTAINMENT -->
					<div class="pair f_deceased_container" style="display: {{ $applicant->f_is_living == '1' ? 'block' : 'none'}};">
						<label for="f_education">Highest Educational Attainment <span class="optional">(Optional)</span> :</label>
						<select name="f_education">
							<option value="" disabled selected hidden>Select educational attainment</option>
							<option value="N/A">N/A</option>
							<option value="No Grade Completed" {{ $applicant->f_education == "No Grade Completed" ? "selected" : ""}}>No Grade Completed</option>
							<option value="Elementary Undergraduate" {{ $applicant->f_education == "Elementary Undergraduate" ? "selected" : ""}}>Elementary Undergraduate</option>
							<option value="Elementary Graduate" {{ $applicant->f_education == "Elementary Graduate" ? "selected" : ""}}>Elementary Graduate</option>
							<option value="High School Undergraduate" {{ $applicant->f_education == "High School Undergraduate" ? "selected" : ""}}>High School Undergraduate</option>
							<option value="High School Graduate" {{ $applicant->f_education == "High School Graduate" ? "selected" : ""}}>High School Graduate</option>
							<option value="Post Secondary Undergraduate" {{ $applicant->f_education == "Post Secondary Undergraduate" ? "selected" : ""}}>Post Secondary Undergraduate</option>
							<option value="Post Secondary Graduate" {{ $applicant->f_education == "Post Secondary Graduate" ? "selected" : ""}}>Post Secondary Graduate</option>
							<option value="College Undergraduate" {{ $applicant->f_education == "College Undergraduate" ? "selected" : ""}}>College Undergraduate</option>
							<option value="College Graduate" {{ $applicant->f_education == "College Graduate" ? "selected" : ""}}>College Graduate</option>
							<option value="Post Baccalaureate" {{ $applicant->f_education == "Post Baccalaureate" ? "selected" : ""}}>Post Baccalaureate</option>
						</select>
					</div>
				</div>
			</div>

			
			<!-- MOTHER -->
			<div class="group">
				<div class="title">
					<h3>Mother</h3>
					<div class="checkboxes">
						<div class="checkbox">
							<input id="m_is_deceased" type="checkbox" name="m_is_deceased" {{ $applicant->m_is_living == 0 ? "checked" : ""}}>
							<label for="m_is_deceased">Deceased</label>
						</div>
					</div>
				</div>

				<div class="pairs">
					<!-- FULL NAME -->
					<div class="pair">
						<label for="m_name">Full Name :</label>
						<input type="text" name="m_name" placeholder="Enter full name" value="{{ $applicant->m_name }}" required>
					</div>

					<!-- ADDRESS -->
					<div class="pair m_deceased_container" style="display: {{ $applicant->m_is_living == '1' ? 'block' : 'none'}};">
						<label for="m_add">Address <span class="optional">(Optional)</span> :</label>
						<input type="text" name="m_add" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->m_add }}">
					</div>

					<!-- CONTACT NUMBER -->
					<div class="pair m_deceased_container" style="display: {{ $applicant->m_is_living == '1' ? 'block' : 'none'}};">
						<label for="m_contact_no">Contact Number <span class="optional">(Optional)</span> :</label>
						<input type="text" name="m_contact_no" data-parsley-validate-contact="" placeholder="E.g. 0999-999-9999" value="{{ $applicant->m_contact_no == null ? '' : $applicant->formatted_m_contact_no }}">
					</div>

					<!-- OCCUPATION -->
					<div class="pair m_deceased_container" style="display: {{ $applicant->m_is_living == '1' ? 'block' : 'none'}};">
						<label for="m_occupation">Occupation <span class="optional">(Optional)</span> :</label>
						<input type="text" name="m_occupation" placeholder="Enter occupation" value="{{ $applicant->m_occupation }}">
					</div>

					<!-- NAME OF EMPLOYER -->
					<div class="pair m_deceased_container" style="display: {{ $applicant->m_is_living == '1' ? 'block' : 'none'}};">
						<label for="m_employer">Name of Employer <span class="optional">(Optional)</span> :</label>
						<input type="text" name="m_employer" placeholder="Enter name of employer" value="{{ $applicant->m_employer }}">
					</div>

					<!-- EMPLOYER ADDRESS -->
					<div class="pair m_deceased_container" style="display: {{ $applicant->m_is_living == '1' ? 'block' : 'none'}};">
						<label for="m_employer_add">Address of Employer <span class="optional">(Optional)</span> :</label>
						<input type="text" name="m_employer_add" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->m_employer_add }}">
					</div>

					<!-- HIGHEST EDUCATIONAL ATTAINMENT -->
					<div class="pair m_deceased_container" style="display: {{ $applicant->m_is_living == '1' ? 'block' : 'none'}};">
						<label for="m_education">Highest Educational Attainment <span class="optional">(Optional)</span> :</label>
						<select name="m_education">
							<option value="" disabled selected hidden>Select educational attainment</option>
							<option value="N/A">N/A</option>
							<option value="No Grade Completed" {{ $applicant->m_education == "No Grade Completed" ? "selected" : ""}}>No Grade Completed</option>
							<option value="Elementary Undergraduate" {{ $applicant->m_education == "Elementary Undergraduate" ? "selected" : ""}}>Elementary Undergraduate</option>
							<option value="Elementary Graduate" {{ $applicant->m_education == "Elementary Graduate" ? "selected" : ""}}>Elementary Graduate</option>
							<option value="High School Undergraduate" {{ $applicant->m_education == "High School Undergraduate" ? "selected" : ""}}>High School Undergraduate</option>
							<option value="High School Graduate" {{ $applicant->m_education == "High School Graduate" ? "selected" : ""}}>High School Graduate</option>
							<option value="Post Secondary Undergraduate" {{ $applicant->m_education == "Post Secondary Undergraduate" ? "selected" : ""}}>Post Secondary Undergraduate</option>
							<option value="Post Secondary Graduate" {{ $applicant->m_education == "Post Secondary Graduate" ? "selected" : ""}}>Post Secondary Graduate</option>
							<option value="College Undergraduate" {{ $applicant->m_education == "College Undergraduate" ? "selected" : ""}}>College Undergraduate</option>
							<option value="College Graduate" {{ $applicant->m_education == "College Graduate" ? "selected" : ""}}>College Graduate</option>
							<option value="Post Baccalaureate" {{ $applicant->m_education == "Post Baccalaureate" ? "selected" : ""}}>Post Baccalaureate</option>
						</select>
					</div>
				</div>
			</div>

			<!-- LEGAL GUARDIAN -->
			<div class="group">
				<div class="title">
					<h3>Legal Guardian</h3>
				</div>
				<div id="legal_guardian_container" class="pairs">
					<!-- FULL NAME -->
					<div class="pair">
						<label for="g_name">Full Name <span class="optional">(Optional)</span> :</label>
						<input type="text" name="g_name" placeholder="Enter full name" value="{{ $applicant->g_name }}">
					</div>

					<!-- ADDRESS -->
					<div class="pair g_deceased_container">
						<label for="g_add">Address <span class="optional">(Optional)</span> :</label>
						<input type="text" name="g_add" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->g_add }}">
					</div>

					<!-- CONTACT NUMBER -->
					<div class="pair g_deceased_container">
						<label for="g_contact_no">Contact Number <span class="optional">(Optional)</span> :</label>
						<input type="text" name="g_contact_no" data-parsley-validate-contact="" placeholder="E.g. 0999-999-9999" value="{{ $applicant->g_contact_no == null ? '' : $applicant->formatted_g_contact_no }}">
					</div>

					<!-- OCCUPATION -->
					<div class="pair g_deceased_container">
						<label for="g_occupation">Occupation <span class="optional">(Optional)</span> :</label>
						<input type="text" name="g_occupation" placeholder="Enter occupation" value="{{ $applicant->g_occupation }}">
					</div>

					<!-- NAME OF EMPLOYER -->
					<div class="pair g_deceased_container">
						<label for="g_employer">Name of Employer <span class="optional">(Optional)</span> :</label>
						<input type="text" name="g_employer" placeholder="Enter name of employer" value="{{ $applicant->g_employer }}">
					</div>

					<!-- EMPLOYER ADDRESS -->
					<div class="pair g_deceased_container">
						<label for="g_employer_add">Address of Employer <span class="optional">(Optional)</span> :</label>
						<input type="text" name="g_employer_add" placeholder="E.g. Baguio City, Benguet" value="{{ $applicant->g_employer_add }}">
					</div>

					<!-- HIGHEST EDUCATIONAL ATTAINMENT -->
					<div class="pair g_deceased_container">
						<label for="g_education">Highest Educational Attainment <span class="optional">(Optional)</span> :</label>
						<select name="g_education">
							<option value="" disabled selected hidden>Select educational attainment</option>
							<option value="N/A">N/A</option>
							<option value="No Grade Completed" {{ $applicant->g_education == "No Grade Completed" ? "selected" : ""}}>No Grade Completed</option>
							<option value="Elementary Undergraduate" {{ $applicant->g_education == "Elementary Undergraduate" ? "selected" : ""}}>Elementary Undergraduate</option>
							<option value="Elementary Graduate" {{ $applicant->g_education == "Elementary Graduate" ? "selected" : ""}}>Elementary Graduate</option>
							<option value="High School Undergraduate" {{ $applicant->g_education == "High School Undergraduate" ? "selected" : ""}}>High School Undergraduate</option>
							<option value="High School Graduate" {{ $applicant->g_education == "High School Graduate" ? "selected" : ""}}>High School Graduate</option>
							<option value="Post Secondary Undergraduate" {{ $applicant->g_education == "Post Secondary Undergraduate" ? "selected" : ""}}>Post Secondary Undergraduate</option>
							<option value="Post Secondary Graduate" {{ $applicant->g_education == "Post Secondary Graduate" ? "selected" : ""}}>Post Secondary Graduate</option>
							<option value="College Undergraduate" {{ $applicant->g_education == "College Undergraduate" ? "selected" : ""}}>College Undergraduate</option>
							<option value="College Graduate" {{ $applicant->g_education == "College Graduate" ? "selected" : ""}}>College Graduate</option>
							<option value="Post Baccalaureate" {{ $applicant->g_education == "Post Baccalaureate" ? "selected" : ""}}>Post Baccalaureate</option>
						</select>
					</div>
				</div>
			</div>

			<!-- FAMILY -->
			<div class="group">
				<div class="title">
					<h3>Family</h3>
				</div>
				<div class="pairs">
					<!-- NUMBER OF SIBLINGS -->
					<div class="pair">
						<label for="siblings">No. of siblings 18 years old and below <span class="optional">(Optional)</span> :</label>
						<input type="number" name="siblings" placeholder="Enter number of siblings" value="{{ $applicant->siblings }}">
					</div>

					<!-- ANNUAL GROSS INCOME -->
					<div class="pair">
						<label for="annual_gross_income">Annual gross income of parent(s) or guardian :</label>
						<input type="number" name="annual_gross_income" placeholder="Enter annual gross income" value="{{ $applicant->annual_gross_income }}" required>
					</div>
				</div>
			</div>

			<!-- INCOME REQUIREMENT -->
			<div class="group">
				<div class="title">
					<h3>Income Requirement</h3>
				</div>

				<div class="pairs">
					<!-- TYPE OF INCOME REQUIREMENT -->
					<div class="pair">
						<label for="income_proof_type">Type of Income Requirement <span class="optional">(Optional)</span> :</label>
						<select id="income_proof_type" name="income_proof_type">
							<option value="" disabled selected hidden>Select type of income requirement</option>
							<option value="Income Tax Return" {{ $applicant->income_proof_type == "Income Tax Return" ? "selected" : ""}}>Latest ITR of parents or guardian if employed</option>
							<option value="Tax Exemption" {{ $applicant->income_proof_type == "Tax Exemption" ? "selected" : ""}}>Certificate of Tax Exemption from the BIR</option>
							<option value="Certificate of Indigency" {{ $applicant->income_proof_type == "Certificate of Indigency" ? "selected" : ""}}>Certificate of Indigency from the Barangay</option>
							<option value="Case Study DSWD" {{ $applicant->income_proof_type == "Case Study DSWD" ? "selected" : ""}}>Certificate or Case Study from DSWD</option>
							<option value="OFW Contract" {{ $applicant->income_proof_type == "OFW Contract" ? "selected" : ""}}>Latest copy of contract or proof of income for children of OFWs and seafarers</option>
						</select>
					</div>
				</div>
			</div>

			<!-- DSWD 4PS -->
			<div class="group">
				<div class="title">
					<h3>Beneficiary of the DSWD's 4Ps</h3>
					<div class="checkbox">
						<input id="is_dswd_4ps" type="checkbox" name="is_dswd_4ps" {{ $applicant->is_dswd_4ps == 1 ? "checked" : ""}}>
					</div>
				</div>
			</div>
		</div>

		<!-- ADDRESS INFORMATION -->
		<div class="step">
			<!-- PERMANENT ADDRESS -->
			<div class="group">
				<div class="title">
					<h3>Permanent Address</h3>
					<div class="checkbox">
						<input type="checkbox" id="perm_add_is_car" name="perm_add_is_car" {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'checked' : '' }}>
						<label for="perm_add_is_car">Within CAR</label>
					</div>
				</div>

				<div class="pairs">
					<!-- INSIDE CAR -->

					<!-- DISTRICT -->
					<div class="pair inside_car" style="display: {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="perm_district">District :</label>
						<select id="perm_district" name="perm_district" {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
							<option value="" disabled selected hidden>Select a district</option>
							<option value="Abra" {{ $applicant->perm_district == "Abra" ? "selected" : ""}}>Abra</option>
							<option value="Apayao" {{ $applicant->perm_district == "Apayao" ? "selected" : ""}}>Apayao</option>
							<option value="Baguio" {{ $applicant->perm_district == "Baguio" ? "selected" : ""}}>Baguio</option>
							<option value="Benguet" {{ $applicant->perm_district == "Benguet" ? "selected" : ""}}>Benguet</option>
							<option value="Ifugao" {{ $applicant->perm_district == "Ifugao" ? "selected" : ""}}>Ifugao</option>
							<option value="Kalinga" {{ $applicant->perm_district == "Kalinga" ? "selected" : ""}}>Kalinga</option>
							<option value="Mountain Province" {{ $applicant->perm_district == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
						</select>
					</div>

					<!-- PROVINCE -->
					<div class="pair inside_car" style="display: {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="perm_province">Province :</label>
						<select id="perm_province" name="perm_province" {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
							<option value="" disabled selected hidden>Select a province</option>
							<option value="Abra" {{ $applicant->perm_province == "Abra" ? "selected" : ""}}>Abra</option>
							<option value="Apayao" {{ $applicant->perm_province == "Apayao" ? "selected" : ""}}>Apayao</option>
							<option value="Benguet" {{ $applicant->perm_province == "Benguet" ? "selected" : ""}}>Benguet</option>
							<option value="Ifugao" {{ $applicant->perm_province == "Ifugao" ? "selected" : ""}}>Ifugao</option>
							<option value="Kalinga" {{ $applicant->perm_province == "Kalinga" ? "selected" : ""}}>Kalinga</option>
							<option value="Mountain Province" {{ $applicant->perm_province == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
						</select>
					</div>

					<!-- MUNICIPALITY OR CITY -->
					<div class="pair inside_car" style="display: {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="perm_muni_city">Municipality or City :</label>
						<select id="perm_muni_city" name="perm_muni_city" {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
							<option value="" disabled selected hidden>Please select a province first</option>
						</select>
					</div>

					<!-- OUTSIDE CAR -->

					<!-- DISTRICT -->
					<div class="pair outside_car" style="display: {{ !in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="perm_district2">District :</label>
						<input id="perm_district2" type="text" name="perm_district2" placeholder="Enter district" value="{{ $applicant->perm_district }}" {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? '' : 'required' }}>
					</div>

					<!-- PROVINCE -->
					<div class="pair outside_car" style="display: {{ !in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="perm_province2">Province :</label>
						<input id="perm_province2" type="text" name="perm_province2" placeholder="Enter province" value="{{ $applicant->perm_province }}" {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? '' : 'required' }}>
					</div>

					<!-- MUNICIPALITY OR CITY -->
					<div class="pair outside_car" style="display: {{ !in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="perm_muni_city2">Municipality or City :</label>
						<input id="perm_muni_city2" type="text" name="perm_muni_city2" placeholder="Enter municipality or city" value="{{ $applicant->perm_muni_city }}" {{ in_array($applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? '' : 'required' }}>
					</div>

					<!-- BARANGAY -->
					<div class="pair">
						<label for="perm_barangay">House No., Building, Street, Barangay :</label>
						<input type="text" name="perm_barangay" placeholder="Enter barangay and other details" value="{{ $applicant->perm_barangay }}" required>
					</div>

					<!-- ZIP CODE -->
					<div class="pair">
						<label for="perm_zip_code">Zip Code :</label>
						<input type="number" name="perm_zip_code" placeholder="Enter zip code" value="{{ $applicant->perm_zip_code }}" required>
					</div>
				</div>
			</div>

			<!-- PRESENT ADDRESS -->
			<div class="group">
				<div class="title">
					<h3>Present Address</h3>
					<div class="checkboxes">
						<div class="checkbox checkbox_pres_add" style="display: {{ !$applicant->pres_is_perm ? 'flex' : 'none' }};">
							<input type="checkbox" id="pres_add_is_car" name="pres_add_is_car" {{ in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'checked' : '' }}>
							<label for="pres_add_is_car">Within CAR</label>
						</div>
						<div class="checkbox">
							<input type="checkbox" id="pres_is_perm" name="pres_is_perm" {{ $applicant->pres_is_perm ? 'checked' : '' }}>
							<label for="pres_is_perm">Same with Permanent Address</label>
						</div>
					</div>
				</div>

				<div class="pairs pres_add" style="display: {{ !$applicant->pres_is_perm ? 'grid' : 'none' }};">
					<!-- INSIDE CAR -->

					<!-- DISTRICT -->
					<div class="pair inside_car2" style="display: {{ in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="pres_district">District :</label>
						<select id="pres_district" name="pres_district" {{ !$applicant->pres_is_perm && in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
							<option value="" disabled selected hidden>Select a district</option>
							<option value="Abra" {{ $applicant->pres_district == "Abra" ? "selected" : ""}}>Abra</option>
							<option value="Apayao" {{ $applicant->pres_district == "Apayao" ? "selected" : ""}}>Apayao</option>
							<option value="Baguio" {{ $applicant->pres_district == "Baguio" ? "selected" : ""}}>Baguio</option>
							<option value="Benguet" {{ $applicant->pres_district == "Benguet" ? "selected" : ""}}>Benguet</option>
							<option value="Ifugao" {{ $applicant->pres_district == "Ifugao" ? "selected" : ""}}>Ifugao</option>
							<option value="Kalinga" {{ $applicant->pres_district == "Kalinga" ? "selected" : ""}}>Kalinga</option>
							<option value="Mountain Province" {{ $applicant->pres_district == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
						</select>
					</div>

					<!-- PROVINCE -->
					<div class="pair inside_car2" style="display: {{ in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="pres_province">Province :</label>
						<select id="pres_province" name="pres_province" {{ !$applicant->pres_is_perm && in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
							<option value="" disabled selected hidden>Select a province</option>
							<option value="Abra" {{ $applicant->pres_province == "Abra" ? "selected" : ""}}>Abra</option>
							<option value="Apayao" {{ $applicant->pres_province == "Apayao" ? "selected" : ""}}>Apayao</option>
							<option value="Benguet" {{ $applicant->pres_province == "Benguet" ? "selected" : ""}}>Benguet</option>
							<option value="Ifugao" {{ $applicant->pres_province == "Ifugao" ? "selected" : ""}}>Ifugao</option>
							<option value="Kalinga" {{ $applicant->pres_province == "Kalinga" ? "selected" : ""}}>Kalinga</option>
							<option value="Mountain Province" {{ $applicant->pres_province == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
						</select>
					</div>

					<!-- MUNICIPALITY OR CITY -->
					<div class="pair inside_car2" style="display: {{ in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="pres_muni_city">Municipality or City :</label>
						<select id="pres_muni_city" name="pres_muni_city" {{ !$applicant->pres_is_perm && in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
							<option value="" disabled selected hidden>Please select a province first</option>
						</select>
					</div>

					<!-- OUTSIDE CAR -->

					<!-- DISTRICT -->
					<div class="pair outside_car2" style="display: {{ !in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="pres_district2">District :</label>
						<input id="pres_district2" type="text" name="pres_district2" placeholder="Enter district" value="{{ $applicant->pres_district }}" {{ !$applicant->pres_is_perm && !in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
					</div>

					<!-- PROVINCE -->
					<div class="pair outside_car2" style="display: {{ !in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="pres_province2">Province :</label>
						<input id="pres_province2" type="text" name="pres_province2" placeholder="Enter province" value="{{ $applicant->pres_province }}" {{ !$applicant->pres_is_perm && !in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
					</div>

					<!-- MUNICIPALITY OR CITY -->
					<div class="pair outside_car2" style="display: {{ !in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
						<label for="pres_muni_city2">Municipality or City :</label>
						<input id="pres_muni_city2" type="text" name="pres_muni_city2" placeholder="Enter municipality or city" value="{{ $applicant->pres_muni_city }}" {{ !$applicant->pres_is_perm && !in_array($applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
					</div>

					<!-- BARANGAY -->
					<div class="pair">
						<label for="pres_barangay">House No., Building, Street, Barangay :</label>
						<input type="text" name="pres_barangay" placeholder="Enter barangay and other details" value="{{ $applicant->pres_barangay }}" {{ !$applicant->pres_is_perm ? 'required' : '' }}>
					</div>

					<!-- ZIP CODE -->
					<div class="pair">
						<label for="pres_zip_code">Zip Code :</label>
						<input type="number" name="pres_zip_code" placeholder="Enter zip code" value="{{ $applicant->pres_zip_code }}" {{ !$applicant->pres_is_perm ? 'required' : '' }}>
					</div>
				</div>
			</div>
		</div>

		<!-- SPECIAL GROUP -->
		<div class="step">
			<!-- IP -->
			<div class="group">
				<div class="title">
					<div class="checkbox">
						<input id="is_ip" type="checkbox" name="is_ip" {{ $applicant->tribe != null ? "checked" : ""}}>
					</div>
					<h3>Indigenous and Ethnic Peoples</h3>
				</div>

				<div id="tribe_container" class="pairs" style="display: {{ $applicant->tribe != null ? 'grid' : 'none'}};">
					<!-- TRIBE MEMBERSHIP -->
					<div class="pair">
						<label for="tribe">Tribe Membership :</label>
						<input id="tribe_input" type="text" name="tribe" placeholder="Enter tribe membership" value="{{ $applicant->tribe }}">
					</div>
				</div>
			</div>

			<!-- PWD -->
			<div class="group">
				<div class="title">
					<div class="checkbox">
						<input id="is_pwd" type="checkbox" name="is_pwd" {{ $applicant->disability != null ? "checked" : ""}}>
					</div>
					<h3>Persons with Disabilities</h3>
				</div>

				<div id="disability_container" class="pairs" style="display: {{ $applicant->disability != null ? 'grid' : 'none'}};">
					<!-- TYPE OF DISABILITY -->
					<div id="disability_select_container" class="pair">
						<label for="disability">Type of Disability :</label>
						<select id="disability_select" name="disability">
							<option value="" selected disabled hidden>Select type of disability</option>
							<option value="CD" {{ $applicant->disability == "CD" ? 'selected' : ''}}>Communication Disability</option>
							<option value="DCI" {{ $applicant->disability == "DCI" ? 'selected' : ''}}>Disability due to Chronic Illness</option>
							<option value="LD" {{ $applicant->disability == "LD" ? 'selected' : ''}}>Learning Disability</option>
							<option value="ID" {{ $applicant->disability == "ID" ? 'selected' : ''}}>Intellectual Disability</option>
							<option value="OD" {{ $applicant->disability == "OD" ? 'selected' : ''}}>Orthopedic Disability</option>
							<option value="MPD" {{ $applicant->disability == "MPD" ? 'selected' : ''}}>Mental/Psychosocial Disability</option>
							<option value="VD" {{ $applicant->disability == "VD" ? 'selected' : ''}}>Visual Disability</option>
							<option value="Others" {{ $applicant->disability != null && !in_array($applicant->disability, ['CD', 'DCI', 'LD', 'ID', 'OD', 'MPD', 'VD']) ? 'selected' : ''}}>Others</option>
						</select>
					</div>

					<!-- SPECIFIC DISABILITY -->
					<div id="disability_input_container" class="pair" style="display: {{ $applicant->disability != null && !in_array($applicant->disability, ['CD', 'DCI', 'LD', 'ID', 'OD', 'MPD', 'VD']) ? 'block' : 'none'}};">
						<label for="disability_others">Please Specify :</label>
						<input id="disability_input" type="text" name="disability_others" placeholder="Enter disability">
					</div>
				</div>
			</div>

			<!-- SENIOR CITIZEN -->
			<div class="group">
				<div class="title">
					<div class="checkbox">
						<input id="is_sc" type="checkbox" name="is_sc" {{ $applicant->sc_type != null ? "checked" : ""}}>
					</div>
					<h3>Dependent of Senior Citizen</h3>
				</div>

				<div id="sc_container" class="pairs" style="display: {{ $applicant->sc_type != null ? 'block' : 'none' }};">
					<!-- SP TYPE -->
					<div class="pair">
						<label for="sp_type">Beneficiary Type :</label>
						<select id="sp_select" name="sp_type" {{ $applicant->sp_type != null ? 'required' : ''}}>
							<option value="" selected disabled hidden>Select beneficiary type</option>
							<option value="Parent" {{ $applicant->sp_type == "Parent" ? "selected" : ""}}>Parent</option>
							<option value="Dependent" {{ $applicant->sp_type == "Dependent" ? "selected" : ""}}>Dependent</option>
						</select>
					</div>
				</div>
			</div>

			<!-- SOLO PARENT -->
			<div class="group">
				<div class="title">
					<div class="checkbox">
						<input id="is_sp" type="checkbox" name="is_sp" {{ $applicant->sp_type != null ? "checked" : ""}}>
					</div>
					<h3>Dependent of Solo Parent</h3>
				</div>

				<div id="sp_container" class="pairs" style="display: {{ $applicant->sc_type != null ? 'grid' : 'none'}};">
					<!-- SP TYPE -->
					<div class="pair">
						<label for="sc_type">Beneficiary Type :</label>
						<select id="sc_select" name="sc_type" {{ $applicant->sc_type != null ? 'required' : ''}}>
							<option value="" selected disabled hidden>Select beneficiary type</option>
							<option value="Senior Citizen" {{ $applicant->sc_type == "Parent" ? "selected" : ""}}>Parent</option>
							<option value="Dependent" {{ $applicant->sc_type == "Dependent" ? "selected" : ""}}>Dependent</option>
						</select>
					</div>
				</div>
			</div>

			<!-- ORPHAN -->
			<div class="group">
				<div class="title">
					<div class="checkbox">
						<input id="is_orphan" type="checkbox" name="is_orphan" {{ $applicant->is_orphan ? "checked" : ""}}>
					</div>
					<h3>Orphan</h3>
				</div>
			</div>
		</div>
	</form>
</section>
<script type="text/javascript" src="{{ URL::asset('js/index.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js" integrity="sha512-eyHL1atYNycXNXZMDndxrDhNAegH2BDWt1TmkXJPoGf1WLlNYt08CSjkqF5lnCRmdm3IrkHid8s2jOUY4NIZVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>

	function navigateTo(index) {
		$steps.removeClass('active_step').eq(index).addClass('active_step');
		for(let i = 0; i <= $steps.length - 1; i++) {
			if(i == index) {
				$('.step' + index).addClass("active");
				$('.step' + index).removeClass("inactive");
			} else {
				$('.step' + i).addClass("inactive");
				$('.step' + i).removeClass("active");
			}
		}
	};

	function validate(index) {
		$('#edit_form').parsley().whenValidate({
			group: 'block-' + current_index()
		}).done(function() {
			navigateTo(index);
		});
	}

	function current_index() {
		return $steps.index($steps.filter('.active_step'));
	}

	var $steps = $('.step');
	$steps.each(function(index, step) {
		$(step).find(':input').attr('data-parsley-group', 'block-' + index);
	});

	navigateTo(0);

	// CONTACT NUMBER VALIDATOR
	window.Parsley.addValidator('validateContact', {
		validateString: function(value) {
			if (/^((09)\d{2}-\d{3}-\d{4})$/.test(value)) {
				return true;
			} else if (/^$/.test(value)) {
				return true;
			} else {
				return false;
			}
		},
		messages: {
			en: 'Valid format: 09XX-XXX-XXXX'
		}
	});

	// FUTURE SCHOOL TOGGLE INPUTS
	$('#hei_is_car').bind('change', function() {
	  if($('#hei_is_car').is(":checked")) {
	    $('.hei_inside_car').css('display', 'block');
	    $('.hei_inside_car').children('select').prop('required', true);

	    $('.hei_outside_car').each(function() {
	      $(this).css('display', 'none');
	      $(this).children('input').prop('required', false);
	      $(this).children('select').prop('required', false);
	    });
	  } else {
	    $('.hei_inside_car').css('display', 'none');
	    $('.hei_inside_car').children('select').prop('required', false);

	    $('.hei_outside_car').each(function() {
	      $(this).css('display', 'block');
	      $(this).children('input').prop('required', true);
	      $(this).children('select').prop('required', true);
	    });
	  }
	});

	// CHECK APPLICANT TYPE
	$('#type').on('change', function() {
		if($('#type').val() == 'Graduate') {
			$('#twelve_gwa_input').prop('readOnly', false);
			$(".are_gwas_unknown_checkbox").css('display', 'flex');

			if($('#are_gwas_unknown').is(":checked")) {
				$("#twelve_gwa_container").css('display', 'block');
				$("#twelve_gwa_container input").prop('required', true);
				$("#twelve_gwa_sems_container").css('display', 'none');
			} else {
				$("#twelve_gwa_container").css('display', 'none');
				$("#twelve_gwa_container input").prop('required', false);
				$("#twelve_gwa_sems_container").css('display', 'block');
			}

			$('#eleven_gwa_container').css('display', 'none');
			$('#eleven_gwa_input').prop('required', false);
			$("#eleven_gwa_sems_container").css('display', 'none');
		} else if($('#type').val() == 'Graduating') {
			$('#twelve_gwa_input').prop('readOnly', false);
			$(".are_gwas_unknown_checkbox").css('display', 'flex');

			if($('#are_gwas_unknown').is(":checked")) {
				$("#twelve_gwa_container").css('display', 'block');
				$("#twelve_gwa_container input").prop('required', true);
				$('#eleven_gwa_container').css('display', 'block');
				$('#eleven_gwa_input').prop('required', true);
				$('.known_gwa').each(function() {
					$(this).css('display', 'none');
				});
			} else {
				$('.unknown_gwa').each(function() {
					$(this).css('display', 'none');
					$(this).children('input').prop('required', false);
				});
				$('.known_gwa').each(function() {
					$(this).css('display', 'block');
				});
			}
		} else {
			$('#twelve_gwa_input').prop('readOnly', true);
			$(".are_gwas_unknown_checkbox").css('display', 'none');
			$("#twelve_gwa_container").css('display', 'block');
			$('#twelve_gwa_input').val('80');
			$('#eleven_gwa_container').css('display', 'none');
			$('#eleven_gwa_input').prop('required', false);
			$('.known_gwa').each(function() {
				$(this).css('display', 'none');
			});
		}
	});

	// IF GWAS ARE UNKNOWN
	$('#are_gwas_unknown').on('change', function() {
		if($('#are_gwas_unknown').is(":checked")) {
			$('.known_gwa').each(function() {
				$(this).css('display', 'none');
			});

			$("#twelve_gwa_container").css('display', 'block');
			$("#twelve_gwa_container input").prop('required', true);
			if($('#type').val() == 'Graduate') {
				$("#eleven_gwa_container").css('display', 'none');
				$("#eleven_gwa_container input").prop('required', false);
			} else {
				$("#eleven_gwa_container").css('display', 'block');
				$("#eleven_gwa_container input").prop('required', true);
			}
		} else {
			$("#twelve_gwa_sems_container").css('display', 'block');
			$('.unknown_gwa').each(function() {
				$(this).css('display', 'none');
				$(this).children('input').prop('required', false);
			});

			if($('#type').val() == 'Graduate') {
				$("#eleven_gwa_sems_container").css('display', 'none');
			} else {
				$("#eleven_gwa_sems_container").css('display', 'block');
			}
		}
	});

	// PERMANENT ADDRESS TOGGLE INPUTS
	$('#perm_add_is_car').bind('change', function() {
		if($('#perm_add_is_car').is(":checked")) {
			$('.inside_car').each(function() {
				$(this).css('display', 'block');
				$(this).children('select').prop('required', true);
			});
			$('.outside_car').each(function() {
				$(this).css('display', 'none');
				$(this).children('input').prop('required', false);
			});
		} else {
			$('.inside_car').each(function() {
				$(this).css('display', 'none');
				$(this).children('select').prop('required', false);
			});
			$('.outside_car').each(function() {
				$(this).css('display', 'block');
				$(this).children('input').prop('required', true);
			});
		}
	});

	// PRESENT ADDRESS TOGGLE INPUTS
	$('#pres_add_is_car').bind('change', function() {
		if($('#pres_add_is_car').is(":checked")) {
			$('.inside_car2').each(function() {
				$(this).css('display', 'block');
				$(this).children('select').prop('required', true);
			});
			$('.outside_car2').each(function() {
				$(this).css('display', 'none');
				$(this).children('input').prop('required', false);
			});
		} else {
			$('.inside_car2').each(function() {
				$(this).css('display', 'none');
				$(this).children('select').prop('required', false);
			});
			$('.outside_car2').each(function() {
				$(this).css('display', 'block');
				$(this).children('input').prop('required', true);
			});
		}
	});

	// PRESENT ADDRESS IS SAME WITH PERMANENT ADDRESS
	$('#pres_is_perm').bind('change', function() {
		if($('#pres_is_perm').is(":checked")) {
			$('.pres_add').css('display', 'none');
			$('.checkbox_pres_add').css('display', 'none');
			$('.pres_add input').each(function() {
				$(this).prop('required', false);
			});
			$('.pres_add select').each(function() {
				$(this).prop('required', false);
			});
		} else {
			$('.pres_add').css('display', 'grid');
			$('.checkbox_pres_add').css('display', 'flex');
			if($('#pres_add_is_car').is(":checked")) {
				$('.pres_add select').each(function() {
					$(this).prop('required', true);
				});
				$('.pres_add input').each(function() {
					$(this).prop('required', false);
				});
			} else {
				$('.pres_add select').each(function() {
					$(this).prop('required', false);
				});
				$('.pres_add input').each(function() {
					$(this).prop('required', true);
				});
			}
		}
	});

	// ADD EVENT LISTENER TO PROVINCE INPUTS
	$('#perm_province').bind('change', function() {
		changeCities(null, '#perm_province', '#perm_muni_city')
	});
	$('#pres_province').bind('change', function() {
		changeCities(null, '#pres_province', '#pres_muni_city')
	});

	// IF FATHER IS DECEASED
	$('#f_is_deceased').bind('change', function() {
		if($('#f_is_deceased').is(":checked")) {
			$('.f_deceased_container').each(function() {
				$(this).css('display', 'none');
			});
		} else {
			$('.f_deceased_container').each(function() {
				$(this).css('display', 'block');
			});
		}
	});

	// IF MOTHER IS DECEASED
	$('#m_is_deceased').bind('change', function() {
		if($('#m_is_deceased').is(":checked")) {
			$('.m_deceased_container').each(function() {
				$(this).css('display', 'none');
			});
			$('.m_deceased_container input').each(function() {
				$(this).prop('required', false);
			});
			$('.m_deceased_container select').each(function() {
				$(this).prop('required', false);
			});
		} else {
			$('.m_deceased_container').each(function() {
				$(this).css('display', 'block');
			});
			$('.m_deceased_container input').each(function() {
				$(this).prop('required', true);
			});
			$('.m_deceased_container select').each(function() {
				$(this).prop('required', true);
			});
		}
	});

	// CHECK IF HAS LEGAL GUARDIAN
	$('.has_legal_guardian').on('change', function() {
		if($('input[name=has_legal_guardian]:checked').val() == 1) {
			$('#legal_guardian_container').css('display', 'grid');
			$('#legal_guardian_container input').each(function() {
				$(this).prop('required', true);
			});
			$('#legal_guardian_container select').each(function() {
				$(this).prop('required', true);
			});
		} else {
			$('#legal_guardian_container').css('display', 'none');
			$('#legal_guardian_container input').each(function() {
				$(this).prop('required', false);
			});
			$('#legal_guardian_container select').each(function() {
				$(this).prop('required', false);
			});
		}
	});

	// IF IP
	$('#is_ip').on('change', function() {
		if($('#is_ip').is(":checked")) {
			$('#tribe_container').css('display', 'grid');
			$('#tribe_input').prop('required', true);
			$('#cert_indigency').prop('required', true);
		} else {
			$('#tribe_container').css('display', 'none');
			$('#tribe_input').prop('required', false);
			$('#cert_indigency').prop('required', false);
		}
	});

	// IF PWD
	$('#is_pwd').on('change', function() {
		if($('#is_pwd').is(":checked")) {
			$('#disability_container').css('display', 'grid');
			$('#disability_select').prop('required', true);
			$('#pwd_id').prop('required', true);
			if($('#disability_select').val() == "Others") {
				$('#disability_input').prop('required', true);
			}
		} else {
			$('#disability_container').css('display', 'none');
			$('#disability_select').prop('required', false);
			$('#pwd_id').prop('required', false);
			$('#disability_input').prop('required', false);
		}
	});

	// IF SP
	$('#is_sp').on('change', function() {
		if($('#is_sp').is(":checked")) {
			$('#sp_container').css('display', 'grid');
			$('#sp_select').prop('required', true);
		} else {
			$('#sp_container').css('display', 'none');
			$('#sp_select').prop('required', false);
		}
	});

	// IF SP
	$('#is_sc').on('change', function() {
		if($('#is_sc').is(":checked")) {
			$('#sc_container').css('display', 'grid');
			$('#sc_select').prop('required', true);
		} else {
			$('#sc_container').css('display', 'none');
			$('#sc_select').prop('required', false);
		}
	});

	// IF TYPE OF DISABILITY IS OTHERS
	$('#disability_select').on('change', function() {
		if($('#disability_select').val() == "Others") {
			$('#disability_input_container').css('display', 'block');
			$('#disability_input').prop('required', true);
		} else {
			$('#disability_input_container').css('display', 'none');
			console.log('hello');
			$('#disability_input').prop('required', false);
		}
	});

	var applicant = {!! json_encode($applicant->toArray(), JSON_HEX_TAG) !!};
	
	if(['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province'].includes(applicant['perm_province'])) {
		window.onload = function() {
			changeCities("{{ $applicant->perm_muni_city }}", '#perm_province', '#perm_muni_city');
		}
	}
	
	if(['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province'].includes(applicant['pres_province'])) {
		window.onload = function() {
			changeCities("{{ $applicant->pres_muni_city }}", '#pres_province', '#pres_muni_city');
		}
	}

	document.getElementById('perm_province').addEventListener('change', changeCities(null, '#perm_province', '#perm_muni_city'));
	
	document.getElementById('pres_province').addEventListener('change', changeCities(null, '#pres_province', '#pres_muni_city'));
</script>
@endsection