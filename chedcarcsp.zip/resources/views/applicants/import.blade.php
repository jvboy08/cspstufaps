@extends('layouts.master')

@section('title')
CHED-CAR Admin | Applicants
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Add applicants</h1>
		<a class="add" href="/applicants">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/applicants/display" enctype="multipart/form-data"> 
		@csrf 
		<!-- CSV FILE -->
		<label for="applicants">CSV File :</label>
		<input type="file" name="applicants" placeholder="Upload a csv file" accept=".csv" required>

		<input type="submit" value="Submit">
	</form>
</section>
@endsection