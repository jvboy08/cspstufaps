@extends('layouts.master_registered_scholar')

@section('title')
CHED-CAR Scholar | Edit 
@endsection

@section('content')
<section class="scholar_body">
  @include('layouts.errors')
  <form id="edit_form" class="edit_form" method="POST" action="/scholar/{{ $scholar->id }}"> 
    @method('PUT') 
    @csrf 
    <div class="stepper">
      <div class="pair_space">
        <h2 class="bold">Edit Information</h2>
        <a class="add" href="{{ url()->previous() }}">Back</a>
      </div>
      <div class="buttons">
        <button type="button" class="step0 active add" onclick="validate(0)"><p>General Information</p></button>
        <button type="button" class="step1 inactive add" onclick="validate(1)"><p>Address Information</p></button>
        <input class="submit" type="submit" value="Submit Changes">
      </div>
    </div>

    <!-- PERSONAL INFORMATION -->
    <div class="step">
      <!-- PERSONAL DETAILS -->
      <div class="round_container">
        <div class="title">
          <h2>General Information</h2>
        </div>
        <div class="pairs">
          <!-- CONTACT NUMBER -->
          <div class="pair">
            <p>Mobile Number <span class="italic">(Optional)</span> :</p>
            <input type="text" name="contact_number" data-parsley-validate-contact="" placeholder="E.g. 09XX-XXX-XXXX" value="{{ $scholar->applicant->contact_number == null ? '' : $scholar->applicant->formatted_contact_number }}">
          </div>

          <!-- FACEBOOK -->
          <div class="pair">
            <p>Facebook Name or Username <span class="italic">(Optional)</span> :</p>
            <input type="text" name="fb_account" placeholder="Enter Facebook name or username" value="{{ $scholar->applicant->fb_account }}">
          </div>

          <!-- CURRENT YEAR LEVEL -->
          <div class="pair">
            <p>Current Year Level :</p>
            <input type="number" name="latest_year_level" placeholder="Enter current year level" value="{{ $scholar->latest_year_level }}" required></input>
          </div>
        </div>
      </div>
    </div>

    <!-- ADDRESS INFORMATION -->
    <div class="step">
      <!-- PERMANENT ADDRESS -->
      <div class="round_container">
        <div class="title">
          <h2>Permanent Address</h2>
          <div class="checkbox">
            <input type="checkbox" id="perm_add_is_car" name="perm_add_is_car" {{ in_array($scholar->applicant->province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'checked' : '' }}>
            <p>Within CAR</p>
          </div>
        </div>

        <div class="pairs">
          <!-- INSIDE CAR -->

          <!-- DISTRICT -->
          <div class="pair inside_car" style="display: {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>District :</p>
            <select id="perm_district" name="perm_district" {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
              <option value="" disabled selected hidden>Select a district</option>
              <option value="Abra" {{ $scholar->applicant->perm_district == "Abra" ? "selected" : ""}}>Abra</option>
              <option value="Apayao" {{ $scholar->applicant->perm_district == "Apayao" ? "selected" : ""}}>Apayao</option>
              <option value="Baguio" {{ $scholar->applicant->perm_district == "Baguio" ? "selected" : ""}}>Baguio</option>
              <option value="Benguet" {{ $scholar->applicant->perm_district == "Benguet" ? "selected" : ""}}>Benguet</option>
              <option value="Ifugao" {{ $scholar->applicant->perm_district == "Ifugao" ? "selected" : ""}}>Ifugao</option>
              <option value="Kalinga" {{ $scholar->applicant->perm_district == "Kalinga" ? "selected" : ""}}>Kalinga</option>
              <option value="Mountain Province" {{ $scholar->applicant->perm_district == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
            </select>
          </div>

          <!-- PROVINCE -->
          <div class="pair inside_car" style="display: {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Province :</p>
            <select id="perm_province" name="perm_province" {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
              <option value="" disabled selected hidden>Select a province</option>
              <option value="Abra" {{ $scholar->applicant->perm_province == "Abra" ? "selected" : ""}}>Abra</option>
              <option value="Apayao" {{ $scholar->applicant->perm_province == "Apayao" ? "selected" : ""}}>Apayao</option>
              <option value="Benguet" {{ $scholar->applicant->perm_province == "Benguet" ? "selected" : ""}}>Benguet</option>
              <option value="Ifugao" {{ $scholar->applicant->perm_province == "Ifugao" ? "selected" : ""}}>Ifugao</option>
              <option value="Kalinga" {{ $scholar->applicant->perm_province == "Kalinga" ? "selected" : ""}}>Kalinga</option>
              <option value="Mountain Province" {{ $scholar->applicant->perm_province == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
            </select>
          </div>

          <!-- MUNICIPALITY OR CITY -->
          <div class="pair inside_car" style="display: {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Municipality or City :</p>
            <select id="perm_muni_city" name="perm_muni_city" {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
              <option value="" disabled selected hidden>Please select a province first</option>
            </select>
          </div>

          <!-- OUTSIDE CAR -->

          <!-- DISTRICT -->
          <div class="pair outside_car" style="display: {{ !in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>District :</p>
            <input id="perm_district2" type="text" name="perm_district2" placeholder="Enter district" value="{{ $scholar->applicant->perm_district }}" {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? '' : 'required' }}>
          </div>

          <!-- PROVINCE -->
          <div class="pair outside_car" style="display: {{ !in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Province :</p>
            <input id="perm_province2" type="text" name="perm_province2" placeholder="Enter province" value="{{ $scholar->applicant->perm_province }}" {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? '' : 'required' }}>
          </div>

          <!-- MUNICIPALITY OR CITY -->
          <div class="pair outside_car" style="display: {{ !in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Municipality or City :</p>
            <input id="perm_muni_city2" type="text" name="perm_muni_city2" placeholder="Enter municipality or city" value="{{ $scholar->applicant->perm_muni_city }}" {{ in_array($scholar->applicant->perm_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? '' : 'required' }}>
          </div>

          <!-- BARANGAY -->
          <div class="pair">
            <p>Street, Barangay :</p>
            <input type="text" name="perm_barangay" placeholder="Enter barangay and other details" value="{{ $scholar->applicant->perm_barangay }}" required>
          </div>

          <!-- ZIP CODE -->
          <div class="pair">
            <p>Zip Code :</p>
            <input type="number" name="perm_zip_code" placeholder="Enter zip code" value="{{ $scholar->applicant->perm_zip_code }}" required>
          </div>
        </div>
      </div>

      <!-- PRESENT ADDRESS -->
      <div class="round_container">
        <div class="title title_tight">
          <h2>Present Address</h2>
          <div class="checkboxes">
            <div class="checkbox checkbox_pres_add" style="display: {{ !$scholar->applicant->pres_is_perm ? 'flex' : 'none' }};">
              <input type="checkbox" id="pres_add_is_car" name="pres_add_is_car" {{ in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'checked' : '' }}>
              <p>Within CAR</p>
            </div>
            <div class="checkbox">
              <input type="checkbox" id="pres_is_perm" name="pres_is_perm" {{ $scholar->applicant->pres_is_perm ? 'checked' : '' }}>
              <p>Same with Permanent Address</p>
            </div>
          </div>
        </div>

        <div class="pairs pres_add" style="display: {{ !$scholar->applicant->pres_is_perm ? 'grid' : 'none' }};">
          <!-- INSIDE CAR -->

          <!-- DISTRICT -->
          <div class="pair inside_car2" style="display: {{ in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>District :</p>
            <select id="pres_district" name="pres_district" {{ !$scholar->applicant->pres_is_perm && in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
              <option value="" disabled selected hidden>Select a district</option>
              <option value="Abra" {{ $scholar->applicant->pres_district == "Abra" ? "selected" : ""}}>Abra</option>
              <option value="Apayao" {{ $scholar->applicant->pres_district == "Apayao" ? "selected" : ""}}>Apayao</option>
              <option value="Baguio" {{ $scholar->applicant->pres_district == "Baguio" ? "selected" : ""}}>Baguio</option>
              <option value="Benguet" {{ $scholar->applicant->pres_district == "Benguet" ? "selected" : ""}}>Benguet</option>
              <option value="Ifugao" {{ $scholar->applicant->pres_district == "Ifugao" ? "selected" : ""}}>Ifugao</option>
              <option value="Kalinga" {{ $scholar->applicant->pres_district == "Kalinga" ? "selected" : ""}}>Kalinga</option>
              <option value="Mountain Province" {{ $scholar->applicant->pres_district == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
            </select>
          </div>

          <!-- PROVINCE -->
          <div class="pair inside_car2" style="display: {{ in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Province :</p>
            <select id="pres_province" name="pres_province" {{ !$scholar->applicant->pres_is_perm && in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
              <option value="" disabled selected hidden>Select a province</option>
              <option value="Abra" {{ $scholar->applicant->pres_province == "Abra" ? "selected" : ""}}>Abra</option>
              <option value="Apayao" {{ $scholar->applicant->pres_province == "Apayao" ? "selected" : ""}}>Apayao</option>
              <option value="Benguet" {{ $scholar->applicant->pres_province == "Benguet" ? "selected" : ""}}>Benguet</option>
              <option value="Ifugao" {{ $scholar->applicant->pres_province == "Ifugao" ? "selected" : ""}}>Ifugao</option>
              <option value="Kalinga" {{ $scholar->applicant->pres_province == "Kalinga" ? "selected" : ""}}>Kalinga</option>
              <option value="Mountain Province" {{ $scholar->applicant->pres_province == "Mountain Province" ? "selected" : ""}}>Mountain Province</option>
            </select>
          </div>

          <!-- MUNICIPALITY OR CITY -->
          <div class="pair inside_car2" style="display: {{ in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Municipality or City :</p>
            <select id="pres_muni_city" name="pres_muni_city" {{ !$scholar->applicant->pres_is_perm && in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
              <option value="" disabled selected hidden>Please select a province first</option>
            </select>
          </div>

          <!-- OUTSIDE CAR -->

          <!-- DISTRICT -->
          <div class="pair outside_car2" style="display: {{ !in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>District :</p>
            <input id="pres_district2" type="text" name="pres_district2" placeholder="Enter district" value="{{ $scholar->applicant->pres_district }}" {{ !$scholar->applicant->pres_is_perm && !in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
          </div>

          <!-- PROVINCE -->
          <div class="pair outside_car2" style="display: {{ !in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Province :</p>
            <input id="pres_province2" type="text" name="pres_province2" placeholder="Enter province" value="{{ $scholar->applicant->pres_province }}" {{ !$scholar->applicant->pres_is_perm && !in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
          </div>

          <!-- MUNICIPALITY OR CITY -->
          <div class="pair outside_car2" style="display: {{ !in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'block' : 'none' }};">
            <p>Municipality or City :</p>
            <input id="pres_muni_city2" type="text" name="pres_muni_city2" placeholder="Enter municipality or city" value="{{ $scholar->applicant->pres_muni_city }}" {{ !$scholar->applicant->pres_is_perm && !in_array($scholar->applicant->pres_province, ['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province']) ? 'required' : '' }}>
          </div>

          <!-- BARANGAY -->
          <div class="pair">
            <p>Street, Barangay :</p>
            <input type="text" name="pres_barangay" placeholder="Enter barangay and other details" value="{{ $scholar->applicant->pres_barangay }}" {{ !$scholar->applicant->pres_is_perm ? 'required' : '' }}>
          </div>

          <!-- ZIP CODE -->
          <div class="pair">
            <p>Zip Code :</p>
            <input type="number" name="pres_zip_code" placeholder="Enter zip code" value="{{ $scholar->applicant->pres_zip_code }}" {{ !$scholar->applicant->pres_is_perm ? 'required' : '' }}>
          </div>
        </div>
      </div>
    </div>
  </form>
</section>
<script type="text/javascript" src="{{ URL::asset('js/index.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js" integrity="sha512-eyHL1atYNycXNXZMDndxrDhNAegH2BDWt1TmkXJPoGf1WLlNYt08CSjkqF5lnCRmdm3IrkHid8s2jOUY4NIZVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script>

  function navigateTo(index) {
    $steps.removeClass('active_step').eq(index).addClass('active_step');
    for(let i = 0; i <= $steps.length - 1; i++) {
      if(i == index) {
        $('.step' + index).addClass("active");
        $('.step' + index).removeClass("inactive");
      } else {
        $('.step' + i).addClass("inactive");
        $('.step' + i).removeClass("active");
      }
    }
  };

  function validate(index) {
    $('#edit_form').parsley().whenValidate({
      group: 'block-' + current_index()
    }).done(function() {
      navigateTo(index);
    });
  }

  function current_index() {
    return $steps.index($steps.filter('.active_step'));
  }

  var $steps = $('.step');
  $steps.each(function(index, step) {
    $(step).find(':input').attr('data-parsley-group', 'block-' + index);
  });

  navigateTo(0);

  // CONTACT NUMBER VALIDATOR
  window.Parsley.addValidator('validateContact', {
    validateString: function(value) {
      if (/^((09)\d{2}-\d{3}-\d{4})$/.test(value)) {
        return true;
      } else if (/^$/.test(value)) {
        return true;
      } else {
        return false;
      }
    },
    messages: {
      en: 'Valid format: 09XX-XXX-XXXX'
    }
  });

  // PERMANENT ADDRESS TOGGLE INPUTS
  $('#perm_add_is_car').bind('change', function() {
    if($('#perm_add_is_car').is(":checked")) {
      $('.inside_car').each(function() {
        $(this).css('display', 'block');
        $(this).children('select').prop('required', true);
      });
      $('.outside_car').each(function() {
        $(this).css('display', 'none');
        $(this).children('input').prop('required', false);
      });
    } else {
      $('.inside_car').each(function() {
        $(this).css('display', 'none');
        $(this).children('select').prop('required', false);
      });
      $('.outside_car').each(function() {
        $(this).css('display', 'block');
        $(this).children('input').prop('required', true);
      });
    }
  });

  // PRESENT ADDRESS TOGGLE INPUTS
  $('#pres_add_is_car').bind('change', function() {
    if($('#pres_add_is_car').is(":checked")) {
      $('.inside_car2').each(function() {
        $(this).css('display', 'block');
        $(this).children('select').prop('required', true);
      });
      $('.outside_car2').each(function() {
        $(this).css('display', 'none');
        $(this).children('input').prop('required', false);
      });
    } else {
      $('.inside_car2').each(function() {
        $(this).css('display', 'none');
        $(this).children('select').prop('required', false);
      });
      $('.outside_car2').each(function() {
        $(this).css('display', 'block');
        $(this).children('input').prop('required', true);
      });
    }
  });

  // PRESENT ADDRESS IS SAME WITH PERMANENT ADDRESS
  $('#pres_is_perm').bind('change', function() {
    if($('#pres_is_perm').is(":checked")) {
      $('.pres_add').css('display', 'none');
      $('.checkbox_pres_add').css('display', 'none');
      $('.pres_add input').each(function() {
        $(this).prop('required', false);
      });
      $('.pres_add select').each(function() {
        $(this).prop('required', false);
      });
    } else {
      $('.pres_add').css('display', 'grid');
      $('.checkbox_pres_add').css('display', 'flex');
      if($('#pres_add_is_car').is(":checked")) {
        $('.pres_add select').each(function() {
          $(this).prop('required', true);
        });
        $('.pres_add input').each(function() {
          $(this).prop('required', false);
        });
      } else {
        $('.pres_add select').each(function() {
          $(this).prop('required', false);
        });
        $('.pres_add input').each(function() {
          $(this).prop('required', true);
        });
      }
    }
  });

  // ADD EVENT LISTENER TO PROVINCE INPUTS
  $('#perm_province').bind('change', function() {
    changeCities(null, '#perm_province', '#perm_muni_city')
  });
  $('#pres_province').bind('change', function() {
    changeCities(null, '#pres_province', '#pres_muni_city')
  });

  // IF FATHER IS DECEASED
  $('#f_is_deceased').bind('change', function() {
    if($('#f_is_deceased').is(":checked")) {
      $('.f_deceased_container').each(function() {
        $(this).css('display', 'none');
      });
    } else {
      $('.f_deceased_container').each(function() {
        $(this).css('display', 'block');
      });
    }
  });

  // IF MOTHER IS DECEASED
  $('#m_is_deceased').bind('change', function() {
    if($('#m_is_deceased').is(":checked")) {
      $('.m_deceased_container').each(function() {
        $(this).css('display', 'none');
      });
      $('.m_deceased_container input').each(function() {
        $(this).prop('required', false);
      });
      $('.m_deceased_container select').each(function() {
        $(this).prop('required', false);
      });
    } else {
      $('.m_deceased_container').each(function() {
        $(this).css('display', 'block');
      });
      $('.m_deceased_container input').each(function() {
        $(this).prop('required', true);
      });
      $('.m_deceased_container select').each(function() {
        $(this).prop('required', true);
      });
    }
  });

  // CHECK IF HAS LEGAL GUARDIAN
  $('.has_legal_guardian').on('change', function() {
    if($('input[name=has_legal_guardian]:checked').val() == 1) {
      $('#legal_guardian_container').css('display', 'grid');
      $('#legal_guardian_container input').each(function() {
        $(this).prop('required', true);
      });
      $('#legal_guardian_container select').each(function() {
        $(this).prop('required', true);
      });
    } else {
      $('#legal_guardian_container').css('display', 'none');
      $('#legal_guardian_container input').each(function() {
        $(this).prop('required', false);
      });
      $('#legal_guardian_container select').each(function() {
        $(this).prop('required', false);
      });
    }
  });

  // IF IP
  $('#is_ip').on('change', function() {
    if($('#is_ip').is(":checked")) {
      $('#tribe_container').css('display', 'grid');
      $('#tribe_input').prop('required', true);
      $('#cert_indigency').prop('required', true);
    } else {
      $('#tribe_container').css('display', 'none');
      $('#tribe_input').prop('required', false);
      $('#cert_indigency').prop('required', false);
    }
  });

  // IF PWD
  $('#is_pwd').on('change', function() {
    if($('#is_pwd').is(":checked")) {
      $('#disability_container').css('display', 'grid');
      $('#disability_select').prop('required', true);
      $('#pwd_id').prop('required', true);
      if($('#disability_select').val() == "Others") {
        $('#disability_input').prop('required', true);
      }
    } else {
      $('#disability_container').css('display', 'none');
      $('#disability_select').prop('required', false);
      $('#pwd_id').prop('required', false);
      $('#disability_input').prop('required', false);
    }
  });

  // IF SP
  $('#is_sp').on('change', function() {
    if($('#is_sp').is(":checked")) {
      $('#sp_container').css('display', 'grid');
      $('#sp_select').prop('required', true);
    } else {
      $('#sp_container').css('display', 'none');
      $('#sp_select').prop('required', false);
    }
  });

  // IF SP
  $('#is_sc').on('change', function() {
    if($('#is_sc').is(":checked")) {
      $('#sc_container').css('display', 'grid');
      $('#sc_select').prop('required', true);
    } else {
      $('#sc_container').css('display', 'none');
      $('#sc_select').prop('required', false);
    }
  });

  // IF TYPE OF DISABILITY IS OTHERS
  $('#disability_select').on('change', function() {
    if($('#disability_select').val() == "Others") {
      $('#disability_input_container').css('display', 'block');
      $('#disability_input').prop('required', true);
    } else {
      $('#disability_input_container').css('display', 'none');
      console.log('hello');
      $('#disability_input').prop('required', false);
    }
  });

  var applicant = {!! json_encode($scholar->applicant->toArray(), JSON_HEX_TAG) !!};
  
  if(['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province'].includes(applicant['perm_province'])) {
    window.onload = function() {
      changeCities("{{ $scholar->applicant->perm_muni_city }}", '#perm_province', '#perm_muni_city');
    }
  }
  
  if(['Abra', 'Apayao', 'Benguet', 'Ifugao', 'Kalinga', 'Mountain Province'].includes(applicant['pres_province'])) {
    window.onload = function() {
      changeCities("{{ $scholar->applicant->pres_muni_city }}", '#pres_province', '#pres_muni_city');
    }
  }

  document.getElementById('perm_province').addEventListener('change', changeCities(null, '#perm_province', '#perm_muni_city'));
  
  document.getElementById('pres_province').addEventListener('change', changeCities(null, '#pres_province', '#pres_muni_city'));
</script>
@endsection