@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Scholar
@endsection

@section('content')
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/scholar/sign_up">
        @csrf
        <h1>Sign Up as Scholar</h1>
        <h6>Please make sure that you are a CHED-CAR scholar and the email address that you will be entering is the one that you have provided in<br>your application form.</h6>
        @include('layouts.errors_no_icon')
        <input type="email" name="email" placeholder="Email address" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <input type="submit" value="Sign Up">
        <a href="/scholar/login"><p>Already have an account? <span class="bold">Log In</span></p></a>
      </form>
    </div>
  </section>
@endsection