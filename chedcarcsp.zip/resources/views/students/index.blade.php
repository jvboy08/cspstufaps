@extends('layouts.master_registered_scholar')

@section('title')
CHED-CAR Scholar | Home
@endsection

@section('content')
<section class="scholar_body">
	<div class="row1">
		<div class="box blue_box">
			<div class="head">
				<div class="title">
					<span class="icon material-icons-round">school</span>
					<p>Financial Assistance Program</p>
				</div>
				<div class="status">{{ $scholar->latest_status }}</div>
			</div>
			<h2>{{ $scholar->award->program->program_name }}</h2>
		</div>
		<div class="box">
			<div class="head">
				<div class="title">
					<span class="icon material-icons-round">person</span>
					<p class="bold">Personal Information</p>
				</div>
				<a href="/scholar/{{ $scholar->id }}/edit" class="add yellow_btn">Edit</a>
			</div>
			<h2>{{ $scholar->applicant->full_name }}</h2>
			<!-- @if($scholar->applicant->institution_id != null)
			<p class="italic">{{ $scholar->applicant->institution->institution_name }}</p>
			@else
			<p class="italic">{{ $scholar->applicant->hei_out_car_name }}</p>
			@endif -->
			<div class="info">
				<p class="italic">Always keep your information up-to-date.</p>
			</div>
		</div>
	</div>

	<div class="row2">
		<div class="right">
			<div class="box">
				<div class="head">
					<div class="title">
						<span class="icon material-icons-round">verified</span>
						<p class="bold">Scholarship Details</p>
					</div>
				</div>
				<div class="details">
					<div class="pair">
						<p class="italic">Award Number</p>
						<p class="bold">{{ $scholar->award_number }}</p>
					</div>
					<div class="pair">
						<p class="italic">Financial Benefits Per Semester</p>
						<p class="bold">PHP {{ number_format($scholar->award->program->amount_per_sem, 2, '.', ',') }}</p>
					</div>
					<div class="pair">
						<p class="italic">Academic Period Accepted</p>
						<p class="bold">A.Y. {{ $scholar->acad_year_accepted }} - {{ $scholar->acad_year_accepted + 1 }}, {{ $scholar->semester_accepted == 1 ? '1st' : '2nd'}} Semester</p>
					</div>
					<div class="pair">
						<p class="italic">Total Benefits Received</p>
						<p class="bold">{{ $sum == 0 ? 'No benefits received yet' : 'PHP '.number_format($sum, 2, '.', ',') }}</p>
					</div>
				</div>
			</div>
		</div>
		<div class="right">
			@if($scholar->is_thru_hei == 0 && in_array($scholar->latest_status, ['Active', 'Replacement']))
			<div class="box">
				<div class="head">
					<div class="title">
						<span class="icon material-icons-round">credit_score</span>
						<p class="bold">Payment Requirements</p>
					</div>
				</div>
				<div class="info">
					<p class="italic">If you will be receiving financial benefits through your school, you can <a onclick="return confirm('Are you sure that you will be receiving financial benefits from your school? This action will hide this section.')" href="/requirements/{{ $scholar->id }}/is_thru_hei">click this</a> to hide this section. Otherwise, please provide the following documents to receive financial benefits through your bank account. (Supports: Image, PDF)</p>
				</div>
				@if($scholar->school_id == null)
				<form class="requirements_form" method="POST" action="/requirements/{{ $scholar->id }}" enctype="multipart/form-data"> 
				@csrf 
					<div class="head requirements_title">
						<p class="bold">School ID and ATM Card</p>
						@if($scholar->school_id == null)
						<input type="submit" value="Submit" class="submit1">
						@endif
					</div>
					<div class="files">
						<div class="pair_input">
							<p>Front of School ID :</p>
							<input type="file" name="school_id" accept="image/png, image/jpeg, application/pdf" required>
						</div>
						<div class="pair_input">
							<p>Front of Land Bank ATM Card :</p>
							<input type="file" name="atm_card" accept="image/png, image/jpeg, application/pdf" required>
						</div>
					</div>
					<input type="submit" value="Submit" class="submit2">
				</form>
				@else
				<div class="head requirements_title">
					<p class="bold">School ID and ATM Card</p>
				</div>
				<div class="files">
					<div class="info">
						<p>School ID</p>
						<div>
							<a class="option" href="{{ $scholar->school_id }}" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<a class="option" href="/requirements/{{ $scholar->id }}/school_id/edit">
							<div><span class="material-icons-round">create</span><p>Update</p></div>
							</a>
						</div>
					</div>
					<div class="info">
						<p>Land Bank Card</p>
						<div>
							<a class="option" href="{{ $scholar->atm_card }}" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<a class="option" href="/requirements/{{ $scholar->id }}/atm_card/edit">
							<div><span class="material-icons-round">create</span><p>Edit</p></div>
							</a>
						</div>
					</div>
				</div>
				@endif

				<form class="requirements_form" method="POST" action="/requirements/{{ $scholar->id }}" enctype="multipart/form-data">
				@csrf 
				<div class="head requirements_title">
					<div class="title">
						<p class="bold">Semestral Requirements</p>
					</div>
					@if($unchecked_semestral_award == null)
					<input type="submit" value="Submit" class="submit1">
					@endif
				</div>
				<div class="info">
					<p class="italic">After the administrator reviews your uploaded semestral requirements and the status given to you is <span class="bold">Active</span>, you will be able to upload semestral requirements again for the following semester.</p>
				</div>
				@if($unchecked_semestral_award == null)
				<div class="files">
					<div class="pair_input">
						@if($scholar->latest_semester == 1)
						<p>Certification of Enrollment and Billing<br><span class="italic">For</span> <span class="italic bold">A.Y. {{ $scholar->latest_acad_year }}-{{ $scholar->latest_acad_year + 1}}, 2nd Semester</span></p>
						@else
						<p>Certification of Enrollment and Billing<br><span class="italic">For</span> <span class="italic bold">A.Y. {{ $scholar->latest_acad_year + 1 }}-{{ $scholar->latest_acad_year + 2}}, 1st Semester</span></p>
						@endif
						<input type="file" name="enrollment_form" accept="image/png, image/jpeg, application/pdf" required>
					</div>
					<div class="pair_input">
						<p>Certification of Grades<br><span class="italic">For</span> <span class="italic bold">A.Y. {{ $scholar->latest_acad_year }}-{{ $scholar->latest_acad_year + 1}}, {{ $scholar->latest_semester == 1 ? '1st' : '2nd' }} Semester</span></p>
						<input type="file" name="previous_grades" accept="image/png, image/jpeg, application/pdf" required>
					</div>
				</div>
				<input type="submit" value="Submit" class="submit2">
				@else
				<div class="files">
					<div class="info">
						@if($scholar->latest_semester == 1)
						<p>Enrollment & Billing<br><span class="italic bold">A.Y. {{ $scholar->latest_acad_year }}, 2nd Sem</span></p>
						@else
						<p>Enrollment & Billing<br><span class="italic bold">A.Y. {{ $scholar->latest_acad_year + 1 }}, 1st Sem</span></p>
						@endif
						<div>
							<a class="option" href="{{ $unchecked_semestral_award->enrollment_form }}" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<a class="option" href="/requirements/{{ $unchecked_semestral_award->id }}/enrollment_form/edit">
							<div><span class="material-icons-round">create</span><p>Edit</p></div>
							</a>
						</div>
					</div>
					<div class="info">
						<p>Previous Grades<br><span class="italic bold">A.Y. {{ $scholar->latest_acad_year }}, {{ $scholar->latest_semester == 1 ? '1st' : '2nd' }} Sem</span></p>
						<div>
							<a class="option" href="{{ $unchecked_semestral_award->previous_grades }}" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<a class="option" href="/requirements/{{ $unchecked_semestral_award->id }}/previous_grades/edit">
							<div><span class="material-icons-round">create</span><p>Edit</p></div>
							</a>
						</div>
					</div>
				</div>
				@endif
				</form>
			</div>
			@endif

			<div class="box">
				<div class="head">
					<div class="title">
						<span class="icon material-icons-round">payments</span>
						<p class="bold">Financial Benefits Received</p>
					</div>
				</div>
				<div class="info">
					<p class="italic">If the payment in a semester has been processed, please indicate if you have already received it by clicking the corresponding switch button in the last column.</p>
				</div>
				<div class="table">
					<table>
						<thead>
							<tr>
								<th>Academic Period</th>
								<th>Year Level</th>
								<th>Status</th>
								<th>Amount Processed</th>
								<th>Date Processed</th>
								<th>Received</th>
							</tr>
						</thead>
						<tbody>
							@foreach($semestral_awards as $key => $semestral_award)
								<tr>
									<td>A.Y. {{ $semestral_award->acad_year }}, {{ $semestral_award->semester == 1 ? '1st' : '2nd'}} Sem</td>
									<td>{{ $semestral_award->status == 'Replaced' ? 'N/A' : $semestral_award->full_year_level }}</td>
									<td>
										@if($loop->index == $semestral_awards->count() - 1 && in_array($semestral_award->status, array('Terminated', 'Graduate', 'Waived', 'Deferred')) && !empty($replaced_by))
											{{ $semestral_award->status }} & Replaced
										@else
											{{ $semestral_award->status }}
										@endif
									</td>
									<td>
										@if($semestral_award->amount_chedro != null)
											PHP {{ number_format($semestral_award->amount_chedro, 2, '.', ',') }}
										@else
											@if(in_array($semestral_award->status, array('Active', 'Replacement', 'Graduating', 'Graduate')))
												Not yet processed
											@else
												N/A
											@endif
										@endif
									</td>
									<td>
										@if($semestral_award->date_processed != null)
											{{ date('M j, Y', strtotime($semestral_award->date_processed)) }}
										@else
										N/A
										@endif
									</td>
									<td>
										@if($semestral_award->date_processed != null)
										<div class="toggle">
						                  <label class="switch">
						                    <input class="received_checkbox" onChange="update_is_payment_received(this)"type="checkbox" name="is_payment_received" data-id="{{ $semestral_award->id }}" {{ $semestral_award->is_payment_received ? 'checked' : '' }} >
						                    <span class="slider round"></span>
						                  </label>
						                </div>
										@else
										N/A
										@endif
									</td>
								</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</section>
<script>
	function update_is_payment_received(checkbox) {
		var value = $(checkbox).is(":checked") ? 1 : 0;
		console.log(value);
		$.ajax({
	        url: '/update/is_payment_received/'+$(checkbox).data('id')+'/'+value,
	        type: "GET",
	        dataType: "text"
	    });
	}
</script>
@endsection