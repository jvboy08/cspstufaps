@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Scholar
@endsection

@section('content')
<section class="login_signup">
	<div class="form_container round_container">
		<div class="message">
			<h1>Email address is not yet verified</h1>
			<p>Please click the link in the email sent to you. If you don't see it, you may need to check your spam folder.</p>
			<a class="add" href="/scholar/login">Return to Log In Page</a>
			<p>Still can't find the email?</p>
			<a class="add dark_grey_btn" href="/resend/{{ $email }}">Resend Email and Log In</a>
		</div>
	</div>
</section>
@endsection