@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Scholar
@endsection

@section('content')
<section class="login_signup">
	<div class="form_container round_container">
		<div class="message">
			<h1>Email Not Found</h1>
			<p>The email address provided does not exist in the list of CHED-CAR scholars.<br><br>If you forgot the email address you inputted in your application form, you may reach out to us with any of the provided contact information found at the bottom of the homepage.</p>
			<a class="add" href="/">Return to Homepage</a>
		</div>
	</div>
</section>
@endsection