@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Scholar
@endsection

@section('content')
<section class="login_signup">
	<div class="form_container round_container">
		<div class="message">
			<h1>Email Verified</h1>
			<p>Your email address was successfully verified! You may now log in using your email address and password.</p>
			<a class="add" href="/scholar/login">Proceed to Log In Page</a>
		</div>
	</div>
</section>
@endsection