@extends('layouts.master_registered_scholar')

@section('title')
CHED-CAR Scholar | Edit 
@endsection

@section('content')
<section class="scholar_form">
	<section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/requirements/{{ $id }}/{{ $document }}" enctype="multipart/form-data">
        @method('PUT')
        @csrf
        <div class="head">
          <h2 class="bold">Update Document</h2>
          <a class="add yellow_btn" href="/scholar/home">Back</a>
        </div>
        <div class="pair_input">
          @if($document == 'school_id')
            <p class="italic">Front of School ID :</p>
          @elseif($document == 'atm_card')
            <p class="italic">Front of Land Bank ATM Card :</p>
          @elseif($document == 'enrollment_form')
            <p class="italic">Certification of enrollment and billing :</p>
          @else
            <p class="italic">Certification of grades from previous sem :</p>
          @endif
          <input type="file" name="file" accept="image/png, image/jpeg, application/pdf" required>
        </div>
        <input type="submit" value="Submit">
      </form>
    </div>
  </section> 
</section>
@endsection