@extends('layouts.master')

@section('title')
CHED-CAR Admin | Payments
@endsection

@section('body')
<section>
	<div class="header">
		@if(!array_key_exists('payment', $sort_filters) || (array_key_exists('payment', $sort_filters) && $sort_filters['payment'] == 0))
			@if(!$semestral_awards->isEmpty())
			<h1 class="result">{{ $semestral_awards->total()}} {{ $semestral_awards->total() > 1 ? 'Unprocessed Payments' : 'Unprocessed Payment' }} Found</h1>
			@else
			<h1 class="result">No Unprocessed Payments Found</h1>
			@endif
		@else
			@if(!$semestral_awards->isEmpty())
			<h1 class="result">{{ $semestral_awards->total()}} {{ $semestral_awards->total() > 1 ? 'Processed Payments' : 'Processed Payment' }} Found</h1>
			@else
			<h1 class="result">No Processed Payments Found</h1>
			@endif
		@endif
		<div class="header_buttons">
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/payments" method="GET">
			<div class="filter">
				<div class="pairs">

					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Name</h3>
						@if(array_key_exists('name', $sort_filters))
						<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
						@else						
						<input type="text" name="name" placeholder="Enter last or first name" id="name">
						@endif
					</div>

					<!-- SORT BY -->
					<div class="pair">
						<h3>Sort By</h3>
						<select name="sort">
							@if(array_key_exists('sort', $sort_filters))
								<option value="award_number" {{ $sort_filters['sort'] == 'award_number' ? 'selected' : ''}}>Award Number</option>
								<option value="alphabetical" {{ $sort_filters['sort'] == 'alphabetical' ? 'selected' : ''}}>Alphabetical</option>
							@else
								<option value="award_number" selected>Award Number</option>
								<option value="alphabetical">Alphabetical</option>
							@endif
						</select>
					</div>

					<!-- FUNDING -->
					<div class="pair">
						<h3>Payment Status</h3>
						<select name="payment">
							@if(array_key_exists('payment', $sort_filters))
								<option value="0" {{ $sort_filters['payment'] == 0 ? 'selected' : ''}}>Not Yet Processed</option>
								<option value="1" {{ $sort_filters['payment'] == 1 ? 'selected' : ''}}>Processed</option>
							@else
								<option value="0" selected>Not Yet Processed</option>
								<option value="1">Processed</option>
							@endif
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>
			<div class="filter">
				<div class="pairs">

					<!-- ACADEMIC YEAR -->
					<div class="pair">
						<h3>Academic Period</h3>
						<select name="period">
							<option value="" disabled selected hidden>Select an academic period</option>
							@if(array_key_exists('period', $sort_filters))
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Semester</option>
						        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Semester</option>
						    @endfor
						    @else
							@for($i = 2016; $i <= now()->year; $i++)
						        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Semester</option>
						        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Semester</option>
						    @endfor
						    @endif
						</select>
					</div>
					
					<!-- INSTITUTION -->
					<div class="pair">
						<h3>Institution</h3>
						<select name="institution">
							<option value="" disabled selected hidden>Select a higher education institution</option>
							@if(array_key_exists('institution', $sort_filters))
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}" {{ $institution->id == $sort_filters['institution'] ? 'selected' : '' }}>{{ $institution->institution_name }}</option>
							@endforeach
							@else
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}">{{ $institution->institution_name }}</option>
							@endforeach
							@endif
						</select>
					</div>
					
					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							@if(array_key_exists('program', $sort_filters))
							@foreach($programs as $program)
								<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
							@endforeach
							@else
							@foreach($programs as $key => $program)
								<option value="{{ $program->id }}" {{ $key == 0 ? 'selected' : ''}}>{{ $program->code }}</option>
							@endforeach
							@endif
						</select>
					</div>

					<!-- MODE OF PAYMENT -->
					<div class="pair">
						<h3>Mode of Payment</h3>
						<select name="mode_of_payment">
							<option value="" disabled selected hidden>Select a mode of payment</option>
							@if(array_key_exists('mode_of_payment', $sort_filters))
								<option value="HEI" {{$sort_filters['mode_of_payment'] == 'HEI' ? 'selected' : '' }}>HEI – if through the HEI</option>
								<option value="STUDENT" {{$sort_filters['mode_of_payment'] == 'STUDENT' ? 'selected' : '' }}>STUDENT – if through the ATM/Cheque</option>
						    @else
								<option value="HEI">HEI – if through the HEI</option>
								<option value="STUDENT">STUDENT – if through ATM/Cheque</option>
						    @endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$semestral_awards->isEmpty())
	<form id="amount_form" method="POST" action="/payments/set_amount">
		@method('PUT')
		@csrf 
		@if(!array_key_exists('payment', $sort_filters) || (array_key_exists('payment', $sort_filters) && $sort_filters['payment'] == 0))
		<div class="set_amount_container">
			<div class="header">
				<h1 id="count_selected" class="result">0 Selected</h1>
			</div>
			<div class="set_amount functions">
				<div class="filters">
					<div class="pairs">
						<div class="pair">
							<h3>Amount Processed</h3>
							<input type="number" name="amount" placeholder="Enter amount processed" value="{{ $amount_per_sem }}"required>
						</div>

						<div class="pair">
							<h3>Date Processed</h3>
							<input type="date" name="date_processed" placeholder="Enter date processed" required>
						</div>
					</div>
				</div>
				<div class="filters">
					<div class="pairs">
						<div class="pair">
							<h3>Mode of Payment</h3>
							<select name="mode_of_payment" required>
								<option value="" disabled selected hidden>Select a mode of payment</option>
								<option value="HEI">HEI – if through the HEI</option>
								<option value="STUDENT">STUDENT – if through ATM/Cheque</option>
							</select>
						</div>
						<input type="submit" value="Set as Processed">
					</div>
				</div>
			</div>
		</div>
		@endif
		<div class="table">
			<table>
				<thead>
					<tr>
						@if(!array_key_exists('payment', $sort_filters) || (array_key_exists('payment', $sort_filters) && $sort_filters['payment'] == 0))
						<th class="checkbox"><input id="payments" type="checkbox"></th>
						@else
						<th>No.</th>
						@endif
						<th>Full Name</th>
						<th>Award Number</th>
						<th>Academic Period</th>
						@if((array_key_exists('payment', $sort_filters) && $sort_filters['payment'] == 1))
						<th>Amount</th>
						<th>Date</th>
						<th>Mode</th>
						@else
						<th>Payment Status</th>
						@endif
						<th>Settings</th>
					</tr>
				</thead>
				<tbody>
					@foreach($semestral_awards as $key => $semestral_award)
						<tr>
							@if(!array_key_exists('payment', $sort_filters) || (array_key_exists('payment', $sort_filters) && $sort_filters['payment'] == 0))
							<td class="checkbox"><input onclick="set_count(this)" type="checkbox" name="semestral_awards[]" value="{{ $semestral_award->semestral_award_id }}"></td>
							@else
							<td>{{ $key + $semestral_awards->firstItem() }}</td>
							@endif
							<td>{{ $semestral_award->applicant->full_name }}</td>
							<td>{{ $semestral_award->award_number }}</td>
							@if((array_key_exists('payment', $sort_filters) && $sort_filters['payment'] == 1))
							<td>A.Y. {{ $semestral_award->acad_year }}, {{ $semestral_award->semester == 1 ? '1st' : '2nd' }} Sem</td>
							<td>{{ number_format($semestral_award->amount_chedro, 2, '.', ',') }}</td>
							<td>{{ date('M j, Y', strtotime($semestral_award->date_processed)) }}</td>
							<td>{{ $semestral_award->mode_of_payment }}</td>
							@else
							<td>A.Y. {{ $semestral_award->acad_year }} - {{ $semestral_award->acad_year + 1 }}, {{ $semestral_award->semester == 1 ? '1st' : '2nd' }} Semester</td>
							<td>Not yet processed</td>
							@endif
							<td class="settings">
								<a href="/scholars/{{ $semestral_award->scholar_id }}/semestral_awards/{{ $semestral_award->semestral_award_id }}/edit" target="_blank">
								<div><span class="material-icons-round">edit</span><p>Edit</p></div>
								</a>
								<a href="/scholars/{{ $semestral_award->scholar_id }}" target="_blank">
								<div><span class="material-icons-round">visibility</span><p>View</p></div>
								</a>
							</td>
						</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<div class="pagination">
			<div class="previous">{{ $semestral_awards->appends($sort_filters)->links() }}</div>
		</div>
	</form>
	@endif
</section>

<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach((select, index) => {
			select.selectedIndex = 0;
		});
		document.getElementById('name').value = null;
	}

	var checked = 0;
	let payments = document.querySelector('#payments');
	let checkboxes = document.querySelectorAll('td input');
	let count_selected = document.querySelector('#count_selected');

	function set_count(checkbox) {
		if(checkbox.checked) {
			checked++;
		} else {
			payments.checked = false;
			checked--;
		}
		count_selected.innerHTML = checked + ' Selected';
	}

	payments.addEventListener('click', function() {
		if(payments.checked) {
			for (let i = 0; i < checkboxes.length; i++) {
				checkboxes[i].checked = true;
			}
			checked = checkboxes.length;
		} else {
			for (let i = 0; i < checkboxes.length; i++) {
				checkboxes[i].checked = false;
			}
			checked = 0;
		}
		count_selected.innerHTML = checked + ' Selected';
	});

	$('#amount_form').submit(function() {
		var check = false;
	    for (let i = 0; i < checkboxes.length; i++) {
	    	if(checkboxes[i].checked) {
	    		check = true;
	    		i = checkboxes.length;
	    	}
		}
		if(check == false) {
			alert('Please check at least one semestral award');
			return false;
		} else {
	    	return true;
		}
	});
</script>
@endsection
