@extends('layouts.master')

@section('title')
CHED-CAR Admin | Degree Programs
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Add a Degree Program</h1>
		<a class="add" href="/academic/degree_programs">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/academic/degree_programs"> 
		@csrf 
		<!-- NAME -->
		<label for="course_name">Name :</label>
		<input type="text" name="course_name" placeholder="Enter name of degree program" autofocus required>

		<!-- PRIORITY COURSE CLUSTER -->
		<label for="cmo_2021">Priority Course Cluster for CMO 10 S. 2021 :</label>
		<select name="cmo_2021" required>
			<option value="" disabled selected hidden>Select a course cluster</option>
			<option value="none">Not a priority course</option>
			<option value="Architecture">Architecture</option>
			<option value="Business Management">Business Management</option>
			<option value="Engineering and Technology">Engineering and Technology</option>
			<option value="Health Profession">Health Profession</option>
			<option value="Information Technology Education">Information Technology Education</option>
			<option value="Maritime Education">Maritime Education</option>
			<option value="Multi and Interdisciplinary Cluster">Multi and Interdisciplinary Cluster</option>
			<option value="Science and Mathematics">Science and Mathematics</option>
			<option value="Social Sciences">Social Sciences</option>
			<option value="Teacher Education">Teacher Education</option>
			<option value="Others (Determined by the Region)">Others (Determined by the Region)</option>
		</select>

		<!-- PRIORITY COURSE CLUSTER -->
		<label for="cmo_2019">Priority Course Cluster for CMO 5 S. 2019 :</label>
		<select name="cmo_2019" required>
			<option value="" disabled selected hidden>Select a course cluster</option>
			<option value="none">Not a priority course</option>
			<option value="Agriculture, Forestry and Fisheries">Agriculture, Forestry and Fisheries</option>
			<option value="Business Process Outsourcing">Business Process Outsourcing</option>
			<option value="Engineering">Engineering</option>
			<option value="Mathematics">Mathematics</option>
			<option value="Science">Science</option>
			<option value="Technology">Technology</option>
			<option value="Tourism">Tourism</option>
		</select>

		<!-- PRIORITY COURSE CLUSTER -->
		<label for="cmo_2014">Priority Course Cluster for CMO 1 S. 2014 :</label>
		<select name="cmo_2014" required>
			<option value="" disabled selected hidden>Select a course cluster</option>
			<option value="none">Not a priority course</option>
			<option value="Agriculture and Related Fields">Agriculture and Related Fields</option>
			<option value="Architecture">Architecture</option>
			<option value="Business Administration and Related Courses">Business Administration and Related Courses</option>
			<option value="Communication">Communication</option>
			<option value="Engineering">Engineering</option>
			<option value="Health Sciences">Health Sciences</option>
			<option value="Information Technology">Information Technology</option>
			<option value="Maritime">Maritime</option>
			<option value="Science and Math">Science and Math</option>
			<option value="Social and Behavioral Sciences">Social and Behavioral Sciences</option>
			<option value="Teacher Education">Teacher Education</option>
			<option value="Others (Determined by the Region)">Others (Determined by the Region)</option>
		</select>

		<input type="submit" value="Submit">
	</form>
</section>
@endsection