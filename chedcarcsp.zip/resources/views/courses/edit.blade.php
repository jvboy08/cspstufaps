 @extends('layouts.master')

@section('title')
CHED-CAR Admin | Degree Programs
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Edit a Degree Program</h1>
		<a class="add" href="/academic/degree_programs">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/academic/degree_programs/{{ $course->id }}">
		@method('PUT')
		@csrf 
		<!-- NAME -->
		<label for="course_name">Name :</label>
		<input type="text" name="course_name" placeholder="Enter name of degree program" value="{{ $course->course_name }}" required>

		<!-- PRIORITY COURSE CLUSTER -->
		<label for="cmo_2021">Priority Course Cluster for CMO 10 S. 2021 :</label>
		<select name="cmo_2021" required>
			<option value="" disabled selected hidden>Select a course cluster</option>
			<option value="none" {{ $course->cmo_2021 == "none" ? "selected" : ""}}>Not a priority course</option>
			<option value="Architecture" {{ $course->cmo_2021 == "Architecture" ? "selected" : ""}}>Architecture</option>
			<option value="Business Management" {{ $course->cmo_2021 == "Business Management" ? "selected" : ""}}>Business Management</option>
			<option value="Engineering and Technology" {{ $course->cmo_2021 == "Engineering and Technology" ? "selected" : ""}}>Engineering and Technology</option>
			<option value="Health Profession" {{ $course->cmo_2021 == "Health Profession" ? "selected" : ""}}>Health Profession</option>
			<option value="Information Technology Education" {{ $course->cmo_2021 == "Information Technology Education" ? "selected" : ""}}>Information Technology Education</option>
			<option value="Maritime Education" {{ $course->cmo_2021 == "Maritime Education" ? "selected" : ""}}>Maritime Education</option>
			<option value="Multi and Interdisciplinary Cluster" {{ $course->cmo_2021 == "Multi and Interdisciplinary Cluster" ? "selected" : ""}}>Multi and Interdisciplinary Cluster</option>
			<option value="Science and Mathematics" {{ $course->cmo_2021 == "Science and Mathematics" ? "selected" : ""}}>Science and Mathematics</option>
			<option value="Social Sciences" {{ $course->cmo_2021 == "Social Sciences" ? "selected" : ""}}>Social Sciences</option>
			<option value="Teacher Education" {{ $course->cmo_2021 == "Teacher Education" ? "selected" : ""}}>Teacher Education</option>
			<option value="Others (Determined by the Region)" {{ $course->cmo_2021 == "Others (Determined by the Region)" ? "selected" : ""}}>Others (Determined by the Region)</option>
		</select>

		<!-- PRIORITY COURSE CLUSTER -->
		<label for="cmo_2019">Priority Course Cluster for CMO 5 S. 2019 :</label>
		<select name="cmo_2019" required>
			<option value="none" {{ $course->cmo_2019 == "none" ? "selected" : ""}}>Not a priority course</option>
			<option value="Agriculture, Forestry and Fisheries" {{ $course->cmo_2019 == "Agriculture, Forestry and Fisheries" ? "selected" : ""}}>Agriculture, Forestry and Fisheries</option>
			<option value="Business Process Outsourcing" {{ $course->cmo_2019 == "Business Process Outsourcing" ? "selected" : ""}}>Business Process Outsourcing</option>
			<option value="Engineering" {{ $course->cmo_2019 == "Engineering" ? "selected" : ""}}>Engineering</option>
			<option value="Mathematics" {{ $course->cmo_2019 == "Mathematics" ? "selected" : ""}}>Mathematics</option>
			<option value="Science" {{ $course->cmo_2019 == "Science" ? "selected" : ""}}>Science</option>
			<option value="Technology" {{ $course->cmo_2019 == "Technology" ? "selected" : ""}}>Technology</option>
			<option value="Tourism" {{ $course->cmo_2019 == "Tourism" ? "selected" : ""}}>Tourism</option>
		</select>

		<!-- PRIORITY COURSE CLUSTER -->
		<label for="cmo_2014">Priority Course Cluster for CMO 1 S. 2014 :</label>
		<select name="cmo_2014" required>
			<option value="none" {{ $course->cmo_2014 == "none" ? "selected" : ""}}>Not a priority course</option>
			<option value="Agriculture and Related Fields" {{ $course->cmo_2014 == "Agriculture and Related Fields" ? "selected" : ""}}>Agriculture and Related Fields</option>
			<option value="Architecture" {{ $course->cmo_2014 == "Architecture" ? "selected" : ""}}>Architecture</option>
			<option value="Business Administration and Related Courses" {{ $course->cmo_2014 == "Business Administration and Related Courses" ? "selected" : ""}}>Business Administration and Related Courses</option>
			<option value="Communication" {{ $course->cmo_2014 == "Communication" ? "selected" : ""}}>Communication</option>
			<option value="Engineering" {{ $course->cmo_2014 == "Engineering" ? "selected" : ""}}>Engineering</option>
			<option value="Health Sciences" {{ $course->cmo_2014 == "Health Sciences" ? "selected" : ""}}>Health Sciences</option>
			<option value="Information Technology" {{ $course->cmo_2014 == "Information Technology" ? "selected" : ""}}>Information Technology</option>
			<option value="Maritime" {{ $course->cmo_2014 == "Maritime" ? "selected" : ""}}>Maritime</option>
			<option value="Science and Math" {{ $course->cmo_2014 == "Science and Math" ? "selected" : ""}}>Science and Math</option>
			<option value="Social and Behavioral Sciences" {{ $course->cmo_2014 == "Social and Behavioral Sciences" ? "selected" : ""}}>Social and Behavioral Sciences</option>
			<option value="Teacher Education" {{ $course->cmo_2014 == "Teacher Education" ? "selected" : ""}}>Teacher Education</option>
			<option value="Others (Determined by the Region)" {{ $course->cmo_2014 == "Others (Determined by the Region)" ? "selected" : ""}}>Others (Determined by the Region)</option>
		</select>
		
		<input type="submit" value="Submit Changes">
	</form>
</section>
@endsection