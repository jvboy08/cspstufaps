@extends('layouts.master')

@section('title')
CHED-CAR Admin | Degree Programs
@endsection

@section('body')
<section class="institutions">
	<div class="header">
		@if(!$courses->isEmpty())
		<h1 class="result">{{ $courses->total()}} {{ $courses->total() > 1 ? 'Degree Programs Found' : 'Degree Program Found' }}</h1>
		@else
		<h1 class="result">No Degree Programs Found</h1>
		@endif
		<div class="header_buttons">
			<a class="add" href="/academic/degree_programs/create">Add a degree program</a>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/academic/degree_programs" method="GET">
			<div class="filter">
				<div class="pairs">
					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Name of Degree Program</h3>
						@if(array_key_exists('name', $sort_filters))
						<input type="text" name="name" placeholder="Enter course name" value="{{ $sort_filters['name'] }}" id="name">
						@else						
						<input type="text" name="name" placeholder="Enter course name" id="name">
						@endif
					</div>

					<!-- PRIORITY COURSE CLUSTER -->
					<div class="pair">
						<h3>Priority For</h3>
						<select name="cmo">
							<option value="" disabled selected hidden>Select a CMO</option>
							@if(array_key_exists('cmo', $sort_filters))
							<option value="2021" {{ $sort_filters['cmo'] == "2021" ? 'selected' : ''}}>CMO 10 S. 2021</option>
							<option value="2019" {{ $sort_filters['cmo'] == "2019" ? 'selected' : ''}}>CMO 5 S. 2019</option>
							<option value="2014" {{ $sort_filters['cmo'] == "2014" ? 'selected' : ''}}>CMO 1 S. 2014</option>
						    @else
							<option value="2021">CMO 10 S. 2021</option>
							<option value="2019">CMO 5 S. 2019</option>
							<option value="2014">CMO 1 S. 2014</option>
						    @endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$courses->isEmpty())
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Name</th>
					<th style="white-space: nowrap;">CMO 1 S. 2014</th>
					<th style="white-space: nowrap;">CMO 5 S. 2019</th>
					<th style="white-space: nowrap;">CMO 10 S. 2021</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($courses as $key => $course)
					<tr>
						<td>{{ $key + $courses->firstItem() }}</td>
						<td>{{ $course->course_name }}</td>
						<td>{{ $course->cmo_2014 == 'none' ? 'Not a priority' : $course->cmo_2014 }}</td>
						<td>{{ $course->cmo_2019 == 'none' ? 'Not a priority' : $course->cmo_2019 }}</td>
						<td>{{ $course->cmo_2021 == 'none' ? 'Not a priority' : $course->cmo_2021 }}</td>
						<td class="settings">
							<a href="/academic/degree_programs/{{ $course->id }}/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							<a href="/academic/degree_programs/{{ $course->id }}/delete" onclick="return confirm('Are you sure you want to delete this degree program?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous">{{ $courses->appends($sort_filters)->links() }}</div>
	</div>
	@endif
</section>

<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
		document.getElementById('name').value = null;
	}
</script>
@endsection
