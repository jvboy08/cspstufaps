@extends('layouts.master')

@section('title')
CHED-CAR Admin | Coordinators
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Edit a Coordinator</h1>
		<a class="add" href="/academic/school_coordinators">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/academic/school_coordinators/{{ $school_coordinator->id }}"> 
		@method('PUT')
		@csrf 

		<!-- NAME -->
		<label for="name">Full Name :</label>
		<input type="text" name="name" value="{{ $school_coordinator->name }}" placeholder="Enter full name of coordinator" required>

		<!-- NAME -->
		<label for="name">Email Address :</label>
		<input type="email" name="email" value="{{ $school_coordinator->email }}" placeholder="Enter email address of coordinator" required>

		<!-- INSTITUTION -->
		<label for="institution_id">Higher Education Institution :</label>
		<select name="institution_id" required>
			<option value="" disabled selected hidden>Select an institution</option>
			@foreach($institutions as $institution)
			<option value="{{ $institution->id }}" {{ $school_coordinator->institution_id == $institution->id ? "selected" : ""}}>{{ $institution->institution_name }}</option>
			@endforeach
		</select>

		<!-- POSITION -->
		<label for="coordinator_role">Position :</label>
		<select name="coordinator_role" required>
			<option value="" disabled selected hidden>Select a position</option>
			<option value="head" {{ $school_coordinator->coordinator_role == 'head' ? "selected" : ""}}>Head Coordinator</option>
			<option value="assistant" {{ $school_coordinator->coordinator_role == 'assistant' ? "selected" : ""}}>Assistant Coordinator</option>
			<option value="assistant">Assistant Coordinator</option>
		</select>

		<div class="error" style="text-align: center;">
			<h2 id="error">Only head coordinators can add and remove accounts of other coordinators</h2>
		</div>
		
		<input type="submit" value="Submit Changes">
	</form>
</section>
@endsection