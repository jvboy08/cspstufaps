@extends('layouts.master')

@section('title')
CHED-CAR Admin | Coordinators
@endsection

@section('body')
<section>
<div id="info" class="info" style="cursor: default;">
	<div class="info_content">
		<span class="material-icons-round help">verified_user</span>
		<p class="code" style="text-align: left;"></p>
		<button class="copy" onclick="copyToClipboard()"><p>Copy</p></button>
	</div>
</div>
	<div class="header">
		@if(!$school_coordinators->isEmpty())
		<h1 class="result">{{ $school_coordinators->total() }} {{ $school_coordinators->total() > 1 ? 'Scholarship Coordinators' : 'Scholarship Coordinator' }} Found</h1>
		@else
		<h1 class="result">No Scholarship Coordinators Found</h1>
		@endif
		<a class="add" href="/academic/school_coordinators/create">Add a scholarship coordinator</a>
	</div>
	<div class="functions">
		<form action="/academic/school_coordinators" method="GET">
			<div class="filter">
				<div class="pairs">
					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Name</h3>
						@if(array_key_exists('name', $sort_filters))
						<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
						@else						
						<input type="text" name="name" placeholder="Enter last or first name" id="name">
						@endif
					</div>

					<!-- STATUS -->
					<div class="pair">
						<h3>Status</h3>
						<select name="status">
							<option value="" disabled selected hidden>Select a status</option>
							@if(array_key_exists('status', $sort_filters))
							<option value="1" {{ $sort_filters['status'] == "1" ? 'selected' : ''}}>Signed Up</option>
							<option value="0" {{ $sort_filters['status'] == "0" ? 'selected' : ''}}>Not Yet Signed Up</option>
						    @else
							<option value="1">Signed Up</option>
							<option value="0">Pending</option>
						    @endif
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							@if(array_key_exists('items', $sort_filters))
								<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
								<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
								<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
								<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
							@else
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							@endif
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						

					<button type="button" class="clear" onclick="resetAll()">Reset</button>
					<input type="submit" value="Submit">
					</div>
				</div>
			</div>

			<div class="filters">
				<div class="pairs">
					<!-- POSITION -->
					<div class="pair">
						<h3>Position</h3>
						<select name="position">
							<option value="" disabled selected hidden>Select a position</option>
							@if(array_key_exists('position', $sort_filters))
							<option value="head" {{ $sort_filters['position'] == "head" ? 'selected' : ''}}>Head Coordinator</option>
							<option value="assistant" {{ $sort_filters['position'] == "assistant" ? 'selected' : ''}}>Assistant Coordinator</option>
						    @else
							<option value="head">Head Coordinator</option>
							<option value="assistant">Assistant Coordinator</option>
						    @endif
						</select>
					</div>

					<!-- INSTITUTION -->
					<div class="pair">
						<h3>Institution</h3>
						<select name="institution">
							<option value="" disabled selected hidden>Select a higher education institution</option>
							@if(array_key_exists('institution', $sort_filters))
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}" {{ $institution->id == $sort_filters['institution'] ? 'selected' : '' }}>{{ $institution->institution_name }}</option>
							@endforeach
							@else
							@foreach($institutions as $institution)
								<option value="{{ $institution->id }}">{{ $institution->institution_name }}</option>
							@endforeach
							@endif
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	@if(!$school_coordinators->isEmpty())
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Email Address</th>
					<th>Institution</th>
					<th>Position</th>
					<th>Status</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($school_coordinators as $key => $school_coordinator)
					<tr>
						<td>{{ $key + $school_coordinators->firstItem() }}</td>
						<td>{{ $school_coordinator->name }}</td>
						<td>{{ $school_coordinator->email }}</td>
						<td>{{ $school_coordinator->institution_name }}</td>
						<td>{{ $school_coordinator->coordinator_role == 'head' ? 'Head' : 'Assistant' }}</td>
						<td>{{ $school_coordinator->is_verified == 0 ? 'Pending' : 'Signed up' }}</td>
						<td class="settings">
							@if($school_coordinator->is_verified == 0)
							<a onclick="display_code('{{ $school_coordinator->verification_code }}')"><div><span class="material-icons-round">verified_user</span><p>Code</p></div></a>
							<a href="/academic/school_coordinators/{{ $school_coordinator->user_id }}/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							@endif
							<a href="/academic/school_coordinators/{{ $school_coordinator->user_id }}/delete" onclick="return confirm('Are you sure you want to delete this scholarship coordinator?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous">{{ $school_coordinators->appends($sort_filters)->links() }}</div>
	</div>
	@else
	@endif
</section>

<script>
	function resetAll() {
		$('#name').val("");
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
	}

	function display_code(code) {
		$(".code").html(code);
		$("#info").css('display', "flex");
	}

	function hide_code() {
		$("#info").css('display', "none");
	}

	function copyToClipboard() {
		var $temp = $("<input>");
		$("body").append($temp);
		$temp.val($('.code').html()).select();
		document.execCommand("copy");
		$temp.remove();
		hide_code();
	}
</script>
@endsection
