@extends('layouts.master')

@section('title')
CHED-CAR Admin | Scholars
@endsection

@section('body')
<section class="form full" id="semestral_award_form">
	<div class="header">
		<h1>Edit a Semestral Award</h1>
		<a class="add" href="/scholars/{{ $scholar->id }}">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/scholars/{{ $scholar->id }}/semestral_awards/{{ $semestral_award->id }}">
		@method('PUT')
		@csrf 
		<div class="columns">
			<div class="column">
				<!-- ACADEMIC YEAR -->
				<label for="acad_year">Academic Year :</label>
				<select name="acad_year" required>
					@for($i = 2016; $i <= now()->year; $i++)
			        <option value="{{$i}}" {{ $semestral_award->acad_year == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
				    @endfor
				</select>

				<!-- SEMESTER -->
				<label for="semester">Semester :</label>
				<select name="semester" required>
					<option value="1" {{ $semestral_award->semester == "1" ? "selected" : ""}}>1st Semester</option>
					<option value="2" {{ $semestral_award->semester == "2" ? "selected" : ""}}>2nd Semester</option>
				</select>

				<!-- CURRENT YEAR LEVEL -->
				<label for="current_year_level">Current Year Level :</label>
				<select name="current_year_level" required>
					@for($i = 1; $i <= 6; $i++)
				        <option value="{{$i}}" {{ $semestral_award->current_year_level == $i ? "selected" : ""}}>{{ $i }}</option>
				    @endfor
				</select>

				<!-- STATUS -->
				<label for="status">Status :</label>
				<select name="status" required id="status">
					<option value="" disabled selected hidden>Select a status</option>
					<option value="Active" {{ $semestral_award->status == "Active" ? "selected" : ""}}>Active</option>
					<option value="Deferred" {{ $semestral_award->status == "Deferred" ? "selected" : ""}}>Deferred</option>
					<option value="Graduate" {{ $semestral_award->status == "Graduate" ? "selected" : ""}}>Graduate</option>
					<option value="Replacement" {{ $semestral_award->status == "Replacement" ? "selected" : ""}}>Replacement</option>
					<option value="Replaced" {{ $semestral_award->status == "Replaced" ? "selected" : ""}}>Replaced</option>
					<option value="Terminated" {{ $semestral_award->status == "Terminated" ? "selected" : ""}}>Terminated</option>
					<option value="Waived" {{ $semestral_award->status == "Waived" ? "selected" : ""}}>Waived</option>
				</select>

				<!-- REMARKS CHEDRO -->
				<label for="remarks_chedro">CHEDRO Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_chedro" value="{{ $semestral_award->remarks_chedro }}" placeholder="Enter remarks of CHEDRO">

				<!-- REMARKS CHEDRO -->
				<label for="remarks_osds">OSDS Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_osds" value="{{ $semestral_award->remarks_osds }}" placeholder="Enter remarks of OSDS">
			</div>

			<div class="column">
				<!-- SARO -->
				<label for="saro">SARO <span class="optional">(Optional)</span> :</label>
				<input type="text" name="saro" value="{{ $semestral_award->saro }}" placeholder="Enter SARO">

				<!-- NTA Number -->
				<label for="nta_number">NTA Number <span class="optional">(Optional)</span> :</label>
				<input type="text" name="nta_number" value="{{ $semestral_award->nta_number }}" placeholder="Enter NTA number">

				<!-- THESIS TITLE -->
				<label for="thesis_title">Thesis Title <span class="optional">(Optional)</span> :</label>
				<input type="text" name="thesis_title" value="{{ $semestral_award->thesis_title }}" placeholder="Enter thesis title">

				<!-- THESIS ALLOWANCE -->
				<label for="thesis_allowance">Thesis Allowance <span class="optional">(Optional)</span> :</label>
				<input type="text" name="thesis_allowance" value="{{ $semestral_award->thesis_allowance }}" placeholder="Enter thesis allowance">

				<!-- THESIS REMARKS -->
				<label for="thesis_remarks">Thesis Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="thesis_remarks" value="{{ $semestral_award->thesis_remarks }}" placeholder="Enter thesis remarks">
			</div>

			<div class="column">
				<!-- IS PROCESSED -->
				<label for="is_processed">Is the payment already processed? :</label>
				<select id="is_processed" name="is_processed">
					<option value="1" {{ $semestral_award->amount_chedro == null ? '' : 'selected' }}>Yes</option>
					<option value="0" {{ $semestral_award->amount_chedro == null ? 'selected' : '' }}>No</option>
				</select>
				
				<div id="processed_container" style="display: {{ $semestral_award->amount_chedro == null ? 'none' : 'block' }};">
					<!-- AMOUNT CHEDRO -->
					<label for="amount_chedro">Amount Processed :</label>
					<input type="number" name="amount_chedro" value="{{ $semestral_award->amount_chedro == null ? null : $semestral_award->amount_chedro + 0 }}" placeholder="Enter amount" {{ $semestral_award->amount_chedro == null ? '' : 'required' }}>

					<!-- DATE PROCESSED -->
					<label for="date_processed">Date Processed <span class="optional">(dd/mm/yyyy)</span> :</label>
					<input type="date" name="date_processed" value="{{ $semestral_award->date_processed }}" {{ $semestral_award->amount_chedro == null ? '' : 'required' }}>

					<!-- MODE OF PAYMENT -->
					<label for="mode_of_payment">Mode of Payment :</label>
					<select name="mode_of_payment" {{ $semestral_award->amount_chedro == null ? '' : 'required' }}>
						<option value="" disabled selected hidden>Select a mode of payment</option>
						<option value="HEI" {{ $semestral_award->mode_of_payment == "HEI" ? "selected" : ""}}>HEI – if through the HEI</option>
						<option value="STUDENT" {{ $semestral_award->mode_of_payment == "STUDENT" ? "selected" : ""}}>STUDENT – if through ATM/Cheque</option>
					</select>
				</div>

				<input type="submit" value="Submit Changes">
			</div>
		</div>
	</form>
</section>

<script type="text/javascript">
	$(document).ready(function() {
		$('#is_processed').on('change', function() {
	    	if($('#is_processed').val() == 1) {
		        $('#processed_container').css('display', 'block');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', true);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', true);
		        });
	    	} else {
		        $('#processed_container').css('display', 'none');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', false);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', false);
		        });
	    	}
	    });
	});
</script>
@endsection