@extends('layouts.master')

@section('title')
CHED-CAR Admin | Scholars
@endsection

@section('body')
<section class="form full" id="semestral_award_form">
	<div class="header">
		<h1>Add a Semestral Award</h1>
		<a class="add" href="/scholars/{{ $scholar->id }}">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/scholars/{{ $scholar->id }}/semestral_awards"> 
		@csrf 
		<div class="columns">
			<div class="column">
				<!-- ACADEMIC YEAR -->
				<label for="acad_year">Academic Year :</label>
				<select name="acad_year" required>
					@if($scholar->latest_acad_year == null)
				    	@if($scholar->semester_accepted == 1)
						@for($i = 2016; $i <= now()->year; $i++)
					        <option value="{{$i}}" {{ $scholar->acad_year_accepted == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
					    @endfor
					    @else
						@for($i = 2016; $i <= now()->year; $i++)
					        <option value="{{$i}}" {{ $scholar->acad_year_accepted + 1 == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
					    @endfor
					    @endif
				    @else
				    	@if($scholar->latest_semester == 1)
						@for($i = 2016; $i <= now()->year; $i++)
					        <option value="{{$i}}" {{ $scholar->latest_acad_year == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
					    @endfor
					    @else
						@for($i = 2016; $i <= now()->year; $i++)
					        <option value="{{$i}}" {{ $scholar->latest_acad_year + 1 == $i ? "selected" : ""}}>{{ $i }} - {{ $i+1 }}</option>
					    @endfor
					    @endif
				    @endif
				</select>

				<!-- SEMESTER -->
				<label for="semester">Semester :</label>
				<select name="semester" required>
					@if($scholar->latest_acad_year == null)
					<option value="1" {{ $scholar->semester_accepted == "1" ? "selected" : ""}}>1st Semester</option>
					<option value="2" {{ $scholar->semester_accepted == "2" ? "selected" : ""}}>2nd Semester</option>
				    @else
					<option value="1" {{ $scholar->latest_semester == "1" ? "" : "selected"}}>1st Semester</option>
					<option value="2" {{ $scholar->latest_semester == "2" ? "" : "selected"}}>2nd Semester</option>
				    @endif
				</select>

				<!-- CURRENT YEAR LEVEL -->
				<label for="current_year_level">Current Year Level :</label>
				<select name="current_year_level" required>
					@if($scholar->latest_acad_year == null)
					@for($i = 1; $i <= 6; $i++)
				        <option value="{{$i}}" {{ 1 == $i ? "selected" : ""}}>{{ $i }}</option>
				    @endfor
				    @else
						@if($scholar->latest_semester == 1)
						@for($i = 1; $i <= 6; $i++)
					        <option value="{{$i}}" {{ $scholar->latest_acad_year - $scholar->acad_year_accepted + 1 == $i ? "selected" : ""}}>{{ $i }}</option>
					    @endfor
					    @else
						@for($i = 1; $i <= 6; $i++)
					        <option value="{{$i}}" {{ $scholar->latest_acad_year - $scholar->acad_year_accepted + 2 == $i ? "selected" : ""}}>{{ $i }}</option>
					    @endfor
					    @endif
				    @endif
				</select>

				<!-- STATUS -->
				<label for="status">Status :</label>
				<select name="status" required id="status">
					<option value="" disabled selected hidden>Select a status</option>
					<option value="Active">Active</option>
					<option value="Deferred">Deferred</option>
					<option value="Graduate">Graduate</option>
					<option value="Terminated">Terminated</option>
					<option value="Waived">Waived</option>
				</select>

				<!-- REMARKS CHEDRO -->
				<label for="remarks_chedro">CHEDRO Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_chedro" placeholder="Enter remarks of CHEDRO">

				<!-- REMARKS OSDS -->
				<label for="remarks_osds">OSDS Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_osds" placeholder="Enter remarks of OSDS">
			</div>

			<div class="column">
				<!-- SARO -->
				<label for="saro">SARO <span class="optional">(Optional)</span> :</label>
				<input type="text" name="saro" placeholder="Enter SARO">

				<!-- NTA Number -->
				<label for="nta_number">NTA Number <span class="optional">(Optional)</span> :</label>
				<input type="text" name="nta_number" placeholder="Enter NTA number">
				
				<!-- THESIS TITLE -->
				<label for="thesis_title">Thesis Title <span class="optional">(Optional)</span> :</label>
				<input type="text" name="thesis_title" placeholder="Enter thesis title">

				<!-- THESIS ALLOWANCE -->
				<label for="thesis_allowance">Thesis Allowance <span class="optional">(Optional)</span> :</label>
				<input type="text" name="thesis_allowance" placeholder="Enter thesis allowance">

				<!-- THESIS REMARKS -->
				<label for="thesis_remarks">Thesis Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="thesis_remarks" placeholder="Enter thesis remarks">
			</div>

			<div class="column">

				<!-- IS PROCESSED -->
				<label for="is_processed">Is the payment already processed? :</label>
				<select id="is_processed" name="is_processed">
					<option value="1">Yes</option>
					<option value="0">No</option>
				</select>

				<div id="processed_container">
					<!-- AMOUNT CHEDRO -->
					<label for="amount_chedro">Amount Processed <span class="optional"> :</label>
					<input type="number" name="amount_chedro" value="{{ $scholar->award->program->amount_per_sem }}" id="amount" placeholder="Enter amount" required>

					<!-- DATE PROCESSED -->
					<label for="date_processed">Date Processed <span class="optional">(dd/mm/yyyy)</span> :</label>
					<input type="text" onfocus="(this.type='date')" name="date_processed" placeholder="Enter date processed" required>

					<!-- MODE OF PAYMENT -->
					<label for="mode_of_payment">Mode of Payment :</label>
					<select name="mode_of_payment" required>
						<option value="" disabled selected hidden>Select a mode of payment</option>
						<option value="HEI">HEI – if through the HEI</option>
						<option value="STUDENT">STUDENT – if through ATM/Cheque</option>
					</select>
				</div>
				
				<input type="submit" value="Submit">
			</div>
		</div>
	</form>
</section>

<script type="text/javascript">
	$(document).ready(function() {
		$('#status').on('change', function() {
			if(['Active', 'Graduating', 'Graduate', 'Replacement'].indexOf($('#status').val()) != -1) {
				$('#amount').val("{{ $scholar->award->program->amount_per_sem }}");
			} else {
				$('#amount').val(null);
			}
		});

		$('#is_processed').on('change', function() {
	    	if($('#is_processed').val() == 1) {
		        $('#processed_container').css('display', 'block');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', true);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', true);
		        });
	    	} else {
		        $('#processed_container').css('display', 'none');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', false);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', false);
		        });
	    	}
	    });
	});
</script>
@endsection