@extends('layouts.master')

@section('title')
CHED-CAR Admin | Scholars
@endsection

@section('body')
<section class="form full">
	<div class="header">
		<h1>{{ $scholar->applicant->full_name }} - No. {{ $scholar->applicant->app_no }}</h1>
		<a class="add" href="/scholars">Go back</a>
	</div>
	<div class="nav-scholar">
		<div id="left-nav" class="left active" onclick="changeView(1)">
			<h1>Scholarship</h1>
		</div>
		<div id="right-nav" class="right" onclick="changeView(2)">
			<h1>Information</h1>
		</div>
	</div>
	<div class="view">
		<div id="left-view" class="left active">
			<div class="header">
				<div class="header_with_info">
					<h1>Scholarship Details</h1>
				</div>
				<div class="header_buttons">
					@if($replaced != null)
					<a class="add" onclick="alert('This scholarship cannot be removed because the scholar has already replaced another scholar.')">Remove Scholarship</a>
					@elseif($replaced_by != null)
					<a class="add" onclick="alert('This scholarship cannot be removed because the scholar has already been replaced.')">Remove Scholarship</a>
					@elseif($is_registered == 1)
					<a class="add" onclick="alert('This scholarship cannot be removed because the scholar has already signed up.')">Remove Scholarship</a>
					@else
					<a class="add" href="/scholars/{{ $scholar->id }}/scholarships/delete" onclick="return confirm('Are you sure you want to remove this scholarship? This scholar will go back to being an applicant and the semestral awards will be deleted.')">Remove Scholarship</a>
					@endif
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Program Name :</p>
					<p>{{ $scholar->award->program->program_name }}</p>
					<p>Award Number :</p>
					<p>{{ $scholar->award_number }}</p>
					<p>Financial Benefits :</p>
					<p>PHP {{ number_format($scholar->award->program->amount_per_sem, 2, '.', ',') }} Per Semester</p>
				</div>
				<div class="column pairs">
					<p>Academic Year Accepted :</p>
					<p>A.Y. {{ $scholar->acad_year_accepted }} - {{ $scholar->acad_year_accepted + 1 }}</p>
					<p>Semester Accepted :</p>
					<p>{{ $scholar->semester_accepted == 1 ? '1st' : '2nd'}} Semester</p>
					<p>Total Benefits Received :</p>
					<p>{{ $sum == 0 ? 'No benefits received yet' : 'PHP '.number_format($sum, 2, '.', ',') }}</p>
				</div>
			</div>
			<div class="header">
				@if(!$semestral_awards->isEmpty())
				<h1 class="result">{{ $semestral_awards->count()}} {{ $semestral_awards->count() > 1 ? 'Semestral Awards' : 'Semestral Award' }} Found</h1>
				@else
				<h1 class="result">No Semestral Awards Found</h1>
				@endif
				<div class="header_buttons">
					@if(in_array($scholar->latest_status, ['Graduate', 'Terminated', 'Waived']))
					<a class="add" href="/scholars/{{ $scholar->id }}/replace_by_scholar">Replace by a new scholar</a>
					@endif
					@if(in_array($scholar->latest_status, ['Active', 'Replacement', 'Deferred']))
					<a class="add" href="/scholars/{{ $scholar->id }}/semestral_awards/create">Add a semestral award</a>
					@endif
				</div>
			</div>
			@if(!$semestral_awards->isEmpty())
			<div class="table" style="margin-bottom: 2vw;">
				<table>
					<thead>
						<tr>
							<th>Academic Period</th>
							<th>Year Level</th>
							<th>Status</th>
							<th>Amount Processed</th>
							<th>Date Processed</th>
							<th>Payment Received</th>
							<th>Settings</th>
						</tr>
					</thead>
					<tbody>
						@foreach($semestral_awards as $semestral_award)
							<tr>
								<td>A.Y. {{ $semestral_award->acad_year }}, {{ $semestral_award->semester == 1 ? '1st' : '2nd' }} Sem</td>
								<td>{{ $semestral_award->status == 'Replaced' ? 'N/A' : $semestral_award->full_year_level }}</td>
								<td style="white-space: nowrap;">
									@if($loop->index == $semestral_awards->count() - 1 && in_array($semestral_award->status, array('Terminated', 'Graduate', 'Waived', 'Deferred')) && !empty($replaced_by))
										<p class="{{ in_array($semestral_award->status, ['Active', 'Graduate', 'Replacement', 'Deferred']) ? 'positive' : 'negative' }}">{{ $semestral_award->status }}</p> & 
										<p class="negative">Replaced</p>
									@else
										<p class="{{ in_array($semestral_award->status, ['Active', 'Graduate', 'Replacement', 'Deferred']) ? 'positive' : 'negative' }}">{{ $semestral_award->status }}</p>
									@endif
								</td>
								<td>
									@if($semestral_award->amount_chedro != null)
										PHP {{ number_format($semestral_award->amount_chedro, 2, '.', ',') }}
									@else
										@if(in_array($semestral_award->status, array('Active', 'Replacement', 'Graduating', 'Graduate')))
											Not yet processed
										@else
											N/A
										@endif
									@endif
								</td>
								<td>
									@if($semestral_award->date_processed != null)
										{{ date('M j, Y', strtotime($semestral_award->date_processed)) }}
									@else
										N/A
									@endif
								</td>
								<td>
									@if($semestral_award->date_processed != null)
										@if($semestral_award->is_payment_received)
											Received
										@else
											Not Yet Received
										@endif
									@else
									N/A
									@endif
								</td>
								<td class="settings">
									<a href="/scholars/{{ $scholar->id }}/semestral_awards/{{ $semestral_award->id }}/edit">
									<div><span class="material-icons-round">edit</span><p>Edit</p></div>
									</a>
									<a href="/scholars/{{ $scholar->id }}/semestral_awards/{{ $semestral_award->id }}/delete" onclick="return confirm('Are you sure you want to delete this semestral award?')">
									<div><span class="material-icons-round">delete</span><p>Delete</p></div>
									</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
			@endif
			@if(!$unreviewed_semestral_awards->isEmpty())
			<div class="header">
				<h1 class="result">{{ $unreviewed_semestral_awards->count()}} {{ $unreviewed_semestral_awards->count() > 1 ? 'Semestral Awards' : 'Semestral Award' }} with No Status Found</h1>
			</div>
			<div class="table" style="margin-bottom: 2vw;">
				<table>
					<thead>
						<tr>
							<th>Academic Period</th>
							@if($unreviewed_semestral_awards->first()->previous_gwa == null)
							<th>Enrollment and Billing</th>
							<th>Grades From Previous Semester</th>
							@else
							<th>Previous GWA</th>
							<th>Units Enrolled</th>
							<th>Tuition Fee</th>
							<th>Remarks</th>
							@endif
							<th>Settings</th>
						</tr>
					</thead>
					<tbody>
						@foreach($unreviewed_semestral_awards as $semestral_award)
							<tr>
								<td class="settings">A.Y. {{ $semestral_award->acad_year }} - {{ $semestral_award->acad_year + 1 }}, {{ $semestral_award->semester == 1 ? '1st' : '2nd' }} Semester</td>
								@if($semestral_award->previous_gwa == null)
								<td class="settings">
									<a href="{{ $semestral_award->enrollment_form }}" target="_blank">
									<div><span class="material-icons-round">open_in_new</span><p>Open in new tab</p></div>
									</a>
								</td>
								<td class="settings">
									<a href="{{ $semestral_award->previous_grades }}" target="_blank">
									<div><span class="material-icons-round">open_in_new</span><p>Open in new tab</p></div>
									</a>
								</td>
								@else
								<td>{{ $semestral_award->previous_gwa == 'NA' ? 'N/A' : $semestral_award->previous_gwa }}</td>
								<td>{{ $semestral_award->units_enrolled == 'NA' ? 'N/A' : $semestral_award->units_enrolled }}</td>
								<td>{{ $semestral_award->tuition_fee == 'NA' ? 'N/A' : $semestral_award->tuition_fee }}</td>
								<td>{{ $semestral_award->remarks_coordinator == null ? 'NA' : $semestral_award->remarks_coordinator }}</td>
								@endif
								<td class="settings">
									<a href="/scholars/{{ $scholar->id }}/semestral_awards/{{ $semestral_award->id }}/edit">
									<div><span class="material-icons-round">add</span><p>Add Status</p></div>
									</a>
								</td>
							</tr>
						@endforeach
					</tbody>
				</table>
			</div>
			@endif
			<div class="header">
				<div class="header_with_info">
					<h1>Replacement Details</h1>
					<div class="info_button" onclick="show(1)"><span class="material-icons-round">help</span></div>
					<div id="info1" class="info" onclick="hide(1)">
						<div class="info_content">
							<span class="material-icons-round help">help</span>
							<p>In order for a scholar to be replaced, their latest semestral award<br>should have a status of Terminated, Waived, or Graduate.</p>
							<span id="close1" class="material-icons-round close" onclick="hide(1)">close</span>
						</div>
					</div>
				</div>
			</div>
			<div class="columns replacement">
				<div class="column pairs">
					<p>Replaced Scholar :</p>
					@if($replaced != null)
					<p>{{ $replaced->applicant->full_name }}
						<a href="/scholars/{{ $replaced->id }}">
						<span class="material-icons-round">visibility</span>View
						</a>
					</p>
					@else
					<p>No Scholar Replaced</p>
					@endif
				</div>
				<div class="column pairs">
					<p>Replacement :</p>
					@if($replaced_by != null)
					<p>{{ $replaced_by->applicant->full_name }}
						<a href="/scholars/{{ $replaced_by->id }}">
						<span class="material-icons-round">visibility</span>View
						</a>
					</p>
					@else
					<p>Not Yet Replaced</p>
					@endif
				</div>
			</div>
		</div>
		<div id="right-view" class="right">
			<div id="display_wrapper">
				<iframe id="display_frame" frameborder="0"></iframe>
			</div>
			<div class="header">
				<div class="header_buttons">
					<button class="add" onclick="downloadPdf()">Create & Download PDF</button>
					<button id="display_btn" class="add" onclick="displayPdf()">Create & Display PDF</button>
				</div>
				<div class="header_buttons">
					@if($scholar->applicant->are_documents_validated == 0)
					<div class="unvalidated">
						<div class="info_button" onclick="show(2)"><span class="material-icons-round">help</span></div><h1 id="checkbox_label">Documents are not yet validated</h1>
						<div id="info2" class="info" onclick="hide(2)">
							<div class="info_content">
								<span class="material-icons-round help">help</span>
								<p>If the documents of the applicant have been validated, click the "Edit<br>Information" button and set the "Validation of Documents" to "Validated".</p>
								<span id="close2" class="material-icons-round close" onclick="hide(2)">close</span>
							</div>
						</div>
					</div>
					@endif
					<a class="add" href="/applicants/{{ $scholar->applicant->id }}/edit">Edit Information</a>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Entry Date :</p>
					<p>{{ date('F d, Y', strtotime($scholar->applicant->entry_date)) }}</p>
				</div>
				<div class="column pairs">
					<p>Academic Year :</p>
					<p>A.Y. {{ $scholar->applicant->entry_acad_year }} - {{ $scholar->applicant->entry_acad_year + 1 }}</p>
				</div>
				<div class="column pairs">
					<p>Total Rank Score :</p>
					<p>{{ $scholar->applicant->score + 0 }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Full Name</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>First Name :</p>
					<p>{{ $scholar->applicant->name_first }}</p>
					<p>Middle Name :</p>
					<p>{{ $scholar->applicant->name_middle == null ? 'N/A' : $scholar->applicant->name_middle }}</p>
				</div>
				<div class="column pairs">
					<p>Last Name :</p>
					<p>{{ $scholar->applicant->name_last }}</p>
					<p>Extension Name :</p>
					<p>{{ $scholar->applicant->name_ext == null ? 'N/A' : $scholar->applicant->name_ext }}</p>
				</div>
				<div class="column pairs">
					<p>Maiden Name :</p>
					<p>{{ $scholar->applicant->name_maiden == null ? 'N/A' : $scholar->applicant->name_maiden }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Personal Details</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Sex :</p>
					<p>{{ $scholar->applicant->sex == 'F' ? 'Female' : 'Male' }}</p>
					<p>Civil Status :</p>
					<p>{{ $scholar->applicant->civil_status }}</p>
				</div>
				<div class="column pairs">
					<p>Citizenship :</p>
					<p>{{ $scholar->applicant->citizenship == null ? 'N/A' : $scholar->applicant->citizenship }}</p>
					<p>Date of Birth :</p>
					<p>{{ date('F d, Y', strtotime($scholar->applicant->birthday)) }}</p>
				</div>
				<div class="column pairs">
					<p>Place of Birth :</p>
					<p>{{ $scholar->applicant->birthplace }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Contact Details</h1>
				</div>
				<div class="column">
					<h1>Personal Identification</h1>
				</div>
				<div class="column">
					<h1>Payment Requirements</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Email :</p>
					<p style="word-break: break-all;">{{ $scholar->applicant->email_address }}</p>
					<p>Contact No. :</p>
					<p>{{ $scholar->applicant->formatted_contact_number }}</p>
					<p>Facebook :</p>
					<p>{{ $scholar->applicant->fb_account == null ? 'N/A' : $scholar->applicant->fb_account }}</p>
				</div>
				<div class="column pairs">
					<p>Birth Certificate :</p>
					@if($scholar->applicant->birth_cert != null)
					<p><a href="{{ $scholar->applicant->birth_cert }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/birth_cert/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/birth_cert/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					<p>ID Photo :</p>
					@if($scholar->applicant->id_photo != null)
					<p><a href="{{ $scholar->applicant->id_photo }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/id_photo/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/id_photo/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
				</div>
				<div class="column pairs">
					<p>Land Bank Card :</p>
					@if($scholar->atm_card != null)
					<p><a href="{{ $scholar->atm_card }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a>
					@else
					<p>N/A</p>
					@endif
					<p>School ID :</p>
					@if($scholar->school_id != null)
					<p><a href="{{ $scholar->school_id }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a>
					@else
					<p>N/A</p>
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column2">
					<h1>Last School Attended</h1>
				</div>
				<div class="column">
					<h1>GWAs</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column2 pairs">
					<p>School Name :</p>
					<p>{{ $scholar->applicant->highschool }}</p>
					<p>School Address :</p>
					<p>{{ $scholar->applicant->highschool_add == null ? 'N/A' : $scholar->applicant->highschool_add }}</p>
					<p>School Sector :</p>
					<p>{{ $scholar->applicant->highschool_sector == null ? 'N/A' : $scholar->applicant->highschool_sector }}</p>
				</div>
				<div class="column pairs">
					@if($scholar->applicant->twelve_gwa_1 == null)
						<!-- GRADE 12 -->
						@if($scholar->applicant->type == 'Graduate' || $scholar->applicant->type == 'Graduating')
						<p>Grade 12 GWA :</p>
						@else
						<!-- IF ALS OR PEPT -->
						<p>GWA :</p>
						@endif
						<p>{{ $scholar->applicant->twelve_gwa }}</p>

						<!-- GRADE 11 -->
						@if($scholar->applicant->type == 'Graduating')
						<p>Grade 11 GWA :</p>
						<p>{{ $scholar->applicant->eleven_gwa }}</p>
						@endif
					@else
						<p>G12 Avg : {{ $scholar->applicant->twelve_gwa }}</p>
						<p>1st: {{ $scholar->applicant->twelve_gwa_1 }}{{ $scholar->applicant->twelve_gwa_2 != null ? ', 2nd: '.$scholar->applicant->twelve_gwa_2 : ''}}{{ $scholar->applicant->twelve_gwa_3 != null ? ', 3rd: '.$scholar->applicant->twelve_gwa_3 : ''}}</p>

						<!-- GRADE 11 -->
						@if($scholar->applicant->type == 'Graduating')
						<p>G11 Avg : {{ $scholar->applicant->eleven_gwa }}</p>
						<p>1st: {{ $scholar->applicant->eleven_gwa_1 }}{{ $scholar->applicant->eleven_gwa_2 != null ? ', 2nd: '.$scholar->applicant->eleven_gwa_2 : ''}}{{ $scholar->applicant->eleven_gwa_3 != null ? ', 3rd: '.$scholar->applicant->eleven_gwa_3 : ''}}</p>
						@endif
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column2">
					<h1>School Intended to Enroll or Enrolled In</h1>
				</div>
				<div class="column">
					<h1>Academic Requirements</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column2 pairs">
					<p>School Name :</p>
					<p>{{ $scholar->applicant->institution_id == null ? $scholar->applicant->hei_out_car_name : $scholar->applicant->institution->institution_name }}</p>
					<p>School Address :</p>
					<p>{{ $scholar->applicant->institution_id == null ? $scholar->applicant->hei_out_car_address : $scholar->applicant->institution->address }}</p>
					<p>Degree Program :</p>
					<p>{{ $scholar->applicant->course->course_name }}</p>
				</div>
				<div class="column pairs">
					<p>Applicant Type :</p>
					<p>{{ $scholar->applicant->full_type }}</p>
					@if($scholar->applicant->type == 'Graduate')
					<p>HS Report Card :</p>
					@elseif($scholar->applicant->type == 'Graduating')
					<p>Grades for G12 :</p>
					@else
					<p>Report Card :</p>
					@endif
					@if($scholar->applicant->twelve_card != null)
					<p><a href="{{ $scholar->applicant->twelve_card }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/twelve_card/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/twelve_card/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@if($scholar->applicant->type == 'Graduating')
					<p>Grades for G11 :</p>
					@if($scholar->applicant->eleven_card != null)
					<p><a href="{{ $scholar->applicant->eleven_card }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/eleven_card/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/eleven_card/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Other Sources of Educational or Financial Assistance</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Grantee Agency :</p>
					<p>{{ $scholar->applicant->other_fa_agency == null ? 'N/A' : $scholar->applicant->other_fa_agency }}</p>
					<p>Scholarship Type :</p>
					<p>{{ $scholar->applicant->other_fa_type == null ? 'N/A' : $scholar->applicant->other_fa_type }}</p>
				</div>
				<div class="column pairs">
					<p>Grantee Agency :</p>
					<p>{{ $scholar->applicant->other_fa_agency2 == null ? 'N/A' : $scholar->applicant->other_fa_agency2 }}</p>
					<p>Scholarship Type :</p>
					<p>{{ $scholar->applicant->other_fa_type2 == null ? 'N/A' : $scholar->applicant->other_fa_type2 }}</p>
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Father{{ $scholar->applicant->f_is_living == 0 ? ' (Deceased)' : '' }}</h1>
				</div>
				@if(!$scholar->applicant->f_is_living && !$scholar->applicant->m_is_living)
				<div class="column">
					<h1>Mother (Deceased)</h1>
				</div>
				@endif
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Full Name :</p>
					<p>{{ $scholar->applicant->f_name == null ? 'N/A' : $scholar->applicant->f_name }}</p>
					@if($scholar->applicant->f_is_living == 1)
					<p>Address :</p>
					<p>{{ $scholar->applicant->f_add == null ? 'N/A' : $scholar->applicant->f_add }}</p>
					<p>Contact Number :</p>
					<p>{{ $scholar->applicant->f_contact_no == null ? 'N/A' : $scholar->applicant->formatted_f_contact_no }}</p>
					<p>Education :</p>
					<p>{{ $scholar->applicant->f_education == null ? 'N/A' : $scholar->applicant->f_education }}</p>
					@endif
				</div>
				<div class="column pairs">
					@if($scholar->applicant->f_is_living == 1)
					<p>Occupation :</p>
					<p>{{ $scholar->applicant->f_occupation == null ? 'N/A' : $scholar->applicant->f_occupation }}</p>
					<p>Employer Name :</p>
					<p>{{ $scholar->applicant->f_employer == null ? 'N/A' : $scholar->applicant->f_employer }}</p>
					<p>Employer Address :</p>
					<p>{{ $scholar->applicant->f_employer_add == null ? 'N/A' : $scholar->applicant->f_employer_add }}</p>
					@endif
					@if(!$scholar->applicant->f_is_living && !$scholar->applicant->m_is_living)
					<p>Full Name :</p>
					<p>{{ $scholar->applicant->m_name == null ? 'N/A' : $scholar->applicant->m_name }}</p>
					@endif
				</div>
			</div>

			@if($scholar->applicant->f_is_living || $scholar->applicant->m_is_living)
			<div class="columns">
				<div class="column">
					<h1>Mother{{ $scholar->applicant->m_is_living == 0 ? ' (Deceased)' : '' }}</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Full Name :</p>
					<p>{{ $scholar->applicant->m_name == null ? 'N/A' : $scholar->applicant->m_name }}</p>
					@if($scholar->applicant->m_is_living == 1)
					<p>Address :</p>
					<p>{{ $scholar->applicant->m_add == null ? 'N/A' : $scholar->applicant->m_add }}</p>
					<p>Contact Number :</p>
					<p>{{ $scholar->applicant->m_contact_no == null ? 'N/A' : $scholar->applicant->formatted_m_contact_no }}</p>
					<p>Education :</p>
					<p>{{ $scholar->applicant->m_education == null ? 'N/A' : $scholar->applicant->m_education }}</p>
					@endif
				</div>
				<div class="column pairs">
					@if($scholar->applicant->m_is_living == 1)
					<p>Occupation :</p>
					<p>{{ $scholar->applicant->m_occupation == null ? 'N/A' : $scholar->applicant->m_occupation }}</p>
					<p>Employer Name :</p>
					<p>{{ $scholar->applicant->m_employer == null ? 'N/A' : $scholar->applicant->m_employer }}</p>
					<p>Employer Address :</p>
					<p>{{ $scholar->applicant->m_employer_add == null ? 'N/A' : $scholar->applicant->m_employer_add }}</p>
					@endif
				</div>
			</div>
			@endif

			@if($scholar->applicant->g_name != null)
			<div class="columns">
				<div class="column">
					<h1>Legal Guardian</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Full Name :</p>
					<p>{{ $scholar->applicant->g_name == null ? 'N/A' : $scholar->applicant->g_name }}</p>
					<p>Address :</p>
					<p>{{ $scholar->applicant->g_add == null ? 'N/A' : $scholar->applicant->g_add }}</p>
					<p>Contact Number :</p>
					<p>{{ $scholar->applicant->g_contact_no == null ? 'N/A' : $scholar->applicant->formatted_g_contact_no }}</p>
					<p>Education :</p>
					<p>{{ $scholar->applicant->g_education == null ? 'N/A' : $scholar->applicant->g_education }}</p>
				</div>
				<div class="column pairs">
					<p>Occupation :</p>
					<p>{{ $scholar->applicant->g_occupation == null ? 'N/A' : $scholar->applicant->g_occupation }}</p>
					<p>Employer Name :</p>
					<p>{{ $scholar->applicant->g_employer == null ? 'N/A' : $scholar->applicant->g_employer }}</p>
					<p>Employer Address :</p>
					<p>{{ $scholar->applicant->g_employer_add == null ? 'N/A' : $scholar->applicant->g_employer_add }}</p>
				</div>
			</div>
			@endif

			<div class="columns">
				<div class="column">
					<h1>Family</h1>
				</div>
				<div class="column">
					<h1>Income Requirement</h1>
				</div>
				<div class="column">
					<h1>DSWD's 4Ps</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Siblings 18 & below :</p>
					<p>{{ $scholar->applicant->siblings }}</p>
					<p>Annual Income :</p>
					<p>PHP {{ number_format($scholar->applicant->annual_gross_income, 2, '.', ',') }}</p>
				</div>
				<div class="column pairs">
					<p>{{ $scholar->applicant->income_proof_type == null ? 'Document' : $scholar->applicant->income_proof_type }} :</p>
					@if($scholar->applicant->income_proof != null)
					<p><a href="{{ $scholar->applicant->income_proof }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/income_proof/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/income_proof/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
				</div>
				<div class="column pairs">
					<p>Beneficiary :</p>
					<p>{{ $scholar->applicant->is_dswd_4ps == 1 ? 'Yes' : 'No' }}</p>
				</div>
			</div>

			<div class="header">
				<h1>{{ $scholar->applicant->pres_is_perm ? 'Permanent and Present Address' : 'Permanent Address' }}</h1>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Zip Code :</p>
					<p>{{ $scholar->applicant->perm_zip_code }}</p>
					<p>District :</p>
					<p>{{ $scholar->applicant->perm_district }}</p>
				</div>
				<div class="column pairs">
					<p>Province :</p>
					<p>{{ $scholar->applicant->perm_province }}</p>
					<p>Municipality :</p>
					<p>{{ $scholar->applicant->perm_muni_city }}</p>
				</div>
				<div class="column pairs">
					<p>Brgy/Street :</p>
					<p>{{ $scholar->applicant->perm_barangay }}</p>
				</div>
			</div>

			@if(!$scholar->applicant->pres_is_perm)
			<div class="header">
				<h1>Present Address</h1>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Zip Code :</p>
					<p>{{ $scholar->applicant->pres_zip_code }}</p>
					<p>District :</p>
					<p>{{ $scholar->applicant->pres_district }}</p>
				</div>
				<div class="column pairs">
					<p>Province :</p>
					<p>{{ $scholar->applicant->pres_province }}</p>
					<p>Municipality :</p>
					<p>{{ $scholar->applicant->pres_muni_city }}</p>
				</div>
				<div class="column pairs">
					<p>Brgy/Street :</p>
					<p>{{ $scholar->applicant->pres_barangay }}</p>
				</div>
			</div>
			@endif

			<div class="columns">
				<div class="column">
					<h1>Persons with Disability</h1>
				</div>
				<div class="column">
					<h1>Indigenous People</h1>
				</div>
				<div class="column">
					<h1>Solo Parent</h1>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Disability :</p>
					<p>{{ $scholar->applicant->disability == null ? 'N/A' : $scholar->applicant->full_disability }}</p>
					@if($scholar->applicant->disability != null)
					<p>PWD ID :</p>
					@if($scholar->applicant->pwd_id != null)
					<p><a href="{{ $scholar->applicant->pwd_id }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/pwd_id/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/pwd_id/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
				<div class="column pairs">
					<p>Tribe :</p>
					<p>{{ $scholar->applicant->tribe == null ? 'N/A' : $scholar->applicant->tribe }}</p>
					@if($scholar->applicant->tribe != null)
					<p>Certification :</p>
					@if($scholar->applicant->cert_indigency != null)
					<p><a href="{{ $scholar->applicant->cert_indigency }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/cert_indigency/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/cert_indigency/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
				<div class="column pairs">
					<p>Beneficiary Type :</p>
					<p>{{ $scholar->applicant->sp_type == null ? 'N/A' : $scholar->applicant->sp_type }}</p>
					@if($scholar->applicant->sp_type != null)
					<p>Solo Parent ID :</p>
					@if($scholar->applicant->sp_id != null)
					<p><a href="{{ $scholar->applicant->sp_id }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/sp_id/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/sp_id/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
			</div>

			<div class="columns">
				<div class="column">
					<h1>Senior Citizen</h1>
				</div>
				<div class="column">
					<h1>Orphan</h1>
				</div>
				<div class="column" style="text-align: right;">
					<a class="add" href="/applicants/{{ $scholar->applicant->id }}/delete" onclick="return confirm('Warning: This would delete all the records of this applicant in the database, are you sure?')">
						Delete Applicant
					</a>
				</div>
			</div>
			<div class="columns">
				<div class="column pairs">
					<p>Beneficiary Type :</p>
					<p>{{ $scholar->applicant->sc_type == null ? 'N/A' : $scholar->applicant->sc_type }}</p>
					@if($scholar->applicant->sc_type != null)
					<p>Senior Citizen ID :</p>
					@if($scholar->applicant->sc_id != null)
					<p><a href="{{ $scholar->applicant->sc_id }}" target="_blank"><span class="material-icons-round">open_in_new</span>Open</a><a href="/applicants/{{ $scholar->applicant->id }}/file/sc_id/edit"><span class="material-icons-round">create</span>Edit</a></p>
					@else
					<p><a href="/applicants/{{ $scholar->applicant->id }}/file/sc_id/create"><span class="material-icons-round">add</span>Add a file</a></p>
					@endif
					@endif
				</div>
				<div class="column pairs">
					<p>Orphan :</p>
					<p>{{ $scholar->applicant->is_orphan? 'Yes' : 'No' }}</p>
				</div>
				<div class="column pairs">
				</div>
			</div>
		</div>
	</div>
</section>

<script type="text/javascript">
	function changeView(view) {
		if(view == 1) {
			document.querySelector('#left-view').classList.add('active');
			document.querySelector('#right-view').classList.remove('active');
			document.querySelector('#left-nav').classList.add('active');
			document.querySelector('#right-nav').classList.remove('active');
		} else {
			document.querySelector('#left-view').classList.remove('active');
			document.querySelector('#right-view').classList.add('active');
			document.querySelector('#left-nav').classList.remove('active');
			document.querySelector('#right-nav').classList.add('active');
		}
	}

	var applicant = {!! json_encode($scholar->applicant->toArray(), JSON_HEX_TAG) !!};
	console.log(applicant);
	if(applicant['disability'] != null) {
		applicant['disability'] = '{!! $scholar->applicant->full_disability !!}';
	}
</script>
<script type="text/javascript" src="{{ URL::asset('js/downloadpdf.js') }}"></script>
@endsection