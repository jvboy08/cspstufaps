@extends('layouts.master')

@section('title')
CHED-CAR Admin | Scholars
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Add semestral awards</h1>
		<a class="add" href="/scholars">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/scholars/display" enctype="multipart/form-data"> 
		@csrf 
		<!-- CSV FILE -->
		<label for="scholars">CSV File :</label>
		<input type="file" name="scholars" placeholder="Upload a csv file" accept=".csv" required>

		<input type="submit" value="Submit">
	</form>
</section>
@endsection