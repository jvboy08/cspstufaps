@extends('layouts.master')

@section('title')
CHED-CAR Admin | Scholars
@endsection

@section('body')
<section>
	<div class="header">
		@if(count($errors) != 0)
		<h1 class="result">{{ count($errors) }} {{ count($errors) > 1 ? 'Rows Were Not' : 'Row Was Not' }} Added</h1>
		@else
		<h1 class="result">All Rows Were Successfully Added</h1>
		@endif
		<a class="add" href="/applicants">Go back</a>
	</div>
	@if(count($errors) != 0)
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>Row</th>
					<th>Scholar</th>
					<th>Error</th>
				</tr>
			</thead>
			<tbody>
				@foreach($errors as $error)
					<tr>
						<td>{{ $error[0] }}</td>
						<td>{{ $error[1] }}</td>
						<td>{{ $error[2] }}</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	@endif
</section>
@endsection
