@extends('layouts.master')

@section('title')
CHED-CAR Admin | Scholars
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Edit Scholarship</h1>
		<a class="add" href="/scholars/{{ $scholar->id }}">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/scholars/{{ $scholar->id }}/scholarships"> 
		@method('PUT')
		@csrf 
		<div class="columns">
			<div class="column">
				<!-- PROGRAM -->
				<label for="program_id">Program :</label>
				<select name="program_id" id="program">
					@foreach($programs as $program)
						@if($program->awards->count() != 0)
						<option value="{{ $program->code }}" {{ $scholar->award->program->code == $program->code ? 'selected' : '' }}>{{ $program->code }} - {{ $program->program_name }}</option>
						@endif
					@endforeach
				</select>

				<!-- AWARD NUMBER -->
				<label for="award_number">Award Number :</label>
				<select name="award_number" required id="award_number">
					@foreach($awards as $award)
						@for($i = $award->start_slot; $i <= $award->end_slot; $i++)
					        <option value="{{ $scholar->award->program->code }}-{{ sprintf("%04d", $i) }}-{{ substr($award->award_year, 2, 4) }}-14" {{ $scholar->award_number == $scholar->award->program->code.'-'.sprintf("%04d", $i).'-'.substr($award->award_year, 2, 4).'-14' ? 'selected' : '' }}>{{ $scholar->award->program->code }}-{{ sprintf("%04d", $i) }}-{{ substr($award->award_year, 2, 4) }}-14</option>
					    @endfor
					@endforeach
				</select>

				<!-- ACADEMIC YEAR WHEN ACCEPTED -->
				<label for="acad_year_accepted">Academic Year When Accepted :</label>
				<select name="acad_year_accepted" required>
					@for($i = 2016; $i <= now()->year; $i++)
				        <option value="{{$i}}" {{ $scholar->acad_year_accepted == $i ? 'selected' : '' }}>{{ $i }} - {{ $i+1 }}</option>
				    @endfor
				</select>

				<!-- SEMESTER WHEN ACCEPTED -->
				<label for="semester_accepted">Semester When Accepted :</label>
				<select name="semester_accepted" required>
					<option value="1" {{ $scholar->semester_accepted == 1 ? 'selected' : '' }}>1st Semester</option>
					<option value="2" {{ $scholar->semester_accepted == 2 ? 'selected' : '' }}>2nd Semester</option>
				</select>

				<input type="submit" value="Submit Changes">
			</div>
		</div>
	</form>
</section>

<script type="text/javascript">
	$(document).ready(function() {
	    $('select[name="program_id"]').on('change', function(){
	    	document.querySelector('#award_number').disabled = false;
	        var program_code = $(this).val();
	        if(program_code) {
	            $.ajax({ 
	                url: '/award_numbers/get/'+program_code,
	                type: "GET",
	                dataType: "json",
	                success: function(data) {
	                    $('select[name="award_number"]').empty();
	                    $.each(data, function(index){
	                    	var award_year = data[index].award_year.toString();
	                    	console.log(award_year);
	                    	for (var i = data[index].start_slot; i <= data[index].end_slot; i++) {    
	                    		var slot = i < 1000 ? ('00' + i).slice(-3) : i;
	                    		$('select[name="award_number"]').append('<option value="'+ program_code + '-' + slot + '-' + award_year.substring(2, 4) + '-14">' + program_code + '-' + slot + '-' + award_year.substring(2, 4) + '-14</option>');       
						    }
	                    });
	                },
	            });
	        } else {
	            $('select[name="award_number"]').empty();
	        }
	    });
	});
</script>
@endsection