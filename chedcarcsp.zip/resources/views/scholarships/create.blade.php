@extends('layouts.master')

@section('title')
CHED-CAR Admin | Applicants
@endsection

@section('body')
<section class="form full">
	<div class="header">
		<h1>Add a Scholarship</h1>
		<a class="add" href="/applicants/{{ $applicant->id }}">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/applicants/{{ $applicant->id }}/scholarships"> 
		@csrf 
		<div class="columns">
			<div class="column">
				<!-- PROGRAM -->
				<label for="program_id">Program :</label>
				<select name="program_id" id="program" required>
					<option value="" disabled selected hidden>Select a program</option>
					@foreach($programs as $program)
						@if($program->awards->count() != 0)
						<option value="{{ $program->code }}">{{ $program->code }} - {{ $program->program_name }}</option>
						@endif
					@endforeach
				</select>

				<!-- AWARD NUMBER -->
				<label for="award_number">Award Number :</label>
				<select name="award_number" required disabled id="award_number" required>
					<option value="" disabled selected hidden>Select an award number</option>
				</select>

				<!-- ACADEMIC YEAR WHEN ACCEPTED -->
				<label for="acad_year_accepted">Academic Year When Accepted :</label>
				<select name="acad_year_accepted" required>
					<option value="" disabled selected hidden>Select an academic year</option>
					@for($i = 2016; $i <= now()->year; $i++)
				        <option value="{{$i}}">{{ $i }} - {{ $i+1 }}</option>
				    @endfor
				</select>

				<!-- SEMESTER WHEN ACCEPTED -->
				<label for="semester_accepted">Semester When Accepted :</label>
				<select name="semester_accepted" required>
					<option value="" disabled selected hidden>Select a semester</option>
					<option value="1">1st Semester</option>
					<option value="2">2nd Semester</option>
				</select>
			</div>

			<div class="column">

				<!-- REMARKS CHEDRO -->
				<label for="remarks_chedro">CHEDRO Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_chedro" placeholder="Enter remarks of CHEDRO">

				<!-- REMARKS OSDS -->
				<label for="remarks_osds">OSDS Remarks <span class="optional">(Optional)</span> :</label>
				<input type="text" name="remarks_osds" placeholder="Enter remarks of OSDS">
				
				<!-- SARO -->
				<label for="saro">SARO <span class="optional">(Optional)</span> :</label>
				<input type="text" name="saro" placeholder="Enter SARO">

				<!-- NTA Number -->
				<label for="nta_number">NTA Number <span class="optional">(Optional)</span> :</label>
				<input type="text" name="nta_number" placeholder="Enter NTA number">
			</div>

			<div class="column">

				<!-- IS PROCESSED -->
				<label for="is_processed">Is the payment already processed? :</label>
				<select id="is_processed" name="is_processed" required>
					<option value="1">Yes</option>
					<option value="0">No</option>
				</select>

				<div id="processed_container">
					<!-- AMOUNT CHEDRO -->
					<label for="amount_chedro">Amount Processed :</label>
					<input type="number" name="amount_chedro" placeholder="Enter amount" required>

					<!-- DATE PROCESSED -->
					<label for="date_processed">Date Processed <span class="optional">(dd/mm/yyyy)</span> :</label>
					<input type="text" onfocus="(this.type='date')" name="date_processed" placeholder="Enter date processed" required>

					<!-- MODE OF PAYMENT -->
					<label for="mode_of_payment">Mode of Payment :</label>
					<select name="mode_of_payment" required>
						<option value="" disabled selected hidden>Select a mode of payment</option>
						<option value="HEI">HEI – if through the HEI</option>
						<option value="STUDENT">STUDENT – if through ATM/Cheque</option>
					</select>
				</div>

				<input type="submit" value="Submit">
			</div>
		</div>
	</form>
</section>

<script type="text/javascript">
	$(document).ready(function() {
	    $('select[name="program_id"]').on('change', function(){
	    	document.querySelector('#award_number').disabled = false;
	        var program_code = $(this).val();
	        if(program_code) {
	            $.ajax({ 
	                url: '/award_numbers/get/'+program_code,
	                type: "GET",
	                dataType: "json",
	                success: function(data) {
	                    $('select[name="award_number"]').empty();
	                    $.each(data, function(index){
	                    	var award_year = data[index].award_year.toString();
	                    	console.log(award_year);
	                    	for (var i = data[index].start_slot; i <= data[index].end_slot; i++) {    
	                    		var slot = i < 1000 ? ('000' + i).slice(-4) : i;
	                    		$('select[name="award_number"]').append('<option value="'+ program_code + '-' + slot + '-' + award_year.substring(2, 4) + '-14">' + program_code + '-' + slot + '-' + award_year.substring(2, 4) + '-14</option>');       
						    }
	                    });
	                },
	                beforeSend: function(){
						document.querySelector('#loading').style.display = 'flex';
				    },
				    complete: function(){
						document.querySelector('#loading').style.display = 'none';
				    },
	            });
	            $.ajax({ 
	                url: '/program_amount/get/'+program_code,
	                type: "GET",
	                dataType: "text",
	                success: function(data) {
	                    $('input[name="amount_chedro"]').val(data);
	                }
	            });
	        } else {
	            $('select[name="award_number"]').empty();
	            $('input[name="amount_chedro"]').val(null);
	        }
	    });

	    $('#is_processed').on('change', function() {
	    	if($('#is_processed').val() == 1) {
		        $('#processed_container').css('display', 'block');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', true);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', true);
		        });
	    	} else {
		        $('#processed_container').css('display', 'none');
		        $('#processed_container input').each(function() {
		          $(this).prop('required', false);
		        });
		        $('#processed_container select').each(function() {
		          $(this).prop('required', false);
		        });
	    	}
	    });
	});
</script>
@endsection