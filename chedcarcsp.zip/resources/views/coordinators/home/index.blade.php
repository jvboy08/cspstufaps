@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Home
@endsection

@section('content')
<section class="scholar_body">
	<div class="row1">
		<!-- HEI -->
		<div class="box">
			<div class="head">
				<div class="title">
					<span class="icon material-icons-round">account_balance</span>
					<p class="bold">Higher Education Institution</p>
				</div>
				<a href="/coordinator/home/institution/{{ $institution->id }}/edit" class="add yellow_btn">Edit</a>
			</div>
			<h2>{{ $institution->institution_name }}</h2>
			<div class="info">
				<p class="italic">Always keep the details of your HEI up-to-date.</p>
			</div>
			<div class="details2">
				<div class="pair" style="max-width: 100%; overflow: hidden;">
					<p class="italic">Address</p>
					<p class="bold" style="white-space: nowrap;">{{ $institution->address == null ? 'N/A' : $institution->address }}</p>
				</div>
				<div class="pair">
					<p class="italic">Email Address</p>
					<p class="bold">{{ $institution->hei_email == null ? 'N/A' : $institution->hei_email }}</p>
				</div>
				<div class="pair">
					<p class="italic">Contact Number</p>
					<p class="bold">{{ $institution->hei_contact_no == null ? 'N/A' : $institution->hei_contact_no }}</p>
				</div>
				<div class="pair">
					<p class="italic">Website Link</p>
					<p class="bold">{{ $institution->hei_website == null ? 'N/A' : $institution->hei_website }}</p>
				</div>
			</div>
		</div>

		<!-- ORGANIZATION -->
		<div class="box">
			<div class="head">
				<div class="title">
					<span class="icon material-icons-round">groups</span>
					<p class="bold">Organization Heads</p>
				</div>
				<a href="/coordinator/home/organization/{{ $institution->id }}/edit" class="yellow_btn add">Edit</a>
			</div>
			<div class="details2">
				<div class="pair">
					<p class="italic">Head of Institution</p>
					<p class="bold">{{ $institution->institution_head == null ? 'N/A' : $institution->institution_head }}</p>
				</div>
				<div class="pair">
					<p class="italic">University Registrar</p>
					<p class="bold">{{ $institution->registrar == null ? 'N/A' : $institution->registrar }}</p>
				</div>
				<div class="pair">
					<p class="italic">Chief Accountant</p>
					<p class="bold">{{ $institution->accountant == null ? 'N/A' : $institution->accountant }}</p>
				</div>
				<div class="pair">
					<p class="italic">Head Coordinator</p>
					<p class="bold">{{ $head_coordinator->name }}</p>
				</div>
			</div>
		</div>
	</div>
</section>
@endsection