@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Edit HEI 
@endsection

@section('content')
<section class="scholar_form">
	<section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/home/institution/{{ $institution->id }}">
        @method('PUT')
        @csrf
        @include('layouts.errors_no_icon')
        <div class="head">
          <h2 class="bold">Edit HEI Details</h2>
          <a class="add grey_btn" href="/coordinator/home">Back</a>
        </div>

        <div class="pair_input">
          <p>Address :</p>
          <input type="text" name="address" placeholder="Enter address" value="{{ $institution->address }}" required>
        </div>

        <div class="pair_input">
          <p>Email Address :</p>
          <input type="text" name="hei_email" placeholder="Enter email address" value="{{ $institution->hei_email }}" required>
        </div>

        <div class="pair_input">
          <p>Contact Number :</p>
          <input type="text" name="hei_contact_no" placeholder="Enter contact number" value="{{ $institution->hei_contact_no }}" required>
        </div>

        <div class="pair_input">
          <p>Website Link <span class="italic">(Optional)</span> :</p>
          <input type="text" name="hei_website" placeholder="Enter website link" value="{{ $institution->hei_website }}">
        </div>
        
        <input type="submit" value="Submit Changes">
      </form>
    </div>
  </section> 
</section>
@endsection