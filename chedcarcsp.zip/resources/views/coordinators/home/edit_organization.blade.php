@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Edit HEI 
@endsection

@section('content')
<section class="scholar_form">
	<section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/home/organization/{{ $institution->id }}">
        @method('PUT')
        @csrf
        @include('layouts.errors_no_icon')
        <div class="head">
          <h2 class="bold">Edit Organization</h2>
          <a class="add grey_btn" href="/coordinator/home">Back</a>
        </div>

        <div class="pair_input">
          <p>Institution Head :</p>
          <input type="text" name="institution_head" placeholder="Enter name of institution head" value="{{ $institution->institution_head }}" required>
        </div>

        <div class="pair_input">
          <p>University Registrar :</p>
          <input type="text" name="registrar" placeholder="Enter name of registrar" value="{{ $institution->registrar }}" required>
        </div>

        <div class="pair_input">
          <p>Chief Accountant :</p>
          <input type="text" name="accountant" placeholder="Enter name of chief accountant" value="{{ $institution->accountant }}" required>
        </div>

        <input type="submit" value="Submit Changes">
      </form>
    </div>
  </section> 
</section>
@endsection