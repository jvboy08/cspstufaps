@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Coordinator
@endsection

@section('content')
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/login">
        @csrf
        <h1>Log In as Coordinator</h1>
        @include('layouts.errors_no_icon')
        <input type="email" id="email" name="email" placeholder="Email address" required>
        <input type="password" id="password" name="password" placeholder="Password" required>
        <a href="/password/email"><p>Forgot password? <span class="bold">Reset Password</span></p></a>
        <input type="submit" value="Log In">
        <a href="/coordinator/sign_up"><p>Don’t have an account? <span class="bold">Sign Up</span></p></a>
      </form>
    </div>
  </section> 
@endsection