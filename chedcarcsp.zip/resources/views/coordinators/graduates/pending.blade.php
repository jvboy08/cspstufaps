@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Graduates
@endsection

@section('content')
<section class="scholar_body">
	<div class="box">
        <div class="head">
	        <h3 class="bold">Pending Graduates</h3>
	        <div class="pair_space">
				<a href="/coordinator/graduates/create" class="add yellow_btn">Add Graduates</a>
				<a class="add grey_btn" href="/coordinator/graduates">Go back</a>
	        </div>
        </div>
		<div class="functions">
			<form action="/coordinator/graduates/pending" method="GET">
				<div class="filter">
					<div class="pairs">

						<!-- SEARCH -->
						<div class="pair">
							<h3>Search By Name</h3>
							@if(array_key_exists('name', $sort_filters))
							<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
							@else						
							<input type="text" name="name" placeholder="Enter last or first name" id="name">
							@endif
						</div>

						<!-- PROGRAM -->
						<div class="pair">
							<h3>Program</h3>
							<select name="program">
								<option value="" disabled selected hidden>Select a program</option>
								@if(array_key_exists('program', $sort_filters))
								@foreach($programs as $program)
									<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
								@endforeach
								@else
								@foreach($programs as $program)
									<option value="{{ $program->id }}">{{ $program->code }}</option>
								@endforeach
								@endif
							</select>
						</div>

						<!-- ITEMS PER PAGE -->
						<div class="pair">
							<h3>Items Per Page</h3>
							<select name="items">
								@if(array_key_exists('items', $sort_filters))
									<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
									<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
									<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
									<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
								@else
									<option value="10" selected>10</option>
									<option value="25">25</option>
									<option value="50">50</option>
									<option value="100">100</option>
								@endif
							</select>
						</div>

						
						<div class="pair">
							<button type="button" class="clear" onclick="resetAll()">Reset</button>
							<input type="submit" value="Submit">
						</div>
					</div>
				</div>
			</form>
		</div>
		@if(!$updates->isEmpty())
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Award Number</th>
					<th>Period Started</th>
					<th>Latest Period</th>
					<th>Remarks</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($updates as $key => $update)
				<tr>
					<td>{{ $key + $updates->firstItem() }}</td>
					<td>{{ $update->applicant->full_name }}</td>
					<td>{{ $update->applicant->scholar->award_number }}</td>
					<td>A.Y. {{ $update->applicant->scholar->acad_year_accepted }}, {{ $update->applicant->scholar->semester_accepted == 1 ? '1st' : '2nd' }} Sem</td>
					<td>A.Y. {{ $update->applicant->scholar->latest_acad_year }}, {{ $update->applicant->scholar->latest_semester == 1 ? '1st' : '2nd' }} Sem</td>
					<td>{{ $update->remarks == null ? 'N/A' : $update->remarks }}</td>
					<td class="settings">
						<div class="pair_no_space">
							<a class="option" onclick="show_form({{ $update->id }})">
							<div><span class="material-icons-round">edit</span><p>Remarks</p></div>
							</a>
				        	<div id="num{{ $update->id }}" class="graduate_container">
								<div class="graduate_content">
									<form class="scholar_form" method="POST" action="/coordinator/graduates/{{ $update->id }}">
										@method('PUT')
										@csrf
										<h3 class="bold">{{ $update->applicant->full_name }}</h3>
										<div class="pair_input">
								          <p>Remarks <span class="italic">(Optional)</span>:</p>
								          <input type="text" name="remarks_{{ $update->id }}" placeholder="E.g. Cum Laude" value="{{ $update->remarks }}">
								        </div>
								        <input type="submit" value="Submit">
										<span class="material-icons-round close" onclick="hide_form('{{ $update->id }}')">close</span>
									</form>
								</div>
							</div>
							<a class="option" href="/coordinator/graduates/pending/cancel/{{ $update->id }}" onclick="return confirm('Are you sure you want to remove this pending graduate?')"><div><span class="material-icons-round">cancel</span><p>Cancel</p></div></a>
						</div>
					</td>
				</tr>
				@endforeach
			</tbody>
		</table>
		@if($updates->total() > 10)
		<div class="pagination">
			<div class="previous">{{ $updates->links() }}</div>
		</div>
		@endif
		@else
		<center><p class="bold">No Pending Graduates Found</p></center>
		@endif
	</div>
</section>
<script type="text/javascript">
	function show_form(num) {
		document.querySelector("#num" + num).style.display = "flex";
	}

	function hide_form(num) {
		document.querySelector("#num" + num).style.display = "none";
	}
</script>
@endsection