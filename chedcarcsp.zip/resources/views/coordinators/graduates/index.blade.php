@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Graduates
@endsection

@section('content')
<section class="scholar_body scholar_body2">
	<div class="scholars_nav">
		<a href="/coordinator/undergraduates">
			<span class="icon material-icons-round">assignment_ind</span>
			<p class="bold">Undergraduate Scholars</p>
		</a>
		<a href="" class="active">
			<span class="icon material-icons-round">school</span>
			<p class="bold">Graduate Scholars</p>
		</a>
	</div>
	<div class="box box3">
		<div class="functions">
			<form action="/coordinator/undergraduates" method="GET">
				<div class="filter">
					<div class="pairs">

						<!-- SEARCH -->
						<div class="pair">
							<h3>Search By Name</h3>
							@if(array_key_exists('name', $sort_filters))
							<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
							@else						
							<input type="text" name="name" placeholder="Enter last or first name" id="name">
							@endif
						</div>

						<!-- SORT BY -->
						<div class="pair">
							<h3>Sort By</h3>
							<select name="sort">
								@if(array_key_exists('sort', $sort_filters))
									<option value="alphabetical" {{ $sort_filters['sort'] == 'alphabetical' ? 'selected' : ''}}>Alphabetical</option>
									<option value="award_number" {{ $sort_filters['sort'] == 'award_number' ? 'selected' : ''}}>Award Number</option>
								@else
									<option value="alphabetical" selected>Alphabetical</option>
									<option value="award_number">Award Number</option>
								@endif
							</select>
						</div>
					</div>

					<div class="pair">
						<div class="pair_no_space">
							<div class="info_button" onclick="show(2)"><span class="material-icons-round">help</span></div>
				        	<div id="info2" class="info_container" onclick="hide(2)">
								<div class="info_content">
									<span class="material-icons-round help">help</span>
									<p style="text-align: left;">Please notify CHED-CAR if there are scholars who recently graduated by clicking<br>the "Add Graduates" button and choosing among the scholars. The "View Pending"<br>button will display the graduates that still needs validation from CHED-CAR.</p>
									<span class="material-icons-round close" onclick="hide(2)">close</span>
								</div>
							</div>
							<a href="/coordinator/graduates/create" class="add yellow_btn">Add Graduates</a>
							<a href="/coordinator/graduates/pending" class="add yellow_btn">View Pending</a>
							<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
						</div>
					</div>
				</div>
				<div class="filter">
					<div class="pairs">

						<!-- PERIOD STARTED-->
						<div class="pair">
							<h3>Period Started</h3>
							<select name="started">
								<option value="" disabled selected hidden>Select an academic period</option>
								@if(array_key_exists('started', $sort_filters))
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @else
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @endif
							</select>
						</div>

						<!-- LATEST ACADEMIC PERIOD -->
						<div class="pair">
							<h3>Period Graduated</h3>
							<select name="period">
								<option value="" disabled selected hidden>Select an academic period</option>
								@if(array_key_exists('period', $sort_filters))
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @else
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @endif
							</select>
						</div>
					</div>
				</div>
				<div class="filter">
					<div class="pairs">
						
						<!-- PROGRAM -->
						<div class="pair">
							<h3>Program</h3>
							<select name="program">
								<option value="" disabled selected hidden>Select a program</option>
								@if(array_key_exists('program', $sort_filters))
								@foreach($programs as $program)
									<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
								@endforeach
								@else
								@foreach($programs as $program)
									<option value="{{ $program->id }}">{{ $program->code }}</option>
								@endforeach
								@endif
							</select>
						</div>

						<!-- ITEMS PER PAGE -->
						<div class="pair">
							<h3>Items Per Page</h3>
							<select name="items">
								@if(array_key_exists('items', $sort_filters))
									<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
									<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
									<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
									<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
								@else
									<option value="10" selected>10</option>
									<option value="25">25</option>
									<option value="50">50</option>
									<option value="100">100</option>
								@endif
							</select>
						</div>
						<div class="pair">
							<button type="button" class="clear" onclick="resetAll()">Reset</button>
							<input type="submit" value="Submit">
						</div>
					</div>
				</div>
			</form>
		</div>
		@if(!$scholars->isEmpty())
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Award Number</th>
					<th>Period Started</th>
					<th>Period Graduated</th>
				</tr>
			</thead>
			<tbody>
				@foreach($scholars as $key => $scholar)
					<tr>
						<td>{{ $key + $scholars->firstItem() }}</td>
						<td>{{ $scholar->applicant->full_name }}</td>
						<td>{{ $scholar->award_number }}</td>
						<td>A.Y. {{ $scholar->acad_year_accepted }}, {{ $scholar->semester_accepted == 1 ? '1st' : '2nd' }} Sem</td>
						<td>A.Y. {{ $scholar->latest_acad_year }}, {{ $scholar->latest_semester == 1 ? '1st' : '2nd' }} Sem</td>
					</tr>
				@endforeach
			</tbody>
		</table>
		@if($scholars->total() > 10)
		<div class="pagination">
			<div class="previous">{{ $scholars->appends($sort_filters)->links() }}</div>
		</div>
		@endif
		@else
		<center><p class="bold">No Scholars Found</p></center>
		@endif
	</div>
</section>
@endsection