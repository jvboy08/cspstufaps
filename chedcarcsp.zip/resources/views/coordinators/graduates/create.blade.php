@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Graduates
@endsection

@section('content')
<section class="scholar_body">
	<div class="box">
        <div class="head">
	        <h3 class="bold">Add Graduates</h3>
	        <div class="pair_space">
				<a href="/coordinator/graduates/pending" class="add yellow_btn">View Pending</a>
				<a class="add grey_btn" href="/coordinator/graduates">Go back</a>
	        </div>
        </div>
		<div class="functions">
			<form action="/coordinator/graduates/create" method="GET">
				<div class="filter">
					<div class="pairs">

						<!-- SEARCH -->
						<div class="pair">
							<h3>Search By Name</h3>
							@if(array_key_exists('name', $sort_filters))
							<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
							@else						
							<input type="text" name="name" placeholder="Enter last or first name" id="name">
							@endif
						</div>

						<!-- SORT BY -->
						<div class="pair">
							<h3>Sort By</h3>
							<select name="sort">
								@if(array_key_exists('sort', $sort_filters))
									<option value="year_level" {{ $sort_filters['sort'] == 'year_level' ? 'selected' : ''}}>Year Level - Descending</option>
									<option value="alphabetical" {{ $sort_filters['sort'] == 'alphabetical' ? 'selected' : ''}}>Alphabetical</option>
								@else
									<option value="year_level" selected>Year Level - Descending</option>
									<option value="alphabetical">Alphabetical</option>
								@endif
							</select>
						</div>
					</div>
					<div class="filter">
						<div class="pairs">
							<div class="pair">
								<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
							</div>	
						</div>
					</div>
				</div>
				<div class="filter">
					<div class="pairs">

						<!-- ACADEMIC PERIOD STARTED-->
						<div class="pair">
							<h3>Period Started</h3>
							<select name="started">
								<option value="" disabled selected hidden>Select an academic period</option>
								@if(array_key_exists('started', $sort_filters))
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @else
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @endif
							</select>
						</div>

						<!-- LATEST ACADEMIC PERIOD -->
						<div class="pair">
							<h3>Latest Period</h3>
							<select name="period">
								<option value="" disabled selected hidden>Select an academic period</option>
								@if(array_key_exists('period', $sort_filters))
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @else
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @endif
							</select>
						</div>
						
						<!-- PROGRAM -->
						<div class="pair">
							<h3>Program</h3>
							<select name="program">
								<option value="" disabled selected hidden>Select a program</option>
								@if(array_key_exists('program', $sort_filters))
								@foreach($programs as $program)
									<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
								@endforeach
								@else
								@foreach($programs as $program)
									<option value="{{ $program->id }}">{{ $program->code }}</option>
								@endforeach
								@endif
							</select>
						</div>

						<!-- YEAR LEVEL -->
						<div class="pair">
							<h3>Year Level</h3>
							<select name="year_level">
								<option value="" disabled selected hidden>Select a year level</option>
								@if(array_key_exists('year_level', $sort_filters))
									<option value="1" {{ $sort_filters['year_level'] == '1' ? 'selected' : ''}}>1</option>
									<option value="2" {{ $sort_filters['year_level'] == '2' ? 'selected' : ''}}>2</option>
									<option value="3" {{ $sort_filters['year_level'] == '3' ? 'selected' : ''}}>3</option>
									<option value="4" {{ $sort_filters['year_level'] == '4' ? 'selected' : ''}}>4</option>
									<option value="5" {{ $sort_filters['year_level'] == '5' ? 'selected' : ''}}>5</option>
									<option value="6" {{ $sort_filters['year_level'] == '6' ? 'selected' : ''}}>6</option>
								@else
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
								@endif
							</select>
						</div>

						<!-- ITEMS PER PAGE -->
						<div class="pair">
							<h3>Items Per Page</h3>
							<select name="items">
								@if(array_key_exists('items', $sort_filters))
									<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
									<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
									<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
									<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
								@else
									<option value="10" selected>10</option>
									<option value="25">25</option>
									<option value="50">50</option>
									<option value="100">100</option>
								@endif
							</select>
						</div>
						<div class="pair">
							<button type="button" class="clear" onclick="resetAll()">Reset</button>
							<input type="submit" value="Submit">
						</div>
					</div>
				</div>
			</form>
		</div>
		@if(!$applicants->isEmpty())
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Award Number</th>
					<th>Period Started</th>
					<th>Latest Period</th>
					<th>Year Level</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($applicants as $key => $applicant)
					<tr>
						<td>{{ $key + $applicants->firstItem() }}</td>
						<td>{{ $applicant->full_name }}</td>
						<td>{{ $applicant->scholar->award_number }}</td>
						<td>A.Y. {{ $applicant->scholar->acad_year_accepted }}, {{ $applicant->scholar->semester_accepted == 1 ? '1st' : '2nd' }} Sem</td>
						<td>A.Y. {{ $applicant->scholar->latest_acad_year }}, {{ $applicant->scholar->latest_semester == 1 ? '1st' : '2nd' }} Sem</td>
						<td>{{ $applicant->scholar->full_latest_year_level }}</td>
						<td class="settings">
							<a class="option" onclick="show_form({{ $applicant->scholar->id }})">
							<div><span class="material-icons-round">school</span><p>Add to Graduates</p></div>
							</a>
				        	<div id="num{{ $applicant->scholar->id }}" class="graduate_container">
								<div class="graduate_content">
									<form class="scholar_form" method="POST" action="/coordinator/graduates/{{ $applicant->scholar->id }}">
										@csrf
										<h3 class="bold">{{ $applicant->full_name }}</h3>
										<div class="pair_input">
								          <p>Remarks <span class="italic">(Optional)</span>:</p>
								          <input type="text" name="remarks_{{ $applicant->scholar->id }}" placeholder="E.g. Cum Laude">
								        </div>
								        <input type="submit" value="Add to Graduates">
										<span class="material-icons-round close" onclick="hide_form('{{ $applicant->scholar->id }}')">close</span>
									</form>
								</div>
							</div>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
		@if($applicants->total() > 10)
		<div class="pagination">
			<div class="previous">{{ $applicants->appends($sort_filters)->links() }}</div>
		</div>
		@endif
		@else
		<center><p class="bold">No Active Scholars Found</p></center>
		@endif
	</div>
</section>
<script>
	function show_form(num) {
		document.querySelector("#num" + num).style.display = "flex";
	}

	function hide_form(num) {
		document.querySelector("#num" + num).style.display = "none";
	}
</script>
@endsection