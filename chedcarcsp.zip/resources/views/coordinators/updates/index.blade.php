@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Updates
@endsection

@section('content')
<section class="scholar_body">
	<div class="box">
		<div class="head">
			<div class="title">
				<span class="icon material-icons-round">update</span>
				<p class="bold">Scholar Information Updates</p>
				<div class="info_button" onclick="show(1)"><span class="material-icons-round">help</span></div>
	        	<div id="info1" class="info_container" onclick="hide(1)">
					<div class="info_content">
						<span class="material-icons-round help">help</span>
						<p style="text-align: left;">Information of the scholars can be updated through the Scholars page which will<br>be validated by CHED-CAR first. This section shows the updates that you and your<br>co-coordinators have made and their status if they have been approved.</p>
						<span class="material-icons-round close" onclick="hide(1)">close</span>
					</div>
				</div>
			</div>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
		<div class="functions">
			<form action="/coordinator/updates" method="GET">
				<div class="filter">
					<div class="pairs">

						<!-- SEARCH -->
						<div class="pair">
							<h3>Search By Name</h3>
							@if(array_key_exists('name', $sort_filters))
							<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
							@else						
							<input type="text" name="name" placeholder="Enter last or first name" id="name">
							@endif
						</div>

						<!-- STATUS -->
						<div class="pair">
							<h3>Status</h3>
							<select name="status">
								@if(array_key_exists('status', $sort_filters))
									<option value="pending" {{ $sort_filters['status'] == 'pending' ? 'selected' : ''}}>Pending</option>
									<option value="approved" {{ $sort_filters['status'] == 'approved' ? 'selected' : ''}}>Approved</option>
									<option value="declined" {{ $sort_filters['status'] == 'declined' ? 'selected' : ''}}>Declined</option>
								@else
									<option value="pending">Pending</option>
									<option value="approved">Approved</option>
									<option value="declined">Declined</option>
								@endif
							</select>
						</div>

						<!-- LABEL -->
						<div class="pair">
							<h3>Label</h3>
							<select name="label">
								<option value="" disabled selected hidden>Select a label</option>
								@if(array_key_exists('label', $sort_filters))
									<option value="institution_id" {{ $sort_filters['label'] == 'institution_id' ? 'selected' : ''}}>Institution</option>
									<option value="course_id" {{ $sort_filters['label'] == 'course_id' ? 'selected' : ''}}>Degree Program</option>
									<option value="latest_year_level" {{ $sort_filters['label'] == 'latest_year_level' ? 'selected' : ''}}>Current Year Level</option>
									<option value="email_address" {{ $sort_filters['label'] == 'email_address' ? 'selected' : ''}}>Email Address</option>
									<option value="contact_number" {{ $sort_filters['label'] == 'contact_number' ? 'selected' : ''}}>Contact Number</option>
									<option value="fb_account" {{ $sort_filters['label'] == 'fb_account' ? 'selected' : ''}}>Facebook Account</option>
									<option value="address" {{ $sort_filters['label'] == 'address' ? 'selected' : ''}}>Address</option>
								@else
									<option value="institution_id">Institution</option>
									<option value="course_id">Degree Program</option>
									<option value="latest_year_level">Current Year Level</option>
									<option value="email_address">Email Address</option>
									<option value="contact_number">Contact Number</option>
									<option value="fb_account">Facebook Account</option>
									<option value="address">Address</option>
								@endif
							</select>
						</div>
					</div>
				</div>
				<div class="filter">
					<div class="pairs">
						<!-- PROGRAM -->
						<div class="pair">
							<h3>Program</h3>
							<select name="program">
								<option value="" disabled selected hidden>Select a program</option>
								@if(array_key_exists('program', $sort_filters))
								@foreach($programs as $program)
									<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
								@endforeach
								@else
								@foreach($programs as $program)
									<option value="{{ $program->id }}">{{ $program->code }}</option>
								@endforeach
								@endif
							</select>
						</div>

						<!-- ITEMS PER PAGE -->
						<div class="pair">
							<h3>Items Per Page</h3>
							<select name="items">
								@if(array_key_exists('items', $sort_filters))
									<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
									<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
									<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
									<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
								@else
									<option value="10" selected>10</option>
									<option value="25">25</option>
									<option value="50">50</option>
									<option value="100">100</option>
								@endif
							</select>
						</div>

						
						<div class="pair">
							<button type="button" class="clear" onclick="resetAll()">Reset</button>
							<input type="submit" value="Submit">
						</div>
					</div>
				</div>
			</form>
		</div>
		@if(!$updates->isEmpty())
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Scholar</th>
					<th>Label</th>
					<th>Previous Value</th>
					<th>New Value</th>
					<th>Status</th>
					@if(!array_key_exists('status', $sort_filters) || (array_key_exists('status', $sort_filters) && $sort_filters['status'] == 'pending'))
					<th>Settings</th>
					@endif
				</tr>
			</thead>
			<tbody>
				@foreach($updates as $key => $update)
				<tr>
					<td>{{ $key + $updates->firstItem() }}</td>
					<td style="white-space: nowrap;">{{ $update->applicant->full_name }}</td>
					<td style="white-space: nowrap;">{{ $update->full_field }}</td>
					@if($update->field == 'email_address')
					<td style="word-break: break-all;">{{ $update->full_old_value }}</td>
					<td style="word-break: break-all;">{{ $update->full_new_value }}</td>
					@elseif($update->field == 'contact_number')
					<td>{{ substr($update->old_value, 0, 4).'-'.substr($update->old_value, 4, 3).'-'.substr($update->old_value, 7, 4) }}</td>
					<td>{{ substr($update->new_value, 0, 4).'-'.substr($update->new_value, 4, 3).'-'.substr($update->new_value, 7, 4) }}</td>
					@elseif($update->field == 'address')
					<td><span class="italic">Permanent: </span>{{ $update->old_permanent_address }}<br><br><span class="italic">Present: </span>{{ $update->old_present_address }}</td>
					<td><span class="italic">Permanent: </span>{{ $update->new_permanent_address }}<br><br><span class="italic">Present: </span>{{ $update->new_present_address }}</td>
					@else
					<td>{{ $update->full_old_value }}</td>
					<td>{{ $update->full_new_value }}</td>
					@endif
					<td><p class="table_status">{{ $update->is_approved == null ? 'Pending' : ($update->is_approved == 1 ? 'Approved' : 'Declined') }}</p></td>
					@if(!array_key_exists('status', $sort_filters) || (array_key_exists('status', $sort_filters) && $sort_filters['status'] == 'pending'))
					<td>
						@if(!$update->is_approved)
						<a class="option" href="/coordinator/updates/cancel/{{ $update->id }}" onclick="return confirm('Are you sure you want to cancel this update?')"><div><span class="material-icons-round">cancel</span><p>Cancel</p></div></a>
						@endif
					</td>
					@endif
				</tr>
				@endforeach
			</tbody>
		</table>
		@if($updates->total() > 10)
		<div class="pagination">
			<div class="previous">{{ $updates->links() }}</div>
		</div>
		@endif
		@else
		<center><p class="bold">No Updates Found</p></center>
		@endif
	</div>
</section>
@endsection