@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Edit HEI 
@endsection

@section('content')
<section class="scholar_form">
	<section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/password/change">
        @method('PUT')
        @csrf
        @include('layouts.errors_no_icon')
        <div class="head">
          <h2 class="bold">Change Password</h2>
          <a class="add yellow_btn" href="/coordinator/home">Back</a>
        </div>

        <div class="pair_input">
          <p>Email Address :</p>
          <input type="email" name="email" placeholder="Enter email address" required>
        </div>

        <div class="pair_input">
          <p>Old Password :</p>
          <input type="password" name="old_password" placeholder="Enter old password" required>
        </div>

        <div class="pair_input">
          <p>New Password :</p>
          <input type="password" name="new_password" placeholder="Minimum of 8 characters" required>
        </div>

        <div class="pair_input">
          <p>Confirm Password :</p>
          <input type="password" name="confirm_password" placeholder="Confirm new password" required>
        </div>

        <input type="submit" value="Change Password">
      </form>
    </div>
  </section> 
</section>
@endsection