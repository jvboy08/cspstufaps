@extends('layouts.master_unregistered')

@section('title')
CHED-CAR | Coordinator
@endsection

@section('content')
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/sign_up">
        @csrf
        <h1>Sign Up as Coordinator</h1>
        @include('layouts.errors_no_icon')
        <input type="email" name="email" placeholder="Email address" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <h6>Please enter the verification code provided by the CHED-CAR staff. If you haven't received it yet, please contact the CHED-CAR staff.</h6>
        <input type="text" name="verification_code" placeholder="Verification Code" required>
        <input type="submit" value="Sign Up">
        <a href="/coordinator/login"><p>Already have an account? <span class="bold">Log In</span></p></a>
      </form>
    </div>
  </section>
@endsection