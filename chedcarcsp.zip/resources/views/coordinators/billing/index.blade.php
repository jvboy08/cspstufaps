@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Billing
@endsection

@section('content')
<section class="scholar_body">
	<div class="box">
		<div class="head">
			<div class="title">
				<span class="icon material-icons-round">payments</span>
				<p class="bold">Billing Statements</p>
				<div class="info_button" onclick="show(3)"><span class="material-icons-round">help</span></div>
	        	<div id="info3" class="info_container" onclick="hide(3)">
					<div class="info_content">
						<span class="material-icons-round help">help</span>
						<p style="text-align: left;">Every semester, the details of the scholars in each program will be entered here to<br>generate billing statements. After a generated billing statement has been signed by the<br>organization heads, the file will be uploaded to be reviewed by CHED-CAR.</p>
						<span class="material-icons-round close" onclick="hide(3)">close</span>
					</div>
				</div>
			</div>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
		<table>
			<thead>
				<tr>
					<th>Academic Period</th>
					@foreach($programs_distinct as $program)
					<th>{{ $program->code }}</th>
					@endforeach
				</tr>
			</thead>
			<tbody>
				@for($i = 0; $i < $count; $i++)
					<tr>
						<td style="white-space: nowrap;">A.Y. {{ 2021 + (floor($i/2)) }}, {{ $i % 2 != 0 ? '2nd' : '1st' }} Sem</td>
						@foreach($programs_distinct as $key => $program)
						<td class="settings">
							@if($counts[$i][$key][0] == 0)
							N/A
							@else
							<div class="pair_space_vertical">
								<div class="pair_no_space">
									<a class="option" href="/coordinator/billing/{{ $program->id }}/{{ 2021 + (floor($i/2)) }}/{{ $i % 2 != 0 ? 2 : 1 }}/edit">
									<div><span class="material-icons-round {{ $counts[$i][$key][1] == $counts[$i][$key][0] ? 'completed' : '' }}">format_list_bulleted</span><p>{{ $counts[$i][$key][1] }}/{{ $counts[$i][$key][0] }}</p></div>
									</a>
									<p class="check pair_no_space"><span class="material-icons-round {{ $counts[$i][$key][1] == $counts[$i][$key][0] ? 'active' : '' }}">check_circle</span></p>
								</div>
								@if($billing_statements[$i][$key] == null)
									@if($counts[$i][$key][1] == $counts[$i][$key][0])
									<a class="option" href="/coordinator/billing/document/{{ $program->id }}/{{ 2021 + (floor($i/2)) }}/{{ $i % 2 != 0 ? 2 : 1 }}">
									<div><span class="material-icons-round">file_upload</span><p>Upload</p></div>
									</a>
									@else
									<a class="option inactive" onclick="alert('Please complete the details of the scholars first.')">
									<div><span class="material-icons-round">file_upload</span><p>Upload</p></div>
									</a>
									@endif
								@else
								<!-- <a class="option" href="ms-excel:ofe|u|{{ $billing_statements[$i][$key]->path }}" target="_blank">
								<div><span class="material-icons-round">launch</span><p>Launch</p></div>
								</a> -->
								<a class="option" href="/coordinator/billing/document/{{ $billing_statements[$i][$key]->id }}/edit">
								<div><span class="material-icons-round">create</span><p>Update</p></div>
								</a>
								@endif
								</div>
							@endif
						</td>
						@endforeach
					</tr>
				@endfor
			</tbody>
		</table>
	</div>
</section>
@endsection