@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Billing
@endsection

@section('content')
<section class="scholar_body">
	<form method="POST" id="form" class="billing_statement_form" action="/coordinator/billing/{{ $program->id }}/{{ $acad_year }}/{{ $semester }}"> 
	@method('PUT') 
	@csrf 
	<div class="box">
        <div class="head">
	        <h3 class="bold">Edit Billing Statement for {{ $program->code }} Scholars (A.Y. {{ $acad_year }}-{{ $acad_year + 1 }}, {{ $semester == 1 ? '1st' : '2nd' }} Semester)</h3>
	        <div class="pair_space">
				<a class="add grey_btn" href="/coordinator/billing">Go back</a>
	        </div>
        </div>
        <div class="info">
        	<p class="italic">Place "NA" to entries that are not applicable or available except for the "Coordinator Remarks" column which you may leave blank.</p>
        </div>
		<div class="table billing_statement">
			<table id="table">
				<thead>
					<tr>
						<th>Award Number</th>
						<th>Full Name</th>
						<th>Year Level</th>
						<th>Prev. GWA</th>
						<th>Units<br>Enrolled</th>
						<th>Tuition Fee</th>
						<th>Coordinator Remarks</th>
						<th>Done</th>
					</tr>
				</thead>
				<tbody>
					@foreach($scholars as $key => $scholar)
					<tr>
						<td style="white-space: nowrap;">{{ $scholar->award_number }}</td>
						<td style="white-space: nowrap;">{{ $scholar->applicant->full_name }}</td>
						@if($semestral_awards[$key] == null)
						<td><input class="required" type="number" name="current_year_level_{{ $key }}" value="{{ $semester == 1 ? $scholar->latest_year_level + 1 : $scholar->latest_year_level }}"></td>
						@else
						<td><input class="required" type="number" name="current_year_level_{{ $key }}" value="{{ $semestral_awards[$key]->current_year_level }}"></td>
						@endif
						<td><input class="required" type="text" name="previous_gwa_{{ $key }}" value="{{ $semestral_awards[$key] == null ? '' : $semestral_awards[$key]->previous_gwa }}" data-parsley-trigger="focusin focusout" data-parsley-validate-number=""></td>
						<td><input class="required {{ $semestral_awards[$key] != null && $semestral_awards[$key]->enrollment_status == '0' ? 'disabled' : '' }}" type="text" name="units_enrolled_{{ $key }}" value="{{ $semestral_awards[$key] == null ? '' : $semestral_awards[$key]->units_enrolled }}" data-parsley-trigger="focusin focusout" data-parsley-validate-number="" {{ $semestral_awards[$key] != null && $semestral_awards[$key]->enrollment_status == '0' ? 'disabled' : '' }}></td>
						<td><input class="required {{ $semestral_awards[$key] != null && $semestral_awards[$key]->enrollment_status == '0' ? 'disabled' : '' }}" type="text" name="tuition_fee_{{ $key }}" value="{{ $semestral_awards[$key] == null ? '' : $semestral_awards[$key]->tuition_fee }}" data-parsley-trigger="focusin focusout" data-parsley-validate-number="" {{ $semestral_awards[$key] != null && $semestral_awards[$key]->enrollment_status == '0' ? 'disabled' : '' }}></td>
						<td><input type="text" name="remarks_{{ $key }}" value="{{ $semestral_awards[$key] == null ? '' : $semestral_awards[$key]->remarks_coordinator }}"></td>
						<td class="check"><span class="material-icons-round {{ $semestral_awards[$key] != null && $semestral_awards[$key]->current_year_level != null && $semestral_awards[$key]->previous_gwa != null && $semestral_awards[$key]->units_enrolled != null && $semestral_awards[$key]->tuition_fee != null ? 'active' : '' }}">check_circle</span></td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
        <div class="head">
	        <div></div>
	        <div class="pair_space">
	        	<div class="info_button" onclick="show(1)"><span class="material-icons-round">help</span></div>
	        	<div id="info1" class="info_container" onclick="hide(1)">
					<div class="info_content">
						<span class="material-icons-round help">help</span>
						<p style="text-align: left;">Saving a billing statement will store the details and allow editing again<br>at another time. Generating a billing statement will display a preview<br>of the billing statement which can be downloaded as an excel file.</p>
						<span id="close1" class="material-icons-round close" onclick="hide(1)">close</span>
					</div>
				</div>
		        <button type="button" class="add save">Save Billing Statement</button>
		        <button type="button" class="add generate">Generate Billing Statement</button>
		        <input type="hidden" id="action" name="action" value="">
	        </div>
        </div>
	</div>
	</form>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js" integrity="sha512-eyHL1atYNycXNXZMDndxrDhNAegH2BDWt1TmkXJPoGf1WLlNYt08CSjkqF5lnCRmdm3IrkHid8s2jOUY4NIZVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="text/javascript">
	window.Parsley.addValidator('validateNumber', {
		validateString: function(value) {
			if (/^\d+$/.test(value)) {
				return true;
			} else if (/^((NA))$/.test(value)) {
				return true;
			} else {
				return false;
			}
		},
		messages: {
			en: 'Invalid'
		}
	});

	$('input.required').each(function() {
		$(this).bind('change', function() {
			var tr = $(this).parent().parent();
			var is_complete = true;
			tr.find('input.required').each(function() {
			   var element = $(this);
			   if (element.val() == '') {
			       is_complete = false;
			   }
			});
			if(is_complete) {
				tr.find('span').addClass('active');
			} else {
				tr.find('span').removeClass('active');
			}
		});
    });

	$('.save').on('click', function() {
		$('#form').parsley().whenValidate({
			group: 'block'
		}).done(function() {
			$('#action').val('save');
			$('#form').submit();
		});
	});

	$('.billing_statement_form').find(':input').attr('data-parsley-group', 'block');

	$('.generate').on('click', function() {
		var is_org_complete = {!! $is_org_complete !!};
		if(is_org_complete) {
			$('#action').val('generate');
			$('#form').submit();
		} else {
			alert('Please provide the organization heads of your institution in the homepage first.');
		}
	});
</script>
@endsection