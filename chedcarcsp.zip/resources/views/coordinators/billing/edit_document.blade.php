@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Scholar | Billing
@endsection

@section('content')
<section class="scholar_form">
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/billing/document/{{ $billing_statement->id }}" enctype="multipart/form-data">
        @method('PUT')
        @csrf
        <div class="head">
          <h2 class="bold">Update Billing Statement</h2>
          <a class="add grey_btn" href="/coordinator/billing">Back</a>
        </div>
        <div class="pair_input">
          <p>{{ $billing_statement->program->code }} (A.Y. {{ $billing_statement->acad_year }}, {{ $billing_statement->semester == 1 ? '1st' : '2nd' }} Sem) :</p>
          <input type="file" name="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required>
        </div>
        <input type="submit" value="Submit">
      </form>
    </div>
  </section> 
</section>
@endsection