@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Scholar | Billing
@endsection

@section('content')
<section class="scholar_form">
	<section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/billing/document/{{ $program->id }}/{{ $acad_year }}/{{ $semester }}" enctype="multipart/form-data">
        @csrf
        <div class="head">
          <h2 class="bold">Upload Billing Statement</h2>
          <a class="add grey_btn" href="/coordinator/billing">Back</a>
        </div>
        <div class="pair_input">
          <p>{{ $program->code }} (A.Y. {{ $acad_year }}, {{ $semester == 1 ? '1st' : '2nd' }} Sem) :</p>
          <input type="file" name="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required>
        </div>
        <input type="submit" value="Submit">
      </form>
    </div>
  </section> 
</section>
@endsection