@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Billing
@endsection

@section('content')
<section class="scholar_body">
	<div class="box" id="report">
        <div class="head">
	        <div></div>
	        <div class="pair_space">
	        	<button class="add" onclick="exportTableToExcel('table', 'Billing Statement for {{ $program->code }} Scholars (AY {{ $acad_year }}, Sem {{ $semester }})')">Download as Excel File</button>
				<a class="add grey_btn" href="/coordinator/billing/{{ $program->id }}/{{ $acad_year }}/{{ $semester }}/edit">Go back</a>
	        </div>
        </div>
		<div class="table billing_statement_preview">
			<table id="table" class="table" style="border: 1px solid black; border-collapse: collapse;">
				<tbody>
					<tr><td colspan="13" style="font-weight: bold; text-align: center; border: thin solid rgb(192, 192, 192);">CERTIFIED LIST OF SCHOLARS {{ strtoupper($program->code) }} PROGRAM FOR PAYMENT</td></tr>
					<tr><td colspan="13" style="font-weight: bold; text-align: center; border: thin solid rgb(192, 192, 192);">CHED-CAR</td></tr>
					<tr><td colspan="13" style="font-weight: bold; text-align: center; border: thin solid rgb(192, 192, 192);">{{ $semester == 1 ? '1st' : '2nd' }} Semester, AY {{ $acad_year }}-{{ $acad_year + 1 }}</td></tr>
					<tr><td colspan="13" style="border: thin solid rgb(192, 192, 192);"><div class="empty"></div></td></tr>
					<tr>
						<td style="border: thin solid rgb(192, 192, 192);">School:</td>
						<td colspan="12" style="border: thin solid rgb(192, 192, 192);">{{ $institution->institution_name }}</td>
					</tr>
					<tr>
						<td style="border: thin solid rgb(192, 192, 192);">Address:</td>
						<td colspan="12" style="border: thin solid rgb(192, 192, 192);">{{ $institution->address }}</td>
					</tr>
					<tr>
						<td style="border: thin solid rgb(192, 192, 192);">Date:</td>
						<td colspan="12" style="border: thin solid rgb(192, 192, 192);">{{ date('F d, Y', strtotime(now())) }}</td>
					</tr>
					<tr><td colspan="13" style="border: thin solid rgb(192, 192, 192); border-bottom: thin solid rgb(0, 0, 0);"><div class="empty"></div></td></tr>
					<tr>
						<td rowspan="2" style="font-weight: bold; text-align: center; border: thin solid rgb(0, 0, 0); vertical-align: middle;">SEQ</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">AWARD NUMBER</td>
						<td colspan="3" style="font-weight: bold; text-align: center; border: thin solid rgb(0, 0, 0);">NAME</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">SEX</td>
						<td rowspan="2" style="font-weight: bold; text-align: center; border: thin solid rgb(0, 0, 0); vertical-align: middle;">COURSE</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">CURR. LEVEL</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">PREVIOUS GWA</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">NO. OF UNITS</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">TOTAL TUITION</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">AMOUNT TO BE PAID BY CHED</td>
						<td rowspan="2" style="font-weight: bold; border: thin solid rgb(0, 0, 0); vertical-align: middle;">REMARKS</td>
					</tr>
					<tr>
						<td style="font-weight: bold; text-align: center; border: thin solid rgb(0, 0, 0);">LAST</td>
						<td style="font-weight: bold; text-align: center; border: thin solid rgb(0, 0, 0);">FIRST</td>
						<td style="font-weight: bold; text-align: center; border: thin solid rgb(0, 0, 0);">MIDDLE</td>
					</tr>
					@foreach($scholars as $key => $scholar)
					<tr>
						<td style="text-align: center; border: thin solid rgb(0, 0, 0); vertical-align: middle;">{{ $key + 1 }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle;">{{ $scholar->award_number }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle;">{{ $scholar->applicant->name_last }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle;">{{ $scholar->applicant->name_first }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle;">{{ $scholar->applicant->name_middle }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle; text-align: center;">{{ $scholar->applicant->sex }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle; white-space: nowrap; width: 100%;">{{ $scholar->applicant->course->course_name }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle; text-align: center;">{{ $semestral_awards[$key]->current_year_level }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle; text-align: center;">{{ $semestral_awards[$key]->previous_gwa }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle; text-align: center;">{{ $semestral_awards[$key]->units_enrolled }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle; text-align: center;">{{ $semestral_awards[$key]->tuition_fee }}</td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle; text-align: center;"></td>
						<td style="border: thin solid rgb(0, 0, 0); vertical-align: middle;">{{ $semestral_awards[$key]->remarks_coordinator }}</td>
					</tr>
					@endforeach
					<tr>
						<td colspan="10" style="border: thin solid rgb(192, 192, 192);"></td>
						<td style="font-weight: bold; border: thin solid rgb(192, 192, 192); text-align: right;">TOTAL :</td>
						<td style="border: thin solid rgb(192, 192, 192); border-bottom: thin solid rgb(0, 0, 0); text-align: left;"></td>
						<td style="border: thin solid rgb(192, 192, 192);"></td>
					</tr>
					<tr><td colspan="13" style="border: thin solid rgb(192, 192, 192);"><div class="empty"></div></td></tr>
					<tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192);"></td>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192);">Certified correct that the scholars maintained the required GWA.</td>
						<td colspan="3" style="border: thin solid rgb(192, 192, 192);"></td>
					</tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192);"><div class="empty"></div></td>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192);"><div class="empty"></div></td>
						<td colspan="3" style="border: thin solid rgb(192, 192, 192);"><div class="empty"></div></td>
					<tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192);">Prepared by:</td>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192);">Certified correct by:</td>
						<td colspan="3" style="border: thin solid rgb(192, 192, 192);">Approved by:</td>
					</tr>
					<tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192); height: 60pt;"><div class="empty"></div></td>
						<td colspan="2" style="border: thin solid rgb(192, 192, 192); height: 60pt;"><div class="empty"></div></td>
						<td colspan="3" style="border: thin solid rgb(192, 192, 192); height: 60pt;"><div class="empty"></div></td>
						<td colspan="3" style="border: thin solid rgb(192, 192, 192); height: 60pt;"><div class="empty"></div></td>
					</tr>
					<tr>
						<td colspan="5" style="font-weight: bold; border: thin solid rgb(192, 192, 192); text-align: center;">{{ strtoupper($head_coordinator->name) }}</td>
						<td colspan="2" style="font-weight: bold; border: thin solid rgb(192, 192, 192); text-align: center;">{{ strtoupper($institution->registrar) }}</td>
						<td colspan="3" style="font-weight: bold; border: thin solid rgb(192, 192, 192); text-align: center;">{{ strtoupper($institution->accountant) }}</td>
						<td colspan="3" style="font-weight: bold; border: thin solid rgb(192, 192, 192); text-align: center;">{{ strtoupper($institution->institution_head) }}</td>
					</tr>
					<tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192); text-align: center;">Scholarship Coordinator</td>
						<td colspan="2" style="border: thin solid rgb(192, 192, 192); text-align: center;">University Registrar </td>
						<td colspan="3" style="border: thin solid rgb(192, 192, 192); text-align: center;">Chief Accountant</td>
						<td colspan="3" style="border: thin solid rgb(192, 192, 192); text-align: center;">University President</td>
					</tr>
					<tr><td colspan="13" style="border: thin solid rgb(192, 192, 192);"><div class="empty"></div></td></tr>
					<tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192);">Reviewed by:</td>
						<td colspan="8" style="border: thin solid rgb(192, 192, 192);"></td>
					</tr>
					<tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192); height: 60pt;"><div class="empty"></div></td>
						<td colspan="8" style="border: thin solid rgb(192, 192, 192);"><div class="empty"></div></td>
					</tr>
					<tr>
						<td colspan="5" style="font-weight: bold;border: thin solid rgb(192, 192, 192); text-align: center;">CHRISTINE M. SORIANO</td>
						<td colspan="8" style="border: thin solid rgb(192, 192, 192);"></td>
					</tr>
					<tr>
						<td colspan="5" style="border: thin solid rgb(192, 192, 192); text-align: center;">ES II/Scholarship Coordinator</td>
						<td colspan="8" style="border: thin solid rgb(192, 192, 192);"></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</section>

<script type="text/javascript">
	function exportTableToExcel(tableID, filename = ''){
	    var downloadLink;
	    var dataType = 'application/vnd.ms-excel';
	    var tableSelect = document.getElementById(tableID);
	    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
	    
	    filename = filename ? filename + '.xls' : 'excel_data.xls';
	    
	    downloadLink = document.createElement("a");
	    
	    document.body.appendChild(downloadLink);
	    
	    if(navigator.msSaveOrOpenBlob){
	        var blob = new Blob(['\ufeff', tableHTML], {
	            type: dataType
	        });
	        navigator.msSaveOrOpenBlob(blob, filename);
	    }else{
	        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
	        downloadLink.download = filename;
	        downloadLink.click();
	    }
	}
</script>
@endsection