@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Coordinators
@endsection

@section('content')
<section class="scholar_body">
	<div class="box">
		<div class="head">
			<div class="title">
				<span class="icon material-icons-round">manage_accounts</span>
				<p class="bold">Scholarship Coordinators</p>
				<div class="info_button" onclick="show(1)"><span class="material-icons-round">help</span></div>
	        	<div id="info1" class="info_container" onclick="hide(1)">
					<div class="info_content">
						<span class="material-icons-round help">help</span>
						<p style="text-align: left;">Only head coordinators can add and remove accounts of other coordinators.<br>If the head coordinator made an assistant coordinator a head coordinator,<br>the originally head coordinator will become the assistant coordinator.</p>
						<span class="material-icons-round close" onclick="hide(1)">close</span>
					</div>
				</div>
			</div>
			<div class="pair_no_space">
				@if(auth()->user()->coordinator_role == 'head')
				<a href="/coordinator/coordinators/create" class="add yellow_btn">Add a Coordinator</a>
				@endif
				<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
			</div>

		</div>
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Email Address</th>
					<th>Position</th>
					@if(auth()->user()->coordinator_role == 'head')
					<th style="white-space: nowrap;">Settings</th>
					@endif
				</tr>
			</thead>
			<tbody>
				@foreach($coordinators as $key => $coordinator)
					<tr>
						<td>{{ $key + 1 }}</td>
						<td>{{ $coordinator->name }}</td>
						<td>{{ $coordinator->email }}</td>
						<td>{{ $coordinator->coordinator_role == 'head' ? 'Head' : 'Assistant' }} Coordinator</td>
						@if(auth()->user()->coordinator_role == 'head')
						<td class="settings" style="white-space: nowrap; width: 0.1%">
							@if($coordinator->coordinator_role == 'assistant')
							<a class="option" href="/coordinator/coordinators/{{ $coordinator->id }}/replace"  onclick="return confirm('Are you sure you want to assign this person as the head coordinator?')" >
							<div><span class="material-icons-round" href="/coordinator/{{ $coordinator->id }}/delete">manage_accounts</span><p>Assign as Head Coordinator</p></div>
							</a>
							<a class="option" onclick="return confirm('Are you sure you want to remove this coordinator?')" href="/coordinator/coordinators/{{ $coordinator->id }}/delete">
							<div><span class="material-icons-round">person_remove</span><p>Remove</p></div>
							</a>
							@endif
						</td>
						@endif
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
</section>
@endsection