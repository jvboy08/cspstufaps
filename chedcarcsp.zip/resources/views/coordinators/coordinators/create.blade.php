@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Coordinators
@endsection

@section('content')
<section class="scholar_form">
	<section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/coordinators">
        @csrf
        <div class="head">
          <h2 class="bold">Add a Coordinator</h2>
          <a class="add grey_btn" href="/coordinator/coordinators">Back</a>
        </div>
        @include('layouts.errors_no_icon')

        <!-- FULL NAME -->
        <div class="pair_input">
          <p>Full Name :</p>
          <input type="text" name="name" placeholder="Enter full name" required>
        </div>

        <!-- EMAIL ADDRESS -->
        <div class="pair_input">
          <p>Email Address :</p>
          <input type="email" name="email" placeholder="Enter email address" required>
        </div>

        <!-- PASSWORD -->
        <div class="pair_input">
          <p>Password <span class="italic">(Minimum of 8 characters)</span> :</p>
          <input type="password" name="password" placeholder="Enter password" required>
        </div>

        <!-- CONFIRM PASSWORD -->
        <div class="pair_input">
          <p>Confirm Password :</p>
          <input type="password" name="confirm_password" placeholder="Confirm password" required>
        </div>

        <input type="submit" value="Submit">
      </form>
    </div>
  </section> 
</section>
@endsection