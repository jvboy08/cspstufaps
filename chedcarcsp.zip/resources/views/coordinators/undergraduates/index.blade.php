@extends('layouts.master_registered_coordinator')

@section('title')
CHED-CAR Coordinator | Undergraduates
@endsection

@section('content')
<section class="scholar_body scholar_body2">
	<div class="scholars_nav">
		<a href="" class="active">
			<span class="icon material-icons-round">assignment_ind</span>
			<p class="bold">Undergraduate Scholars</p>
		</a>
		<a href="/coordinator/graduates">
			<span class="icon material-icons-round">school</span>
			<p class="bold">Graduate Scholars</p>
		</a>
	</div>
	<div class="box box2">
		<div class="functions">
			<form action="/coordinator/undergraduates" method="GET">
				<div class="filter">
					<div class="pairs">

						<!-- SEARCH -->
						<div class="pair">
							<h3>Search By Name</h3>
							@if(array_key_exists('name', $sort_filters))
							<input type="text" name="name" placeholder="Enter last or first name" value="{{ $sort_filters['name'] }}" id="name">
							@else						
							<input type="text" name="name" placeholder="Enter last or first name" id="name">
							@endif
						</div>

						<!-- SORT BY -->
						<div class="pair">
							<h3>Sort By</h3>
							<select name="sort">
								@if(array_key_exists('sort', $sort_filters))
									<option value="alphabetical" {{ $sort_filters['sort'] == 'alphabetical' ? 'selected' : ''}}>Alphabetical</option>
									<option value="award_number" {{ $sort_filters['sort'] == 'award_number' ? 'selected' : ''}}>Award Number</option>
								@else
									<option value="alphabetical" selected>Alphabetical</option>
									<option value="award_number">Award Number</option>
								@endif
							</select>
						</div>

						<!-- STATUS -->
						<div class="pair">
							<h3>Latest Status</h3>
							<select name="status">
								@if(array_key_exists('status', $sort_filters))
									<option value="Active" {{ $sort_filters['status'] == 'Active' ? 'selected' : ''}}>Active</option>
									<option value="Deferred" {{ $sort_filters["status"] == "Deferred" ? "selected" : ""}}>Deferred</option>
									<option value="Waived" {{ $sort_filters["status"] == "Waived" ? "selected" : ""}}>Waived</option>
									<option value="Replacement" {{ $sort_filters["status"] == "Replacement" ? "selected" : ""}}>Replacement</option>
									<option value="Replaced" {{ $sort_filters["status"] == "Replaced" ? "selected" : ""}}>Replaced</option>
									<option value="Terminated" {{ $sort_filters["status"] == "Terminated" ? "selected" : ""}}>Terminated</option>
								@else
									<option value="Active" selected>Active</option>
									<option value="Deferred">Deferred</option>
									<option value="Waived">Waived</option>
									<option value="Replacement">Replacement</option>
									<option value="Replaced">Replaced</option>
									<option value="Terminated">Terminated</option>
								@endif
							</select>
						</div>

					</div>
					<div class="filter">
						<div class="pairs">
							<div class="pair">
								<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
							</div>	
						</div>
					</div>
				</div>
				<div class="filter">
					<div class="pairs">

						<!-- ACADEMIC PERIOD STARTED-->
						<div class="pair">
							<h3>Period Started</h3>
							<select name="started">
								<option value="" disabled selected hidden>Select an academic period</option>
								@if(array_key_exists('started', $sort_filters))
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['started'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @else
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @endif
							</select>
						</div>

						<!-- LATEST ACADEMIC PERIOD -->
						<div class="pair">
							<h3>Latest Period</h3>
							<select name="period">
								<option value="" disabled selected hidden>Select an academic period</option>
								@if(array_key_exists('period', $sort_filters))
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}" {{ $i.',1' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}" {{ $i.',2' == $sort_filters['period'] ? 'selected' : '' }}>A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @else
								@for($i = 2016; $i <= now()->year; $i++)
							        <option value="{{$i.',1'}}">A.Y. {{ $i }} - {{ $i+1 }}, 1st Sem</option>
							        <option value="{{$i.',2'}}">A.Y. {{ $i }} - {{ $i+1 }}, 2nd Sem</option>
							    @endfor
							    @endif
							</select>
						</div>
						
						<!-- PROGRAM -->
						<div class="pair">
							<h3>Program</h3>
							<select name="program">
								<option value="" disabled selected hidden>Select a program</option>
								@if(array_key_exists('program', $sort_filters))
								@foreach($programs as $program)
									<option value="{{ $program->id }}" {{ $program->id == $sort_filters['program'] ? 'selected' : '' }}>{{ $program->code }}</option>
								@endforeach
								@else
								@foreach($programs as $program)
									<option value="{{ $program->id }}">{{ $program->code }}</option>
								@endforeach
								@endif
							</select>
						</div>

						<!-- YEAR LEVEL -->
						<div class="pair">
							<h3>Year Level</h3>
							<select name="year_level">
								<option value="" disabled selected hidden>Select a year level</option>
								@if(array_key_exists('year_level', $sort_filters))
									<option value="1" {{ $sort_filters['year_level'] == '1' ? 'selected' : ''}}>1</option>
									<option value="2" {{ $sort_filters['year_level'] == '2' ? 'selected' : ''}}>2</option>
									<option value="3" {{ $sort_filters['year_level'] == '3' ? 'selected' : ''}}>3</option>
									<option value="4" {{ $sort_filters['year_level'] == '4' ? 'selected' : ''}}>4</option>
									<option value="5" {{ $sort_filters['year_level'] == '5' ? 'selected' : ''}}>5</option>
									<option value="6" {{ $sort_filters['year_level'] == '6' ? 'selected' : ''}}>6</option>
								@else
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
								@endif
							</select>
						</div>

						<!-- ITEMS PER PAGE -->
						<div class="pair">
							<h3>Items Per Page</h3>
							<select name="items">
								@if(array_key_exists('items', $sort_filters))
									<option value="10" {{ $sort_filters['items'] == '10' ? 'selected' : ''}}>10</option>
									<option value="25" {{ $sort_filters['items'] == '25' ? 'selected' : ''}}>25</option>
									<option value="50" {{ $sort_filters['items'] == '50' ? 'selected' : ''}}>50</option>
									<option value="100" {{ $sort_filters['items'] == '100' ? 'selected' : ''}}>100</option>
								@else
									<option value="10" selected>10</option>
									<option value="25">25</option>
									<option value="50">50</option>
									<option value="100">100</option>
								@endif
							</select>
						</div>
						<div class="pair">
							<button type="button" class="clear" onclick="resetAll()">Reset</button>
							<input type="submit" value="Submit">
						</div>
					</div>
				</div>
			</form>
		</div>
		@if(!$scholars->isEmpty())
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Award Number</th>
					<th>Period Started</th>
					<th>Latest Period</th>
					<th>Year Level</th>
					<th>Status</th>
					<th>
						<div class="pair_no_space">
							<p class="bold">Settings</p>
							<div class="info_button" onclick="show(4)"><span class="material-icons-round">help</span></div>
				        	<div id="info4" class="info_container" onclick="hide(4)">
								<div class="info_content">
									<span class="material-icons-round help">help</span>
									<p style="text-align: left;">The information of active scholars can be updated through the "Edit" button.<br>Scholarship coordinators are advised to always keep their information up-to-date.<br>However, in order for the changes to take effect, all the edited portions must be<br>validated by CHED-CAR first. The pending updates are seen in the Updates Page.</p>
									<span class="material-icons-round close" onclick="hide(4)">close</span>
								</div>
							</div>
						</div>
					</th>
				</tr>
			</thead>
			<tbody>
				@foreach($scholars as $key => $scholar)
					<tr>
						<td>{{ $key + $scholars->firstItem() }}</td>
						<td>{{ $scholar->applicant->full_name }}</td>
						<td>{{ $scholar->award_number }}</td>
						<td>A.Y. {{ $scholar->acad_year_accepted }}, {{ $scholar->semester_accepted == 1 ? '1st' : '2nd' }} Sem</td>
						<td>A.Y. {{ $scholar->latest_acad_year }}, {{ $scholar->latest_semester == 1 ? '1st' : '2nd' }} Sem</td>
						<td>{{ $scholar->full_latest_year_level }}</td>
						<td><p class="table_status">{{ $scholar->latest_status }}</p></td>
						<td class="settings">
							<a class="option" href="/coordinator/undergraduates/{{ $scholar->scholar_id }}/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
		@if($scholars->total() > 10)
		<div class="pagination">
			<div class="previous">{{ $scholars->appends($sort_filters)->links() }}</div>
		</div>
		@endif
		@else
		<center><p class="bold">No Scholars Found</p></center>
		@endif
	</div>
</section>
@endsection