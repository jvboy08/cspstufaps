@extends('layouts.master_unregistered')

@section('content')
<section class="login_signup">
	<div class="form_container">
		<div class="message">
			<h1>Email Address Already in Use</h1>
			<p>Looks like this email address has already been signed up and verified. You can try logging in with this email address.</p>
			<a class="add" href="/coordinator/login">Proceed to Log In Page</a>
		</div>
	</div>
</section>
@endsection