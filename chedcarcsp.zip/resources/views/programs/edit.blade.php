 @extends('layouts.master')

@section('title')
CHED-CAR Admin | Programs
@endsection

@section('body')
<section class="form half">
	<div class="header">
		<h1>Edit a Program</h1>
		<a class="add" href="/programs">Go back</a>
	</div>
	@include('layouts.errors')
	<form method="POST" action="/programs/{{ $program->id }}">
		@method('PUT')
		@csrf 

		<!-- NAME -->
		<label for="program_name">Name :</label>
		<input type="text" name="program_name" placeholder="Enter program name" value="{{ $program->program_name }}" required>

		<!-- CODE -->
		<label for="code">Code :</label>
		<input type="text" name="code" placeholder="Enter program code" value="{{ $program->code }}" required>

		<!-- FINANCIAL BENEFITS PER SEMESTER -->
		<label for="amount_per_sem">Financial Benefits Per Semester :</label>
		<input type="number" name="amount_per_sem" placeholder="Enter amount" value="{{ $program->amount_per_sem }}" required>

		<!-- REFERENCE CMO -->
		<label for="reference_cmo">Reference CMO for Priority Disciplines :</label>
		<select name="reference_cmo" required>
			<option value="CMO 1 S. 2014" {{ $program->reference_cmo == "CMO 1 S. 2014" ? "selected" : ""}}>CMO 1 S. 2014</option>
			<option value="CMO 5 S. 2019" {{ $program->reference_cmo == "CMO 5 S. 2019" ? "selected" : ""}}>CMO 5 S. 2019</option>
		</select>

		<input type="submit" value="Submit Changes">
	</form>
</section>
@endsection