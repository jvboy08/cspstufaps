@extends('layouts.master')

@section('title')
CHED-CAR Admin | Programs
@endsection

@section('body')
<section>
	<div class="header">
		@if(!$programs->isEmpty())
		<h1 class="result">{{ $programs->total()}} {{ $programs->total() > 1 ? 'Programs' : 'Program' }} Found</h1>
		@else
		<h1 class="result">No Programs Found</h1>
		@endif
		<a class="add" href="/programs/create">Add a program</a>
	</div>
	@if(!$programs->isEmpty())
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Program Name</th>
					<th style="white-space: nowrap;">Program Code</th>
					<th style="white-space: nowrap;">Amount Per Sem</th>
					<th style="white-space: nowrap;">Priority Disciplines</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				@foreach($programs as $key => $program)
					<tr>
						<td>{{ $key + $programs->firstItem() }}</td>
						<td>{{ $program->program_name }}</td>
						<td>{{ $program->code }}</td>
						<td>PHP {{ number_format($program->amount_per_sem, 2, '.', ',') }}</td>
						<td>{{ $program->reference_cmo }}</td>
						<td class="settings">
							<a href="/programs/{{ $program->id }}/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							<a href="/programs/{{ $program->id }}/delete" onclick="return confirm('Are you sure you want to delete this program?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				@endforeach
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous">{{ $programs->links() }}</div>
	</div>
	@else
	@endif
</section>
@endsection
