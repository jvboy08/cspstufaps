@if ($errors->any())
  @foreach($errors->all() as $error)
  <div class="error">
      <h2 id="error">{{ $error }}</h2>
  </div>
  @endforeach 
@endif