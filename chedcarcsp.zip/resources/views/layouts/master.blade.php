<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">     
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <link rel="stylesheet" type="text/css" href="/css/style.css?v=1">
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&family=Roboto:ital,wght@0,400;0,500;1,400;1,500&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <link rel="icon" href="{{ URL::asset('/favicon.png') }}" type="image/x-icon"/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <title>@yield('title')</title>
  <script type="text/javascript" src="{{ URL::asset('js/index.js') }}"></script>
  <script src="https://unpkg.com/pdf-lib@1.11.0"></script>
  <script src="https://unpkg.com/downloadjs@1.4.7"></script>
</head>
<body>
  <div id="loading" class="loading">
    <div class="loader"></div>
    <h1>Please wait...</h1>
  </div>

  <header>
    <div class="left">
      <div class="logos">
        <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
        <div class="names">
         <h1>Commission on Higher Education</h1>
         <h2>Cordillera Administrative Region</h2>
        </div>
      </div>
    </div>
    <div class="dropdown">
      <button class="dropdown-button"><span class="material-icons-round">person</span>{{ auth()->user()->name }}<span class="material-icons-round">arrow_drop_down</span></button>
      <div class="dropdown-content">
        <a href="/logout">Log Out</a>
        <a href="/administrators/password">Change Password</a>
        @if(\App\User::count() > 0)
        <a href="/administrators/delete" onclick="return confirm('Are you sure you want to permanently delete your account? This cannot be undone.')">Delete Account</a>
        @else
        <a onclick="alert("Sorry. You cannot delete your account if there is only one administrator left.")">Delete Account</a>
        @endif
      </div>
    </div>
  </header>
  
  <section class="banner">
    <h1>CHED-CAR <span>Scholarship Program</span> Admin Panel</h1>
  </section>

  <section class="content">
    @include('layouts.sidebar')
    <div class="body">
      @yield('body')
    </div>
  </section>
</body>
</html>