<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">   
  <link rel="stylesheet" type="text/css" href="/css/style2.css?v=1">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&display=swap" rel="stylesheet">
  <link rel="icon" href="{{ URL::asset('/favicon.png') }}" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <title>@yield('title')</title>
</head>
<body class="application">
  <header>
    <div class="left">
      <div class="logos">
        <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
      </div>
      <div class="names">
        <h1>Commission on Higher Education</h1>
        <h2>Cordillera Administrative Region</h2>
      </div>
    </div>
    <div class="dropdown">
      <button class="dropdown-button"><span class="material-icons-round">person</span>{{ auth()->user()->scholar->applicant->alternate_full_name }}<span class="material-icons-round">arrow_drop_down</span></button>
      <div class="dropdown-content">
        <a href="/scholar/logout">Log Out</a>
        <a href="/scholar/password/change">Change Password</a>
      </div>
    </div>
  </header>

  <section class="banner">
    <h1>CHED <span class="italic_yellow">Scholarship Program</span> Scholar</h1>
  </section>

  @yield('content')

  @include('layouts.footer')
</body>
<script type="text/javascript">
  $( document ).ready(function() {
    $('.dropdown-button').on('click', function (event) {
      event.stopPropagation();
      if($('.dropdown-content').hasClass('active')) {
        $('.dropdown-content').removeClass('active');
      } else {
        $('.dropdown-content').addClass('active');
      }
    });

    $(document).click(function(e) {
      if($('.dropdown-content').hasClass('active')) {
        $('.dropdown-content').removeClass('active');
      }
    });
  });
</script>
</html>