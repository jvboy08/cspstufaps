<div class="sidebar">
  <a  href="{{ url('/dashboard') }}">
    <div class="page {{ Request::is('dashboard*') ? 'active' : '' }}">
      <span class="material-icons-round">home</span>
      <h1>Dashboard</h1>
    </div>
  </a>
  <div class="dropdown {{ Request::is('programs*') || Request::is('awards*') ? 'active' : '' }}">
      <div class="dropdown-button"><span class="material-icons-round">school</span>
        <h1>Scholarship</h1>
      </div>
      <div class="dropdown-content">
        <a href="/programs">Programs</a>
        <a href="/awards">Awards</a>
      </div>
  </div>
  <div class="dropdown {{ Request::is('academic*') ? 'active' : '' }}">
      <div class="dropdown-button"><span class="material-icons-round">account_balance</span>
        <h1>Academic</h1>
      </div>
      <div class="dropdown-content">
        <a href="/academic/institutions">Institutions</a>
        <a href="/academic/degree_programs">Degree Programs</a>
        <a href="/academic/school_coordinators">Coordinators</a>
      </div>
  </div>
  <div class="dropdown {{ Request::is('applicants*') || Request::is('scholars*') ? 'active' : '' }}">
      <div class="dropdown-button"><span class="material-icons-round">groups</span>
        <h1>Students</h1>
      </div>
      <div class="dropdown-content">
        <a href="/applicants">Applicants</a>
        <a href="/scholars">Scholars</a>
      </div>
  </div>
  <div class="dropdown {{ Request::is('documents*') ? 'active' : '' }}">
      <div class="dropdown-button"><span class="material-icons-round">description</span>
        <h1>Documents</h1>
      </div>
      <div class="dropdown-content">
        <a href="/documents/billing_statements">Billing Statements</a>
        <a href="/documents/payment_requirements">Payment Requirements</a>
        <a href="/documents/semestral_requirements">Semestral Requirements</a>
      </div>
  </div>
  <div class="dropdown {{ Request::is('updates*') ? 'active' : '' }}">
      <div class="dropdown-button"><span class="material-icons-round">info</span>
        <h1>Updates</h1>
      </div>
      <div class="dropdown-content">
        <a href="/updates/scholars">Scholar Information</a>
        <a href="/updates/graduates">Pending Graduates</a>
      </div>
  </div>
  <a  href="{{ url('/payments') }}">
    <div class="page {{ Request::is('payments*') ? 'active' : '' }}">
      <span class="material-icons-round">payments</span>
      <h1>Payments</h1>
    </div>
  </a>
  <a  href="{{ url('/reports') }}">
    <div class="page {{ Request::is('reports*') ? 'active' : '' }}">
      <span class="material-icons-round">table_chart</span>
      <h1>Reports</h1>
    </div>
  </a>
  <a  href="{{ url('/administrators') }}">
    <div class="page {{ Request::is('administrators*') ? 'active' : '' }}">
      <span class="material-icons-round">manage_accounts</span>
      <h1>Admins</h1>
    </div>
  </a>
</div>