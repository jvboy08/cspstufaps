<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Institutions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="institutions">
	<div class="header">
		<?php if(!$institutions->isEmpty()): ?>
		<h1 class="result"><?php echo e($institutions->total()); ?> <?php echo e($institutions->total() > 1 ? 'Higher Education Institutions' : 'Higher Education Institution'); ?> Found</h1>
		<?php else: ?>
		<h1 class="result">No Higher Education Institutions Found</h1>
		<?php endif; ?>
		<div class="header_buttons">
			<a class="add" href="/academic/institutions/create">Add an institution</a>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/academic/institutions" method="GET">
			<div class="filter">
				<div class="pairs">
					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Institution Name</h3>
						<?php if(array_key_exists('name', $sort_filters)): ?>
						<input type="text" name="name" placeholder="Enter institution name" value="<?php echo e($sort_filters['name']); ?>" id="name">
						<?php else: ?>						
						<input type="text" name="name" placeholder="Enter institution name" id="name">
						<?php endif; ?>
					</div>

					<!-- SECTOR -->
					<div class="pair">
						<h3>Sector</h3>
						<select name="sector">
							<option value="" disabled selected hidden>Select a sector</option>
							<?php if(array_key_exists('sector', $sort_filters)): ?>
							<option value="P" <?php echo e($sort_filters['sector'] == "P" ? 'selected' : ''); ?>>Private</option>
							<option value="SUC" <?php echo e($sort_filters['sector'] == "SUC" ? 'selected' : ''); ?>>State Universities and Colleges</option>
							<option value="LUC" <?php echo e($sort_filters['sector'] == "LUC" ? 'selected' : ''); ?>>Public Universities and Colleges</option>
							<option value="OGS" <?php echo e($sort_filters['sector'] == "OGS" ? 'selected' : ''); ?>>Other Govt. Schools</option>
						    <?php else: ?>
							<option value="P">Private</option>
							<option value="SUC">State Universities and Colleges</option>
							<option value="LUC">Public Universities and Colleges</option>
							<option value="OGS">Other Govt. Schools</option>
						    <?php endif; ?>
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							<?php if(array_key_exists('items', $sort_filters)): ?>
								<option value="10" <?php echo e($sort_filters['items'] == '10' ? 'selected' : ''); ?>>10</option>
								<option value="25" <?php echo e($sort_filters['items'] == '25' ? 'selected' : ''); ?>>25</option>
								<option value="50" <?php echo e($sort_filters['items'] == '50' ? 'selected' : ''); ?>>50</option>
								<option value="100" <?php echo e($sort_filters['items'] == '100' ? 'selected' : ''); ?>>100</option>
							<?php else: ?>
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							<?php endif; ?>
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>
		</form>
	</div>
	<?php if(!$institutions->isEmpty()): ?>
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Institution Name</th>
					<th>Sector</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($key + $institutions->firstItem()); ?></td>
						<td><?php echo e($institution->institution_name); ?></td>
						<td><?php echo e($institution->alternate_full_sector); ?></td>
						<td class="settings">
							<a href="/academic/institutions/<?php echo e($institution->id); ?>">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<a href="/academic/institutions/<?php echo e($institution->id); ?>/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							<a href="/academic/institutions/<?php echo e($institution->id); ?>/delete" onclick="return confirm('Are you sure you want to delete this institution?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous"><?php echo e($institutions->appends($sort_filters)->links()); ?></div>
	</div>
	<?php endif; ?>
</section>

<script>
	function resetAll() {
		$('#name').val("");
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach((select, index) => {
			select.selectedIndex = 0;
		});
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/institutions/index.blade.php ENDPATH**/ ?>