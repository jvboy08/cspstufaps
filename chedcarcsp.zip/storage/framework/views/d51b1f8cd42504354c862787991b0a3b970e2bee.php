<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Awards
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="form half">
	<div class="header">
		<h1>Award New Slots</h1>
		<a class="add" href="/awards">Go back</a>
	</div>
	<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<form method="POST" action="/awards"> 
		<?php echo csrf_field(); ?> 
		<!-- PROGRAM -->
		<label for="program_id">Program :</label>
		<select name="program_id">
			<option value="" disabled selected hidden>Select a program</option>
			<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<option value="<?php echo e($program->id); ?>"><?php echo e($program->code); ?> - <?php echo e($program->program_name); ?></option>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</select>

		<!-- ACADEMIC YEAR AWARDED -->
		<label for="award_year">Academic Year Awarded :</label>
		<select name="award_year" required>
			<option value="" disabled selected hidden>Select an academic year</option>
			<?php for($i = 2016; $i <= now()->year; $i++): ?>
		        <option value="<?php echo e($i); ?>"><?php echo e($i); ?> - <?php echo e($i+1); ?></option>
		    <?php endfor; ?>
		</select>

		<!-- STARTING SLOT -->
		<label for="start_slot">Starting Slot :</label>
		<input type="number" name="start_slot" placeholder="Enter number of starting slot" required>

		<!-- ENDING SLOT -->
		<label for="end_slot">Ending Slot :</label>
		<input type="number" name="end_slot" placeholder="Enter number of ending slot" required>

		<input type="submit" value="Submit">
	</form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/awards/create.blade.php ENDPATH**/ ?>