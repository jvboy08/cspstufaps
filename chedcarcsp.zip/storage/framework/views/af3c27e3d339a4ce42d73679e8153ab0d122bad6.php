 

<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Programs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="form half">
	<div class="header">
		<h1>Edit a Program</h1>
		<a class="add" href="/programs">Go back</a>
	</div>
	<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<form method="POST" action="/programs/<?php echo e($program->id); ?>">
		<?php echo method_field('PUT'); ?>
		<?php echo csrf_field(); ?> 

		<!-- NAME -->
		<label for="program_name">Name :</label>
		<input type="text" name="program_name" placeholder="Enter program name" value="<?php echo e($program->program_name); ?>" required>

		<!-- CODE -->
		<label for="code">Code :</label>
		<input type="text" name="code" placeholder="Enter program code" value="<?php echo e($program->code); ?>" required>

		<!-- FINANCIAL BENEFITS PER SEMESTER -->
		<label for="amount_per_sem">Financial Benefits Per Semester :</label>
		<input type="number" name="amount_per_sem" placeholder="Enter amount" value="<?php echo e($program->amount_per_sem); ?>" required>

		<!-- REFERENCE CMO -->
		<label for="reference_cmo">Reference CMO for Priority Disciplines :</label>
		<select name="reference_cmo" required>
			<option value="CMO 1 S. 2014" <?php echo e($program->reference_cmo == "CMO 1 S. 2014" ? "selected" : ""); ?>>CMO 1 S. 2014</option>
			<option value="CMO 5 S. 2019" <?php echo e($program->reference_cmo == "CMO 5 S. 2019" ? "selected" : ""); ?>>CMO 5 S. 2019</option>
		</select>

		<input type="submit" value="Submit Changes">
	</form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/programs/edit.blade.php ENDPATH**/ ?>