<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">     
  <link rel="stylesheet" type="text/css" href="/css/style.css?v=1">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&family=Roboto:ital,wght@0,400;0,500;1,400;1,500&display=swap" rel="stylesheet">
  <link rel="icon" href="<?php echo e(URL::asset('/favicon.png')); ?>" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <title>CHED-CAR | Admin Login</title>
</head>
<body class="login_body">
  <header>
    <a href="/">
      <div class="left">
        <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
        <div class="names">
         <h1>Commission on Higher Education</h1>
         <h2>Cordillera Administrative Region</h2>
        </div>
      </div>
      <div class="right">
        <a class="add" href="/">Homepage</a>
      </div>
    </a>
  </header>
  <section class="main">
    <div class="left">
      <h1>CHED-CAR</h1>
      <h2>Scholarship</h2>
      <h3>Admin Panel</h3>
    </div>
    <div class="right">
      <form class="login-form" method="POST" action="/login">
        <?php echo csrf_field(); ?>
        <h1>Admin Login</h1>
        <input type="email" id="email" name="email" placeholder="Email address" required>
        <input type="password" id="password" name="password" placeholder="Password" required>
        <input type="submit" value="Login">
      </form>
      <?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </section>
</body>
<script src="/javascript/script.js?v=1"></script>
</html><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/login/index.blade.php ENDPATH**/ ?>