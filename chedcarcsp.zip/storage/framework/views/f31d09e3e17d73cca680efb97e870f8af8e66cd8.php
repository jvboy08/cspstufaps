<?php $__env->startSection('title'); ?>
CHED-CAR | Coordinator
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/coordinator/login">
        <?php echo csrf_field(); ?>
        <h1>Log In as Coordinator</h1>
        <?php echo $__env->make('layouts.errors_no_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="email" id="email" name="email" placeholder="Email address" required>
        <input type="password" id="password" name="password" placeholder="Password" required>
        <a href="/password/email"><p>Forgot password? <span class="bold">Reset Password</span></p></a>
        <input type="submit" value="Log In">
        <a href="/coordinator/sign_up"><p>Don’t have an account? <span class="bold">Sign Up</span></p></a>
      </form>
    </div>
  </section> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_unregistered', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp-master\resources\views/coordinators/login.blade.php ENDPATH**/ ?>