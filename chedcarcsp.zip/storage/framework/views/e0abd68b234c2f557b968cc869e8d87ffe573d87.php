<footer>
	<embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
	<p>Copyright © 2021 CHED CAR | Benguet, Philippines. All Rights Reserved.</p>
</footer><?php /**PATH C:\wamp64\www\chedcar-master\resources\views/layouts/footer.blade.php ENDPATH**/ ?>