<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Institutions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="form full">
	<div class="header">
		<h1><?php echo e($institution->institution_name); ?></h1>
		<a class="add" href="/academic/institutions">Go back</a>
	</div>
	<div class="view">
		<div class="columns">
			<div class="column pairs">
				<p>School Sector :</p>
				<p><?php echo e($institution->full_sector); ?></p>
			</div>
			<div class="column pairs">
				<p>School Address :</p>
				<p><?php echo e($institution->address); ?></p>
			</div>
		</div>
		<div class="columns">
			<div class="column">
				<h1>Organization Heads</h1>
			</div>
		</div>
		<div class="columns">
			<div class="column pairs">
				<p>Institution Head :</p>
				<p><?php echo e($institution->institution_head == null ? 'N/A' : $institution->institution_head); ?></p>
				<p>University Registrar :</p>
				<p><?php echo e($institution->registrar == null ? 'N/A' : $institution->registrar); ?></p>
			</div>
			<div class="column pairs">
				<p>Chief Accountant :</p>
				<p><?php echo e($institution->accountant == null ? 'N/A' : $institution->accountant); ?></p>
			</div>
		</div>
		<div class="columns">
			<div class="column">
				<h1>Contact Details</h1>
			</div>
		</div>
		<div class="columns">
			<div class="column pairs">
				<p>Email Address :</p>
				<p><?php echo e($institution->hei_email == null ? 'N/A' : $institution->hei_email); ?></p>
				<p>Contact Number :</p>
				<p><?php echo e($institution->hei_contact_no == null ? 'N/A' : $institution->hei_contact_no); ?></p>
			</div>
			<div class="column pairs">
				<p>Website Link :</p>
				<p><?php echo e($institution->hei_website == null ? 'N/A' : $institution->hei_website); ?></p>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/institutions/show.blade.php ENDPATH**/ ?>