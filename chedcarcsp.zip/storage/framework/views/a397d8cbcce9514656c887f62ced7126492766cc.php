<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Programs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section>
	<div class="header">
		<?php if(!$programs->isEmpty()): ?>
		<h1 class="result"><?php echo e($programs->total()); ?> <?php echo e($programs->total() > 1 ? 'Programs' : 'Program'); ?> Found</h1>
		<?php else: ?>
		<h1 class="result">No Programs Found</h1>
		<?php endif; ?>
		<a class="add" href="/programs/create">Add a program</a>
	</div>
	<?php if(!$programs->isEmpty()): ?>
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Program Name</th>
					<th style="white-space: nowrap;">Program Code</th>
					<th style="white-space: nowrap;">Amount Per Sem</th>
					<th style="white-space: nowrap;">Priority Disciplines</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($key + $programs->firstItem()); ?></td>
						<td><?php echo e($program->program_name); ?></td>
						<td><?php echo e($program->code); ?></td>
						<td>PHP <?php echo e(number_format($program->amount_per_sem, 2, '.', ',')); ?></td>
						<td><?php echo e($program->reference_cmo); ?></td>
						<td class="settings">
							<a href="/programs/<?php echo e($program->id); ?>/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							<a href="/programs/<?php echo e($program->id); ?>/delete" onclick="return confirm('Are you sure you want to delete this program?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous"><?php echo e($programs->links()); ?></div>
	</div>
	<?php else: ?>
	<?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/programs/index.blade.php ENDPATH**/ ?>