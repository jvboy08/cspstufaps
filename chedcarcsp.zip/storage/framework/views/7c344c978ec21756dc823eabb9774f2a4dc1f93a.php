<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Awards
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section>
	<div class="header">
		<?php if(!$awards->isEmpty()): ?>
		<h1 class="result"><?php echo e($awards->total()); ?> Awarded Slots Found</h1>
		<?php else: ?>
		<h1 class="result">No Awarded Slots Found</h1>
		<?php endif; ?>
		<a class="add" href="/awards/create">Award new slots</a>
	</div>
	<div class="functions">
		<form action="/awards" method="GET">
			<div class="filter">
				<div class="pairs">

					<!-- SORT -->
					<div class="pair">
						<h3>Sort by</h3>
						<select name="sort">
							<?php if(array_key_exists('sort', $sort_filters)): ?>
							<option value="program_name" <?php echo e($sort_filters["sort"] == "program_name" ? "selected" : ""); ?>>Alphabetical</option>
							<option value="award_year_asc" <?php echo e($sort_filters["sort"] == "award_year_asc" ? "selected" : ""); ?>>Academic Year - Ascending</option>
							<option value="award_year_desc" <?php echo e($sort_filters['sort'] == 'award_year_desc' ? 'selected' : ''); ?>>Academic Year - Descending</option>
							<?php else: ?>
							<option value="program_name" selected>Alphabetical</option>
							<option value="award_year_asc">Academic Year - Ascending</option>
							<option value="award_year_desc">Academic Year - Descending</option>
							<?php endif; ?>
						</select>
					</div>

					<!-- ACADEMIC YEAR AWARDED -->
					<div class="pair">
						<h3>Academic Year Awarded</h3>
						<select name="acad_year">
							<option value="" disabled selected hidden>Select an academic year</option>
							<?php if(array_key_exists('acad_year', $sort_filters)): ?>
							<?php for($i = 2016; $i <= now()->year; $i++): ?>
						        <option value="<?php echo e($i); ?>" <?php echo e($sort_filters["acad_year"] == $i ? "selected" : ""); ?>>A.Y. <?php echo e($i); ?> - <?php echo e($i+1); ?></option>
						    <?php endfor; ?>
						    <?php else: ?>
							<?php for($i = 2016; $i <= now()->year; $i++): ?>
						        <option value="<?php echo e($i); ?>">A.Y. <?php echo e($i); ?> - <?php echo e($i+1); ?></option>
						    <?php endfor; ?>
						    <?php endif; ?>
						</select>
					</div>

					<button type="button" class="clear" onclick="resetAll()">Reset</button>
					<input type="submit" value="Submit">
				</div>
			</div>
			<div class="filter">
				<div class="pairs">
					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program">
							<option value="" disabled selected hidden>Select a program</option>
							<?php if(array_key_exists('program', $sort_filters)): ?>
							<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($program->id); ?>" <?php echo e($program->id == $sort_filters['program'] ? 'selected' : ''); ?>><?php echo e($program->code); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
							<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($program->id); ?>"><?php echo e($program->code); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	<?php if(!$awards->isEmpty()): ?>
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th style="white-space: nowrap;">Program Code</th>
					<th style="white-space: nowrap;">Academic Year Awarded</th>
					<th style="white-space: nowrap;">Starting Slot</th>
					<th style="white-space: nowrap;">Ending Slot</th>
					<th style="white-space: nowrap;">Total Slots</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $awards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $award): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($key + $awards->firstItem()); ?></td>
						<td><?php echo e($award->code); ?></td>
						<td>A.Y. <?php echo e($award->award_year); ?> - <?php echo e($award->award_year+1); ?></td>
						<td><?php echo e(sprintf("%04d", $award->start_slot)); ?></td>
						<td><?php echo e(sprintf("%04d", $award->end_slot)); ?></td>
						<td><?php echo e($award->end_slot - $award->start_slot + 1); ?></td>
						<td class="settings">
							<a href="/awards/<?php echo e($award->award_id); ?>/edit">
							<div><span class="material-icons-round">edit</span><p>Edit</p></div>
							</a>
							<a href="/awards/<?php echo e($award->award_id); ?>/delete" onclick="return confirm('Are you sure you want to delete these awarded slots?')">
							<div><span class="material-icons-round">delete</span><p>Delete</p></div>
							</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous"><?php echo e($awards->appends($sort_filters)->links()); ?></div>
	</div>
	<?php else: ?>
	<?php endif; ?>
</section>

<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/awards/index.blade.php ENDPATH**/ ?>