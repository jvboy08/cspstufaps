<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Reports
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="full reports_container">

	<!-- DATABASE -->
	<form action="/reports/database" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter">
				<div class="pairs">
					<h1>Prescribed Database Cleansing Standards</h1>
				</div>
			</div>
		</div>

		<div class="reports">
			<div class="report">
				<h2>Database</h2>
				<a type="submit" href="/reports/database"><span class="material-icons-round">article</span>Generate
				</a>
			</div>
		</div>
	</form>

	<!-- BY ACADEMIC YEAR -->
	<form action="/reports/yearly" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter">
				<div class="pairs">
					<h1>By Academic Year</h1>

					<!-- ACADEMIC YEAR -->
					<div class="pair">
						<h3>Academic Year</h3>
						<select name="acad_year" required>
							<?php for($i = 2016; $i <= now()->year; $i++): ?>
						        <option value="<?php echo e($i); ?>" <?php echo e($i == (now()->month < 8 ? now()->year-1 : now()->year) ? 'selected' : ''); ?>>A.Y. <?php echo e($i); ?> - <?php echo e($i+1); ?></option>
						    <?php endfor; ?>
						</select>
					</div>
				</div>
			</div>
		</div>

		<div class="reports">
			<div class="report">
				<h2>Ranklist</h2>
				<button type="submit" name="report" value="ranklist"><span class="material-icons-round">article</span>Generate
				</button>
			</div>

			<div class="report">
				<h2>Processed Benefits</h2>
				<button type="submit" name="report" value="benefits"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
		</div>
	</form>

	<!-- BY ACADEMIC PERIOD AND PROGRAM -->

	<form action="/reports/semestral_program" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter" style="margin-bottom: 1vw">
				<div class="pairs">
					<h1>By Academic Period & Program</h1>

					<!-- ACADEMIC PERIOD -->
					<div class="pair">
						<h3>Academic Period</h3>
						<select name="period" required>
							<option value="" disabled selected hidden>Select an academic period</option>
							<?php for($i = 2016; $i <= now()->year; $i++): ?>
						        <option value="<?php echo e($i.',1'); ?>">A.Y. <?php echo e($i); ?> - <?php echo e($i+1); ?>, 1st Semester</option>
						        <option value="<?php echo e($i.',2'); ?>">A.Y. <?php echo e($i); ?> - <?php echo e($i+1); ?>, 2nd Semester</option>
						    <?php endfor; ?>
						</select>
					</div>

					<!-- PROGRAM -->
					<div class="pair">
						<h3>Program</h3>
						<select name="program" required>
							<option value="" disabled selected hidden>Select a program</option>
							<?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($program->id); ?>"><?php echo e($program->code); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
				</div>
			</div>
		</div>

		<div class="reports">
			<div class="report">
				<h2>Masterlist</h2>
				<button type="submit" name="report" value="masterlist"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
		</div>
	</form>

	<!-- BY ACADEMIC PERIOD -->

	<form action="/reports/semestral" method="GET">
		<div class="functions" style="margin-bottom: 2.5vw">
			<div class="filter">
				<div class="pairs">
					<h1>By Academic Period</h1>

					<!-- ACADEMIC PERIOD -->
					<div class="pair">
						<h3>Academic Period</h3>
						<select name="period" required>
							<option value="" disabled selected hidden>Select an academic period</option>
							<?php for($i = 2016; $i <= now()->year; $i++): ?>
						        <option value="<?php echo e($i.',1'); ?>">A.Y. <?php echo e($i); ?> - <?php echo e($i+1); ?>, 1st Semester</option>
						        <option value="<?php echo e($i.',2'); ?>">A.Y. <?php echo e($i); ?> - <?php echo e($i+1); ?>, 2nd Semester</option>
						    <?php endfor; ?>
						</select>
					</div>
				</div>
			</div>
		</div>

		<div class="reports" style="margin-bottom: 0;">
			<div class="report">
				<h2>Status of Beneficiaries</h2>
				<button type="submit" name="report" value="status_total"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>Report on Graduates</h2>
				<button type="submit" name="report" value="graduates_total"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>Graduates of StuFAPs</h2>
				<button type="submit" name="report" value="graduates_list"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By Curriculum Level</h2>
				<button type="submit" name="report" value="by_level"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By Sex</h2>
				<button type="submit" name="report" value="by_sex"><span class="material-icons-round">article</span>Generate
				</button>
			</div>

			<div class="report">
				<h2>By Type of HEI</h2>
				<button type="submit" name="report" value="by_hei_type"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By District</h2>
				<button type="submit" name="report" value="by_district"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
			<div class="report">
				<h2>By Special Group</h2>
				<button type="submit" name="report" value="by_special"><span class="material-icons-round">article</span>Generate
				</button>
			</div>
		</div>
	</form>
</section>

<script type="text/javascript">
	function changeView(view) {
		if(view == 1) {
			document.querySelector('#left-view').classList.add('active');
			document.querySelector('#right-view').classList.remove('active');
			document.querySelector('#left-nav').classList.add('active');
			document.querySelector('#right-nav').classList.remove('active');
		} else {
			document.querySelector('#left-view').classList.remove('active');
			document.querySelector('#right-view').classList.add('active');
			document.querySelector('#left-nav').classList.remove('active');
			document.querySelector('#right-nav').classList.add('active');
		}
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/reports/index.blade.php ENDPATH**/ ?>