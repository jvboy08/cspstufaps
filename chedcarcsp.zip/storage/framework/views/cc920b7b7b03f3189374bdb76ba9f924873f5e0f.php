<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Programs
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="form half">
	<div class="header">
		<h1>Add a Program</h1>
		<a class="add" href="/programs">Go back</a>
	</div>
	<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<form method="POST" action="/programs"> 
		<?php echo csrf_field(); ?> 

		<!-- NAME -->
		<label for="program_name">Name :</label>
		<input type="text" name="program_name" placeholder="Enter program name" required>

		<!-- CODE -->
		<label for="code">Code :</label>
		<input type="text" name="code" placeholder="Enter program code" required>

		<!-- FINANCIAL BENEFITS PER SEMESTER -->
		<label for="amount_per_sem">Financial Benefits Per Semester :</label>
		<input type="number" name="amount_per_sem" placeholder="Enter amount" required>

		<!-- REFERENCE CMO --> 
		<label for="reference_cmo">Reference CMO for Priority Disciplines :</label>
		<select name="reference_cmo" required>
			<option value="" disabled selected hidden>Select a reference CMO</option>
			<option value="CMO 1 S. 2014">CMO 1 S. 2014</option>
			<option value="CMO 5 S. 2019">CMO 5 S. 2019</option>
			<option value="CMO 10 S. 2021">CMO 10 S. 2021</option>
		</select>
		
		<input type="submit" value="Submit">
	</form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/programs/create.blade.php ENDPATH**/ ?>