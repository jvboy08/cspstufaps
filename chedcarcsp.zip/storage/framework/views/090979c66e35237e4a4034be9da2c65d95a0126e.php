<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Applicants
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section> 
	<div class="header">
		<?php if(!$applicants->isEmpty()): ?>
		<h1 class="result"><?php echo e($applicants->total()); ?> <?php echo e($applicants->total() > 1 ? 'Applicants' : 'Applicant'); ?> Found</h1>
		<?php else: ?>
		<h1 class="result">No Applicants Found</h1>
		<?php endif; ?>
		<div class="header_buttons">
			<a class="add" href="/applicants/import">Upload a CSV file</a>
			<a class="add" onclick="location.reload()"><span class="material-icons-round dropdown">refresh</span></a>
		</div>
	</div>
	<div class="functions">
		<form action="/applicants" method="GET">
			<div class="filter">
				<div class="pairs">

					<!-- SEARCH -->
					<div class="pair">
						<h3>Search By Name</h3>
						<?php if(array_key_exists('name', $sort_filters)): ?>
						<input type="text" name="name" placeholder="Enter last or first name" value="<?php echo e($sort_filters['name']); ?>" id="name">
						<?php else: ?>						
						<input type="text" name="name" placeholder="Enter last or first name" id="name">
						<?php endif; ?>
					</div>

					<!-- SORT BY -->
					<div class="pair">
						<h3>Sort By</h3>
						<select name="sort">
							<?php if(array_key_exists('sort', $sort_filters)): ?>
								<option value="score" <?php echo e($sort_filters['sort'] == 'score' ? 'selected' : ''); ?>>Total Rank Score</option>
								<option value="entry_date" <?php echo e($sort_filters['sort'] == 'entry_date' ? 'selected' : ''); ?>>Date Applied</option>
								<option value="alphabetical" <?php echo e($sort_filters['sort'] == 'alphabetical' ? 'selected' : ''); ?>>Alphabetical</option>
								<option value="added" <?php echo e($sort_filters['sort'] == 'added' ? 'selected' : ''); ?>>Date Added</option>
							<?php else: ?>
								<option value="score" selected>Total Rank Score</option>
								<option value="entry_date">Date Applied</option>
								<option value="alphabetical">Alphabetical</option>
								<option value="added">Date Added</option>
							<?php endif; ?>
						</select>
					</div>

					<!-- STATUS -->
					<div class="pair">
						<h3>Application</h3>
						<select name="status">
							<option value="" disabled selected hidden>Select status</option>
							<?php if(array_key_exists('status', $sort_filters)): ?>
						        <option value="0" <?php echo e($sort_filters['status'] == 0 ? 'selected' : ''); ?>>Pending</option>
						        <option value="1" <?php echo e($sort_filters['status'] == 1 ? 'selected' : ''); ?>>Accepted</option>
							<?php else: ?>
						        <option value="0">Pending</option>
						        <option value="1">Accepted</option>
							<?php endif; ?>
						</select>
					</div>
				</div>
				<div class="pairs">
					<div class="pair">
						<button type="button" class="clear" onclick="resetAll()">Reset</button>
						<input type="submit" value="Submit">
					</div>
				</div>
			</div>

			<div class="filter">
				<div class="pairs">

					<!-- ACADEMIC YEAR OF ENTRY -->
					<div class="pair">
						<h3>Academic Year of Application</h3>
						<select name="acad_year" id="acad_year">
							<?php if(array_key_exists('acad_year', $sort_filters)): ?>
							<?php for($i = 2016; $i <= now()->year; $i++): ?>
						        <option value="<?php echo e($i); ?>" <?php echo e($sort_filters['acad_year'] == $i ? 'selected' : ''); ?>><?php echo e($i); ?> - <?php echo e($i+1); ?></option>
						    <?php endfor; ?>
							<?php else: ?>
							<?php for($i = 2016; $i <= now()->year; $i++): ?>
						        <option value="<?php echo e($i); ?>" <?php echo e($i == (now()->month < 8 ? now()->year-1 : now()->year) ? 'selected' : ''); ?>><?php echo e($i); ?> - <?php echo e($i+1); ?></option>
						    <?php endfor; ?>
							<?php endif; ?>
						</select>
					</div>
					
					<!-- INSTITUTION -->
					<div class="pair">
						<h3>Institution</h3>
						<select name="institution">
							<option value="" disabled selected hidden>Select a higher education institution</option>
							<?php if(array_key_exists('institution', $sort_filters)): ?>
							<option value="outside_car" <?php echo e($sort_filters['institution'] == 'outside_car' ? 'selected' : ''); ?>>Institution Outside CAR</option>
							<?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($institution->id); ?>" <?php echo e($institution->id == $sort_filters['institution'] ? 'selected' : ''); ?>><?php echo e($institution->institution_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php else: ?>
							<option value="outside_car">Institution Outside CAR</option>
							<?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($institution->id); ?>"><?php echo e($institution->institution_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						</select>
					</div>

					<!-- PRIORITY COURSE CLUSTER -->
					<div class="pair">
						<h3>Priority Disciplines</h3>
						<select name="cmo">
							<option value="" disabled selected hidden>Select a CMO</option>
							<?php if(array_key_exists('cmo', $sort_filters)): ?>
							<option value="2021" <?php echo e($sort_filters['cmo'] == "2021" ? 'selected' : ''); ?>>CMO 10 S. 2021</option>
							<option value="2019" <?php echo e($sort_filters['cmo'] == "2019" ? 'selected' : ''); ?>>CMO 5 S. 2019</option>
							<option value="2014" <?php echo e($sort_filters['cmo'] == "2014" ? 'selected' : ''); ?>>CMO 1 S. 2014</option>
						    <?php else: ?>
							<option value="2021">CMO 10 S. 2021</option>
							<option value="2019">CMO 5 S. 2019</option>
							<option value="2014">CMO 1 S. 2014</option>
						    <?php endif; ?>
						</select>
					</div>

					<!-- VALIDATED DOCUMENTS -->
					<div class="pair">
						<h3>Validation of Documents</h3>
						<select name="are_documents_validated">
							<option value="" disabled selected hidden>Select status</option>
							<?php if(array_key_exists('are_documents_validated', $sort_filters)): ?>
						        <option value="0" <?php echo e($sort_filters['are_documents_validated'] == 0 ? 'selected' : ''); ?>>Not yet validated</option>
						        <option value="1" <?php echo e($sort_filters['are_documents_validated'] == 1 ? 'selected' : ''); ?>>Validated</option>
							<?php else: ?>
						        <option value="0">Not yet validated</option>
						        <option value="1">Validated</option>
							<?php endif; ?>
						</select>
					</div>

					<!-- ITEMS PER PAGE -->
					<div class="pair">
						<h3>Items Per Page</h3>
						<select name="items">
							<?php if(array_key_exists('items', $sort_filters)): ?>
								<option value="10" <?php echo e($sort_filters['items'] == '10' ? 'selected' : ''); ?>>10</option>
								<option value="25" <?php echo e($sort_filters['items'] == '25' ? 'selected' : ''); ?>>25</option>
								<option value="50" <?php echo e($sort_filters['items'] == '50' ? 'selected' : ''); ?>>50</option>
								<option value="100" <?php echo e($sort_filters['items'] == '100' ? 'selected' : ''); ?>>100</option>
							<?php else: ?>
								<option value="10" selected>10</option>
								<option value="25">25</option>
								<option value="50">50</option>
								<option value="100">100</option>
							<?php endif; ?>
						</select>
					</div>
				</div>
			</div>
		</form>
	</div>
	<?php if(!$applicants->isEmpty()): ?>
	<div class="table">
		<table>
			<thead>
				<tr>
					<th>No.</th>
					<th>Full Name</th>
					<th>Date Applied</th>
					<th>Special Group</th>
					<th>Score</th>
					<th>Application</th>
					<th>Documents</th>
					<th>Settings</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $applicants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $applicant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($key + $applicants->firstItem()); ?></td>
						<td><?php echo e($applicant->full_name); ?></td>
						<td><?php echo e(date('M j, Y', strtotime($applicant->entry_date))); ?></td>
						<?php if($applicant->tribe == null && $applicant->disability == null && $applicant->sp_type == null && $applicant->is_orphan == 0): ?>
						<td>N/A</td>
						<?php else: ?>
						<td><?php echo e($applicant->tribe != null ? 'IP' : ''); ?><?php echo e($applicant->disability != null ? $applicant->tribe != null ? ', PWD' : 'PWD' : ''); ?><?php echo e($applicant->sp_type != null ? $applicant->tribe != null || $applicant->disability != null ? ', SP' : 'SP' : ''); ?><?php echo e($applicant->is_orphan == 1 ? $applicant->tribe != null || $applicant->disability != null || $applicant->sp_type != null ? ', Orphan' : 'Orphan' : ''); ?><?php echo e($applicant->sc_type != null ? $applicant->tribe != null || $applicant->disability != null || $applicant->sp_type != null || $applicant->is_orphan == 1 ? ', SC' : 'SC' : ''); ?></td>
						<?php endif; ?>
						<td><?php echo e($applicant->score + 0); ?></td>
						<td><p class="<?php echo e($applicant->is_accepted == 0 ? 'negative' : 'positive'); ?>"><?php echo e($applicant->is_accepted == 0 ? 'Pending' : 'Accepted'); ?></p></td>
						<td><p class="<?php echo e($applicant->are_documents_validated == 0 ? 'negative' : 'positive'); ?>"><?php echo e($applicant->are_documents_validated == 0 ? 'Not yet validated' : 'Validated'); ?></p></td>
						<td class="settings">
							<?php if($applicant->is_accepted == 1): ?>
							<a href="/scholars/<?php echo e(\App\Scholar::where(['applicant_id' => $applicant->applicant_id])->first()->id); ?>" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<?php else: ?>
							<a href="<?php echo e('/applicants/'.$applicant->applicant_id); ?>" target="_blank">
							<div><span class="material-icons-round">visibility</span><p>View</p></div>
							</a>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	<div class="pagination">
		<div class="previous"><?php echo e($applicants->appends($sort_filters)->links()); ?></div>
	</div>
	<?php endif; ?>
</section>

<script>
	function resetAll() {
		Array.prototype.slice.call(document.getElementsByTagName('select')).forEach(select => {
			select.selectedIndex = 0;
		});
		document.getElementById('name').value = null;
		let options = [];
		let year = new Date().getFullYear();
		let month = new Date().getMonth() + 1;
		for(let i = 2016; i <= year; i++) {
			let check = i == (month < 8 ? year - 1 : year) ? 'selected' : ''; 
			options.push(`<option value='${ i }' ${ check }>${ i } - ${ i + 1 }</option>`);
		}
		document.getElementById('acad_year').innerHTML = options.join();
	}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/applicants/index.blade.php ENDPATH**/ ?>