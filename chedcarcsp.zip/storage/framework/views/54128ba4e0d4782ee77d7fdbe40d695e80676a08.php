<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">     
  <link rel="stylesheet" type="text/css" href="/css/style2.css?v=1">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&display=swap" rel="stylesheet">
  <link rel="icon" href="<?php echo e(URL::asset('/favicon.png')); ?>" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/parsley.js/2.9.2/parsley.min.js" integrity="sha512-eyHL1atYNycXNXZMDndxrDhNAegH2BDWt1TmkXJPoGf1WLlNYt08CSjkqF5lnCRmdm3IrkHid8s2jOUY4NIZVQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://unpkg.com/pdf-lib@1.11.0"></script>
  <script src="https://unpkg.com/downloadjs@1.4.7"></script>
  <title>CHED-CAR | CSP Application</title>
</head>
<body class="application">
  <div id="loading" class="loading">
    <div class="loader"></div>
  </div>
  <header>
    <a href="/">
      <div class="left">
        <div class="logos">
          <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
        </div>
        <div class="names">
          <h1>Commission on Higher Education</h1>
          <h2>Cordillera Administrative Region</h2>
        </div>
      </div>
    </a>
    <div class="right">
      <a class="add" href="/">Home</a>
    </div>
  </header>

  <section class="banner">
    <h1>CHED <span class="italic_yellow">Scholarship Program</span> Application</h1>
  </section>

  <section class="form">
    <div class="stepper">
      <div class="step0 active">
        <div class="pair">
          <div class="circle">
            <h6>1</h6>
          </div>
          <h5>Introduction</h5>
        </div>
        <div class="line"></div>
      </div>

      <div class="step1 active">
        <div class="pair">
          <div class="circle">
            <h6>2</h6>
          </div>
          <h5>Personal Information</h5>
        </div>
        <div class="line"></div>
      </div>

      <div class="step2 inactive">
        <div class="pair">
          <div class="circle">
            <h6>3</h6>
          </div>
          <h5>Academic Information</h5>
        </div>
        <div class="line"></div>
      </div>

      <div class="step3 inactive">
        <div class="pair">
          <div class="circle">
            <h6>4</h6>
          </div>
          <h5>Family Background</h5>
        </div>
        <div class="line"></div>
      </div>

      <div class="step4 active">
        <div class="pair">
          <div class="circle">
            <h6>5</h6>
          </div>
          <h5>Address Information</h5>
        </div>
        <div class="line"></div>
      </div>

      <div class="step5 inactive">
        <div class="pair">
          <div class="circle">
            <h6>6</h6>
          </div>
          <h5>Special Group</h5>
        </div>
        <div class="line"></div>
      </div>

      <div class="step6 inactive">
        <div class="pair">
          <div class="circle">
            <h6>7</h6>
          </div>
          <h5>Terms & Conditions</h5>
        </div>
      </div>
    </div>
    <form id="application_form" class="application_form" method="POST" action="/application/store" enctype="multipart/form-data"> 
      <?php echo csrf_field(); ?> 

      <!-- INTRODUCTION -->
      <div class="step">
        <div class="form_header">
          <div class="left">
            <span class="material-icons-round">description</span>
            <h4>Introduction</h4>
          </div>
          <div class="buttons buttons">
            <button type="button" class="add yellow_btn next">Next</button>
          </div>
        </div>

        <!-- INSTRUCTIONS -->
        <div class="group">
          <div class="title">
            <h5>Instructions :</h5>
          </div>
          <div class="content">
            <p><span class="bold italic">1.</span> Read Eligibility and Documentary Requirements.<br>
              <span class="bold italic">2.</span> Fill in all the required information.<br>
              <span class="bold italic">3.</span> Do not leave an item blank. If item is not applicable, indicate "<span class="bold ">NA</span>".<br>
              <span class="bold italic">4.</span> You may return to previous steps and your inputs will not be removed in the succeeding steps. However, all inputs entered will disappear if the page is reloaded.<br>
            </p>
          </div>
        </div>

        <!-- CRITERIA OF ELIGIBILITY -->
        <div class="group">
          <div class="title">
            <h5>Eligibility Requirements:</h5>
          </div>
          <div class="content">
            <p><span class="bold italic">1.</span> Filipino Citizen<br>
              <span class="bold italic">2.</span> Graduating high school student or high school graduate<br>
              <span class="bold italic">3.</span> General Weighted Average (GWA) of atleast 93% or above<br>
              <span class="bold italic">4.</span> Combined annual gross income of parents/guardians not to exceed Four Hundred Thousand (PHP 400,000.00) or solo parent/guardian whose annual gross income does not exceed the said amount;<br>
              <span class="italic">In highly exceptional cases where income exceeds PHP 400,000.00, the CHEDRO StuFAPs Committee shall determine the merits of the application</span><br>
              <span class="bold italic">5.</span> Avail of only one government-funded financial assistance program
            </p>
          </div>
        </div>

        <!-- CRITERIA OF ELIGIBILITY -->
        <div class="group">
          <div class="title">
            <h5>Documentary Requirements:</h5>
          </div>
          <div class="content">
            <p><span class="bold italic">1.</span> Personal Identification :<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> Duly certified true copy of birth certificate<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> 2x2 ID Photo<br>
              <span class="bold italic">2.</span> Academic Requirements - <span class="italic">any one of the following:</span><br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> For SHS graduates, duly certified true copy of G12 grade<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> For graduating SHS students, duly certified true copy of grades for Grade 11 and 1st semester of Grade 12<br>
              <span class="bold italic">3.</span> Income Requirements - <span class="italic">any one of the following:</span><br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> Latest ITR of parents or guardian if employed<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> Certificate of Tax Exemption from the BIR<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">c.</span> Certificate of Indigency from their Barangay<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">d.</span> Certificate/Case Study from DSWD<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">e.</span> Latest copy of contract or proof of income for children of Overseas Filipino Workers (OFW) and seafarers<br>
              <span class="bold italic">4.</span> Others :</span><br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> Certificate of Indigency for indigenous and ethnic peoples<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> PWD ID for persons with disabilities<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">c.</span> Senior Citizen ID for dependents of senior citizens<br>
              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">d.</span> Solo Parent ID for dependents of solo parents<br>
            </p>
          </div>
        </div>
      </div>

      <!-- PERSONAL INFORMATION -->
      <div class="step">
        <div class="form_header">
          <div class="left">
            <span class="material-icons-round">person</span>
            <h4>Personal Information</h4>
          </div>
          <div class="buttons buttons">
            <button type="button" class="add yellow_btn prev">Previous</button>
            <button type="button" class="add yellow_btn next">Next</button>
          </div>
        </div>

        <!-- PERSONAL DETAILS -->
        <div class="group">
          <div class="title">
            <h5>Personal Details</h5>
          </div>
          <div class="pairs">
            <!-- FIRST NAME -->
            <div class="pair">
              <label for="name_first">First Name :</label>
              <input id="name_first" type="text" name="name_first" placeholder="Enter first name" required>
            </div>

            <!-- MIDDLE NAME -->
            <div class="pair">
              <label for="name_middle">Middle Name :</label>
              <input id="name_middle" type="text" name="name_middle" placeholder="Enter middle name" required>
            </div>

            <!-- LAST NAME -->
            <div class="pair">
              <label for="name_last">Last Name :</label>
              <input id="name_last" type="text" name="name_last" placeholder="Enter last name" required>
            </div>

            <!-- EXTENSION NAME -->
            <div class="pair">
              <label for="name_ext">Extension Name :</label>
              <input id="name_ext" type="text" name="name_ext" placeholder="Enter extension name" >
            </div>

            <!-- EXTENSION NAME -->
            <div class="pair">
              <label for="name_maiden">Maiden Name <span class="optional">(For Married Women)</span> :</label>
              <input id="name_maiden" type="text" name="name_maiden" placeholder="Enter maiden name" >
            </div>

            <!-- BIRTHDATE -->
            <div class="pair">
              <label for="birthday">Date of Birth <span class="optional">(dd/mm/yyyy)</span> :</label>
              <input id="birthday" type="text" onfocus="(this.type='date')" name="birthday" placeholder="Enter date of birth" required>
            </div>

            <!-- BIRTHPLACE -->
            <div class="pair">
              <label for="birthplace">Place of Birth <span class="optional">(City/Province)</span> :</label>
              <input type="text" name="birthplace" placeholder="E.g. Baguio City, Benguet" required>
            </div>

            <!-- SEX -->
            <div class="pair">
              <label for="sex">Sex :</label>
              <select name="sex" required>
                <option value="" disabled selected hidden>Select a sex</option>
                <option value="M">Male</option>
                <option value="F">Female</option>
              </select>
            </div>

            <!-- CIVIL STATUS -->
            <div class="pair">
              <label for="civil_status">Civil Status :</label>
              <select name="civil_status" required>
                <option value="" disabled selected hidden>Select a civil status</option>
                <option value="Single">Single</option>
                <option value="Married">Married</option>
                <option value="Annulled">Annulled</option>
                <option value="Widowed">Widowed</option>
                <option value="Separated">Separated</option>
                <option value="Others">Others</option>
              </select>
            </div>

            <!-- CITIZENSHIP -->
            <div class="pair">
              <label for="citizenship">Citizenship :</label>
              <input type="text" name="citizenship" placeholder="Enter citizenship" required>
            </div>
          </div>
        </div>

        <!-- CONTACT DETAILS -->
        <div class="group">
          <div class="title">
            <h5>Contact Details</h5>
          </div>

          <div class="pairs">
            <!-- EMAIL ADDRESS -->
            <div class="pair">
              <label for="email_address">Email Address :</label>
              <input type="email" name="email_address" placeholder="Enter email address" required>
            </div>

            <!-- CONTACT NUMBER -->
            <div class="pair">
              <label for="contact_number">Mobile Number :</label>
              <input type="text" name="contact_number" data-parsley-validate-contact="" placeholder="E.g. 0999-999-9999" required>
            </div>

            <!-- FACEBOOK -->
            <div class="pair">
              <label for="fb_account">Facebook Name or Username :</label>
              <input type="text" name="fb_account" placeholder="Enter Facebook name or username" required>
            </div>
          </div>
        </div>

        <!-- PERSONAL IDENTIFICATION -->
        <div class="group">
          <div class="title">
            <h5>Personal Identification</h5>
          </div>

          <div class="pairs">
            <!-- BIRTH CERTIFICATE -->
            <div class="pair">
              <label for="birth_cert">Birth Certificate <span class="optional">(Image or PDF)</span> :</label>
              <input type="file" name="birth_cert" placeholder="Upload birth certificate" accept="image/png, image/jpeg, application/pdf" required>
            </div>

            <!-- ID PHOTO -->
            <div class="pair">
              <label for="id_photo">2x2 ID Photo <span class="optional">(Image)</span> :</label>
              <input type="file" id="id_photo" name="id_photo" placeholder="Upload ID picture" data-parsley-validate-photo="" accept="image/png, image/jpeg" >
            </div>
          </div>
        </div>
      </div>

      <!-- ACADEMIC INFORMATION -->
      <div class="step">
        <div class="form_header"> 
          <div class="left">
            <span class="material-icons-round">school</span>
            <h4>Academic Information</h4>
          </div>
          <div class="buttons buttons">
            <button type="button" class="add yellow_btn prev">Previous</button>
            <button type="button" class="add yellow_btn next">Next</button>
          </div>
        </div>

        <!-- PREVIOUS SCHOOL -->
        <div class="group">
          <div class="title">
            <h5>Last School Attended</h5>
          </div>
          <div class="pairs">
            <!-- HIGH SCHOOL -->
            <div class="pair">
              <label for="highschool">School Name :</label>
              <input type="text" name="highschool" placeholder="Enter name of school" required>
            </div>

            <!-- SCHOOL ADDRESS -->
            <div class="pair">
              <label for="highschool_add">School Address :</label>
              <input type="text" name="highschool_add" placeholder="Enter address of school" required>
            </div>

            <!-- SCHOOL SECTOR -->
            <div class="pair">
              <label for="highschool_sector">School Sector :</label>
              <select name="highschool_sector" required>
                <option value="" disabled selected hidden>Select a sector</option>
                <option value="Private">Private</option>
                <option value="Public">Public</option>
              </select>
            </div>

            <!-- APPLICANT TYPE -->
            <div class="pair">
              <label for="type">Applicant type :</label>
              <select id="type" name="type" required>
                <option value="" disabled selected hidden>Select an applicant type</option>
                <option value="Graduate">Senior/High School Graduate</option>
                <option value="Graduating">Graduating Senior High</option>
              </select>
            </div>
          </div>
        </div>

        <!-- GWA -->
        <div class="group gwa_container">
          <div class="title">
            <h5>General Weighted Averages (GWAs)</h5>
          </div>
          <label class="info italic">Please provide the GWAs for the semesters that you were able to finish. The third semester is only applicable for schools with a trimester system.</label>
          <div class="pairs">
            <!-- GRADE 12 GWA -->
            <div id="twelve_gwa_container" class="pair">
              <label id="twelve_gwa_label" for="twelve_gwa">Grade 12 GWAs :</label>
              <div class="grades">
                <div class="pair">
                  <label for="twelve_gwa_1">1st Sem :</label>
                  <input id="twelve_gwa_1" type="text" name="twelve_gwa_1" placeholder="GWA"data-parsley-validate-grade="" required>
                </div>
                <div class="pair">
                  <label for="twelve_gwa_2">2nd Sem :</label>
                  <input id="twelve_gwa_2" type="text" name="twelve_gwa_2" placeholder="GWA"data-parsley-validate-grade-nullable="" required>
                </div>
                <div class="pair">
                  <label for="twelve_gwa_3">3rd Sem :</label>
                  <input id="twelve_gwa_3" type="text" name="twelve_gwa_3" placeholder="GWA"data-parsley-validate-grade-nullable="">
                </div>
              </div>
            </div>

            <!-- GRADE 11 GWA -->
            <div id="eleven_gwa_container" class="pair">
              <label for="eleven_gwa">Grade 11 GWAs :</label>
              <div class="grades">
                <div class="pair">
                  <label for="eleven_gwa_1">1st Sem :</label>
                  <input id="eleven_gwa_1" type="text" name="eleven_gwa_1" placeholder="GWA"data-parsley-validate-grade="">
                </div>
                <div class="pair">
                  <label for="eleven_gwa_2">2nd Sem :</label>
                  <input id="eleven_gwa_2" type="text" name="eleven_gwa_2" placeholder="GWA"data-parsley-validate-grade="">
                </div>
                <div class="pair">
                  <label for="eleven_gwa_3">3rd Sem :</label>
                  <input id="eleven_gwa_3" type="text" name="eleven_gwa_3" placeholder="GWA"data-parsley-validate-grade-nullable="">
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- ACADEMIC REQUIREMENTS -->
        <div id="report_cards_container" class="group">
          <div class="title">
            <h5>Academic Requirements</h5>
          </div>
          <label class="info italic">Please make sure that the grades are visible as proof that the GWAs entered are valid.</label>

          <div class="pairs">
            <!-- GRADE 12 CARD -->
            <div class="pair">
              <label id="twelve_card_label" for="twelve_card">G12 Grades</label>
              <input type="file" name="twelve_card" accept="image/png, image/jpeg, application/pdf" required>
            </div>

            <!-- GRADE 11 CARD -->
            <div id="eleven_card_container" class="pair">
              <label for="eleven_card">Certified Grades for G11 <span class="optional">(Image or PDF)</span> :</label>
              <input id="eleven_card" type="file" name="eleven_card" accept="image/png, image/jpeg, application/pdf">
            </div>
          </div>
        </div>

        <!-- FUTURE SCHOOL -->
        <div class="group">
          <div class="title">
            <h5>School Intended to Enroll or Enrolled In</h5>
            <div class="checkbox">
              <input type="checkbox" id="hei_is_car" name="hei_is_car" checked>
              <label for="hei_is_car" style="white-space: nowrap;">Within CAR</label>
            </div>
          </div>
          <div class="pairs">

            <!-- INSTITUTION -->
            <div class="pair hei_inside_car">
              <label for="institution_id">School Name :</label>
              <select name="institution_id" required>
                <option value="" disabled selected hidden>Select a school</option>
                <?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>o
                <option value="<?php echo e($institution->id); ?>" data-sector="<?php echo e($institution->sector); ?>" data-address="<?php echo e($institution->address); ?>"><?php echo e($institution->institution_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <!-- WITHIN CAR - SCHOOL NAME -->
            <div class="pair hei_outside_car">
              <label for="hei_out_car_name">School Name :</label>
              <input id="hei_out_car_name" type="text" name="hei_out_car_name" placeholder="Enter name of school">
            </div>

            <!-- OUTSIDE CAR - ADDRESS -->
            <div class="pair hei_outside_car">
              <label for="hei_out_car_address">School Address :</label>
              <input id="hei_out_car_address" type="text" name="hei_out_car_address" placeholder="Enter address of school">
            </div>

            <!-- OUTSIDE CAR - SCHOOL SECTOR -->
            <div class="pair hei_outside_car">
              <label for="hei_out_car_sector">School Sector :</label>
              <select id="hei_out_car_sector" name="hei_out_car_sector">
                <option value="" disabled selected hidden>Select a sector</option>
                <option value="Private">Private</option>
                <option value="Public">Public</option>
              </select>
            </div>

            <!-- COURSE -->
            <div class="pair">
              <label for="course_id">Degree Program :</label>
              <select name="course_id" required id="course">
                <option value="" disabled selected hidden>Select a degree program</option>
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($course->id); ?>" data-priority="<?php echo e($course->cmo_2019); ?>"><?php echo e($course->course_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
        </div>

        <!-- OTHER SOURCES OF ASSISTANCE -->
        <div class="group">
          <div class="title">
            <h5>Are you enjoying other source of educational or financial assistance?</h5>
            <div class="radios">
              <div class="radio">
                <input type="radio" name="has_other_fa" class="has_other_fa" value="1">
                <label for="1">Yes</label>
              </div>
              <div class="radio">
                <input type="radio" name="has_other_fa" class="has_other_fa" value="0" checked>
                <label for="0">No</label>
              </div>
            </div>
          </div>

          <input type="hidden" id="other_fa_count" name="other_fa_count" value="1">

          <div class="other_fa_container">
            <div class="pairs other_fa">
              <div class="title title_first_fa">
                <h5>First Source of Assistance</h5>
              </div>
              <div class="title_first_fa"></div>

              <!-- AGENCY -->
              <div class="pair">
                <label for="other_fa_agency">Grantee Institution or Agency :</label>
                <input type="text" name="other_fa_agency" placeholder="Enter grantee institution or agency">
              </div>

              <!-- TYPE -->
              <div class="pair">
                <label for="other_fa_type">Type of Scholarship :</label>
                <input type="text" name="other_fa_type" placeholder="Enter type of scholarship">
              </div>
            </div>

            <div class="add_second_fa">
              <button type="button" class="add">Add another source of assistance</button>
            </div>

            <div class="pairs other_fa2">
              <div class="title">
                <h5>Second Source of Assistance</h5>
              </div>
              <div></div>

              <!-- AGENCY -->
              <div class="pair">
                <label for="other_fa_agency2">Grantee Institution or Agency :</label>
                <input type="text" name="other_fa_agency2" placeholder="Enter grantee institution or agency">
              </div>

              <!-- TYPE -->
              <div class="pair">
                <label for="other_fa_type2">Type of Scholarship :</label>
                <input type="text" name="other_fa_type2" placeholder="Enter type of scholarship">
              </div>
            </div>

            <div class="remove_second_fa">
              <button type="button" class="add">Remove second source of assistance</button>
            </div>
          </div>
        </div>
      </div>

      <!-- FAMILY BACKGROUND -->
      <div class="step">
        <div class="form_header">
          <div class="left">
            <span class="material-icons-round">family_restroom</span>
            <h4>Family Background</h4>
          </div>
          <div class="buttons buttons">
            <button type="button" class="add yellow_btn prev">Previous</button>
            <button type="button" class="add yellow_btn next">Next</button>
          </div>
        </div>

        <!-- FATHER -->
        <div class="group">
          <div class="title">
            <h5>Father</h5>
            <div class="checkboxes">
              <label for="f_is_deceased">Deceased</label>
              <div class="toggle">
                <label class="switch">
                  <input type="checkbox" name="f_is_deceased" id="f_is_deceased">
                  <span class="slider round"></span>
                </label>
              </div>
            </div>
          </div>

          <div class="pairs">
            <!-- FULL NAME -->
            <div class="pair">
              <label for="f_name">Full Name :</label>
              <input type="text" name="f_name" placeholder="Enter full name" required>
            </div>

            <!-- ADDRESS -->
            <div class="pair f_deceased_container">
              <label for="f_add">Address <span class="optional">(City & Province)</span> :</label>
              <input type="text" name="f_add" placeholder="E.g. Baguio City, Benguet" required>
            </div>

            <!-- CONTACT NUMBER -->
            <div class="pair f_deceased_container">
              <label for="f_contact_no">Contact Number :</label>
              <input type="text" name="f_contact_no" data-parsley-validate-contact="" placeholder="E.g. 0999-999-9999" required>
            </div>

            <!-- OCCUPATION -->
            <div class="pair f_deceased_container">
              <label for="f_occupation">Occupation :</label>
              <input type="text" name="f_occupation" placeholder="Enter occupation" required>
            </div>

            <!-- NAME OF EMPLOYER -->
            <div class="pair f_deceased_container">
              <label for="f_employer">Name of Employer :</label>
              <input type="text" name="f_employer" placeholder="Enter name of employer" required>
            </div>

            <!-- EMPLOYER ADDRESS -->
            <div class="pair f_deceased_container">
              <label for="f_employer_add">Employer Address <span class="optional">(City & Province)</span> :</label>
              <input type="text" name="f_employer_add" placeholder="E.g. Baguio City, Benguet" required>
            </div>

            <!-- HIGHEST EDUCATIONAL ATTAINMENT -->
            <div class="pair f_deceased_container">
              <label for="f_education">Highest Educational Attainment :</label>
              <select name="f_education" required>
                <option value="" disabled selected hidden>Select educational attainment</option>
                <option value="N/A">N/A</option>
                <option value="No Grade Completed">No Grade Completed</option>
                <option value="Elementary Undergraduate">Elementary Undergraduate</option>
                <option value="Elementary Graduate">Elementary Graduate</option>
                <option value="High School Undergraduate">High School Undergraduate</option>
                <option value="High School Graduate">High School Graduate</option>
                <option value="Post Secondary Undergraduate">Post Secondary Undergraduate</option>
                <option value="Post Secondary Graduate">Post Secondary Graduate</option>
                <option value="College Undergraduate">College Undergraduate</option>
                <option value="College Graduate">College Graduate</option>
                <option value="Post Baccalaureate">Post Baccalaureate</option>
              </select>
            </div>
          </div>
        </div>

        <!-- MOTHER -->
        <div class="group">
          <div class="title">
            <h5>Mother</h5>
            <div class="checkboxes">
              <label for="m_is_deceased">Deceased</label>
              <div class="toggle">
                <label class="switch">
                  <input type="checkbox" name="m_is_deceased" id="m_is_deceased">
                  <span class="slider round"></span>
                </label>
              </div>
            </div>
          </div>

          <div class="pairs">
            <!-- FULL NAME -->
            <div class="pair">
              <label for="m_name">Full Name :</label>
              <input type="text" name="m_name" placeholder="Enter full name" required>
            </div>

            <!-- ADDRESS -->
            <div class="pair m_deceased_container">
              <label for="m_add">Address <span class="optional">(City & Province)</span> :</label>
              <input type="text" name="m_add" placeholder="E.g. Baguio City, Benguet" required>
            </div>

            <!-- CONTACT NUMBER -->
            <div class="pair m_deceased_container">
              <label for="m_contact_no">Contact Number :</label>
              <input type="text" name="m_contact_no" data-parsley-validate-contact="" placeholder="E.g. 0999-999-9999" required>
            </div>

            <!-- OCCUPATION -->
            <div class="pair m_deceased_container">
              <label for="m_occupation">Occupation :</label>
              <input type="text" name="m_occupation" placeholder="Enter occupation" required>
            </div>

            <!-- NAME OF EMPLOYER -->
            <div class="pair m_deceased_container">
              <label for="m_employer">Name of Employer :</label>
              <input type="text" name="m_employer" placeholder="Enter name of employer" required>
            </div>

            <!-- EMPLOYER ADDRESS -->
            <div class="pair m_deceased_container">
              <label for="m_employer_add">Employer Address <span class="optional">(City & Province)</span> :</label>
              <input type="text" name="m_employer_add" placeholder="E.g. Baguio City, Benguet" required>
            </div>

            <!-- HIGHEST EDUCATIONAL ATTAINMENT -->
            <div class="pair m_deceased_container">
              <label for="m_education">Highest Educational Attainment :</label>
              <select name="m_education" required>
                <option value="" disabled selected hidden>Select educational attainment</option>
                <option value="N/A">N/A</option>
                <option value="No Grade Completed">No Grade Completed</option>
                <option value="Elementary Undergraduate">Elementary Undergraduate</option>
                <option value="Elementary Graduate">Elementary Graduate</option>
                <option value="High School Undergraduate">High School Undergraduate</option>
                <option value="High School Graduate">High School Graduate</option>
                <option value="Post Secondary Undergraduate">Post Secondary Undergraduate</option>
                <option value="Post Secondary Graduate">Post Secondary Graduate</option>
                <option value="College Undergraduate">College Undergraduate</option>
                <option value="College Graduate">College Graduate</option>
                <option value="Post Baccalaureate">Post Baccalaureate</option>
              </select>
            </div>
          </div>
        </div>

        <!-- LEGAL GUARDIAN -->
        <div class="group">
          <div class="title">
            <div class="radios">
              <h5>Do you have a legal guardian?</h5>
              <div class="radio">
                <input type="radio" name="has_legal_guardian" class="has_legal_guardian" value="1">
                <label for="1">Yes</label>
              </div>
              <div class="radio">
                <input type="radio" name="has_legal_guardian" class="has_legal_guardian" value="0" checked>
                <label for="0">No</label>
              </div>
            </div>
          </div>
          <div id="legal_guardian_container" class="pairs">
            <!-- FULL NAME -->
            <div class="pair">
              <label for="g_name">Full Name :</label>
              <input type="text" name="g_name" placeholder="Enter full name">
            </div>

            <!-- ADDRESS -->
            <div class="pair">
              <label for="g_add">Address <span class="optional">(City & Province)</span> :</label>
              <input type="text" name="g_add" placeholder="E.g. Baguio City, Benguet">
            </div>

            <!-- CONTACT NUMBER -->
            <div class="pair">
              <label for="g_contact_no">Contact Number :</label>
              <input type="text" name="g_contact_no" data-parsley-validate-contact="" placeholder="E.g. 0999-999-9999">
            </div>

            <!-- OCCUPATION -->
            <div class="pair">
              <label for="g_occupation">Occupation :</label>
              <input type="text" name="g_occupation" placeholder="Enter occupation">
            </div>

            <!-- NAME OF EMPLOYER -->
            <div class="pair">
              <label for="g_employer">Name of Employer :</label>
              <input type="text" name="g_employer" placeholder="Enter name of employer">
            </div>

            <!-- EMPLOYER ADDRESS -->
            <div class="pair">
              <label for="g_employer_add">Employer Address <span class="optional">(City & Province)</span> :</label>
              <input type="text" name="g_employer_add" placeholder="E.g. Baguio City, Benguet">
            </div>

            <!-- HIGHEST EDUCATIONAL ATTAINMENT -->
            <div class="pair">
              <label for="g_education">Highest Educational Attainment :</label>
              <select name="g_education">
                <option value="" disabled selected hidden>Select educational attainment</option>
                <option value="N/A">N/A</option>
                <option value="No Grade Completed">No Grade Completed</option>
                <option value="Elementary Undergraduate">Elementary Undergraduate</option>
                <option value="Elementary Graduate">Elementary Graduate</option>
                <option value="High School Undergraduate">High School Undergraduate</option>
                <option value="High School Graduate">High School Graduate</option>
                <option value="Post Secondary Undergraduate">Post Secondary Undergraduate</option>
                <option value="Post Secondary Graduate">Post Secondary Graduate</option>
                <option value="College Undergraduate">College Undergraduate</option>
                <option value="College Graduate">College Graduate</option>
                <option value="Post Baccalaureate">Post Baccalaureate</option>
              </select>
            </div>
          </div>
        </div>

        <!-- FAMILY -->
        <div class="group">
          <div class="title">
            <h5>Family</h5>
          </div>
          <div class="pairs">
            <!-- NUMBER OF SIBLINGS -->
            <div class="pair">
              <label for="siblings">Number of siblings in the family 18 years old and below :</label>
              <input type="number" name="siblings" placeholder="Enter number of siblings" required>
            </div>

            <!-- ANNUAL GROSS INCOME -->
            <div class="pair">
              <label for="annual_gross_income">Annual gross income of parent(s) or guardian :</label>
              <input type="number" name="annual_gross_income" placeholder="Enter annual gross income" required>
            </div>
          </div>
        </div>

        <!-- INCOME REQUIREMENT -->
        <div class="group">
          <div class="title">
            <h5>Income Requirement</h5>
          </div>

          <div class="pairs">
            <!-- TYPE OF INCOME REQUIREMENT -->
            <div class="pair">
              <label for="income_proof_type">Type of Income Requirement :</label>
              <select id="income_proof_type" name="income_proof_type" required>
                <option value="" disabled selected hidden>Select type of income requirement</option>
                <option value="Income Tax Return">Latest ITR of parents or guardian if employed</option>
                <option value="Tax Exemption">Certificate of Tax Exemption from the BIR</option>
                <option value="Certificate of Indigency">Certificate of Indigency from the Barangay</option>
                <option value="Case Study DSWD">Certificate or Case Study from DSWD</option>
                <option value="OFW Contract">Latest copy of contract or proof of income for children of OFWs and seafarers</option>
              </select>
            </div>

            <!-- INCOME REQUIREMENT FILE -->
            <div id="income_proof_container" class="pair">
              <label id="income_proof_label" for="income_proof"></label>
              <input type="file" name="income_proof" accept="image/png, image/jpeg, application/pdf" required>
            </div>
          </div>
        </div>

        <!-- DSWD 4PS -->
        <div class="group">
          <div class="title">
            <h5>Is your family a beneficiary of the DSWD's Pantawid Pamilyang Pilipino Program (4Ps)?</h5>
            <div class="radios">
              <div class="radio">
                <input type="radio" name="is_dswd_4ps" value="1">
                <label for="1">Yes</label>
              </div>
              <div class="radio">
                <input type="radio" name="is_dswd_4ps" value="0" checked>
                <label for="0">No</label>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- ADDRESS INFORMATION -->
      <div class="step">
        <div class="form_header">
          <div class="left">
            <span class="material-icons-round">place</span>
            <h4>Address Information</h4>
          </div>
          <div class="buttons buttons">
            <button type="button" class="add yellow_btn prev">Previous</button>
            <button type="button" class="add yellow_btn next">Next</button>
          </div>
        </div>

        <!-- PERMANENT ADDRESS -->
        <div class="group">
          <div class="title">
            <h5>Permanent Address</h5>
            <div class="checkbox">
              <input type="checkbox" id="perm_add_is_car" name="perm_add_is_car" checked>
              <label for="perm_add_is_car">Within CAR</label>
            </div>
          </div>

          <div class="pairs">
            <!-- INSIDE CAR -->

            <!-- DISTRICT -->
            <div class="pair inside_car">
              <label for="perm_district">District :</label>
              <select id="perm_district" name="perm_district" required>
                <option value="" disabled selected hidden>Select a district</option>
                <option value="Abra">Abra</option>
                <option value="Apayao">Apayao</option>
                <option value="Baguio">Baguio</option>
                <option value="Benguet">Benguet</option>
                <option value="Ifugao">Ifugao</option>
                <option value="Kalinga">Kalinga</option>
                <option value="Mountain Province">Mountain Province</option>
              </select>
            </div>

            <!-- PROVINCE -->
            <div class="pair inside_car">
              <label for="perm_province">Province :</label>
              <select id="perm_province" name="perm_province" required>
                <option value="" disabled selected hidden>Select a province</option>
                <option value="Abra">Abra</option>
                <option value="Apayao">Apayao</option>
                <option value="Benguet">Benguet</option>
                <option value="Ifugao">Ifugao</option>
                <option value="Kalinga">Kalinga</option>
                <option value="Mountain Province">Mountain Province</option>
              </select>
            </div>

            <!-- MUNICIPALITY OR CITY -->
            <div class="pair inside_car">
              <label for="perm_muni_city">Municipality or City :</label>
              <select id="perm_muni_city" name="perm_muni_city" required>
                <option value="" disabled selected hidden>Please select a province first</option>
              </select>
            </div>

            <!-- OUTSIDE CAR -->

            <!-- DISTRICT -->
            <div class="pair outside_car">
              <label for="perm_district2">District :</label>
              <input id="perm_district2" type="text" name="perm_district2" placeholder="Enter district">
            </div>

            <!-- PROVINCE -->
            <div class="pair outside_car">
              <label for="perm_province2">Province :</label>
              <input id="perm_province2" type="text" name="perm_province2" placeholder="Enter province">
            </div>

            <!-- MUNICIPALITY OR CITY -->
            <div class="pair outside_car">
              <label for="perm_muni_city2">Municipality or City :</label>
              <input id="perm_muni_city2" type="text" name="perm_muni_city2" placeholder="Enter municipality or city">
            </div>

            <!-- BARANGAY -->
            <div class="pair">
              <label for="perm_barangay">Street, Barangay :</label>
              <input type="text" name="perm_barangay" placeholder="Enter barangay and other details" required>
            </div>

            <!-- ZIP CODE -->
            <div class="pair">
              <label for="perm_zip_code">Zip Code :</label>
              <input type="number" name="perm_zip_code" placeholder="Enter zip code" required>
            </div>
          </div>
        </div>

        <!-- PRESENT ADDRESS -->
        <div class="group">
          <div class="title title_tight">
            <h5>Present Address</h5>
            <div class="checkboxes">
              <div class="checkbox checkbox_pres_add">
                <input type="checkbox" id="pres_add_is_car" name="pres_add_is_car" checked>
                <label for="pres_add_is_car">Within CAR</label>
              </div>
              <div class="checkbox">
                <input type="checkbox" id="pres_is_perm" name="pres_is_perm">
                <label for="pres_is_perm">Same with Permanent Address</label>
              </div>
            </div>
          </div>

          <div class="pairs pres_add">
            <!-- INSIDE CAR -->

            <!-- DISTRICT -->
            <div class="pair inside_car2">
              <label for="pres_district">District :</label>
              <select id="pres_district" name="pres_district" required>
                <option value="" disabled selected hidden>Select a district</option>
                <option value="Abra">Abra</option>
                <option value="Apayao">Apayao</option>
                <option value="Baguio">Baguio</option>
                <option value="Benguet">Benguet</option>
                <option value="Ifugao">Ifugao</option>
                <option value="Kalinga">Kalinga</option>
                <option value="Mountain Province">Mountain Province</option>
              </select>
            </div>

            <!-- PROVINCE -->
            <div class="pair inside_car2">
              <label for="pres_province">Province :</label>
              <select id="pres_province" name="pres_province" required>
                <option value="" disabled selected hidden>Select a province</option>
                <option value="Abra">Abra</option>
                <option value="Apayao">Apayao</option>
                <option value="Benguet">Benguet</option>
                <option value="Ifugao">Ifugao</option>
                <option value="Kalinga">Kalinga</option>
                <option value="Mountain Province">Mountain Province</option>
              </select>
            </div>

            <!-- MUNICIPALITY OR CITY -->
            <div class="pair inside_car2">
              <label for="pres_muni_city">Municipality or City :</label>
              <select id="pres_muni_city" name="pres_muni_city" required>
                <option value="" disabled selected hidden>Please select a province first</option>
              </select>
            </div>

            <!-- OUTSIDE CAR -->

            <!-- DISTRICT -->
            <div class="pair outside_car2">
              <label for="pres_district2">District :</label>
              <input id="pres_district2" type="text" name="pres_district2" placeholder="Enter district">
            </div>

            <!-- PROVINCE -->
            <div class="pair outside_car2">
              <label for="pres_province2">Province :</label>
              <input id="pres_province2" type="text" name="pres_province2" placeholder="Enter province">
            </div>

            <!-- MUNICIPALITY OR CITY -->
            <div class="pair outside_car2">
              <label for="pres_muni_city2">Municipality or City :</label>
              <input id="pres_muni_city2" type="text" name="pres_muni_city2" placeholder="Enter municipality or city">
            </div>

            <!-- BARANGAY -->
            <div class="pair">
              <label for="pres_barangay">Street, Barangay :</label>
              <input type="text" name="pres_barangay" placeholder="Enter barangay and other details" required>
            </div>

            <!-- ZIP CODE -->
            <div class="pair">
              <label for="pres_zip_code">Zip Code :</label>
              <input type="number" name="pres_zip_code" placeholder="Enter zip code" required>
            </div>
          </div>
        </div>
      </div>

      <!-- SPECIAL GROUP -->
      <div class="step">
        <div class="form_header">
          <div class="left">
            <span class="material-icons-round">group</span>
            <h4>Special Group</h4>
          </div>
          <div class="buttons buttons">
            <button type="button" class="add yellow_btn prev">Previous</button>
            <button type="button" class="add yellow_btn next">Next</button>
          </div>
        </div>

        <!-- IP -->
        <div class="group">
          <div class="title">
            <h5>Indigenous and Ethnic Peoples</h5>
            <div class="toggle">
              <label class="switch">
                <input type="checkbox" name="is_ip" id="is_ip">
                <span class="slider round"></span>
              </label>
            </div>
          </div>

          <div id="tribe_container" class="pairs">
            <!-- TRIBE MEMBERSHIP -->
            <div class="pair">
              <label for="tribe">Tribe Membership :</label>
              <input id="tribe_input" type="text" name="tribe" placeholder="Enter tribe membership">
            </div>

            <!-- CERTIFICATION -->
            <div class="pair">
              <label for="cert_indigency">Certificate from NCIP <span class="optional">(Image or PDF)</span> :</label>
              <input id="cert_indigency" type="file" name="cert_indigency" accept="image/png, image/jpeg, application/pdf">
            </div>
          </div>
        </div>

        <!-- PWD -->
        <div class="group">
          <div class="title">
            <h5>Persons with Disabilities</h5>
            <div class="toggle">
              <label class="switch">
                <input type="checkbox" name="is_pwd" id="is_pwd">
                <span class="slider round"></span>
              </label>
            </div>
          </div>

          <div id="disability_container" class="pairs">
            <!-- PWD ID -->
            <div class="pair">
              <label for="pwd_id">PWD ID <span class="optional">(Image or PDF)</span> :</label>
              <input id="pwd_id" type="file" name="pwd_id" accept="image/png, image/jpeg, application/pdf">
            </div>

            <!-- TYPE OF DISABILITY -->
            <div id="disability_select_container" class="pair">
              <label for="disability">Type of Disability :</label>
              <select id="disability_select" name="disability">
                <option value="" selected disabled hidden>Select type of disability</option>
                <option value="CD">Communication Disability</option>
                <option value="DCI">Disability due to Chronic Illness</option>
                <option value="LD">Learning Disability</option>
                <option value="ID">Intellectual Disability</option>
                <option value="OD">Orthopedic Disability</option>
                <option value="MPD">Mental/Psychosocial Disability</option>
                <option value="VD">Visual Disability</option>
                <option value="Others">Others</option>
              </select>
            </div>

            <!-- SPECIFIC DISABILITY -->
            <div id="disability_input_container" class="pair">
              <label for="disability_others">Please Specify :</label>
              <input id="disability_input" type="text" name="disability_others" placeholder="Enter disability">
            </div>
          </div>
        </div>

        <!-- SENIOR CITIZEN -->
        <div class="group">
          <div class="title">
            <h5>Dependent of Senior Citizen</h5>
            <div class="toggle">
              <label class="switch">
                <input type="checkbox" name="is_sc" id="is_sc">
                <span class="slider round"></span>
              </label>
            </div>
          </div>

          <div id="sc_container" class="pairs">
            <!-- SC ID -->
            <div class="pair">
              <label for="sc_id">Senior Citizen ID of Parent or Guardian <span class="optional">(Image or PDF)</span> :</label>
              <input id="sc_id" type="file" name="sc_id" accept="image/png, image/jpeg, application/pdf">
            </div>
          </div>
        </div>

        <!-- SOLO PARENT -->
        <div class="group">
          <div class="title">
            <h5>Dependent of Solo Parent</h5>
            <div class="toggle">
              <label class="switch">
                <input type="checkbox" name="is_sp" id="is_sp">
                <span class="slider round"></span>
              </label>
            </div>
          </div>

          <div id="sp_container" class="pairs">
            <!-- SP ID -->
            <div class="pair">
              <label for="sp_id">Solo Parent ID of Parent or Guardian <span class="optional">(Image or PDF)</span> :</label>
              <input id="sp_id" type="file" name="sp_id" accept="image/png, image/jpeg, application/pdf">
            </div>
          </div>
        </div>
      </div>

      <!-- TERMS AND CONDITIONS -->
      <div class="step">
        <div class="form_header">
          <div class="left">
            <span class="material-icons-round">verified_user</span>
            <h4>Terms & Conditions</h4>
          </div>
          <div class="buttons buttons">
            <button type="button" class="add yellow_btn prev">Previous</button>
          </div>
        </div>

        <!-- CRITERIA OF ELIGIBILITY -->
        <div class="group">
          <div class="content" style="margin-top: 0">
            <p>I hereby certify that foregoing statements are true and correct. Any misinformation or witholding of information will automatically disqualify me from the CHED Scholarship Program. I am willing to refund the financial benefits received if such information is discovered after acceptance of the award.<br><br>
            I hereby express my consent for the Commission on Higher Education to collect, record, organize, update or modify, retrieve, consult, use, consolidate, block, erase or destruct my personal data as part of my information. I hereby affirm my right to be informed, object to processing, access and rectify, suspend or withdraw my personal data and be indemnified in case of damages pursuant to the provisions of the Republic Act No. 10173 of the Philippines, Data Privacy Act of 2012 and its corresponding Implementing Rules and Regulations.</p>
          </div>
        </div>
      </div>

      <div class="buttons">
        <button type="button" class="add yellow_btn prev">Previous</button>
        <button type="button" class="add yellow_btn next">Next</button>
        <input id="submit_btn" style="width: auto;" class="add yellow_btn submit" type="submit" value="Download Application Form & Submit">
      </div>
    </form>
  </section>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script type="text/javascript" src="<?php echo e(URL::asset('js/index.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('js/application.js')); ?>"></script>
<script type="text/javascript">
  // SUBMIT
  $('#application_form').on('submit', async function(event) {
    event.preventDefault();
    event.stopImmediatePropagation();
    $('#loading').css('display', 'flex');
    await createPdf();
    $(this).unbind(); 
    $(this).submit();
  });
</script>
</html><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/applications/form.blade.php ENDPATH**/ ?>