<?php $__env->startSection('title'); ?>
CHED-CAR | Scholar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="login_signup">
    <div class="form_container round_container">
      <form method="POST" action="/scholar/sign_up">
        <?php echo csrf_field(); ?>
        <h1>Sign Up as Scholar</h1>
        <h6>Please make sure that you are a CHED-CAR scholar and the email address that you will be entering is the one that you have provided in<br>your application form.</h6>
        <?php echo $__env->make('layouts.errors_no_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="email" name="email" placeholder="Email address" required>
        <input type="password" name="password" placeholder="Password" required>
        <input type="password" name="confirm_password" placeholder="Confirm Password" required>
        <input type="submit" value="Sign Up">
        <a href="/scholar/login"><p>Already have an account? <span class="bold">Log In</span></p></a>
      </form>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master_unregistered', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcar-master\resources\views/students/sign_up.blade.php ENDPATH**/ ?>