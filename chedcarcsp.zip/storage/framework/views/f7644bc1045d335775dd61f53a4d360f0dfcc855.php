<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">   
  <meta name="description" content="CHED-CAR offers a variety of scholarship programs that caters to different scholars. Applicants may apply online and thus we are looking forward to helping you achieve your diploma!">  
  <link rel="stylesheet" type="text/css" href="/css/style2.css?v=1">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&display=swap" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <link rel="icon" href="<?php echo e(URL::asset('/favicon.png')); ?>" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <link rel="stylesheet" href="https://unpkg.com/flickity@2/dist/flickity.min.css">
  <title>CHED-CAR | Online Application for CHED Scholarship Program (CSP)</title>
</head>
<body class="application">
  <header>
    <div class="left">
      <div class="logos">
        <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
      </div>
      <div class="names">
        <h1>Commission on Higher Education</h1>
        <h2>Cordillera Administrative Region</h2>
      </div>
    </div>
    <div class="right">
      <a class="add" href="/higher_education_institutions">List of HEIs</a>
      <div class="dropdown">
        <button class="dropdown-button db1">Log In<span class="material-icons-round">arrow_drop_down</span></button>
        <div class="dropdown-content dc1">
          <a href="/scholar/login">Scholar</a>
          <a href="/coordinator/login">Coordinator</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropdown-button db2">Sign Up<span class="material-icons-round">arrow_drop_down</span></button>
        <div class="dropdown-content dc2">
          <a href="/scholar/sign_up">Scholar</a>
          <a href="/coordinator/sign_up">Coordinator</a>
        </div>
      </div>
    </div>
  </header>

  <section class="header index_header">
    <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
    <h1>CHED-CAR <span class="italic_yellow">Scholarship Program</span></h1>
    <h2>Online Scholarship Application</h2>
    <div class="schedule">
      <div class="left">
        <p>Application Period<br class="app_period"> for Academic Year <?php echo e($application_period->acad_year); ?>-<?php echo e($application_period->acad_year + 1); ?></p>
        <h3><?php echo e(date('M j, Y', strtotime($application_period->start_date))); ?> to <?php echo e(date('M j, Y', strtotime($application_period->end_date))); ?></h3>
      </div>
      <?php if(now() >= $application_period->start_date && now() <= $application_period->end_date): ?>
      <a class="add open" href="/application">Apply Now</a>
      <?php elseif(now() < $application_period->start_date): ?>
      <a class="add closed">Not open yet</a>
      <?php else: ?>
      <a class="add closed">Closed</a>
      <?php endif; ?>
    </div>
  </section>

  <section class="sign_up">
    <div class="left">
      <h2>Are you a CHED-CAR scholar?</h2>
      <p>Sign up to keep track of your latest status, upload required documents, and monitor your financial benefits every semester!</p>
      <a class="add yellow_btn" href="/scholar/sign_up">Sign Up as Scholar</a>
    </div>
    <div class="right">
      <img class="desktop" src="<?php echo e(URL::asset('/img/preview1.png')); ?>">
      <img class="tablet" src="<?php echo e(URL::asset('/img/preview2.png')); ?>">
    </div>
  </section>

  <section class="about">
    <div class="photo photo1"></div>
    <div class="text">
      <div class="title">
        <h1>Bridging the Gap</h1>
        <div class="highlight"></div>
      </div>
      <p>The CHED-CAR continues to provide deserving and financially-incapable Filipinos opportunities to quality higher education. The organization has significantly increased the number of graduates in college which has been crucial to the development of a strong and vibrant Philippine economy.<br><br>
      Grab your opportunities now! With financial assistance from being a CHED scholar, a bright future is closer to you.</p>  
    </div>
    <div class="photo photo2"></div>
  </section>

  <section class="programs">
    <div class="left">
      <h2>What financial assistance programs await you</h2>
      <p>With the <span class="italic bold">CHED Scholarship Programs</span>, qualified scholars can enjoy these financial assistance every academic year!</p>
    </div>
    <div class="right">
      <div class="carousel" data-flickity-options='{ "wrapAround": true }' data-flickity>
        <div class="carousel-cell">
          <h2>FULL-PESFA</h2>
          <p class="italic">Full Private Education Student Financial Assistance Program</p>
          <h2><span class="small">PHP</span> 120,000<span class="small">.00</span></h2>
          <p class="italic">For students enrolling in private universities or colleges</p>
        </div>
        <div class="carousel-cell">
          <h2>HALF-PESFA</h2>
          <p class="italic">Half Private Education Student Financial Assistance Program</p>
          <h2><span class="small">PHP</span> 60,000<span class="small">.00</span></h2>
          <p class="italic">For students enrolling in private universities or colleges</p>
        </div>
        <div class="carousel-cell">
          <h2>FULL-SSP</h2>
          <p class="italic">Full State Scholarship Program</p>
          <h2><span class="small">PHP</span> 80,000<span class="small">.00</span></h2>
          <p class="italic">For students enrolling in public universities or colleges</p>
        </div>
        <div class="carousel-cell">
          <h2>HALF-SSP</h2>
          <p class="italic">Half State Scholarship Program</p>
          <h2><span class="small">PHP</span> 40,000<span class="small">.00</span></h2>
          <p class="italic">For students enrolling in public universities or colleges</p>
        </div>
      </div>
    </div>
  </section>
--> 


-- >
  <section class="how">
    <h1>How to apply for the <br class="br"><span class="bold italic_yellow">CHED Scholarship Program</span>?</h1>
    <div class="how_steps">
      <div class="how_step">
        <h2>1</h2>
        <h3>Qualifications</h3>
        <p>Check whether you are qualified by going over the Eligibility Requirements and Priority Courses below</p>
      </div>
      <div class="how_step">
        <h2>2</h2>
        <h3>Documents</h3>
        <p>View the Documentary Requirements below and take photos of or scan the documents that are applicable to you</p>
      </div>
      <div class="how_step">
        <h2>3</h2>
        <h3>CSP Application</h3>
        <p>If the applications are open, click the "Apply Now" button above and fill out the online CSP application form</p>
      </div>
      <div class="how_step">
        <h2>4</h2>
        <h3>Validation</h3>
        <p>If there is a need to validate the certified true copies of your documents, you will be contacted by our staff</p>
      </div>
    </div>
  </section>

  <section class="requirements">
    <div class="nav-requirements">
      <div id="first_nav" class="left tab active" onclick="changeView(1)">
        <h1>Eligibility Requirements</h1>
      </div>
      <div id="second_nav" class="right tab" onclick="changeView(2)">
        <h1>Priority <br class="br">Courses</h1>
      </div>
      <div id="third_nav" class="left tab" onclick="changeView(3)">
        <h1>Documentary Requirements</h1>
      </div>
    </div>
    <div class="view">
      <div id="first_view" class="left active">
        <p class="direction">A student-applicant must comply with the following criteria to qualify for the scholarship grant:</p>
        <div class="pairs">
          <div class="pair">
            <h2>1</h2>
            <p>Filipino citizen</p>
          </div>
          <div class="pair">
            <h2>2</h2>
            <p>Graduating Senior high school student or Senior high school graduate</p>
          </div>
          <div class="pair">
            <h2>3</h2>
            <p>General Weighted Average (GWA) of atleast 93% or above</p>
          </div>
>
          <div class="pair">
            <h2>4</h2>
            <p>Must enroll in CHED Priority Programs (See CHED Priority Program)</p>
          </div>
<
          <div class="pair">
            <h2>5</h2>
            <p>Combined annual gross income of parents/guardians not to exceed Four Hundred Thousand (PHP 400,000.00) or solo parent/guardian whose annual gross income does not exceed the said amount; <span class="italic">In cases where income exceeds PHP 400,000.00 an applicant must present a written certification or medical findings of illness of a family member, or school certifications of two or more dependents enrolled in college.</span></p>
          </div>
          <div class="pair">
            <h2>6</h2>
            <p>Aside from the requirements, those student-applicants belonging to the special group of persons such as the Underprivileged and Homeless Citizens under RA No. 7279, Persons with Disability (PWDs) under RA No. 7277 as amended, Solo Parents and/or their Dependents under RA No. 8972, Senior Citizens under RA 9994, and Indigenous Peoples under RA 8371, <span class="italic">shall submit certifications and/or Identification Cards (IDs) issued by the appropriate offices or agencies. </span></p>
          </div>
          <div class="pair">
            <h2>7</h2>
            <p>Avail of only one government-funded financial assistance program</p>
          </div>
        </div>
      </div>
      <div id="second_view" class="right">
        <p class="direction">Qualified beneficiaries are directed to enroll in the following priority courses:(CMO No. 10, Series of 2021)</p>
        <h2>Science and Mathematics</h2>
        <div class="courses">
          <p>Physics/Applied Physics</p>
          <p>Mathematics/Applied Mathematics</p>
          <p>Statistics/Applied Statistics</p>
          <p>Biochemistry</p>
          <p>Biology</p>
          <p>Botany</p>
          <p>Geology</p>
          <p>Human Biology</p>
          <p>Marine Biology</p>
          <p>Marine Science</p>
          <p>Meteorology</p>
          <p>Molecular Biology and Biotechnology</p>
          <p>Chemistry</p>
          <p>Environmental Science</p>
        </div>

        <h2>Information Technology Education</h2>
        <div class="courses">
          <p>Computer Science</p>
          <p>Entertainment and Multimedia Computing</p>
          <p>Information System</p>
          <p>Information Technology</p>
          <p>Game Development and Animation</p>
          <p>Cyber Sceurity</p>
          <p>Library and Information Science</p>
        </div>

        <h2>Engineering and Technology</h2>
        <div class="courses">
          <p>Agricultural and Biosystems Engineering</p>
          <p>Ceramic Engineering</p>
          <p>Chemical Engineering</p>
          <p>Civil Engineering</p>
          <p>Computer Engineering</p>
          <p>Electrical Engineering</p>
          <p>Electronics Engineering</p>
          <p>Electronics and Communication Engineering</p>
          <p>Food Engineering</p>
          <p>Geodetic Engineering</p>
          <p>Industrial Engineering</p>
          <p>Manufacturing/Production Engineering</p>
          <p>Materials Engineering</p>
          <p>Mechanical Engineering</p>
          <p>Mechatronics Engineering</p>
          <p>Metallurgical Engineering</p>
          <p>Mining Engineering</p>
          <p>Petroleum Engineering</p>
          <p>Robotics Engineering</p>
          <p>Sanitary Engineering</p>
          <p>Structural Engineering</p>
          <p>Aircraft Maintenance Technology</p>
          <p>Aviation Related Programs</p>
          <p>Engineering Technology</p>
          <p>Industrial Technology</p>
          <p>Mechatronics Engineering Technology</p>
        </div>

        <h2>Architecture</h2>
        <div class="courses">
          <p>Architecture</p>
          <p>Fine Arts</p>
          <p>Interior Design</p>
          <p>Landscape Architecture</p>
          <p>Environmental Planning</p>
        </div>

        <h2>Business Management</h2>
        <div class="courses">
          <p>Accountancy</p>
          <p>Business Analytics (Straight or Major)</p>
          <p>Hospitality Managment</p>
          <p>Hotel and Restaurant Management</p>
          <p>Tourism Management/Tourism</p>
        </div>

        <h2>Health Profession</h2>
        <div class="courses">
          <p>Dental Medicine</p>
          <p>Optometry</p>
          <p>Medical Technology</p>
          <p>Medical Laboratory Science</p>
          <p>Midwifery</p>
          <p>Nursing</p>
          <p>Nutrition and Dietetics</p>
          <p>Occupational Therapy</p>
          <p>Pharmacy</p>
          <p>Physical Therapy</p>
          <p>Radiologic Technology</p>
          <p>Respiratory Therapy</p>
          <p>Speech Language Pathology</p>
        </div>

        <h2>Maritime Education</h2>
        <div class="courses">
          <p>Marine Engineering</p>
          <p>Marine Transportation</p>
        </div>

        <h2>Social Sciences</h2>
        <div class="courses">
          <p>Community Development</p>
          <p>Human Services (Guidance and Counselling)</p>
          <p>Indigenous Peoples Studies/Education</p>
          <p>Peace Studies/Education</p>
          <p>Psychology</p>
          <p>Social Work</p>
        </div>

        <h2>Teacher Education</h2>
        <div class="courses">
          <p>Secondary Education Majors in Science</p>
          <p>Secondary Education Majors in Mathematics</p>
          <p>Culture and Arts</p>
          <p>Early Childhood Education</p>
          <p>Special Needs Education</p>
          <p>Sports and Exercise Science</p>
        </div>

        <h2>Multi and Interdisciplinary Cluster</h2>
        <div class="courses">
          <p>Agribusiness</p>
          <p>Agro-Forestry</p>
          <p>Data Science and Analytics</p>
          <p>Disaster Risk Management/Climate Change</p>
          <p>Renewable/Sustainable Energy</p>
        </div>
      </div>
      <div id="third_view" class="left">
        <p class="direction">The following documents are required to verify qualification of applicants:</p>
        <div class="pairs">
          <div class="pair">
            <h2>1</h2>
            <p>Personal Identification :<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> Duly certified true copy of birth certificate<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> 2x2 ID Photo
            </p>
          </div>
          <div class="pair">
            <h2>2</h2>
            <p>Academic Requirements - <span class="italic">any one of the following:</span><br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> For Senior High School graduates, duly certified true copy of Senior High report card<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> For graduating Senior high school students, duly certified true copy of grades for grade 11 and 1st semester of grade 12</p>
          </div>
          <div class="pair">
            <h2>3</h2>
            <p>Income Requirements - <span class="italic">any one of the following:</span><br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> Latest ITR of parents or guardian if employed<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> Certificate of Tax Exemption from the BIR<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">c.</span> Certificate of Indigency from their Barangay<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">d.</span> Certificate/Case Study from DSWD<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">e.</span> Latest copy of contract or proof of income for children of Overseas Filipino Workers (OFW) and seafarers</p>
          </div>
          <div class="pair">
            <h2>4</h2>
            <p>Others (if applicable):</span><br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">a.</span> Certificate of Indigency for indigenous and ethnic peoples<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">b.</span> PWD ID for persons with disabilities<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">c.</span> Senior Citizen ID for dependents of senior citizens<br>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="bold italic">d.</span> Solo Parent ID for dependents of solo parents</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="contact_container" id="contact">
    <div class="title">
      <h2>Contact Us</h2>
      <p>If you have inquiries regarding the <span class="bold italic">CHED Scholarship Program</span> for A.Y. 2022-2023, please do not hesitate to reach out to us</p>
    </div>
    <div class="contacts">
      <div class="contact">
        <div class="icon">
          <span class="material-icons-round">email</span>
        </div>
        <h3>Email Address</h3>
        <p>chedrocar_stufaps@ched.gov.ph</p>
      </div>
      <div class="contact">
        <div class="icon">
          <span class="material-icons-round">call</span>
        </div>
        <h3>Telephone</h3>
        <p>(074) 422-2418<br>(074) 422-4052</p>
      </div>
      <div class="contact">
        <div class="icon">
          <span class="material-icons-round">language</span>
        </div>
        <h3>Links</h3>
        <a target="_blank" href="https://www.facebook.com/chedstufaps.cordillera"><p>CHEDCAR-StuFAPs Facebook Page</p></a>
        <a target="_blank" href="https://chedcar.com/"><p>Official Website of CHED-CAR</p></a>
      </div>
      <div class="contact">
        <div class="icon">
          <span class="material-icons-round">location_on</span>
        </div>
        <h3>Address</h3>
        <p>BSU Compound, Km. 6, Cabanao,<br>Balili, La Trinidad, Benguet</p>
      </div>
    </div>
  </section>
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script>
<script type="text/javascript">
  function changeView(view) {
    if(view == 1) {
      $('#first_view').addClass('active');
      $('#second_view').removeClass('active');
      $('#third_view').removeClass('active');
      $('#first_nav').addClass('active');
      $('#second_nav').removeClass('active');
      $('#third_nav').removeClass('active');
    } else if(view == 2) {
      $('#first_view').removeClass('active');
      $('#second_view').addClass('active');
      $('#third_view').removeClass('active');
      $('#first_nav').removeClass('active');
      $('#second_nav').addClass('active');
      $('#third_nav').removeClass('active');
    } else {
      $('#first_view').removeClass('active');
      $('#second_view').removeClass('active');
      $('#third_view').addClass('active');
      $('#first_nav').removeClass('active');
      $('#second_nav').removeClass('active');
      $('#third_nav').addClass('active');
    }
  }

  $('.db1').on('click', function () {
    event.stopPropagation();
    if($('.dc1').hasClass('active')) {
      $('.dc1').removeClass('active');
    } else {
      if($('.dc2').hasClass('active')) {
        $('.dc2').removeClass('active');
      }
      $('.dc1').addClass('active');
    }
  });

  $('.db2').on('click', function () {
    event.stopPropagation();
    if($('.dc2').hasClass('active')) {
      $('.dc2').removeClass('active');
    } else {
      if($('.dc1').hasClass('active')) {
        $('.dc1').removeClass('active');
      }
      $('.dc2').addClass('active');
    }
  });

  $(document).click(function(e) {
    $('.dc1').removeClass('active');
    $('.dc2').removeClass('active');
  });
</script>
</html><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/applications/index.blade.php ENDPATH**/ ?>