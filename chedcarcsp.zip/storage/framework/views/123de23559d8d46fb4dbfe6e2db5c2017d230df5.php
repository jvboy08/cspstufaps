<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="error">
      <h2 id="error"><?php echo e($error); ?></h2>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?><?php /**PATH C:\wamp64\www\chedcar-master\resources\views/layouts/errors_no_icon.blade.php ENDPATH**/ ?>