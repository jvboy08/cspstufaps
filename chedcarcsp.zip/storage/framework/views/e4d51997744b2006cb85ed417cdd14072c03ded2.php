<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="error">
      <span class="material-icons-round">error</span>
      <h2 id="error"><?php echo e($error); ?></h2>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?><?php /**PATH C:\wamp64\www\chedcarcsp-master\resources\views/layouts/errors.blade.php ENDPATH**/ ?>