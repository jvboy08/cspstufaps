<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">   
  <link rel="stylesheet" type="text/css" href="/css/style2.css?v=1">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&display=swap" rel="stylesheet">
  <link rel="icon" href="<?php echo e(URL::asset('/favicon.png')); ?>" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body class="application">
  <header>
    <a href="/">
      <div class="left">
        <div class="logos">
          <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
        </div>
        <div class="names">
          <h1>Commission on Higher Education</h1>
          <h2>Cordillera Administrative Region</h2>
        </div>
      </div>
    </a>
    <div class="right">
      <a class="add" href="/">Home</a>
      <div class="dropdown">
        <button class="dropdown-button db1">Log In<span class="material-icons-round">arrow_drop_down</span></button>
        <div class="dropdown-content dc1">
          <a href="/scholar/login">Scholar</a>
          <a href="/coordinator/login">Coordinator</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropdown-button db2">Sign Up<span class="material-icons-round">arrow_drop_down</span></button>
        <div class="dropdown-content dc2">
          <a href="/scholar/sign_up">Scholar</a>
          <a href="/coordinator/sign_up">Coordinator</a>
        </div>
      </div>
    </div>
  </header>

  <?php echo $__env->yieldContent('content'); ?>
  
  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script type="text/javascript">
  $('.db1').on('click', function (event) {
    event.stopPropagation();
    if($('.dc1').hasClass('active')) {
      $('.dc1').removeClass('active');
    } else {
      if($('.dc2').hasClass('active')) {
        $('.dc2').removeClass('active');
      }
      $('.dc1').addClass('active');
    }
  });

  $('.db2').on('click', function (event) {
    event.stopPropagation();
    if($('.dc2').hasClass('active')) {
      $('.dc2').removeClass('active');
    } else {
      if($('.dc1').hasClass('active')) {
        $('.dc1').removeClass('active');
      }
      $('.dc2').addClass('active');
    }
  });

  $(document).click(function(e) {
    $('.dc1').removeClass('active');
    $('.dc2').removeClass('active');
  });
</script>
</html><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/layouts/master_unregistered.blade.php ENDPATH**/ ?>