<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width">     
  <link rel="stylesheet" type="text/css" href="/css/style2.css?v=1">
  <link href="https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,500;0,700;1,500;1,700&display=swap" rel="stylesheet">
  <link rel="icon" href="<?php echo e(URL::asset('/favicon.png')); ?>" type="image/x-icon"/>
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <title>CHED-CAR | List of Higher Education Institutions</title>
</head>
<body class="application">
  <header>
    <a href="/">
      <div class="left">
        <div class="logos">
          <embed src="/svg/logo-ched.svg" type="image/svg+xml" class="logo"/>
        </div>
        <div class="names">
          <h1>Commission on Higher Education</h1>
          <h2>Cordillera Administrative Region</h2>
        </div>
      </div>
    </a>
    <div class="right">
      <a class="add" href="/">Home</a>
      <div class="dropdown">
        <button class="dropdown-button db1">Log In<span class="material-icons-round">arrow_drop_down</span></button>
        <div class="dropdown-content dc1">
          <a href="/scholar/login">Scholar</a>
          <a href="/coordinator/login">Coordinator</a>
        </div>
      </div>
      <div class="dropdown">
        <button class="dropdown-button db2">Sign Up<span class="material-icons-round">arrow_drop_down</span></button>
        <div class="dropdown-content dc2">
          <a href="/scholar/sign_up">Scholar</a>
          <a href="/coordinator/sign_up">Coordinator</a>
        </div>
      </div>
    </div>
  </header>

  <section class="banner">
    <h1>CHED-CAR <span class="italic_yellow">Higher Education Institutions</span></h1>
  </section>

  <section class="institutions">
    <?php $__currentLoopData = $institutions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $institution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($key == 0 || ($key != 0 && substr($institutions[$key - 1]->institution_name, 0, 1) != substr($institution->institution_name, 0, 1))): ?>
    <div class="letter"><h4><?php echo e(substr($institution->institution_name, 0, 1)); ?></h4></div>
    <?php else: ?>
    <div></div>
    <?php endif; ?>
    <div class="institution institution_<?php echo e($key); ?> <?php echo e($key == 0 ? 'active' : ''); ?>" onclick="display('<?php echo e($key); ?>')">
      <div class="name">
        <p class="bold"><?php echo e($institution->institution_name); ?></p> 
        <span class="material-icons-round">arrow_drop_down</span>
      </div>
      <div class="details">
        <p class="italic">President:</p>
        <p class="italic"><?php echo e($institution->president == null ? 'NA' : $institution->president); ?></p>
        <p class="italic">Address:</p>
        <p class="italic"><?php echo e($institution->address == null ? 'NA' : $institution->address); ?></p>
        <p class="italic">Contact No.:</p>
        <p class="italic"><?php echo e($institution->hei_contact_no == null ? 'NA' : $institution->hei_contact_no); ?></p>
        <p class="italic">Email Address:</p>
        <p class="italic"><?php echo e($institution->hei_email == null ? 'NA' : $institution->hei_email); ?></p>
        <p class="italic">Website:</p>
        <p class="italic"><?php echo e($institution->hei_website == null ? 'NA' : $institution->hei_website); ?></p>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>

  <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
<script type="text/javascript">
  $('.db1').on('click', function () {
    event.stopPropagation();
    if($('.dc1').hasClass('active')) {
      $('.dc1').removeClass('active');
    } else {
      if($('.dc2').hasClass('active')) {
        $('.dc2').removeClass('active');
      }
      $('.dc1').addClass('active');
    }
  });

  $('.db2').on('click', function () {
    event.stopPropagation();
    if($('.dc2').hasClass('active')) {
      $('.dc2').removeClass('active');
    } else {
      if($('.dc1').hasClass('active')) {
        $('.dc1').removeClass('active');
      }
      $('.dc2').addClass('active');
    }
  });

  $(document).click(function(e) {
    $('.dc1').removeClass('active');
    $('.dc2').removeClass('active');
  });

  var active = 0;

  function display(index) {
    $('.institution_' + active).removeClass('active');
    $('.institution_' + index).addClass('active');
    active = index;
  }

</script>
</html><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/applications/heis.blade.php ENDPATH**/ ?>