<?php $__env->startSection('title'); ?>
CHED-CAR Admin | Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<section class="form half">
	<div class="header">
		<h1>Edit an Application Period</h1>
		<a class="add" href="/dashboard">Go back</a>
	</div>
	<?php echo $__env->make('layouts.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<form method="POST" action="/dashboard/application_periods/<?php echo e($application_period->id); ?>">
		<?php echo method_field('PUT'); ?>
		<?php echo csrf_field(); ?>

		<!-- ACADEMIC YEAR -->
		<label for="acad_year">Academic Year :</label>
		<select name="acad_year" required>
			<option value="" disabled selected hidden>Select an academic year</option>
			<?php for($i = 2016; $i <= now()->year; $i++): ?>
		        <option value="<?php echo e($i); ?>" <?php echo e($application_period->acad_year == $i ? 'selected' : ''); ?>><?php echo e($i); ?> - <?php echo e($i+1); ?></option>
		    <?php endfor; ?>
		</select>

		<!-- START DATE -->
		<label for="start_date">Start Date <span class="optional">(dd/mm/yyyy)</span> :</label>
		<input type="date" name="start_date" value="<?php echo e($application_period->start_date); ?>" required>

		<!-- END DATE -->
		<label for="end_date">End Date <span class="optional">(dd/mm/yyyy)</span> :</label>
		<input type="date" name="end_date" value="<?php echo e($application_period->end_date); ?>" required>

		<input type="submit" value="Submit Changes">
	</form>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\chedcarcsp\resources\views/dashboard/edit.blade.php ENDPATH**/ ?>