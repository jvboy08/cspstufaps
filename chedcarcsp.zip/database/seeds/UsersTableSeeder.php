<?php

use Illuminate\Database\Seeder;
use App\User;
use App\Institution;
use Faker\Generator as Faker;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run(Faker $faker)
    {
        $user = [
			'name' => 'Christine Soriano',
			'email' => 'christinesoriano@gmail.com',
            'is_verified' => 1,
			'password' => bcrypt('password'),
            'user_type' => 'admin'
		];

        User::create($user);

        $institutions = Institution::get();

        foreach ($institutions as $key => $institution) {
            $verification_code = '';
            $check = true;
            while($check) {
                $verification_code = sha1(time() - rand(1, 2000));
                if(User::where('verification_code', $verification_code)->first() == null) {
                    $check = false;
                }
            }

            User::create([
                'name' => $faker->name,
                'email' => $faker->unique()->safeEmail,
                'is_verified' => 0,
                'institution_id' => $institution->id,
                'user_type' => 'coordinator',
                'verification_code' => $verification_code,
                'coordinator_role' => 'head'
            ]);

            $number_assistants = mt_rand(1, 4);

            for($i = 1; $i <= $number_assistants; $i++) {
                $verification_code = '';
                $check = true;
                while($check) {
                    $verification_code = sha1(time() - rand(1, 2000));
                    if(User::where('verification_code', $verification_code)->first() == null) {
                        $check = false;
                    }
                }

                User::create([
                    'name' => $faker->name,
                    'email' => $faker->unique()->safeEmail,
                    'is_verified' => 0,
                    'institution_id' => $institution->id,
                    'user_type' => 'coordinator',
                    'verification_code' => $verification_code,
                    'coordinator_role' => 'assistant'
                ]);
            }
        }

        // factory(\App\User::class, 43)->create();
    }
}
