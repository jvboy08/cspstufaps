<?php

use Illuminate\Database\Seeder;
use App\Institution;
use App\Course;

class CoursesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {


        $courses = [
            [   'course_name' => 'Bachelor of Early Childhood Education',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],
            [   'course_name' => 'Bachelor in Elementary Education-Special Education',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],
            [   'course_name' => 'Bachelor in Medical Laboratory Science',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],
            [   'course_name' => 'Bachelor of Arts in Psychology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Social Sciences'],        
            [   'course_name' => 'Bachelor of Culture and Arts Education',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],
            [   'course_name' => 'Bachelor of Fine Arts',
                'cmo_2014' => 'Architecture',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Architecture'],
            [   'course_name' => 'Bachelor of Library and Information Science',
                'cmo_2014' => 'Information Technology',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Information Technology Education'],
            [   'course_name' => 'Bachelor of Science in Accountancy',
                'cmo_2014' => 'Business Administration and Related Courses',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Business Management'],
            [   'course_name' => 'Bachelor of Science in Accounting Technology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Business Management'],

            

            [   'course_name' => 'Bachelor of Science in Agribusiness',
                'cmo_2014' => 'Agriculture and Related Fields',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Multi and Interdisciplinary Cluster'],

            [   'course_name' => 'Bachelor of Science in Agribusiness Management',
                'cmo_2014' => 'Agriculture and Related Fields',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Multi and Interdisciplinary Cluster'],

            [   'course_name' => 'Bachelor of Science in Agricultural and Biosystems Engineering',
                'cmo_2014' => 'Agriculture and Related Fields',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            

            

            [   'course_name' => 'Bachelor of Science in Agro-Forestry',
                'cmo_2014' => 'Agriculture and Related Fields',
                'cmo_2019' => 'Agriculture, Forestry and Fisheries',
                'cmo_2021' => 'Multi and Interdisciplinary Cluster'],

            [   'course_name' => 'Bachelor of Science in Aircraft Maintenance Technology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Engineering and Technology'],

            

            [   'course_name' => 'Bachelor of Science in Applied Mathematics',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Mathematics',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Applied Physics',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Applied Statistics',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Mathematics',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Architecture',
                'cmo_2014' => 'Architecture',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Architecture'],

            

            [   'course_name' => 'Bachelor of Science in Aviation Technology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Biochemistry',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Biology',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Botany',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

           

            [   'course_name' => 'Bachelor of Science in Business Administration-Business Analytics',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Business Process Outsourcing',
                'cmo_2021' => 'Business Management'],

            

            [   'course_name' => 'Bachelor of Science in Business Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Business Management'],

            [   'course_name' => 'Bachelor of Science in Ceramic Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Chemical Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Chemistry',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Civil Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            

            [   'course_name' => 'Bachelor of Science in Climate Change',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Multi and Interdisciplinary Cluster'],

            [   'course_name' => 'Bachelor of Science in Computer Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            

            [   'course_name' => 'Bachelor of Science in Computer Science',
                'cmo_2014' => 'Information Technology',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Information Technology Education'],

            

            [   'course_name' => 'Bachelor of Science in Cyber Security',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Information Technology Education'],

            [   'course_name' => 'Bachelor of Science in Data Analytics',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Multi and Interdisciplinary Cluster'],

            

            [   'course_name' => 'Bachelor of Science in Disaster Risk Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Multi and Interdisciplinary Cluster'],

            

            [   'course_name' => 'Bachelor of Science in Electrical Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            

            [   'course_name' => 'Bachelor of Science in Electronics and Communications Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Electronics Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

           

            [   'course_name' => 'Bachelor of Science in Engineering Technology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Entertainment and Multimedia Computing',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Information Technology Education'],

           

            [   'course_name' => 'Bachelor of Science in Environmental Science',
                'cmo_2014' => 'Science',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            

            [   'course_name' => 'Bachelor of Science in Food Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            

            [   'course_name' => 'Bachelor of Science in Geodetic Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Geology',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

           

            [   'course_name' => 'Bachelor of Science in Hospitality Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Tourism',
                'cmo_2021' => 'Business Management'],

            [   'course_name' => 'Bachelor of Science in Hotel and Restaurant Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Tourism',
                'cmo_2021' => 'Business Management'],

            [   'course_name' => 'Bachelor of Science in Human Biology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Industrial Education',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Engineering and Technology'],

            

            [   'course_name' => 'Bachelor of Science in Industrial Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

           

            [   'course_name' => 'Bachelor of Science in Industrial Technology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Information System',
                'cmo_2014' => 'Information Technology',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Information Technology Education'],

            [   'course_name' => 'Bachelor of Science in Information Technology',
                'cmo_2014' => 'Information Technology',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Information Technology Education'],

            [   'course_name' => 'Bachelor of Science in Interior Design',
                'cmo_2014' => 'Architecture',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Architecture'],


            [   'course_name' => 'Bachelor of Science in Manufacturing Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Marine Biology',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Marine Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Maritime Education'],

            [   'course_name' => 'Bachelor of Science in Marine Science',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Marine Transportation',
                'cmo_2014' => 'Maritime',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Maritime Education'],

            

            [   'course_name' => 'Bachelor of Science in Materials Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Mathematics',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Mathematics',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Mechanical Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],


            [   'course_name' => 'Bachelor of Science in Mechatronics Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Mechatronics Engineering Technology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Metallurgical Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Meteorology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Midwifery',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            [   'course_name' => 'Bachelor of Science in Mining Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Molecular Biology and Biotechnology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],

            
            [   'course_name' => 'Bachelor of Science in Nursing',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            

            [   'course_name' => 'Bachelor of Science in Nutrition and Dietetics',
                'cmo_2014' => 'Health Sciences',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],


            [   'course_name' => 'Bachelor of Science in Petroleum Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Pharmacy',
                'cmo_2014' => 'Health Sciences',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            
            [   'course_name' => 'Bachelor of Science in Physical Therapy',
                'cmo_2014' => 'Health Sciences',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            [   'course_name' => 'Bachelor of Science in Physics',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Science and Mathematics'],


            [   'course_name' => 'Bachelor of Science in Production Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],


            [   'course_name' => 'Bachelor of Science in Psychology',
                'cmo_2014' => 'Social and Behavioral Sciences',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Social Sciences'],


            [   'course_name' => 'Bachelor of Science in Radiologic Technology',
                'cmo_2014' => 'Health Sciences',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],



            [   'course_name' => 'Bachelor of Science in Respiratory Therapy',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            [   'course_name' => 'Bachelor of Science in Robotics Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Sanitary Engineering',
                'cmo_2014' => 'Engineering',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            [   'course_name' => 'Bachelor of Science in Social Science',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Social Sciences'],

            [   'course_name' => 'Bachelor of Science in Social Work',
                'cmo_2014' => 'Social and Behavioral Sciences',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Social Sciences'],

            [   'course_name' => 'Bachelor of Science in Statistics',
                'cmo_2014' => 'Science and Math',
                'cmo_2019' => 'Mathematics',
                'cmo_2021' => 'Science and Mathematics'],

            [   'course_name' => 'Bachelor of Science in Structural Engineering',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Engineering',
                'cmo_2021' => 'Engineering and Technology'],

            
            [   'course_name' => 'Bachelor of Science in Tourism',
                'cmo_2014' => 'Business Administration and Related Courses',
                'cmo_2019' => 'Tourism',
                'cmo_2021' => 'Tourism'],

           

            [   'course_name' => 'Bachelor of Early Childhood Education',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],

            [   'course_name' => 'Bachelor of Secondary Education-English',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

        

            [   'course_name' => 'Bachelor of Secondary Education-Mathematics',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],

            [   'course_name' => 'Bachelor of Secondary Education-PE',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],
            [   'course_name' => 'Bachelor of Secondary Education-Physical Science',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],
            [   'course_name' => 'Bachelor of Secondary Education-Science',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],

            [   'course_name' => 'Bachelor of Secondary Education-Social Studies',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Secondary Education-Special Education',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],
            [   'course_name' => 'Bachelor of Science in Midwifery',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Health Profession'],

            [   'course_name' => 'Doctor of Dental Medicine',
                'cmo_2014' => 'none',
                'cmo_2019' => 'Science',
                'cmo_2021' => 'Health Profession'],
            // FROM ONLINE APP FORM
            

            [   'course_name' => 'Bachelor in Landscape Architecture',
                'cmo_2014' => 'Architecture',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Architecture'],

          

            [   'course_name' => 'Bachelor in Secondary Education Major in Mathematics',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],



            [   'course_name' => 'Bachelor of Culture and the Arts Education',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Teacher Education'],

            

            [   'course_name' => 'Bachelor of Fine Arts',
                'cmo_2014' => 'Architecture',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Architecture'],

        

            [   'course_name' => 'Bachelor of Science in Agroforestry',
                'cmo_2014' => 'Agriculture and Related Fields',
                'cmo_2019' => 'Agriculture, Forestry and Fisheries',
                'cmo_2021' => 'Multi and Interdisciplinary Cluster'],

            [   'course_name' => 'Bachelor of Science in Business Administration Major in Business Economics',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Science in Business Administration Major in Financial Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Science in Business Administration Major in Human Resource Development',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Science in Business Administration Major in Marketing Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Science in Business Administration Major in Operations Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Science in Information Systems',
                'cmo_2014' => 'Information Technology',
                'cmo_2019' => 'Technology',
                'cmo_2021' => 'Information Technology Education'],

            [   'course_name' => 'Bachelor of Science in Islamic Studies',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Science in Medical Technology',
                'cmo_2014' => 'Health Sciences',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            [   'course_name' => 'Bachelor of Science in Occupational Therapy',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            [   'course_name' => 'Bachelor of Science in Real Estate Management',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'none'],

            [   'course_name' => 'Bachelor of Science in Speech-Language Pathology',
                'cmo_2014' => 'none',
                'cmo_2019' => 'none',
                'cmo_2021' => 'Health Profession'],

            [   'course_name' => 'Bachelor of Science in Tourism Management',
                'cmo_2014' => 'Business Administration and Related Courses',
                'cmo_2019' => 'Tourism',
                'cmo_2021' => 'Business Management'],

            [   'course_name' => 'Bachelor of Sports Science',
                'cmo_2014' => 'Teacher Education',
                'cmo_2019' => 'none',
                'cmo_2021' => '']
        ];


        foreach($courses as $course){
            Course::create($course);
        }
    }
}
