<?php

use Illuminate\Database\Seeder;
use App\Program;
use App\Scholar;
use App\Award;
use App\Applicant;
use App\SemestralAward;

class ScholarsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	for($j = 2016; $j < 2021; $j++) {
			$programs = Program::inRandomOrder()->get();

			foreach ($programs as $key => $program) {
				$award = Award::where('program_id', $program->id)
					->where('award_year', $j)
					->first();

				$range = ($award->end_slot - $award->start_slot) * 0.75;
				$applicants_count = Applicant::where('entry_acad_year', $j)->where('is_accepted', 0)->count();
				$is_range_higher = $range > $applicants_count;

				for($i = $award->start_slot; $i < $award->start_slot + ($is_range_higher ? $applicants_count : $range); $i++) {
					$check = true;

					$award_number = $program->code.'-'.sprintf("%04d", $i).'-'.substr($j, 2, 2).'-14';

					$applicant = Applicant::where('entry_acad_year', $j)
						->where('is_accepted', 0)
						->orderBy('score', 'DESC')
						->first();

				    $applicant->update([
				        'is_accepted' => 1
				    ]);

				    $scholar = Scholar::create([
				        'applicant_id' => $applicant->id,

				        'award_id' => $award->id,
				        'award_number' => $award_number,

				        'acad_year_accepted' => $j,
				        'semester_accepted' => '1',

				        'latest_status' => 'Active',
				        'latest_acad_year' => $j,
				        'latest_semester' => '1',
				        'latest_year_level' => '1'
				    ]);

				    $is_paid = mt_rand(0, 1);

				    SemestralAward::create([
				    	'scholar_id' => $scholar->id,
			            'acad_year' => $j,
			            'semester' => '1',
			            'current_year_level' => '1',
			            'status' => 'Active',
			            'amount_chedro' => $is_paid ? $program->amount_per_sem : null,
			            'date_processed' => $is_paid ? $j.'-'.sprintf("%02d", mt_rand(1, 12)).'-'.sprintf("%02d", mt_rand(1, 28)) : null,
			            'mode_of_payment' => $is_paid ? 'HEI' : null
				    ]);

				    $year_level = 1;
				    $statuses = ['Active', 'Active', 'Active', 'Active', 'Active', 'Active', 'Terminated', 'Deferred', 'Waived', 'Graduate'];

				    $random_last_year = $j == 2020 ? 2020 : mt_rand($j + 1, 2020);

				    for($k = $j + 0.5; $k <= $random_last_year + 0.5; $k = $k + 0.5) {
				    	$year_level = $year_level + 0.5;
				    	$status = $statuses[mt_rand(0, 9)];

				    	$is_paid = mt_rand(0, 1);

				    	SemestralAward::create([
					    	'scholar_id' => $scholar->id,
				            'acad_year' => floor($k),
				            'semester' => floor($k) != $k ? 2 : 1,
				            'current_year_level' => floor($year_level),
				            'status' => $status,
				            'amount_chedro' => $is_paid && in_array($status, ['Active', 'Graduate']) ? $program->amount_per_sem : null,
			            	'date_processed' => $is_paid && in_array($status, ['Active', 'Graduate']) ? floor($k).'-'.sprintf("%02d", mt_rand(1, 12)).'-'.sprintf("%02d", mt_rand(1, 28)) : null,
			            	'mode_of_payment' => $is_paid && in_array($status, ['Active', 'Graduate']) ? 'HEI' : null
					    ]);

				    	if(in_array($status, ['Terminated', 'Deferred', 'Waived', 'Graduate']) || $k == $random_last_year + 0.5) {
					    	$scholar->update([
						        'latest_status' => $status,
						        'latest_acad_year' => floor($k),
						        'latest_semester' => floor($k) != $k ? 2 : 1,
						        'latest_year_level' => floor($year_level)
						    ]);
						    $k = 2020.5;
				    	}
				    }
		    	}
			}
    	}
    }
}
