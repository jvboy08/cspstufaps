<?php

use Illuminate\Database\Seeder;
use App\Award;
use App\Program;

class AwardsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $programs = Program::get();

        foreach($programs as $program){
            for($i = 2016; $i <= 2021; $i++){
                $start_slot = mt_rand(0, 500);

                Award::create([
                    'program_id' => $program->id,
                    'award_year' => $i,
                    'start_slot' => $start_slot,
                    'end_slot' => $start_slot + mt_rand(10, 100),
                ]);
            }
        }
    }
}
