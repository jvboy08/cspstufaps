<?php

use Illuminate\Database\Seeder;
use App\Applicant;

class ApplicantsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Applicant::class, 2000)->create();
        //\App\Applicant::factory()->count(2000)->create(); 
    }
}
