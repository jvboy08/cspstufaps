<?php

use Illuminate\Database\Seeder;
use App\ApplicationPeriod;

class ApplicationPeriodsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        ApplicationPeriod::create([
            'start_date' => '2022-03-01',
            'end_date' => '2022-12-31',
            'acad_year' => '2022'
        ]);
    }
}
