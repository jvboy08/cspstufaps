<?php

use Illuminate\Database\Seeder;
use App\Program;

class ProgramsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $programs = [
            [   'program_name' => 'Full Merit Scholarship Program',
                'code' => 'FS101',
                'amount_per_sem' => '15000',
                'reference_cmo' => 'CMO 1 S. 2014'],
            [   'program_name' => 'Private Scholarship Program',
                'code' => 'PS101',
                'amount_per_sem' => '15000',
                'reference_cmo' => 'CMO 1 S. 2014'],
            [   'program_name' => 'Tulong Dunong Scholarship Program',
                'code' => 'TD00',
                'amount_per_sem' => '6000',
                'reference_cmo' => 'CMO 1 S. 2014'],
            [   'program_name' => 'Tulong Dunong Scholarship Program',
                'code' => 'TD01',
                'amount_per_sem' => '6000',
                'reference_cmo' => 'CMO 1 S. 2014'],
            [   'program_name' => 'Half Merit Scholarship Program',
                'code' => 'PESFA',
                'amount_per_sem' => '7500',
                'reference_cmo' => 'CMO 1 S. 2014'],

            [	'program_name' => 'Full State Scholarship Program',
                'code' => 'FULL-SSP',
                'amount_per_sem' => '30000',
                'reference_cmo' => 'CMO 5 S. 2021'],
            [   'program_name' => 'Half State Scholarship Program',
                'code' => 'HALF-SSP',
                'amount_per_sem' => '15000',
                'reference_cmo' => 'CMO 5 S. 2021'],
            [   'program_name' => 'Full Program and Private Education Student Financial Assistance',
                'code' => 'FULL-PESFA',
                'amount_per_sem' => '30000',
                'reference_cmo' => 'CMO 5 S. 2021'],
            [   'program_name' => 'Half Program and Private Education Student Financial Assistance',
                'code' => 'HALF-PESFA',
                'amount_per_sem' => '15000',
                'reference_cmo' => 'CMO 5 S. 2021'],
                [	'program_name' => 'Full State Scholarship Program-GAD',
                'code' => 'FULL-SSP-GAD',
                'amount_per_sem' => '40000',
                'reference_cmo' => 'CMO 11 S. 2021'],
            [   'program_name' => 'Half State Scholarship Program-GAD',
                'code' => 'HALF-SSP-GAD',
                'amount_per_sem' => '20000',
                'reference_cmo' => 'CMO 11 S. 2021'],
            [   'program_name' => 'Full Program and Private Education Student Financial Assistance-GAD',
                'code' => 'FULL-PESFA-GAD',
                'amount_per_sem' => '60000',
                'reference_cmo' => 'CMO 11 S. 2021'],
            [   'program_name' => 'Half Program and Private Education Student Financial Assistance-GAD',
                'code' => 'HALF-PESFA-GAD',
                'amount_per_sem' => '30000',
                'reference_cmo' => 'CMO 11 S. 2021']    
        ];
        
        foreach($programs as $program){
            Program::create($program);
        }
    }
}

