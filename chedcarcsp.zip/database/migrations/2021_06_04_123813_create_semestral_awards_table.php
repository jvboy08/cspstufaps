<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSemestralAwardsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('mysql')->create('semestral_awards', function (Blueprint $table) {
            $table->id();
            $table->integer('scholar_id')->unsigned();
            $table->integer('acad_year');
            $table->integer('semester');
            $table->integer('current_year_level')->nullable();
            $table->string('status')->nullable();
            $table->string('remarks_chedro')->nullable();

            // PAYMENT DETAILS
            $table->decimal('amount_chedro', 10, 2)->nullable();
            $table->string('date_processed')->nullable();
            $table->string('mode_of_payment')->nullable();
            $table->boolean('is_payment_received')->default('0');

            // PROVIDED BY COORDINATORS
            $table->string('previous_gwa', 5)->nullable();
            $table->string('units_enrolled', 5)->nullable();
            $table->string('tuition_fee', 8)->nullable();
            $table->string('remarks_coordinator')->nullable();

            // PROVIDED BY OSDS
            $table->string('saro')->nullable();
            $table->string('nta_number')->nullable();
            $table->decimal('amount_osds', 10, 2)->nullable();
            $table->string('remarks_osds')->nullable();

            // THESIS DETAILS
            $table->string('thesis_title')->nullable();
            $table->decimal('thesis_allowance', 10, 2)->nullable();
            $table->string('thesis_remarks')->nullable();

            // REQUIREMENTS
            $table->string('enrollment_form')->nullable();
            $table->string('previous_grades')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('mysql')->dropIfExists('semestral_awards');
    }
}
