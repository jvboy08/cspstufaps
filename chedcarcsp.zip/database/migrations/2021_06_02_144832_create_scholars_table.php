<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateScholarsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('mysql')->create('scholars', function (Blueprint $table) {
            $table->id();
            $table->integer('applicant_id')->unsigned();

            // SCHOLARSHIP
            $table->integer('award_id')->unsigned();
            $table->string('award_number');

            // ACADEMIC PERIOD ACCEPTED
            $table->integer('acad_year_accepted');
            $table->integer('semester_accepted');

            // LATEST DETAILS
            $table->string('latest_status')->nullable();
            $table->integer('latest_acad_year')->nullable();
            $table->integer('latest_semester')->nullable();
            $table->integer('latest_year_level')->nullable();

            // PAYMENT REQUIREMENTS
            $table->boolean('is_thru_hei')->default('0');
            $table->string('school_id')->nullable();
            $table->string('atm_card')->nullable();
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('mysql')->dropIfExists('scholars');
    }
}
