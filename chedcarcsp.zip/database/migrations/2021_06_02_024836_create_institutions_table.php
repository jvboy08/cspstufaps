<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInstitutionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::connection('mysql')->create('institutions', function (Blueprint $table) {
            $table->id();
            $table->string('institution_name');
            $table->string('sector');

            // ORGANIZATION
            $table->string('institution_head')->nullable();
            $table->string('registrar')->nullable();
            $table->string('accountant')->nullable();

            // CONTACT DETAILS
            $table->string('address')->nullable();
            $table->string('hei_website')->nullable();
            $table->string('hei_email')->nullable();
            $table->string('hei_contact_no')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::connection('mysql')->dropIfExists('institutions');
    }
}
