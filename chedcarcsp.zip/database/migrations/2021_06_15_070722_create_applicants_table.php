<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateApplicantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('applicants', function (Blueprint $table) {
            $table->id();

        ////////// APPLICATION DETAILS

            $table->string('app_no', 10);
            $table->string('entry_date', 10);
            $table->string('entry_acad_year', 4);
            $table->boolean('is_accepted');
            $table->boolean('are_documents_validated');
            $table->decimal('score', 5, 2);

        ////////// PERSONAL INFORMATION
            
            // PERSONAL DETAILS
            $table->string('name_last');
            $table->string('name_first');
            $table->string('name_middle')->nullable();
            $table->string('name_ext')->nullable();
            $table->string('name_maiden')->nullable();
            $table->string('birthday', 10);
            $table->string('birthplace');
            $table->string('sex', 1);
            $table->string('civil_status', 15);
            $table->string('citizenship')->nullable();

            // CONTACT DETAILS
            $table->string('email_address');
            $table->string('contact_number', 15);
            $table->string('fb_account')->nullable();

            // PERSONAL IDENTIFICATION
            $table->string('birth_cert')->nullable();
            $table->string('id_photo')->nullable(); 

        ////////// ADDRESS INFORMATION

            // PERMANENT ADDRESS
            $table->string('perm_district');
            $table->string('perm_province');
            $table->string('perm_muni_city');
            $table->string('perm_barangay');
            $table->string('perm_zip_code', 4);

            // PRESENT ADDRESS
            $table->boolean('pres_is_perm');
            $table->string('pres_district')->nullable();
            $table->string('pres_province')->nullable();
            $table->string('pres_muni_city')->nullable();
            $table->string('pres_barangay')->nullable();
            $table->string('pres_zip_code', 4)->nullable();

        ////////// ACADEMIC INFORMATION

            // PREVIOUS SCHOOL
            $table->string('highschool');
            $table->string('highschool_add')->nullable();
            $table->string('highschool_sector')->nullable();
            $table->string('type', 20);
            $table->integer('gwa')->nullable();
            $table->integer('twelve_gwa')->nullable();
            $table->integer('twelve_gwa_1')->nullable();
            $table->integer('twelve_gwa_2')->nullable();
            $table->integer('twelve_gwa_3')->nullable();
            $table->integer('eleven_gwa')->nullable();
            $table->integer('eleven_gwa_1')->nullable();
            $table->integer('eleven_gwa_2')->nullable();
            $table->integer('eleven_gwa_3')->nullable();

            // ACADEMIC REQUIREMENTS
            $table->string('twelve_card')->nullable();
            $table->string('eleven_card')->nullable();

            // IF FUTURE SCHOOL IS WITHIN CAR
            $table->integer('institution_id')->unsigned()->nullable();

            // IF FUTURE SCHOOL IS OUTSIDE CAR
            $table->string('hei_out_car_name')->nullable();
            $table->string('hei_out_car_address')->nullable();
            $table->string('hei_out_car_sector')->nullable();

            // COURSE
            $table->integer('course_id')->unsigned();

            // OTHER SOURCES OF ASSISTANCE
            $table->string('other_fa_agency')->nullable();
            $table->string('other_fa_type')->nullable();
            $table->string('other_fa_agency2')->nullable();
            $table->string('other_fa_type2')->nullable();

        ////////// FAMILY BACKGROUND

            // FATHER
            $table->boolean('f_is_living');
            $table->string('f_name')->nullable();
            $table->string('f_add')->nullable();
            $table->string('f_contact_no', 15)->nullable();
            $table->string('f_occupation')->nullable();
            $table->string('f_employer')->nullable();
            $table->string('f_employer_add')->nullable();
            $table->string('f_education')->nullable();

            // MOTHER
            $table->boolean('m_is_living');
            $table->string('m_name')->nullable();
            $table->string('m_add')->nullable();
            $table->string('m_contact_no', 15)->nullable();
            $table->string('m_occupation')->nullable();
            $table->string('m_employer')->nullable();
            $table->string('m_employer_add')->nullable();
            $table->string('m_education')->nullable();

            // LEGAL GUARDIAN
            $table->string('g_name')->nullable();
            $table->string('g_add')->nullable();
            $table->string('g_contact_no', 15)->nullable();
            $table->string('g_occupation')->nullable();
            $table->string('g_employer')->nullable();
            $table->string('g_employer_add')->nullable();
            $table->string('g_education')->nullable();

            // FAMILY
            $table->integer('siblings');
            $table->integer('annual_gross_income');

            // INCOME REQUIREMENT
            $table->string('income_proof_type')->nullable();
            $table->string('income_proof')->nullable();

            // DSWD 4PS 
            $table->boolean('is_dswd_4ps');

        ////////// SPECIAL GROUP

            // IP
            $table->string('tribe')->nullable();
            $table->string('cert_indigency')->nullable();

            // PWD
            $table->string('disability')->nullable();
            $table->string('pwd_id')->nullable();

            // SC
            $table->string('sc_type', 15)->nullable();
            $table->string('sc_id')->nullable();

            // SP
            $table->string('sp_type', 15)->nullable();
            $table->string('sp_id')->nullable();

            // ORPHAN
            $table->boolean('is_orphan');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('applicants');
    }
}
