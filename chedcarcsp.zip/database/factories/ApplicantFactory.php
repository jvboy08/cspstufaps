<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Applicant;
use Faker\Generator as Faker;
use App\Course;
use App\Institution;

$factory->define(Applicant::class, function (Faker $faker) {
	$district = $faker->randomElement(["Abra", "Apayao", "Benguet", "Ifugao", "Kalinga", "Mountain Province"]);
	$muni_city;
	$highschool;
	if($district == "Abra") {
		$muni_city = $faker->randomElement(['Bangued', 'Boliney', 'Bucay', 'Bucloc', 'Daguioman', 'Danglas', 'Dolores', 'La Paz', 'Lacub', 'Lagangilang', 'Lagayan', 'Langiden', 'Licuan-Baay', 'Luba', 'Malibcong', 'Manabo', 'Penarrubia', 'Pidigan', 'Pilar', 'Sallapadan', 'San Isidro', 'San Juan', 'San Quintin', 'Tayum', 'Tineg', 'Tubo', 'Villaviciosa']);
		$highschool = $faker->randomElement(['Abra HS', 'Boliney NHS', 'Cristina B. Gonzales MHS', 'Dugong NHS', 'Pangtod NHS', 'Capitan NHS', 'Western Abra NHS', 'Rosalio Eduarte NHS', 'Cayapa NHS', 'Tagodtod NHS', 'Pulot NHS', 'Langiden NHS', 'Baay NHS']);
	} else if($district == "Apayao") {
		$muni_city = $faker->randomElement(['Calanasan (Bayag)', 'Conner', 'Flora', 'Kabugao', 'Luna', 'Pudtol', 'Sta. Marcela']);
		$highschool = $faker->randomElement(["Apayao Nat'l Ind'l. & Agr'l. HS", 'Calanasan NHS', 'Pio Da Lim Mem. SAT - Tanglagan Annex', 'Pio Dalim Mem. SAT', 'Conner Central NHS', 'Gov. Benjamin Leguiyab, Sr. Mem. NHS', 'Flora NHS', "Kabugao Agro-Ind'l. HS"]);
	} else if($district == "Benguet") {
		$muni_city = $faker->randomElement(['Atok', 'Baguio City', 'Bakun', 'Bokod', 'Buguias', 'Itogon', 'Kabayan', 'Kapangan', 'Kibungan', 'La Trinidad', 'Lepanto, Mankayan', 'Mankayan', 'Philippine Military Academy, Baguio', 'Sablan', 'Tuba', 'Tublay']);
		$highschool = $faker->randomElement(['Baguio City National High School', 'Philippine Science High School', 'Pines City NHS', 'Atok NHS', 'Ampusongan NHS', 'Bakun NHS', 'Bokod NHS', 'Buguias NHS', 'Alejo M. Pacalso Mem. NHS', 'Binga NHS']);
	} else if($district == "Ifugao") {
		$muni_city = $faker->randomElement(['Aguinaldo', 'Alista', 'Asipulo', 'Banaue', 'Hingyon', 'Hungduan', 'Kiangan', 'Lagawe', 'Lamut', 'Mayoyao', 'Tinoc']);
		$highschool = $faker->randomElement(['Aguinaldo NHS (ISCAF)', 'Rufino I. Chungalao Science HS', 'Eastern NHS', 'Namillangan NHS', 'Potia NHS', 'Sta. Maria NHS', 'Asipulo NHS', 'Haliap NHS', 'Banaue NHS', 'Gohang NHS', 'Bangbang NHS']);
	} else if($district == "Kalinga") {
		$muni_city = $faker->randomElement(['Balbalan', 'Lubuagan', 'Pasil', 'Pinukpuk', 'Rizal', 'Tabuk City', 'Tanudan', 'Tinglayan']);
		$highschool = $faker->randomElement(['Aguinaldo NHS (ISCAF)', 'Rufino I. Chungalao Science HS', 'Eastern NHS', 'Namillangan NHS', 'Potia NHS', 'Sta. Maria NHS', 'Asipulo NHS', 'Haliap NHS', 'Banaue NHS', 'Gohang NHS', 'Bangbang NHS']);
	} else if($district == "Mountain Province") {
		$muni_city = $faker->randomElement(['Barlig', 'Bauko', 'Besao', 'Bontoc', 'Natonin', 'Paracelis', 'Sabangan', 'Sadanga', 'Sagada', 'Tadian']);
		$highschool = $faker->randomElement(['Aguinaldo NHS (ISCAF)', 'Rufino I. Chungalao Science HS', 'Eastern NHS', 'Namillangan NHS', 'Potia NHS', 'Sta. Maria NHS', 'Asipulo NHS', 'Haliap NHS', 'Banaue NHS', 'Gohang NHS', 'Bangbang NHS']);
	}
	$barangay = $faker->streetAddress;
	$zip_code = mt_rand(2000, 4000);

	$twelve_gwa = mt_rand(80, 100);
	$annual_gross_income = mt_rand(100000, 400000);
	$gwa = $twelve_gwa;

	$tribe = $faker->randomElement(['Applai', 'Balangao', 'Bontok', 'Kankana-ey', 'Tingguian', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null]);
	$disability = $faker->randomElement(['CD', 'DCI', 'LD', 'ID', 'OD', 'MPD', 'VD', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null]);
	$sp_type = $faker->randomElement(['Dependent', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null]);
	$is_orphan = $faker->randomElement(['1', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0']);

	$score = 0;
	if($gwa >= 99) {
		$score += (100 * 0.7);
	} else if($gwa >= 97) {
		$score += (95 * 0.7);
	} else if($gwa >= 95) {
		$score += (90 * 0.7);
	} else if($gwa >= 93) {
		$score += (85 * 0.7);
	} else if($gwa >= 91) {
		$score += (80 * 0.7);
	} else {
		$score += (75 * 0.7);
	}

	if($annual_gross_income <= 70000) {
		$score += (100 * 0.3);
	} else if($annual_gross_income <= 136000) {
		$score += (95 * 0.3);
	} else if($annual_gross_income <= 202000) {
		$score += (90 * 0.3);
	} else if($annual_gross_income <= 268000) {
		$score += (85 * 0.3);
	} else if($annual_gross_income <= 334000) {
		$score += (80 * 0.3);
	} else {
		$score += (75 * 0.3);
	}

	if($tribe != null || $disability != null || $sp_type != null || $is_orphan == 1) {
		$score += 5;
	}

	$gender = $faker->randomElement(['M', 'F']);
	$year = $faker->randomElement([6, 6, 6, 6, 5, 4, 3, 2, 1]);
	$entry_date = $faker->dateTimeBetween($startDate = '-'.$year.' years', $endDate = 'now', $timezone = null)->format('Y-m-d');

	$name_last = $faker->lastName;
	$name_first = $gender == 'M' ? $faker->firstNameMale : $faker->firstNameFemale;

	$other_fa_agency = $faker->randomElement(['DOST', 'LANI', null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null]);

	if($other_fa_agency == 'DOST') {
		$other_fa_type = $faker->randomElement(['S&T Undergraduate Scholarship', 'Junior Level Science Scholarship']);
	} else if($other_fa_agency == 'LANI') {
		$other_fa_type = $faker->randomElement(['Premier/Specialized School', 'Honors', 'Priority Courses and Skills Training', 'Basic + SUC/LCU', 'SUC/LCU', 'Basic']);
	} else {
		$other_fa_type = null;
	}

    $app_no = 0;
    $check = true;
    while($check) {
        $app_no = rand(1000000, 9999999);
        if(Applicant::where('app_no', $app_no)->first() == null) {
            $check = false;
        }
    }

    $name_last = $faker->lastName;

    return [
    ////////// APPLICATION DETAILS
        'app_no' => $app_no,
    	'entry_date' => $entry_date,
    	'entry_acad_year' => substr($entry_date, 0, 4),
    	'is_accepted' => 0,
        'are_documents_validated' => 0,
        'score' => $score,

    ////////// PERSONAL INFORMATION
        
        // PERSONAL DETAILS
        'name_last' => $name_last,
        'name_first' => $name_first,
        'name_middle' => $faker->lastName,
        'name_ext' => null,
        'name_maiden' => null,
        'birthday' => $faker->dateTimeBetween($startDate = '-20 years', $endDate = '-15 years', $timezone = null)->format('Y-m-d'),
        'birthplace' => $faker->streetAddress,
        'sex' => $gender,
        'civil_status' => 'Single',
        'citizenship' => 'Filipino',

        // CONTACT DETAILS
        'email_address' => $faker->email,
        'contact_number' => '0'.mt_rand(9000000000, 9999999999),
        'fb_account' => $name_first.' '.$name_last,

        // PERSONAL IDENTIFICATION
        'birth_cert' => null,
        'id_photo' => null,

    ////////// ADDRESS INFORMATION

        // PERMANENT ADDRESS
        'perm_district' => $district,
        'perm_province' => $district,
        'perm_muni_city' => $muni_city,
        'perm_barangay' => $barangay,
        'perm_zip_code' => $zip_code,

        // PRESENT ADDRESS
        'pres_is_perm' => 1,
        'pres_district' => null,
        'pres_province' => null,
        'pres_muni_city' => null,
        'pres_barangay' => null,
        'pres_zip_code' => null,

    ////////// ACADEMIC INFORMATION

        // PREVIOUS SCHOOL
		'highschool' => $highschool,
        'highschool_add' => $faker->address,
        'highschool_sector' => mt_rand(0, 1) == 1 ? 'Private' : 'Public',
		'type' => 'Graduate',
        'gwa' => $gwa,
        'twelve_gwa' => $twelve_gwa,

        // ACADEMIC REQUIREMENTS
        'twelve_card' => null,
        'eleven_card' => null,

        // FUTURE SCHOOL
        'institution_id' => mt_rand(1, Institution::count()),
		'course_id' => mt_rand(1, Course::count()),

        // OTHER SOURCES OF ASSISTANCE
        'other_fa_agency' => $other_fa_agency,
        'other_fa_type' => $other_fa_type,
        'other_fa_agency2' => null,
        'other_fa_type2' => null,

    ////////// FAMILY BACKGROUND

        // FATHER
        'f_is_living' => $is_orphan || $sp_type == null ? 0 : 1,
        'f_name' => $faker->firstNameMale.' '.substr($faker->lastName, 0, 1).'. '.$name_last,
        'f_add' => $is_orphan || $sp_type != null ? null : $barangay.', '.$muni_city.', '.$district.' '.$zip_code,
        'f_contact_no' => $is_orphan || $sp_type != null ? null : '0'.mt_rand(9000000000, 9999999999),
        'f_occupation' => $is_orphan || $sp_type != null ? null : $faker->randomElement(['Technical Support Staff', 'Call Center Agent', 'Customer Service Assistant', 'IT Specialist', 'Factory Worker', 'Salesperson', 'Sales Clerk', 'Construction Laborer', 'Receptionist', 'Accounts Executive']),
        'f_employer' => $is_orphan || $sp_type != null ? null : $faker->name,
        'f_employer_add' => $is_orphan || $sp_type != null ? null : $faker->address,
        'f_education' => $is_orphan || $sp_type != null ? null : $faker->randomElement(['No Grade Completed', 'Elementary Undergraduate', 'Elementary Graduate', 'High School Undergraduate', 'High School Graduate', 'Post Secondary Undergraduate', 'Post Secondary Graduate', 'College Undergraduate', 'College Graduate', 'Post Baccalaureate']),

        // MOTHER
        'm_is_living' => $is_orphan ? 0 : 1,
        'm_name' => $faker->firstNameFemale.' '.substr($faker->lastName, 0, 1).'. '.$name_last,
        'm_add' => $is_orphan ? null : $barangay.', '.$muni_city.', '.$district.' '.$zip_code,
        'm_contact_no' => $is_orphan ? null : '0'.mt_rand(9000000000, 9999999999),
        'm_occupation' => $is_orphan ? null : $faker->randomElement(['Technical Support Staff', 'Call Center Agent', 'Customer Service Assistant', 'IT Specialist', 'Factory Worker', 'Salesperson', 'Sales Clerk', 'Construction Laborer', 'Receptionist', 'Accounts Executive']),
        'm_employer' => $is_orphan ? null : $faker->name,
        'm_employer_add' => $is_orphan ? null : $faker->address,
        'm_education' => $is_orphan ? null : $faker->randomElement(['No Grade Completed', 'Elementary Undergraduate', 'Elementary Graduate', 'High School Undergraduate', 'High School Graduate', 'Post Secondary Undergraduate', 'Post Secondary Graduate', 'College Undergraduate', 'College Graduate', 'Post Baccalaureate']),

        // LEGAL GUARDIAN
        'g_name' => $is_orphan ? $faker->firstName.' '.substr($faker->lastName, 0, 1).'. '.$name_last : null,
        'g_add' => $is_orphan ? $barangay.', '.$muni_city.', '.$district.' '.$zip_code : null,
        'g_contact_no' => $is_orphan ? '0'.mt_rand(9000000000, 9999999999) : null,
        'g_occupation' => $is_orphan ? $faker->randomElement(['Technical Support Staff', 'Call Center Agent', 'Customer Service Assistant', 'IT Specialist', 'Factory Worker', 'Salesperson', 'Sales Clerk', 'Construction Laborer', 'Receptionist', 'Accounts Executive']) : null,
        'g_employer' => $is_orphan ? $faker->name : null,
        'g_employer_add' => $is_orphan ? $faker->address : null,
        'g_education' => $is_orphan ? $faker->randomElement(['No Grade Completed', 'Elementary Undergraduate', 'Elementary Graduate', 'High School Undergraduate', 'High School Graduate', 'Post Secondary Undergraduate', 'Post Secondary Graduate', 'College Undergraduate', 'College Graduate', 'Post Baccalaureate']) : null,

        // FAMILY
        'siblings' => mt_rand(1, 5),
        'annual_gross_income' => $annual_gross_income,

        // INCOME REQUIREMENT
        'income_proof_type' => null,
        'income_proof' => null,

        // DSWD 4PS 
        'is_dswd_4ps' => $faker->randomElement([0, 0, 0, 0, 0, 0, 0, 0, 0, 1]),

    ////////// SPECIAL GROUP

        // IP
        'tribe' => $tribe,
        'cert_indigency' => null,

        // PWD
        'disability' => $disability,
        'pwd_id' => null,

        // SC
        'sc_type' => null,
        'sc_id' => null,

        // SP
        'sp_type' => $sp_type,
        'sp_id' => null,

        // ORPHAN
        'is_orphan' => $is_orphan
    ];
});