<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\User;
use Faker\Generator as Faker;
use Illuminate\Support\Str;
use App\Institution;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->define(User::class, function (Faker $faker) {
	$verification_code = '';
    $check = true;
    while($check) {
        $verification_code = sha1(time() - rand(1, 2000));
        if(User::where('verification_code', $verification_code)->first() == null) {
            $check = false;
        }
    }

    return [
        'name' => $faker->name,
        'email' => $faker->unique()->safeEmail,
        'is_verified' => 0,
        'institution_id' => mt_rand(1, Institution::count()),
        'user_type' => 'coordinator',
        'verification_code' => $verification_code,
        'coordinator_role' => $faker->randomElement(['head', 'head', 'head', 'head', 'assistant'])
    ];
});
