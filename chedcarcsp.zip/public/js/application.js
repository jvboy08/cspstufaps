// DOWNLOAD APPLICATION FORM AS PDF
const { PDFDocument, rgb, StandardFonts } = PDFLib;
const url = "../pdf/csp.pdf";
var pdfDoc;
var helvetica;

async function createPdf() {
  const existingPdfBytes = await fetch(url).then(res => res.arrayBuffer());
  pdfDoc = await PDFDocument.load(existingPdfBytes);
  helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const symbols = await pdfDoc.embedFont(StandardFonts.ZapfDingbats);
  const pages = pdfDoc.getPages();
  const firstPage = pages[0];
  const { width, height } = firstPage.getSize();

  // FIRST NAME
  firstPage.drawText($('input[name="name_first"]').val(), {
    x: 183, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // MIDDLE NAME
  firstPage.drawText(['na', 'n/a'].includes($('input[name="name_middle"]').val().toLowerCase()) ? 'N/A' : $('input[name="name_middle"]').val(), {
    x: 352, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // LAST NAME
  firstPage.drawText(['na', 'n/a'].includes($('input[name="name_ext"]').val().toLowerCase()) ? $('input[name="name_last"]').val() : $('input[name="name_last"]').val() + ' ' + $('input[name="name_ext"]').val(), {
    x: 73, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // MAIDEN NAME
  firstPage.drawText(['na', 'n/a'].includes($('input[name="name_maiden"]').val().toLowerCase()) ? 'N/A' : $('input[name="name_maiden"]').val(), {
    x: 420, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // DATE OF BIRTH
  var birthday = $('input[name="birthday"]').val();
  firstPage.drawText(birthday.substring(5, 7) + '/' + birthday.substring(8, 10) + '/' + birthday.substring(0, 4), {
    x: 121, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // PLACE OF BIRTH
  let birthplace_canvas = document.createElement("canvas");
  let birthplace_context = birthplace_canvas.getContext("2d");
  birthplace_context.font = "regular 6pt helvetica";
  let birthplace_metrics = birthplace_context.measureText($('input[name="birthplace"]').val());
  firstPage.drawText(['na', 'n/a'].includes($('input[name="birthplace"]').val().toLowerCase()) ? 'N/A' : $('input[name="birthplace"]').val(), {
    x: 121, y: height - 346, size: birthplace_metrics.width < 200 ? 6 : 5, font: helvetica, color: rgb(0, 0, 0)
  });

  // SEX
  firstPage.drawText('✓', {
    x: $('select[name="sex"]').val() == 'M' ? 127 : 167, y: height - 356, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // CIVIL STATUS
  var x_pos = 0;
  var y_pos = 0;
  if($('select[name="civil_status"]').val() == 'Single') {
    x_pos = 127;
    y_pos = 366;
  } else if($('select[name="civil_status"]').val() == 'Married') {
    x_pos = 127;
    y_pos = 377;
  } else if($('select[name="civil_status"]').val() == 'Annulled') {
    x_pos = 127;
    y_pos = 387;
  } else if($('select[name="civil_status"]').val() == 'Widowed') {
    x_pos = 167;
    y_pos = 366;
  } else if($('select[name="civil_status"]').val() == 'Separated') {
    x_pos = 167;
    y_pos = 377;
  } else {
    x_pos = 167;
    y_pos = 387;
  }
  firstPage.drawText('✓', {
    x: x_pos, y: height - y_pos, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // CITIZENSHIP
  firstPage.drawText(['na', 'n/a'].includes($('input[name="citizenship"]').val().toLowerCase()) ? 'N/A' : $('input[name="citizenship"]').val(), {
    x: 121, y: height - 397, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // MOBILE NUMBER
  firstPage.drawText(['na', 'n/a'].includes($('input[name="contact_number"]').val().toLowerCase()) ? 'N/A' : $('input[name="contact_number"]').val(), {
    x: 121, y: height - 407, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // EMAIL ADDRESS
  let email_address_canvas = document.createElement("canvas");
  let email_address_context = email_address_canvas.getContext("2d");
  email_address_context.font = "regular 6pt helvetica";
  let email_address_metrics = email_address_context.measureText($('input[name="email_address"]').val());
  firstPage.drawText(['na', 'n/a'].includes($('input[name="email_address"]').val().toLowerCase()) ? 'N/A' : $('input[name="email_address"]').val(), {
    x: 121, y: height - 417, size: email_address_metrics.width < 200 ? 6 : 5, font: helvetica, color: rgb(0, 0, 0)
  });

  // ID PHOTO
  var id_photo_image = null;
  var id_photo = document.querySelector('input[name="id_photo"]').files[0];
  var id_photo_parts = $('input[name="id_photo"]').val().split('.');
  if(id_photo_parts[id_photo_parts.length - 1].toLowerCase() == 'png') {
    id_photo_image = await pdfDoc.embedPng(await toBase64(id_photo));
  } else {
    id_photo_image = await pdfDoc.embedJpg(await toBase64(id_photo));
  }

  firstPage.drawImage(id_photo_image, {
    x: 492, y: height - 131, width: 72, height: 72
  });

  // BIRTH CERTIFICATE
  var birth_cert_parts = $('input[name="birth_cert"]').val().split('.');
  if(birth_cert_parts[birth_cert_parts.length - 1].toLowerCase() == 'pdf') {
    await addPdf('birth_cert');
  } else {
    const birth_cert_page = await addImage('birth_cert');
    birth_cert_page.drawText('Birth Certificate', {
      x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
    });
  }

  // HIGHSCHOOL
  firstPage.drawText(['na', 'n/a'].includes($('input[name="highschool"]').val().toLowerCase()) ? 'N/A' : $('input[name="highschool"]').val(), {
    x: 351, y: height - 397, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // HIGHSCHOOL ADDRESS
  var highschool_add_canvas = document.createElement("canvas");
  var highschool_add_context = highschool_add_canvas.getContext("2d");
  highschool_add_context.font = "regular 6pt helvetica";
  var highschool_add_metrics = highschool_add_context.measureText($('input[name="highschool_add"]').val());
  if(highschool_add_metrics.width < 367 || ['na', 'n/a'].includes($('input[name="highschool_add"]').val().toLowerCase())) {
    firstPage.drawText(['na', 'n/a'].includes($('input[name="highschool_add"]').val().toLowerCase()) ? 'N/A' : $('input[name="highschool_add"]').val(), {
      x: 351, y: height - 407, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
  } else {
    var string = $('input[name="highschool_add"]').val();
    for(var i = string.length; i > 0; i--) {
      if (string[i] == " ") {
        var string_canvas = document.createElement("canvas");
        var string_context = string_canvas.getContext("2d");
        string_context.font = "regular 6pt helvetica";
        var string_metrics = string_context.measureText($('input[name="highschool_add"]').val().substring(0, i));
        if(string_metrics.width <= 367) {
          var first_half  = $('input[name="highschool_add"]').val().substring(0, i);
          var second_half  = $('input[name="highschool_add"]').val().substring(i + 1, $('input[name="highschool_add"]').val().length);
          i = 0;
        }
      }
    }
    firstPage.drawText(first_half, {
      x: 351, y: height - 407, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(second_half, {
      x: 351, y: height - 417, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
  }

  // HIGHSCHOOL SECTOR
  firstPage.drawText('✓', {
    x: $('select[name="highschool_sector"]').val() == 'Public' ? 125 : 160, y: height - 427.5, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // ACADEMIC REQUIREMENTS
  if($('select[name="type"]').val() == 'Graduate') {
    firstPage.drawText('✓', {
      x: 291.5, y: height - 184, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 312.5, y: height - 769, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
  } else {
    firstPage.drawText('✓', {
      x: 291.5, y: height - 193.5, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 354.5, y: height - 769, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
  }

  // FUTURE SCHOOL
  if($('#hei_is_car').is(":checked")) {
    firstPage.drawText($('select[name="institution_id"]').children("option:selected").html(), {
      x: 165, y: height - 559.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('select[name="institution_id"]').children("option:selected").html(), {
      x: 153, y: height - 821.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });

    firstPage.drawText($('select[name="institution_id"]').children("option:selected").data('address'), {
      x: 165, y: height - 569.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('select[name="institution_id"]').children("option:selected").data('address'), {
      x: 153, y: height - 831.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });

    firstPage.drawText($('select[name="institution_id"]').children("option:selected").data('sector') == 'P' ? 'Private' : 'Public', {
      x: 165, y: height - 580, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: $('select[name="institution_id"]').children("option:selected").data('sector') == 'P' ? 184.5 : 155, y: height - 842.5, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
  } else {
    firstPage.drawText($('input[name="hei_out_car_name"]').val(), {
      x: 165, y: height - 559.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('input[name="hei_out_car_name"]').val(), {
      x: 153, y: height - 821.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });

    firstPage.drawText($('input[name="hei_out_car_address"]').val(), {
      x: 165, y: height - 569.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('input[name="hei_out_car_address"]').val(), {
      x: 153, y: height - 831.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });

    firstPage.drawText($('select[name="hei_out_car_sector"]').children("option:selected").val(), {
      x: 165, y: height - 580, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: $('select[name="hei_out_car_sector"]').children("option:selected").val() == 'Private' ? 184.5 : 155, y: height - 842.5, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
  }

  // COURSE
  firstPage.drawText($('select[name="course_id"]').children("option:selected").html(), {
    x: 165, y: height - 589.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  firstPage.drawText($('select[name="course_id"]').children("option:selected").html(), {
    x: 229, y: height - 852, size: 5, font: helvetica, color: rgb(0, 0, 0)
  });
  firstPage.drawText('✓', {
    x: $('select[name="course_id"]').children("option:selected").data('priority') == 'none' ? 186.5 : 155, y: height - 852.5, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // OTHER FINANCIAL ASSISTANCE
  if($('input[name=has_other_fa]:checked').val() == 1) {
    firstPage.drawText('✓', {
      x: 167.5, y: height - 610, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('input[name="other_fa_type"]').val(), {
      x: 297, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('input[name="other_fa_agency"]').val(), {
      x: 440, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    if($('input[name=other_fa_count]').val() == 2) {
      firstPage.drawText($('input[name="other_fa_type2"]').val(), {
        x: 297, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText($('input[name="other_fa_agency2"]').val(), {
        x: 440, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    } else {
      firstPage.drawText('N/A', {
        x: 297, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText('N/A', {
        x: 440, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  } else {
    firstPage.drawText('✓', {
      x: 196.5, y: height - 610, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 297, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 440, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 297, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 440, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
  }

  // GRADE 12 CARD / HIGH SCHOOL REPORT CARD
  var twelve_card_parts = $('input[name="twelve_card"]').val().split('.');
  if(twelve_card_parts[twelve_card_parts.length - 1].toLowerCase() == 'pdf') {
    await addPdf('twelve_card');
  } else {
    const twelve_card_page = await addImage('twelve_card');
    twelve_card_page.drawText($('#type').val() == 'Graduating' ? 'Certified Grades for 1st Semester of Grade 12' : 'High School Report Card', {
      x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
    });
  }

  // GRADE 11 CARD
  if($('#type').val() == 'Graduating') {
    var eleven_card_parts = $('input[name="eleven_card"]').val().split('.');
    if(eleven_card_parts[eleven_card_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('eleven_card');
    } else {
      const eleven_card_page = await addImage('eleven_card');
      eleven_card_page.drawText('Certified Grades for Grade 11', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // F DECEASED
  firstPage.drawText('✓', {
    x: $('#f_is_deceased').is(":checked") ? 210 : 173, y: height - 458, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // F NAME
  firstPage.drawText(['na', 'n/a'].includes($('input[name="f_name"]').val().toLowerCase()) ? 'N/A' : $('input[name="f_name"]').val(), {
    x: 127, y: height - 468, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F ADDRESS
  firstPage.drawText($('#f_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="f_add"]').val().toLowerCase()) ? 'N/A' : $('input[name="f_add"]').val(), {
    x: 127, y: height - 478, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F CONTACT NUMBER
  firstPage.drawText($('#f_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="f_contact_no"]').val().toLowerCase()) ? 'N/A' : $('input[name="f_contact_no"]').val(), {
    x: 127, y: height - 488.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F OCCUPATION
  firstPage.drawText($('#f_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="f_occupation"]').val().toLowerCase()) ? 'N/A' : $('input[name="f_occupation"]').val(), {
    x: 127, y: height - 498, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F EMPLOYER
  firstPage.drawText($('#f_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="f_employer"]').val().toLowerCase()) ? 'N/A' : $('input[name="f_employer"]').val(), {
    x: 127, y: height - 508.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F EMPLOYER ADDRESS
  firstPage.drawText($('#f_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="f_employer_add"]').val().toLowerCase()) ? 'N/A' : $('input[name="f_employer_add"]').val(), {
    x: 127, y: height - 518.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F EDUCATION
  firstPage.drawText($('#f_is_deceased').is(":checked") || $('select[name="f_education"]').val() == null ? 'N/A' : $('select[name="f_education"]').val(), {
    x: 127, y: height - 529, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M DECEASED
  firstPage.drawText('✓', {
    x: $('#m_is_deceased').is(":checked") ? 362 : 325, y: height - 458, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // M NAME
  firstPage.drawText(['na', 'n/a'].includes($('input[name="m_name"]').val().toLowerCase()) ? 'N/A' : $('input[name="m_name"]').val(), {
    x: 279, y: height - 468, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M ADDRESS
  firstPage.drawText($('#m_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="m_add"]').val().toLowerCase()) ? 'N/A' : $('input[name="m_add"]').val(), {
    x: 279, y: height - 478, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M CONTACT NUMBER
  firstPage.drawText($('#m_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="m_contact_no"]').val().toLowerCase()) ? 'N/A' : $('input[name="m_contact_no"]').val(), {
    x: 279, y: height - 488.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M OCCUPATION
  firstPage.drawText($('#m_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="m_occupation"]').val().toLowerCase()) ? 'N/A' : $('input[name="m_occupation"]').val(), {
    x: 279, y: height - 498, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M EMPLOYER
  firstPage.drawText($('#m_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="m_employer"]').val().toLowerCase()) ? 'N/A' : $('input[name="m_employer"]').val(), {
    x: 279, y: height - 508.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M EMPLOYER ADDRESS
  firstPage.drawText($('#m_is_deceased').is(":checked") || ['na', 'n/a'].includes($('input[name="m_employer_add"]').val().toLowerCase()) ? 'N/A' : $('input[name="m_employer_add"]').val(), {
    x: 279, y: height - 518.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M EDUCATION
  firstPage.drawText($('#m_is_deceased').is(":checked") || $('select[name="m_education"]').val() == null ? 'N/A' : $('select[name="m_education"]').val(), {
    x: 279, y: height - 529, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G NAME
  firstPage.drawText($('input[name=has_legal_guardian]:checked').val() == 0 || ['na', 'n/a'].includes($('input[name="g_name"]').val().toLowerCase()) ? 'N/A' : $('input[name="g_name"]').val(), {
    x: 430, y: height - 468, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G ADDRESS
  firstPage.drawText($('input[name=has_legal_guardian]:checked').val() == 0 || ['na', 'n/a'].includes($('input[name="g_add"]').val().toLowerCase()) ? 'N/A' : $('input[name="g_add"]').val(), {
    x: 430, y: height - 478, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G CONTACT NUMBER
  firstPage.drawText($('input[name=has_legal_guardian]:checked').val() == 0 || ['na', 'n/a'].includes($('input[name="g_contact_no"]').val().toLowerCase()) ? 'N/A' : $('input[name="g_contact_no"]').val(), {
    x: 430, y: height - 488.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G OCCUPATION
  firstPage.drawText($('input[name=has_legal_guardian]:checked').val() == 0 || ['na', 'n/a'].includes($('input[name="g_occupation"]').val().toLowerCase()) ? 'N/A' : $('input[name="g_occupation"]').val(), {
    x: 430, y: height - 498, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G EMPLOYER
  firstPage.drawText($('input[name=has_legal_guardian]:checked').val() == 0 || ['na', 'n/a'].includes($('input[name="g_employer"]').val().toLowerCase()) ? 'N/A' : $('input[name="g_employer"]').val(), {
    x: 430, y: height - 508.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G EMPLOYER ADDRESS
  firstPage.drawText($('input[name=has_legal_guardian]:checked').val() == 0 || ['na', 'n/a'].includes($('input[name="g_employer_add"]').val().toLowerCase()) ? 'N/A' : $('input[name="g_employer_add"]').val(), {
    x: 430, y: height - 518.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G EDUCATION
  firstPage.drawText($('input[name=has_legal_guardian]:checked').val() == 0 || $('select[name="g_education"]').val() == null ? 'N/A' : $('select[name="g_education"]').val(), {
    x: 430, y: height - 529, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // ANNUAL GROSS INCOME
  firstPage.drawText('PHP ' + $('input[name="annual_gross_income"]').val().toLocaleString(), {
    x: 195, y: height - 539, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // SIBLINGS
  firstPage.drawText($('input[name="siblings"]').val(), {
    x: 195, y: height - 549.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // INCOME PROOF TYPE
  var y_position1 = 0;
  var x_position2 = 0;
  var y_position2 = 0;
  if($('#income_proof_type').val() == 'Income Tax Return') {
    y_position1 = 227;
    x_position2 = 312.5;
    y_position2 = 785;
  } else if($('#income_proof_type').val() == 'Tax Exemption'){
    y_position1 = 236;
    x_position2 = 333.5;
    y_position2 = 785;
  } else if($('#income_proof_type').val() == 'Certificate of Indigency') {
    y_position1 = 245;
    x_position2 = 382;
    y_position2 = 785;
  } else if($('#income_proof_type').val() == 'Case Study DSWD') {
    y_position1 = 253.5;
    x_position2 = 312.5;
    y_position2 = 793;
  } else if($('#income_proof_type').val() == 'OFW Contract') {
    y_position1 = 262;
    x_position2 = 369.5;
    y_position2 = 793;
  }
  firstPage.drawText('✓', {
    x: 291.5, y: height - y_position1, size: 6, font: symbols, color: rgb(0, 0, 0)
  });
  firstPage.drawText('✓', {
    x: x_position2, y: height - y_position2, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // INCOME PROOF DOCUMENT
  var income_proof_parts = $('input[name="income_proof"]').val().split('.');
  if(income_proof_parts[income_proof_parts.length - 1].toLowerCase() == 'pdf') {
    await addPdf('income_proof');
  } else {
    const income_proof_page = await addImage('income_proof');
    income_proof_page.drawText($('select[name="income_proof_type"]').children("option:selected").html(), {
      x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
    });
  }

  // DSWD 4PS
  firstPage.drawText('✓', {
    x: $('input[name=is_dswd_4ps]:checked').val() == 1 ? 433 : 462, y: height - 544, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // PERMANENT AND PRESENT ADDRESS
  var permanent_address = '';
  if($('#perm_add_is_car').is(":checked")) {
    permanent_address = $('input[name=perm_barangay]').val() + ', ' + $('select[name=perm_muni_city]').val() + ', ' + $('select[name=perm_province]').val() + ', ' + $('select[name=perm_district]').val();
  } else {
    permanent_address = $('input[name=perm_barangay]').val() + ', ' + $('input[name=perm_muni_city2]').val() + ', ' + $('input[name=perm_province2]').val() + ', ' + $('input[name=perm_district2]').val();
  }
  var permanent_address_canvas = document.createElement("canvas");
  var permanent_address_context = permanent_address_canvas.getContext("2d");
  permanent_address_context.font = "regular 6pt helvetica";
  var permanent_address_metrics = permanent_address_context.measureText(permanent_address);
  if(permanent_address_metrics.width < 367) {
    firstPage.drawText(permanent_address, {
      x: 351, y: height - 366.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    if($('#pres_is_perm').is(":checked")) {
      firstPage.drawText(permanent_address, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  } else {
    var string = permanent_address;
    for(var i = string.length; i > 0; i--) {
      if (string[i] == " ") {
        var string_canvas = document.createElement("canvas");
        var string_context = string_canvas.getContext("2d");
        string_context.font = "regular 6pt helvetica";
        var string_metrics = string_context.measureText(permanent_address.substring(0, i));
        if(string_metrics.width <= 367) {
          var first_half  = permanent_address.substring(0, i);
          var second_half  = permanent_address.substring(i + 1, permanent_address.length);
          i = 0;
        }
      }
    }
    firstPage.drawText(first_half, {
      x: 351, y: height - 366.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(second_half, {
      x: 351, y: height - 376.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    if($('#pres_is_perm').is(":checked")) {
      firstPage.drawText(first_half, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText(second_half, {
        x: 351, y: height - 346, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }
  if(!$('#pres_is_perm').is(":checked")) {
    var present_address = '';
    if($('#pres_add_is_car').is(":checked")) {
      present_address = $('input[name=pres_barangay]').val() + ', ' + $('select[name=pres_muni_city]').val() + ', ' + $('select[name=pres_province]').val() + ', ' + $('select[name=pres_district]').val();
    } else {
      present_address = $('input[name=pres_barangay]').val() + ', ' + $('input[name=pres_muni_city2]').val() + ', ' + $('input[name=pres_province2]').val() + ', ' + $('input[name=pres_district2]').val();
    }
    var present_address_canvas = document.createElement("canvas");
    var present_address_context = present_address_canvas.getContext("2d");
    present_address_context.font = "regular 6pt helvetica";
    var present_address_metrics = present_address_context.measureText(present_address);
    if(present_address_metrics.width < 367) {
      firstPage.drawText(present_address, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    } else {
      var string = present_address;
      for(var i = string.length; i > 0; i--) {
        if (string[i] == " ") {
          var string_canvas = document.createElement("canvas");
          var string_context = string_canvas.getContext("2d");
          string_context.font = "regular 6pt helvetica";
          var string_metrics = string_context.measureText(present_address.substring(0, i));
          if(string_metrics.width <= 367) {
            var first_half  = present_address.substring(0, i);
            var second_half  = present_address.substring(i + 1, present_address.length);
            i = 0;
          }
        }
      }
      firstPage.drawText(first_half, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText(second_half, {
        x: 351, y: height - 346, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // ZIP CODE
  firstPage.drawText($('input[name=perm_zip_code]').val(), {
    x: 351, y: height - 386.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  firstPage.drawText($('#pres_is_perm').is(":checked") ? $('input[name=perm_zip_code]').val() : $('input[name=pres_zip_code]').val(), {
    x: 351, y: height - 356, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // IP
  firstPage.drawText(!$('#is_ip').is(":checked") ? 'N/A' : $('input[name=tribe]').val(), {
    x: 351, y: height - 437, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  if($('#is_ip').is(":checked")) {
    firstPage.drawText('✓', {
      x: 400, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 785, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('input[name=tribe]').val(), {
      x: 225, y: height - 783, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });
    var cert_indigency_parts = $('input[name="cert_indigency"]').val().split('.');
    if(cert_indigency_parts[cert_indigency_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('cert_indigency');
    } else {
      const cert_indigency_page = await addImage('cert_indigency');
      cert_indigency_page.drawText('Certificate of Indigency', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // PWD
  firstPage.drawText(!$('#is_pwd').is(":checked") ? 'N/A' :  ($('select[name=disability]').val() == 'Others' ? $('input[name=disability_others]').val() : $('select[name="disability"]').children("option:selected").html()), {
    x: 351, y: height - 427, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  if($('#is_pwd').is(":checked")) {
    firstPage.drawText('✓', {
      x: 420.5, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 777, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText($('select[name=disability]').val() == 'Others' ? $('input[name=disability_others]').val() : $('select[name="disability"]').children("option:selected").html(), {
      x: 225, y: height - 775, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });
    var pwd_id_parts = $('input[name="pwd_id"]').val().split('.');
    if(pwd_id_parts[pwd_id_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('pwd_id');
    } else {
      const pwd_id_page = await addImage('pwd_id');
      pwd_id_page.drawText('PWD ID', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // Solo Parent
  if($('#is_sp').is(":checked")) {
    firstPage.drawText('✓', {
      x: 313, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 761, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    var sp_id_parts = $('input[name="sp_id"]').val().split('.');
    if(sp_id_parts[sp_id_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('sp_id');
    } else {
      const sp_id_page = await addImage('sp_id');
      sp_id_page.drawText('Solo Parent ID', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // Senior Citizen
  if($('#is_sc').is(":checked")) {
    firstPage.drawText('✓', {
      x: 353, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 769, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    var sc_id_parts = $('input[name="sc_id"]').val().split('.');
    if(sc_id_parts[sc_id_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('sc_id');
    } else {
      const sc_id_page = await addImage('sc_id');
      sc_id_page.drawText('Senior Citizen ID', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  const pdfBytes = await pdfDoc.save();
  download(pdfBytes, "CHED-CAR CSP Application Form.pdf", "application/pdf");
}

// CONVERT STRING TO BASE64
const toBase64 = file => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.readAsDataURL(file);
  reader.onload = () => resolve(reader.result);
  reader.onerror = error => reject(error);
});

// ADD UPLOADED PDF
async function addPdf(input) {
  const file = document.querySelector('input[name="' + input + '"]').files[0];
  const pdf = await PDFDocument.load(await toBase64(file));
  const [page] = await pdfDoc.copyPages(pdf, [0]);
  pdfDoc.addPage(page);
}

// ADD UPLOADED IMAGE
async function addImage(input) {
  var file = document.querySelector('input[name="' + input + '"]').files[0];
  var parts = $('input[name="' + input + '"]').val().split('.');
  var image = null;
  if(parts[parts.length - 1].toLowerCase() == 'png') {
    image = await pdfDoc.embedPng(await toBase64(file));
  } else {
    image = await pdfDoc.embedJpg(await toBase64(file));
  }
  const page = pdfDoc.addPage([612, 936]);
  const scaled_image = image.scaleToFit(540, 864);
  page.drawImage(image, {
    x: 36 + ((540 - scaled_image.width) / 2), y: 36 + (864 - scaled_image.height), height: scaled_image.height, width: scaled_image.width
  });
  return page;
}

// FORM STEPS
var container_top = 0;
$(window).load(function() {
  container_top = $('.form').offset().top;
});

var $steps = $('.step');

function navigateTo(index) {
  $steps.removeClass('active_step').eq(index).addClass('active_step');
  $('.prev').toggle(index > 0);
  var last_index = index >= $steps.length - 1;
  $('.next').toggle(!last_index);
  $('.submit').toggle(last_index);

  for(let j = index - 1; j >= 0; j--) {
    $('.step' + j).addClass("done");
    $('.step' + j).removeClass("active inactive");
    $('.step' + j + ' .circle').html("<span class='material-icons-round check'>check</span>");
  }
  for(let i = index + 1; i <= $steps.length - 1; i++) {
    $('.step' + i).addClass("inactive");
    $('.step' + i).removeClass("active done");
    $('.step' + i + ' .circle').html("<h6>" + (i + 1) + "</h6>");
  }

  $('.step' + index).addClass("active");
  $('.step' + index).removeClass("inactive done");
  $('.step' + index + ' .circle').html("<h6>" + (index + 1) + "</h6>");
};

function current_index() {
  return $steps.index($steps.filter('.active_step'));
}

$('.prev').click(function() {
  navigateTo(current_index() - 1);
  $("html, body").animate({
    scrollTop: container_top
  }, 800);
});

$('.next').click(function() {
  $('.application_form').parsley().whenValidate({
    group: 'block-' + current_index()
  }).done(function() {
    if(current_index() == 1) {
      $.ajax({ 
        url: '/application/check/'+$('#name_first').val()+'/'+$('#name_middle').val()+'/'+$('#name_last').val()+'/'+$('#name_ext').val()+'/'+$('#name_maiden').val()+'/'+$('#birthday').val(),
        type: "GET",
        dataType: "text",
        success: function(data) {
          if(data == 0) {
            navigateTo(current_index() + 1);
            $("html, body").animate({
              scrollTop: container_top
            }, 800);
          } else {
            $('.form').addClass('existing');
            $('.existing').removeClass('form');
            $('.existing').empty();
            $('.existing').html("<p>We found an existing applicant for CHED Scholarship Program with the same name and date of birth that you have provided. In view of this, we advise you to email us at <span class='bold'>chedcar@ched.gov.ph</span>, message us at the <a href='https://www.facebook.com/chedstufaps.cordillera'><span class='bold'>CHED Cordillera-StuFAPs</span></a> Facebook page, or visit the office of CHED-CAR in BSU Compound, La Trinidad, Benguet for assistance. Thank you for your understanding.</p><a type='button' class='add' href='/'>Return to Homepage</a>");
          }
        }
      });
    } else {
      navigateTo(current_index() + 1);
      $("html, body").animate({
        scrollTop: container_top
      }, 800);
    }
  });
});

$steps.each(function(index, step) {
  $(step).find(':input').attr('data-parsley-group', 'block-' + index);
});

navigateTo(0);

// CONTACT NUMBER VALIDATOR
window.Parsley.addValidator('validateContact', {
  validateString: function(value) {
    if (/^((09)\d{2}-\d{3}-\d{4})$/.test(value)) {
      return true;
    } else if (/^((NA))$/.test(value)) {
      return true;
    } else {
      return false;
    }
  },
  messages: {
    en: 'Valid format: 0999-999-9999'
  }
});

// GWA VALIDATOR
window.Parsley.addValidator('validateGradeNullable', {
  validateString: function(value) {
    if (/^6[5-9]|[7-9][0-9]|100$/.test(value)) {
      return true;
    } else if (/^((NA))$/.test(value)) {
      return true;
    } else {
      return false;
    }
  },
  messages: {
    en: 'Value should be 65 to 100'
  }
});

// GWA VALIDATOR
window.Parsley.addValidator('validateGrade', {
  validateString: function(value) {
    if (/^6[5-9]|[7-9][0-9]|100$/.test(value)) {
      return true;
    } else {
      return false;
    }
  },
  messages: {
    en: 'Value should be 65 to 100'
  }
});

// CHECK IF IMAGE IS SQUARE
window.Parsley.addValidator('validatePhoto', {
  validateString: function (value) {
    let file = document.querySelector('input[name="id_photo"]').files[0];
    let image = new Image();
    let deferred = $.Deferred();
    image.src = window.URL.createObjectURL(file);
    image.onload = function() {
      if(Math.abs(this.width - this.height) < 5) {
        deferred.resolve();
      } else {
        deferred.reject("Image should have equal width and height");
      }
    };
    return deferred.promise();
  },
  messages: {
    en: 'Image should have equal width and height'
  }
});

// FUTURE SCHOOL TOGGLE INPUTS
$('#hei_is_car').bind('change', function() {
  if($('#hei_is_car').is(":checked")) {
    $('.hei_inside_car').css('display', 'block');
    $('.hei_inside_car').children('select').prop('required', true);

    $('.hei_outside_car').each(function() {
      $(this).css('display', 'none');
      $(this).children('input').prop('required', false);
      $(this).children('select').prop('required', false);
    });
  } else {
    $('.hei_inside_car').css('display', 'none');
    $('.hei_inside_car').children('select').prop('required', false);

    $('.hei_outside_car').each(function() {
      $(this).css('display', 'block');
      $(this).children('input').prop('required', true);
      $(this).children('select').prop('required', true);
    });
  }
});

// PERMANENT ADDRESS TOGGLE INPUTS
$('#perm_add_is_car').bind('change', function() {
  if($('#perm_add_is_car').is(":checked")) {
    $('.inside_car').each(function() {
      $(this).css('display', 'block');
      $(this).children('select').prop('required', true);
    });
    $('.outside_car').each(function() {
      $(this).css('display', 'none');
      $(this).children('input').prop('required', false);
    });
  } else {
    $('.inside_car').each(function() {
      $(this).css('display', 'none');
      $(this).children('select').prop('required', false);
    });
    $('.outside_car').each(function() {
      $(this).css('display', 'block');
      $(this).children('input').prop('required', true);
    });
  }
});

// PRESENT ADDRESS TOGGLE INPUTS
$('#pres_add_is_car').bind('change', function() {
  if($('#pres_add_is_car').is(":checked")) {
    $('.inside_car2').each(function() {
      $(this).css('display', 'block');
      $(this).children('select').prop('required', true);
    });
    $('.outside_car2').each(function() {
      $(this).css('display', 'none');
      $(this).children('input').prop('required', false);
    });
  } else {
    $('.inside_car2').each(function() {
      $(this).css('display', 'none');
      $(this).children('select').prop('required', false);
    });
    $('.outside_car2').each(function() {
      $(this).css('display', 'block');
      $(this).children('input').prop('required', true);
    });
  }
});

// PRESENT ADDRESS IS SAME WITH PERMANENT ADDRESS
$('#pres_is_perm').bind('change', function() {
  if($('#pres_is_perm').is(":checked")) {
    $('.pres_add').css('display', 'none');
    $('.checkbox_pres_add').css('display', 'none');
    $('.pres_add input').each(function() {
      $(this).prop('required', false);
    });
    $('.pres_add select').each(function() {
      $(this).prop('required', false);
    });
  } else {
    $('.pres_add').css('display', 'grid');
    $('.checkbox_pres_add').css('display', 'flex');
    if($('#pres_add_is_car').is(":checked")) {
      $('.pres_add select').each(function() {
        $(this).prop('required', true);
      });
      $('.pres_add input').each(function() {
        $(this).prop('required', false);
      });
    } else {
      $('.pres_add select').each(function() {
        $(this).prop('required', false);
      });
      $('.pres_add input').each(function() {
        $(this).prop('required', true);
      });
    }
  }
});

// ADD EVENT LISTENER TO PROVINCE INPUTS
$('#perm_province').bind('change', function() {
  changeCities(null, '#perm_province', '#perm_muni_city')
});
$('#pres_province').bind('change', function() {
  changeCities(null, '#pres_province', '#pres_muni_city')
});

// CHECK IF ENJOYS OTHER SOURCE OF ASSISTANCE
$('.has_other_fa').on('change', function() {
  if($('input[name=has_other_fa]:checked').val() == 1) {
    $('.other_fa_container').css('display', 'block');
    $('.other_fa input').each(function() {
      $(this).prop('required', true);
    });
    checkSecondFA();
  } else {
    $('.other_fa_container').css('display', 'none');
    $('.other_fa input').each(function() {
      $(this).prop('required', false);
    });
    $('.other_fa2 input').each(function() {
      $(this).prop('required', false);
    });
  }
});

function checkSecondFA() {
  if($('input[name=other_fa_count]').val() == 2) {
    $('.other_fa2').css('display', 'grid');
    $('.other_fa2 input').each(function() {
      $(this).prop('required', true);
    });
    $('.add_second_fa').css('display', 'none');
    $('.remove_second_fa').css('display', 'block');
    $('.title_first_fa').css('display', 'block');
  } else {
    $('.other_fa2').css('display', 'none');
    $('.other_fa2 input').each(function() {
      $(this).prop('required', false);
    });
    $('.add_second_fa').css('display', 'block');
    $('.remove_second_fa').css('display', 'none');
    $('.title_first_fa').css('display', 'none');
  }
}

$('.add_second_fa').on('click', function() {
  $('input[name=other_fa_count]').val(2);
  checkSecondFA();
});

$('.remove_second_fa').on('click', function() {
  $('input[name=other_fa_count]').val(1);
  checkSecondFA();
});

checkSecondFA();

// IF FATHER IS DECEASED
$('#f_is_deceased').bind('change', function() {
  if($('#f_is_deceased').is(":checked")) {
    $('.f_deceased_container').each(function() {
      $(this).css('display', 'none');
    });
    $('.f_deceased_container input').each(function() {
      $(this).prop('required', false);
    });
    $('.f_deceased_container select').each(function() {
      $(this).prop('required', false);
    });
  } else {
    $('.f_deceased_container').each(function() {
      $(this).css('display', 'block');
    });
    $('.f_deceased_container input').each(function() {
      $(this).prop('required', true);
    });
    $('.f_deceased_container select').each(function() {
      $(this).prop('required', true);
    });
  }
});

// IF MOTHER IS DECEASED
$('#m_is_deceased').bind('change', function() {
  if($('#m_is_deceased').is(":checked")) {
    $('.m_deceased_container').each(function() {
      $(this).css('display', 'none');
    });
    $('.m_deceased_container input').each(function() {
      $(this).prop('required', false);
    });
    $('.m_deceased_container select').each(function() {
      $(this).prop('required', false);
    });
  } else {
    $('.m_deceased_container').each(function() {
      $(this).css('display', 'block');
    });
    $('.m_deceased_container input').each(function() {
      $(this).prop('required', true);
    });
    $('.m_deceased_container select').each(function() {
      $(this).prop('required', true);
    });
  }
});

// CHECK IF HAS LEGAL GUARDIAN
$('.has_legal_guardian').on('change', function() {
  if($('input[name=has_legal_guardian]:checked').val() == 1) {
    $('#legal_guardian_container').css('display', 'grid');
    $('#legal_guardian_container input').each(function() {
      $(this).prop('required', true);
    });
    $('#legal_guardian_container select').each(function() {
      $(this).prop('required', true);
    });
  } else {
    $('#legal_guardian_container').css('display', 'none');
    $('#legal_guardian_container input').each(function() {
      $(this).prop('required', false);
    });
    $('#legal_guardian_container select').each(function() {
      $(this).prop('required', false);
    });
  }
});

// IF IP
$('#is_ip').on('change', function() {
  if($('#is_ip').is(":checked")) {
    $('#tribe_container').css('display', 'grid');
    $('#tribe_input').prop('required', true);
    $('#cert_indigency').prop('required', true);
  } else {
    $('#tribe_container').css('display', 'none');
    $('#tribe_input').prop('required', false);
    $('#cert_indigency').prop('required', false);
  }
});

// IF PWD
$('#is_pwd').on('change', function() {
  if($('#is_pwd').is(":checked")) {
    $('#disability_container').css('display', 'grid');
    $('#disability_select').prop('required', true);
    $('#pwd_id').prop('required', true);
    if($('#disability_select').val() == "Others") {
      $('#disability_input').prop('required', true);
    }
  } else {
    $('#disability_container').css('display', 'none');
    $('#disability_select').prop('required', false);
    $('#pwd_id').prop('required', false);
    $('#disability_input').prop('required', false);
  }
});

// IF SC
$('#is_sc').on('change', function() {
  if($('#is_sc').is(":checked")) {
    $('#sc_container').css('display', 'grid');
    $('#sc_id').prop('required', true);
  } else {
    $('#sc_container').css('display', 'none');
    $('#sc_id').prop('required', false);
  }
});

// IF SP
$('#is_sp').on('change', function() {
  if($('#is_sp').is(":checked")) {
    $('#sp_container').css('display', 'grid');
    $('#sp_id').prop('required', true);
  } else {
    $('#sp_container').css('display', 'none');
    $('#sp_id').prop('required', false);
  }
});

// IF TYPE OF DISABILITY IS OTHERS
$('#disability_select').on('change', function() {
  if($('#disability_select').val() == "Others") {
    $('#disability_input_container').css('display', 'block');
    $('#disability_input').prop('required', true);
  } else {
    $('#disability_input_container').css('display', 'none');
    console.log('hello');
    $('#disability_input').prop('required', false);
  }
});

// CHECK APPLICANT TYPE
$('#type').on('change', function() {
  $('.gwa_container').css('display', 'block');
  $('#report_cards_container').css('display', 'block');

  if($('#type').val() == 'Graduate') {
    // GWAS
    $('#eleven_gwa_container').css('display', 'none');
    $('#eleven_gwa_container .grades input').each(function() {
      $(this).prop('required', false);
    });

    // ACADEMIC REQUIREMENTS
    $('#twelve_card_label').html('High School Report Card <span class="optional">(Image or PDF)</span> :');
    $('#eleven_card_container').css('display', 'none');
    $('#eleven_card').prop('required', false);
  } else {
    // GWAS
    $('#eleven_gwa_container').css('display', 'block');
    $('#eleven_gwa_container .grades input').each(function() {
      $(this).prop('required', true);
    });

    // ACADEMIC REQUIREMENTS
    $('#twelve_card_label').html('Certified Grades for G12 <span class="optional">(Image or PDF)</span> :');
    $('#eleven_card_container').css('display', 'block');
    $('#eleven_card').prop('required', true);
  }
});

// CHECK TYPE OF INCOME REQUIREMENT
$('#income_proof_type').on('change', function() {
  $('#income_proof_container').css('display', 'block');
  $('#income_proof_label').html($('#income_proof_type').val() + ' <span class="optional">(Image or PDF)</span> :');
});