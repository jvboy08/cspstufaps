const { PDFDocument, rgb, StandardFonts } = PDFLib;
const url = "../pdf/csp.pdf";
var pdfDoc;
var helvetica;
var pdfBytes;
var blob_iframe;

// DOWNLOAD APPLICATION FORM AS PDF
async function createPdf() {
  const existingPdfBytes = await fetch(url).then(res => res.arrayBuffer());
  pdfDoc = await PDFDocument.load(existingPdfBytes);
  helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const symbols = await pdfDoc.embedFont(StandardFonts.ZapfDingbats);
  const pages = pdfDoc.getPages();
  const firstPage = pages[0];
  const { width, height } = firstPage.getSize();

  // FIRST NAME
  firstPage.drawText(applicant['name_first'], {
    x: 183, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // MIDDLE NAME
  firstPage.drawText(applicant['name_middle'] == null ? 'N/A' : applicant['name_middle'], {
    x: 352, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // LAST NAME
  firstPage.drawText(applicant['name_ext'] == null ? applicant['name_last'] : applicant['name_last'] + ' ' + applicant['name_ext'], {
    x: 73, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // MAIDEN NAME
  firstPage.drawText(applicant['name_maiden'] == null ? 'N/A' : applicant['name_maiden'], {
    x: 420, y: height - 306, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // DATE OF BIRTH
  var birthday = applicant['birthday'];
  firstPage.drawText(birthday.substring(5, 7) + '/' + birthday.substring(8, 10) + '/' + birthday.substring(0, 4), {
    x: 121, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // PLACE OF BIRTH
  let birthplace_canvas = document.createElement("canvas");
  let birthplace_context = birthplace_canvas.getContext("2d");
  birthplace_context.font = "regular 6pt helvetica";
  let birthplace_metrics = birthplace_context.measureText(applicant['birthplace']);
  firstPage.drawText(applicant['birthplace'] == null ? 'N/A' : applicant['birthplace'], {
    x: 121, y: height - 346, size: birthplace_metrics.width < 200 ? 6 : 5, font: helvetica, color: rgb(0, 0, 0)
  });

  // SEX
  firstPage.drawText('✓', {
    x: applicant['sex'] == 'M' ? 127 : 167, y: height - 356, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // CIVIL STATUS
  var x_pos = 0;
  var y_pos = 0;
  if(applicant['civil_status'] == 'Single') {
      x_pos = 127;
      y_pos = 366;
  } else if(applicant['civil_status'] == 'Married') {
      x_pos = 127;
      y_pos = 377;
  } else if(applicant['civil_status'] == 'Annulled') {
      x_pos = 127;
      y_pos = 387;
  } else if(applicant['civil_status'] == 'Widowed') {
      x_pos = 167;
      y_pos = 366;
  } else if(applicant['civil_status'] == 'Separated') {
      x_pos = 167;
      y_pos = 377;
  } else {
      x_pos = 167;
      y_pos = 387;
  }
  firstPage.drawText('✓', {
    x: x_pos, y: height - y_pos, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // CITIZENSHIP
  firstPage.drawText(applicant['citizenship'] == null ? 'N/A' : applicant['citizenship'], {
    x: 121, y: height - 397, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // MOBILE NUMBER
  firstPage.drawText(applicant['contact_number'] == null ? 'N/A' : applicant['contact_number'], {
    x: 121, y: height - 407, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // EMAIL ADDRESS
  let email_address_canvas = document.createElement("canvas");
  let email_address_context = email_address_canvas.getContext("2d");
  email_address_context.font = "regular 6pt helvetica";
  let email_address_metrics = email_address_context.measureText(applicant['email_address']);
  firstPage.drawText(applicant['email_address'] == null ? 'N/A' : applicant['email_address'], {
    x: 121, y: height - 417, size: email_address_metrics.width < 200 ? 6 : 5, font: helvetica, color: rgb(0, 0, 0)
  });

  // ID PHOTO
  if(applicant['id_photo'] != null) {
    const arrayBuffer = await fetch(applicant['id_photo']).then(res => res.arrayBuffer());
    var id_photo_parts = applicant['id_photo'].split('.');
    if(id_photo_parts[id_photo_parts.length - 1].toLowerCase() == 'png') {
      id_photo_image = await pdfDoc.embedPng(arrayBuffer);
    } else {
      id_photo_image = await pdfDoc.embedJpg(arrayBuffer);
    }
    firstPage.drawImage(id_photo_image, {
      x: 492, y: height - 131, width: 72, height: 72
    });
  }

  // BIRTH CERTIFICATE
  if(applicant['birth_cert'] != null) {
    var birth_cert_parts = applicant['birth_cert'].split('.');
    if(birth_cert_parts[birth_cert_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('birth_cert');
    } else {
      const birth_cert_page = await addImage('birth_cert');
      birth_cert_page.drawText('Birth Certificate', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // HIGHSCHOOL
  firstPage.drawText(applicant['highschool'] == null ? 'N/A' : applicant['highschool'], {
    x: 351, y: height - 397, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // HIGHSCHOOL ADDRESS
  if(applicant['highschool_add'] == null) {
    firstPage.drawText('N/A', {
      x: 351, y: height - 407, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
  } else {
    var highschool_add_canvas = document.createElement("canvas");
    var highschool_add_context = highschool_add_canvas.getContext("2d");
    highschool_add_context.font = "regular 6pt helvetica";
    var highschool_add_metrics = highschool_add_context.measureText(applicant['highschool_add']);
    if(highschool_add_metrics.width < 367) {
      firstPage.drawText(applicant['highschool_add'], {
        x: 351, y: height - 407, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    } else {
      var string = applicant['highschool_add'];
      for(var i = string.length; i > 0; i--) {
        if (string[i] == " ") {
          var string_canvas = document.createElement("canvas");
          var string_context = string_canvas.getContext("2d");
          string_context.font = "regular 6pt helvetica";
          var string_metrics = string_context.measureText(applicant['highschool_add'].substring(0, i));
          if(string_metrics.width <= 367) {
            var first_half  = applicant['highschool_add'].substring(0, i);
            var second_half  = applicant['highschool_add'].substring(i + 1, applicant['highschool_add'].length);
            i = 0;
          }
        }
      }
      firstPage.drawText(first_half, {
        x: 351, y: height - 407, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText(second_half, {
        x: 351, y: height - 417, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // HIGHSCHOOL SECTOR
  if(applicant['highschool_sector'] != null) {
    firstPage.drawText('✓', {
      x: applicant['highschool_sector'] == 'Public' ? 125 : 160, y: height - 427.5, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
  }

  // ACADEMIC REQUIREMENTS
  if(applicant['twelve_card'] != null) {
    if(applicant['type'] == 'Graduate') {
      firstPage.drawText('✓', {
        x: 291.5, y: height - 184, size: 6, font: symbols, color: rgb(0, 0, 0)
      });
      firstPage.drawText('✓', {
        x: 312.5, y: height - 769, size: 6, font: symbols, color: rgb(0, 0, 0)
      });
    } else {
      firstPage.drawText('✓', {
        x: 291.5, y: height - 193.5, size: 6, font: symbols, color: rgb(0, 0, 0)
      });
      firstPage.drawText('✓', {
        x: 354.5, y: height - 769, size: 6, font: symbols, color: rgb(0, 0, 0)
      });
    }
  }

  // FUTURE SCHOOL
  if(applicant['institution_id'] != null) {
    firstPage.drawText(applicant['institution']['institution_name'], {
      x: 165, y: height - 559.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['institution']['institution_name'], {
      x: 153, y: height - 821.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });

    firstPage.drawText(applicant['institution']['address'], {
      x: 165, y: height - 569.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['institution']['address'], {
      x: 153, y: height - 831.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });

    firstPage.drawText(applicant['institution']['sector'] == 'P' ? 'Private' : 'Public', {
      x: 165, y: height - 580, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: applicant['institution']['sector'] == 'P' ? 184.5 : 155, y: height - 842.5, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
  } else {
    firstPage.drawText(applicant['hei_out_car_name'], {
      x: 165, y: height - 559.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['hei_out_car_name'], {
      x: 153, y: height - 821.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });

    firstPage.drawText(applicant['hei_out_car_address'], {
      x: 165, y: height - 569.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['hei_out_car_address'], {
      x: 153, y: height - 831.5, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });
    
    firstPage.drawText(applicant['hei_out_car_sector'], {
      x: 165, y: height - 580, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: applicant['hei_out_car_sector'] == 'Private' ? 184.5 : 155, y: height - 842.5, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
  }

  // COURSE
  firstPage.drawText(applicant['course']['course_name'], {
    x: 165, y: height - 589.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  firstPage.drawText(applicant['course']['course_name'], {
    x: 229, y: height - 852, size: 5, font: helvetica, color: rgb(0, 0, 0)
  });
  firstPage.drawText('✓', {
    x: applicant['course']['cmo_2019'] == 'none' ? 186.5 : 155, y: height - 852.5, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // OTHER FINANCIAL ASSISTANCE
  if(applicant['other_fa_agency'] != null) {
    firstPage.drawText('✓', {
      x: 167.5, y: height - 610, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['other_fa_type'], {
      x: 297, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['other_fa_agency'], {
      x: 440, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    if(applicant['other_fa_agency2'] != null) {
      firstPage.drawText(applicant['other_fa_type2'], {
        x: 297, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText(applicant['other_fa_agency2'], {
        x: 440, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    } else {
      firstPage.drawText('N/A', {
        x: 297, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText('N/A', {
        x: 440, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  } else {
    firstPage.drawText('✓', {
      x: 196.5, y: height - 610, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 297, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 440, y: height - 610, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 297, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText('N/A', {
      x: 440, y: height - 620.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
  }

  // GRADE 12 CARD / HIGH SCHOOL REPORT CARD
  if(applicant['twelve_card'] != null) {
    var twelve_card_parts = applicant['twelve_card'].split('.');
    if(twelve_card_parts[twelve_card_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('twelve_card');
    } else {
      const twelve_card_page = await addImage('twelve_card');
      twelve_card_page.drawText(applicant['type'] == 'Graduating' ? 'Certified Grades for 1st Semester of Grade 12' : 'High School Report Card', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // GRADE 11 CARD
  if(applicant['eleven_card'] != null) {
    var eleven_card_parts = applicant['eleven_card'].split('.');
    if(eleven_card_parts[eleven_card_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('eleven_card');
    } else {
      const eleven_card_page = await addImage('eleven_card');
      eleven_card_page.drawText('Certified Grades for Grade 11', {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // F DECEASED
  firstPage.drawText('✓', {
    x: !applicant['f_is_living'] ? 210 : 173, y: height - 458, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // F NAME
  firstPage.drawText(applicant['f_name'] == null ? 'N/A' : applicant['f_name'], {
    x: 127, y: height - 468, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F ADDRESS
  firstPage.drawText(!applicant['f_is_living'] || applicant['f_add'] == null ? 'N/A' : applicant['f_add'], {
    x: 127, y: height - 478, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F CONTACT NUMBER
  firstPage.drawText(!applicant['f_is_living'] || applicant['f_contact_no'] == null ? 'N/A' : applicant['f_contact_no'], {
    x: 127, y: height - 488.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F OCCUPATION
  firstPage.drawText(!applicant['f_is_living'] || applicant['f_occupation'] == null ? 'N/A' : applicant['f_occupation'], {
    x: 127, y: height - 498, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F EMPLOYER
  firstPage.drawText(!applicant['f_is_living'] || applicant['f_employer'] == null ? 'N/A' : applicant['f_employer'], {
    x: 127, y: height - 508.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F EMPLOYER ADDRESS
  firstPage.drawText(!applicant['f_is_living'] || applicant['f_employer_add'] == null ? 'N/A' : applicant['f_employer_add'], {
    x: 127, y: height - 518.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // F EDUCATION
  firstPage.drawText(!applicant['f_is_living'] || applicant['f_education'] == null ? 'N/A' : applicant['f_education'], {
    x: 127, y: height - 529, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M DECEASED
  firstPage.drawText('✓', {
    x: !applicant['m_is_living'] ? 362 : 325, y: height - 458, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // M NAME
  firstPage.drawText(applicant['m_name'] == null ? 'N/A' : applicant['m_name'], {
    x: 279, y: height - 468, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M ADDRESS
  firstPage.drawText(!applicant['m_is_living'] || applicant['m_add'] == null ? 'N/A' : applicant['m_add'], {
    x: 279, y: height - 478, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M CONTACT NUMBER
  firstPage.drawText(!applicant['m_is_living'] || applicant['m_contact_no'] == null ? 'N/A' : applicant['m_contact_no'], {
    x: 279, y: height - 488.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M OCCUPATION
  firstPage.drawText(!applicant['m_is_living'] || applicant['m_occupation'] == null ? 'N/A' : applicant['m_occupation'], {
    x: 279, y: height - 498, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M EMPLOYER
  firstPage.drawText(!applicant['m_is_living'] || applicant['m_employer'] == null ? 'N/A' : applicant['m_employer'], {
    x: 279, y: height - 508.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M EMPLOYER ADDRESS
  firstPage.drawText(!applicant['m_is_living'] || applicant['m_employer_add'] == null ? 'N/A' : applicant['m_employer_add'], {
    x: 279, y: height - 518.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // M EDUCATION
  firstPage.drawText(!applicant['m_is_living'] || applicant['m_education'] == null ? 'N/A' : applicant['m_education'], {
    x: 279, y: height - 529, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G NAME
  firstPage.drawText(applicant['g_name'] != null ? applicant['g_name'] : 'N/A', {
    x: 430, y: height - 468, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G ADDRESS
  firstPage.drawText(applicant['g_add'] != null ? applicant['g_add'] : 'N/A', {
    x: 430, y: height - 478, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G CONTACT NUMBER
  firstPage.drawText(applicant['g_contact_no'] != null ? applicant['g_contact_no'] : 'N/A', {
    x: 430, y: height - 488.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G OCCUPATION
  firstPage.drawText(applicant['g_occupation'] != null ? applicant['g_occupation'] : 'N/A', {
    x: 430, y: height - 498, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G EMPLOYER
  firstPage.drawText(applicant['g_employer'] != null ? applicant['g_employer'] : 'N/A', {
    x: 430, y: height - 508.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G EMPLOYER ADDRESS
  firstPage.drawText(applicant['g_employer_add'] != null ? applicant['g_employer_add'] : 'N/A', {
    x: 430, y: height - 518.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // G EDUCATION
  firstPage.drawText(applicant['g_education'] != null ? applicant['g_education'] : 'N/A', {
    x: 430, y: height - 529, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // ANNUAL GROSS INCOME
  firstPage.drawText('PHP ' + applicant['annual_gross_income'], {
    x: 195, y: height - 539, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // SIBLINGS
  firstPage.drawText('' + applicant['siblings'], {
    x: 195, y: height - 549.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  if(applicant['income_proof'] != null) {
    // INCOME PROOF TYPE
    var y_position1 = 0;
    var x_position2 = 0;
    var y_position2 = 0;
    if(applicant['income_proof_type'] == 'Income Tax Return') {
      y_position1 = 227;
      x_position2 = 312.5;
      y_position2 = 785;
    } else if(applicant['income_proof_type'] == 'Tax Exemption'){
      y_position1 = 236;
      x_position2 = 333.5;
      y_position2 = 785;
    } else if(applicant['income_proof_type'] == 'Certificate of Indigency') {
      y_position1 = 245;
      x_position2 = 382;
      y_position2 = 785;
    } else if(applicant['income_proof_type'] == 'Case Study DSWD') {
      y_position1 = 253.5;
      x_position2 = 312.5;
      y_position2 = 793;
    } else if(applicant['income_proof_type'] == 'OFW Contract') {
      y_position1 = 262;
      x_position2 = 369.5;
      y_position2 = 793;
    }
    firstPage.drawText('✓', {
      x: 291.5, y: height - y_position1, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: x_position2, y: height - y_position2, size: 6, font: symbols, color: rgb(0, 0, 0)
    });

    // INCOME PROOF DOCUMENT
    var income_proof_parts = applicant['income_proof'].split('.');
    if(income_proof_parts[income_proof_parts.length - 1].toLowerCase() == 'pdf') {
      await addPdf('income_proof');
    } else {
      const income_proof_page = await addImage('income_proof');
      income_proof_page.drawText(applicant['income_proof_type'], {
        x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // DSWD 4PS
  firstPage.drawText('✓', {
    x: applicant['is_dswd_4ps'] ? 433 : 462, y: height - 544, size: 6, font: symbols, color: rgb(0, 0, 0)
  });

  // PERMANENT AND PRESENT ADDRESS
  var permanent_address =  applicant['perm_barangay'] + ', ' + applicant['perm_muni_city'] + ', ' + applicant['perm_province'] + ', ' + applicant['perm_district'];
  var permanent_address_canvas = document.createElement("canvas");
  var permanent_address_context = permanent_address_canvas.getContext("2d");
  permanent_address_context.font = "regular 6pt helvetica";
  var permanent_address_metrics = permanent_address_context.measureText(permanent_address);
  if(permanent_address_metrics.width < 367) {
    firstPage.drawText(permanent_address, {
      x: 351, y: height - 366.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    if(applicant['pres_is_perm']) {
      firstPage.drawText(permanent_address, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  } else {
    var string = permanent_address;
    for(var i = string.length; i > 0; i--) {
      if (string[i] == " ") {
        var string_canvas = document.createElement("canvas");
        var string_context = string_canvas.getContext("2d");
        string_context.font = "regular 6pt helvetica";
        var string_metrics = string_context.measureText(permanent_address.substring(0, i));
        if(string_metrics.width <= 367) {
          var first_half  = permanent_address.substring(0, i);
          var second_half  = permanent_address.substring(i + 1, permanent_address.length);
          i = 0;
        }
      }
    }
    firstPage.drawText(first_half, {
      x: 351, y: height - 366.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    firstPage.drawText(second_half, {
      x: 351, y: height - 376.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
    });
    if(applicant['pres_is_perm']) {
      firstPage.drawText(first_half, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText(second_half, {
        x: 351, y: height - 346, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }
  if(!applicant['pres_is_perm']) {
    var present_address = applicant['pres_barangay'] + ', ' + applicant['pres_muni_city'] + ', ' + applicant['pres_province'] + ', ' + applicant['pres_district'];
    var present_address_canvas = document.createElement("canvas");
    var present_address_context = present_address_canvas.getContext("2d");
    present_address_context.font = "regular 6pt helvetica";
    var present_address_metrics = present_address_context.measureText(present_address);
    if(present_address_metrics.width < 367) {
      firstPage.drawText(present_address, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    } else {
      var string = present_address;
      for(var i = string.length; i > 0; i--) {
        if (string[i] == " ") {
          var string_canvas = document.createElement("canvas");
          var string_context = string_canvas.getContext("2d");
          string_context.font = "regular 6pt helvetica";
          var string_metrics = string_context.measureText(present_address.substring(0, i));
          if(string_metrics.width <= 367) {
            var first_half  = present_address.substring(0, i);
            var second_half  = present_address.substring(i + 1, present_address.length);
            i = 0;
          }
        }
      }
      firstPage.drawText(first_half, {
        x: 351, y: height - 336, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
      firstPage.drawText(second_half, {
        x: 351, y: height - 346, size: 6, font: helvetica, color: rgb(0, 0, 0)
      });
    }
  }

  // ZIP CODE
  firstPage.drawText(applicant['perm_zip_code'], {
    x: 351, y: height - 386.5, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  firstPage.drawText(applicant['pres_is_perm'] ? applicant['perm_zip_code'] : applicant['pres_zip_code'], {
    x: 351, y: height - 356, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });

  // IP
  firstPage.drawText(applicant['tribe'] == null ? 'N/A' : applicant['tribe'], {
    x: 351, y: height - 437, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  if(applicant['tribe'] != null) {
    firstPage.drawText('✓', {
      x: 400, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 785, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['tribe'], {
      x: 225, y: height - 783, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });
    if(applicant['cert_indigency'] != null) {
      var cert_indigency_parts = applicant['cert_indigency'].split('.');
      if(cert_indigency_parts[cert_indigency_parts.length - 1].toLowerCase() == 'pdf') {
        await addPdf('cert_indigency');
      } else {
        const cert_indigency_page = await addImage('cert_indigency');
        cert_indigency_page.drawText('Certificate of Indigency', {
          x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
        });
      }
    }
  }

  // PWD
  firstPage.drawText(applicant['disability'] == null ? 'N/A' : applicant['disability'], {
    x: 351, y: height - 427, size: 6, font: helvetica, color: rgb(0, 0, 0)
  });
  if(applicant['disability'] != null) {
    firstPage.drawText('✓', {
      x: 420.5, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 777, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText(applicant['disability'], {
      x: 225, y: height - 775, size: 5, font: helvetica, color: rgb(0, 0, 0)
    });
    if(applicant['pwd_id'] != null) {
      var pwd_id_parts = applicant['pwd_id'].split('.');
      if(pwd_id_parts[pwd_id_parts.length - 1].toLowerCase() == 'pdf') {
        await addPdf('pwd_id');
      } else {
        const pwd_id_page = await addImage('pwd_id');
        pwd_id_page.drawText('PWD ID', {
          x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
        });
      }
    }
  }

  // Solo Parent
  if(applicant['sp_type'] != null) {
    firstPage.drawText('✓', {
      x: 313, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 761, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    if(applicant['sp_id'] != null) {
      var sp_id_parts = applicant['sp_id'].split('.');
      if(sp_id_parts[sp_id_parts.length - 1].toLowerCase() == 'pdf') {
        await addPdf('sp_id');
      } else {
        const sp_id_page = await addImage('sp_id');
        sp_id_page.drawText('Solo Parent ID', {
          x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
        });
      }
    }
  }

  // Senior Citizen
  if(applicant['sc_type'] != null) {
    firstPage.drawText('✓', {
      x: 353, y: height - 809, size: 6, font: symbols, color: rgb(0, 0, 0)
    });
    firstPage.drawText('✓', {
      x: 44.5, y: height - 769, size: 5, font: symbols, color: rgb(0, 0, 0)
    });
    if(applicant['sc_id'] != null) {
      var sc_id_parts = applicant['sc_id'].split('.');
      if(sc_id_parts[sc_id_parts.length - 1].toLowerCase() == 'pdf') {
        await addPdf('sc_id');
      } else {
        const sc_id_page = await addImage('sc_id');
        sc_id_page.drawText('Senior Citizen ID', {
          x: 20, y: 913, size: 8, font: helvetica, color: rgb(0, 0, 0)
        });
      }
    }
  }

  pdfBytes = await pdfDoc.save();
}

// ADD UPLOADED PDF
async function addPdf(input) {
  const arrayBuffer = await fetch(applicant[input]).then(res => res.arrayBuffer());
  const pdf = await PDFDocument.load(arrayBuffer);
  const [page] = await pdfDoc.copyPages(pdf, [0]);
  pdfDoc.addPage(page);
}

// ADD UPLOADED IMAGE
async function addImage(input) {
  const arrayBuffer = await fetch(applicant[input]).then(res => res.arrayBuffer());
  var parts = applicant[input].split('.');
  var image = null;
  if(parts[parts.length - 1].toLowerCase() == 'png') {
    image = await pdfDoc.embedPng(arrayBuffer);
  } else {
    image = await pdfDoc.embedJpg(arrayBuffer);
  }
  const page = pdfDoc.addPage([612, 936]);
  const scaled_image = image.scaleToFit(540, 864);
  page.drawImage(image, {
    x: 36 + ((540 - scaled_image.width) / 2), y: 36 + (864 - scaled_image.height), height: scaled_image.height, width: scaled_image.width
  });
  return page;
}

async function downloadPdf() {
  document.querySelector('#loading').style.display = 'flex';
  if(pdfBytes == null) {
    await createPdf();
  }
  download(pdfBytes, "CHED-CAR - App No. " + applicant['app_no'] + ".pdf", "application/pdf");
  document.querySelector('#loading').style.display = 'none';
}

async function displayPdf() {
  document.querySelector('#loading').style.display = 'flex';
  if($('#display_wrapper').css('display') == 'block') {
    $('#display_wrapper').css('display', 'none');
    $('#display_btn').html('Create & Display PDF');
  } else {
    if(pdfBytes == null) {
      await createPdf();
    }
    $('#display_wrapper').css('display', 'block');
    if(blob_iframe == null) {
      var bytes = new Uint8Array(pdfBytes); 
      var blob = new Blob([bytes], { type: "application/pdf" });
      const docUrl = URL.createObjectURL(blob);
      blob_iframe = document.querySelector('#display_frame');
      blob_iframe.src = docUrl;
    }
    $('#display_btn').html('Close PDF');
  }
  document.querySelector('#loading').style.display = 'none';
}