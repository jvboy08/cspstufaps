const cities_in_abra = ['Bangued', 'Boliney', 'Bucay', 'Bucloc', 'Daguioman', 'Danglas', 'Dolores', 'La Paz', 'Lacub', 'Lagangilang', 'Lagayan', 'Langiden', 'Licuan-Baay', 'Luba', 'Malibcong', 'Manabo', 'Penarrubia', 'Pidigan', 'Pilar', 'Sallapadan', 'San Isidro', 'San Juan', 'San Quintin', 'Tayum', 'Tineg', 'Tubo', 'Villaviciosa'];
const cities_in_apayao = ['Calanasan (Bayag)', 'Conner', 'Flora', 'Kabugao', 'Luna', 'Pudtol', 'Sta. Marcela'];
const cities_in_benguet = ['Atok', 'Baguio City', 'Bakun', 'Bokod', 'Buguias', 'Itogon', 'Kabayan', 'Kapangan', 'Kibungan', 'La Trinidad', 'Lepanto, Mankayan', 'Mankayan', 'Philippine Military Academy, Baguio', 'Sablan', 'Tuba', 'Tublay'];
const cities_in_ifugao = ['Aguinaldo', 'Alista', 'Asipulo', 'Banaue', 'Hingyon', 'Hungduan', 'Kiangan', 'Lagawe', 'Lamut', 'Mayoyao', 'Tinoc'];
const cities_in_kalinga = ['Balbalan', 'Lubuagan', 'Pasil', 'Pinukpuk', 'Rizal', 'Tabuk City', 'Tanudan', 'Tinglayan'];
const cities_in_mountain_province = ['Barlig', 'Bauko', 'Besao', 'Bontoc', 'Natonin', 'Paracelis', 'Sabangan', 'Sadanga', 'Sagada', 'Tadian'];

function changeCities(default_city, province_id, city_id) {
	const city_select = document.querySelector(city_id);
	city_select.disabled = false;
	const province_select = document.querySelector(province_id).value;
	const length = city_select.options.length;
	for (i = length - 1; i >= 0; i--) {
	  city_select.options[i] = null;
	}

	let cities = new Array();
	if(province_select == 'Abra') {
		cities = [...cities_in_abra];
	} else if(province_select == 'Apayao') {
		cities = [...cities_in_apayao];
	} else if(province_select == 'Benguet') {
		cities = [...cities_in_benguet];
	} else if(province_select == 'Ifugao') {
		cities = [...cities_in_ifugao];
	} else if(province_select == 'Kalinga') {
		cities = [...cities_in_kalinga];
	} else if(province_select == 'Mountain Province') {
		cities = [...cities_in_mountain_province];
	}

	cities.forEach(city => {
	    const opt = document.createElement('option');
	    opt.value = city;
	    opt.innerHTML = city;
	    if(city == default_city) {
	    	opt.selected = true;
	    }
	    city_select.appendChild(opt);
	});
}

function show(num) {
	document.querySelector("#info" + num).style.display = "flex";
}

function hide(num) {
	document.querySelector("#info" + num).style.display = "none";
}

var clicked = 0;

function highlight(num) {
	if(clicked != 0) {
		var tr_previous = document.querySelector(".row" + clicked);
		var children_previous = tr_previous.getElementsByTagName("*");
		for (i = 0; i < children_previous.length; i++) {
			children_previous[i].style.background = '#F5F5F5';
		}
	}
	var tr = document.querySelector(".row" + num);
	var children = tr.getElementsByTagName("*");
	for (i = 0; i < children.length; i++) {
		children[i].style.background = '#E1E1E1';
	}
	clicked = num;
}

function exportTableToExcel(tableID, filename = ''){
    var downloadLink;
    var dataType = 'application/vnd.ms-excel';
    var tableSelect = document.getElementById(tableID);
    var tableHTML = tableSelect.outerHTML.replace(/ /g, '%20');
    
    filename = filename ? filename + '.xls' : 'excel_data.xls';
    
    downloadLink = document.createElement("a");
    
    document.body.appendChild(downloadLink);
    
    if(navigator.msSaveOrOpenBlob){
        var blob = new Blob(['\ufeff', tableHTML], {
            type: dataType
        });
        navigator.msSaveOrOpenBlob(blob, filename);
    }else{
        downloadLink.href = 'data:' + dataType + ', ' + tableHTML;
        downloadLink.download = filename;
        downloadLink.click();
    }
}